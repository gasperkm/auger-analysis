#include "RdPlots.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserConfig.h"

#include "RecEvent.h"
#include "RdRecStation.h"
#include "RdRecChannel.h"
#include "Detector.h"
#include "DetectorGeometry.h"

#include "Detector.h"
#include "RdEvent.h"
#include "ArrayPlot.h"
#include "StyleManager.h"

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TF2.h>
#include <TH1F.h>
#include <TH2F.h>
#include <TClass.h>
#include <TLegend.h>
#include <TLegendEntry.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TLatex.h>
#include <TGSlider.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TMarker.h>
#include <TTimeStamp.h>
#include <TText.h>
#include <TColor.h>
#include <TGDoubleSlider.h>
#include <TBox.h>
#include <TStyle.h>
#include <TPaletteAxis.h>
#include <TROOT.h>
#include <TGraphPainter.h>

#include <algorithm>
#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <iomanip>

#include <ShowerRRecDataQuantities.h>

using namespace std;

ClassImp(RdPlots);
#define round(x) (x<0? ceil( (x)-0.5 ) : floor( (x)+0.5 ))

RdPlots::RdPlots(TGCompositeFrame* main,
                 const StyleManager*const * styleManager,
                 const DetectorGeometry*const * geom,
                 const RecEvent*const * event, const bool& isMC) :
  fStyleManager(styleManager),
  fEvent(event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fShowFD(false),
  fShowMC(false),  // Not Ready to show MC informafion the MC is not written yet
  fShowAllTraces(true),
  fRdArrayOnStatus(true),
  fHasStationTraces(false),
  fHasRdChannelTraces(false),
  fShowMCTraces(false),
  fDrawChannel(false),
  fDrawTriggerWindow(false),
  fDrawNoiseWindow(false),
  fDrawPeakLine(false),
  fDrawVertPolarization(false),
  fDrawEastPolarization(true),
  fDrawNorthPolarization(true),
  fDrawVxBPolarization(false),
  fDrawVxVxBPolarization(false),
  fDrawVPolarization(false),
  fDrawResAxis(true),
  fDrawSdAxis(false),
  fCurrentStation(0)

{
  fSdLDFOnStatus = true;
  fPMTObjects = new TObjArray();
  fPMTObjects->SetOwner(kTRUE);
  fEventObjects = new TObjArray();
  fEventObjects->SetOwner(kTRUE);
  fPlotsObjects = new TObjArray();
  fPlotsObjects->SetOwner(kTRUE);

  fTracesObjects = new TObjArray();
  fTracesObjects->SetOwner(kTRUE);

  fMain = main;
  fMain->SetCleanup(kDeepCleanup);

  double width = main->GetWidth();
  double height = main->GetHeight();

  TGLayoutHints* mainHorizontalLayout = new TGLayoutHints(kLHintsExpandX, 3, 3, 3, 3);

  TGHorizontalFrame* mainHorizontal1 = new TGHorizontalFrame(main, UInt_t(width), UInt_t(0.55 * height));
//  TGHorizontalFrame* mainHorizontal1bis = new TGHorizontalFrame(main, UInt_t(width)*0.5, UInt_t(0.55*height));
  TGHorizontalFrame* mainHorizontal2 = new TGHorizontalFrame(main, UInt_t(width), UInt_t(0.45 * height));

  main->AddFrame(mainHorizontal1, mainHorizontalLayout);
//  main->AddFrame(mainHorizontal1bis,new TGLayoutHints());
  main->AddFrame(mainHorizontal2, mainHorizontalLayout);

  //*************** FIRST HORIZONTAL FRAME ******/
  TGVerticalFrame* vertical1 = new TGVerticalFrame(mainHorizontal1, UInt_t(0.2 * width), UInt_t(0.55 * height));
  //*************** FIRST VERTICAL FRAME ********/

  // event info
  fRdEventInfoTab = new TGTab(vertical1, UInt_t(0.2 * width), UInt_t(0.4 * height));
  TGCompositeFrame *eventInfoFrame = fRdEventInfoTab->AddTab("Event Info");
  TGHorizontalFrame *horizFrameInfo = new TGHorizontalFrame(eventInfoFrame, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas *canvasInfoEmb = new TRootEmbeddedCanvas("canvasInfoEmb", horizFrameInfo, UInt_t(0.23 * width),
      UInt_t(0.4 * height));
  fCanvasInfo = canvasInfoEmb->GetCanvas();
// MC Info
  TGCompositeFrame *MCInfoFrame = fRdEventInfoTab->AddTab("MC Info");
  TGHorizontalFrame *horizFrameMC = new TGHorizontalFrame(MCInfoFrame, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas *canMCInfoEmb = new TRootEmbeddedCanvas("MCInfoEmb", horizFrameMC, UInt_t(0.23 * width),
      UInt_t(0.4 * height));
  fCanvasMCInfo = canMCInfoEmb->GetCanvas();
// LDF info
  TGCompositeFrame *LDFInfoFrame = fRdEventInfoTab->AddTab("LDF Info");
  TGHorizontalFrame *horizFrameLDFinfo = new TGHorizontalFrame(LDFInfoFrame, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas *canLDFInfoEmb = new TRootEmbeddedCanvas("LDFInfoEmb", horizFrameLDFinfo, UInt_t(0.23 * width),
      UInt_t(0.4 * height));
  canLDFInfoEmb->SetScrolling(TGCanvas::kCanvasScrollBoth);
  fCanvasLDFInfo = canLDFInfoEmb->GetCanvas();

// Zoom

  TGVButtonGroup* arrayButtons = new TGVButtonGroup(vertical1, "");
  fArrayZoomButton = new TGHSlider(arrayButtons, 190, kSlider2 | kScaleBoth, eSDZoomToCore);
  fArrayZoomButton->Connect("Pressed()", "RdPlots", this, "DoRdPressed()");
  fArrayZoomButton->Connect("Released()", "RdPlots", this, "DoRdReleased()");
  fArrayZoomButton->SetRange(0, 1000);
  fArrayZoomButton->SetPosition(940);

  //*************** SECOND VERTICAL FRAME *****************************************/

  TGVerticalFrame* vertical2 = new TGVerticalFrame(mainHorizontal1, UInt_t(0.4 * width), UInt_t(0.55 * height));
  
  // Station Tab
  fRdStationTab = new TGTab(vertical2, UInt_t(0.4 * width), UInt_t(0.5 * height));
  
  // StationList
  TGCompositeFrame *stationListFrame = fRdStationTab->AddTab("Station List");
  fStationsListBox = new TGListBox(stationListFrame, 89);
  fStationsListBox->Connect("Selected(Int_t)", "RdPlots", this, "SelectStation()");
  fStationsListBox->Resize(UInt_t(0.4 * width), UInt_t(0.25 * height));
  
  // StationInfo
  TRootEmbeddedCanvas* canvasStationInfoemb = new TRootEmbeddedCanvas("canvasStationInfoemb", stationListFrame, UInt_t(0.4 * width), UInt_t(0.25 * height));
  fCanvasStationInfo = canvasStationInfoemb->GetCanvas();
  fCanvasStationInfo->SetBottomMargin(0.14);
  fCanvasStationInfo->SetTopMargin(0.06);

  // Options Tab
  TGCompositeFrame *optionsFrame = fRdStationTab->AddTab("Options");
  TGVerticalFrame *vertFrameOption = new TGVerticalFrame(optionsFrame, UInt_t(0.4 * width), UInt_t(0.5 * height));
  
  // Buttons to enable drawing of signal/noise windows, peak line and the traces for different polarizations
  TGHButtonGroup* RdDrawingButtons1 = new TGHButtonGroup(vertFrameOption, "Trace Drawing Options");
  TGHButtonGroup* RdDrawingButtons2 = new TGHButtonGroup(vertFrameOption, "Polarization Drawing Options");

  fRdTriggerWindowButton = new TGCheckButton(RdDrawingButtons1, new TGHotString("Signal window"), eRdTriggerWindow);
  fRdNoiseWindowButton = new TGCheckButton(RdDrawingButtons1, new TGHotString("Noise window"), eRdNoiseWindow);
  fRdPeakLineButton = new TGCheckButton(RdDrawingButtons1, new TGHotString("Peak line"), eRDPeakLine);
  fRdEastPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("East pol."), eRdEastPolarization);
  fRdNorthPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("North pol."), eRdNorthPolarization);
  fRdVertPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("Vertical pol."), eRdVertPolarization);
  fRdVxBPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("VxB pol."), eRdVxBPolarization);
  fRdVxVxBPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("VxVxB pol."), eRdVxVxBPolarization);
  fRdVPolarizationButton = new TGCheckButton(RdDrawingButtons2, new TGHotString("V pol."), eRdVPolarization);

  fRdEastPolarizationButton->SetState(kButtonDown);
  fRdNorthPolarizationButton->SetState(kButtonDown);

  fRdTriggerWindowButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdNoiseWindowButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdPeakLineButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdVertPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdEastPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdNorthPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdVxBPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdVxVxBPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdVPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  
  //Buttons to select if station or channel traces are drawn
  TGHButtonGroup *TraceButtons = new TGHButtonGroup(vertFrameOption, "Trace Drawing Level");
  fStationButton = new TGRadioButton(TraceButtons, "Station  ", eRDStation);
  fChannelButton = new TGRadioButton(TraceButtons, "Channel  ", eRDChannel);
  fStationButton->SetToolTipText("Draw trace and spectrum at the station level");
  fChannelButton->SetToolTipText("Draw trace and spectrum at the channel level");
  fStationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fChannelButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  
  // Buttons to select how the residuals are plotted
  TGHButtonGroup* ResidualButtons = new TGHButtonGroup(vertFrameOption, "Residuals");
  fResAxisButton = new TGRadioButton(ResidualButtons, new TGHotString("Shower axis"),eResAxis);
  fResStationButton = new TGRadioButton(ResidualButtons, new TGHotString("Station Id"),eResStation);
  fResAxisButton->SetToolTipText("Plot residuals as function of shower axis");
  fResStationButton->SetToolTipText("Plot residuals as function of station number");
  fResAxisButton->SetState(kButtonDown);
  fResAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fResStationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");

  // Buttons to select which shower axis is used
  TGHButtonGroup* AxisButtons = new TGHButtonGroup(vertFrameOption, "LDF / Residuals Shower Axis");
  fRadioAxisButton = new TGRadioButton(AxisButtons, new TGHotString("Radio"),eRadioAxis);
  fSdAxisButton = new TGRadioButton(AxisButtons, new TGHotString("Sd"),eSdAxis);
  fMCAxisButton = new TGRadioButton(AxisButtons, new TGHotString("MC"),eMCAxis);
  fRadioAxisButton->SetToolTipText("Plot LDF and residuals with radio axis");
  fSdAxisButton->SetToolTipText("Plot LDF and residuals with Sd axis");
  fMCAxisButton->SetToolTipText("Plot LDF and residuals with MC axis");
  fRadioAxisButton->SetState(kButtonDown);
  fRadioAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fSdAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fMCAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  
  //*************** THIRD VERTICAL FRAME *****************************************/
  fRdGeoTab = new TGTab(mainHorizontal1, UInt_t(0.45 * width), UInt_t(0.5 * height));
  TGCompositeFrame *Arrayframe = fRdGeoTab->AddTab("Array");
  TGHorizontalFrame *horizframeArray = new TGHorizontalFrame(Arrayframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasArrayEmb = new TRootEmbeddedCanvas("canvasArrayEmb", horizframeArray, UInt_t(0.45 * width),
      UInt_t(0.65 * height));

  fCanvasArray = canvasArrayEmb->GetCanvas();

  fCanvasArray->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "RdPlots", this,
      "HandleArrayClicked(Int_t,Int_t,Int_t,TObject*)");
  fCanvasArray->SetBottomMargin(0.14);
  fCanvasArray->SetTopMargin(0.06);
  fCanvasArray->GetCanvas()->SetEditable(false);
  fArrayPlot = new ArrayPlot(fEvent, fDetectorGeometry, fStyleManager, fArrayZoomButton, fCanvasArray);
  fArrayPlot->SetSDColorStatus(fSdColorStatus);
  fArrayPlot->SetRadioOn();
  fArrayPlot->SetSDColorStatus(eSDGroundTimeColors);
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  fArrayZoomButton->Connect("PositionChanged(Int_t)", "ArrayPlot", fArrayPlot, "DoSdZoom(Int_t)");

  // TwoDLDF Plot
  TGCompositeFrame *TwoDLDFframe = fRdGeoTab->AddTab("2D-LDF");
  TGHorizontalFrame *horizFrameTwoDLDF = new TGHorizontalFrame(TwoDLDFframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasTwoDLDFEmb = new TRootEmbeddedCanvas("canvasTwoDLDFEmb", horizFrameTwoDLDF, UInt_t(0.45 * width),
      UInt_t(0.65 * height));
  fCanvasTwoDLDF = canvasTwoDLDFEmb->GetCanvas();
  fCanvasTwoDLDF->SetBottomMargin(0.14);
  fCanvasTwoDLDF->SetTopMargin(0.06);

  TGCompositeFrame *LDFframe = fRdGeoTab->AddTab("LDF");
  TGHorizontalFrame *horizFrameLDF = new TGHorizontalFrame(LDFframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasLDFEmb = new TRootEmbeddedCanvas("canvasLDFEmb", horizFrameLDF, UInt_t(0.45 * width),
      UInt_t(0.65 * height));
  fCanvasLDF = canvasLDFEmb->GetCanvas();
  fCanvasLDF->SetBottomMargin(0.14);
  fCanvasLDF->SetTopMargin(0.06);

  TGCompositeFrame *Residualsframe = fRdGeoTab->AddTab("Residuals");
  TGHorizontalFrame *horizFrameResiduals = new TGHorizontalFrame(Residualsframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasResidualsEmb = new TRootEmbeddedCanvas("canvasResidualsEmb", horizFrameResiduals,
      UInt_t(0.45 * width), UInt_t(0.65 * height));
  fCanvasResiduals = canvasResidualsEmb->GetCanvas();
  fCanvasResiduals->SetBottomMargin(0.14);
  fCanvasResiduals->SetTopMargin(0.06);

  //  Angle Plot
  TGCompositeFrame *Lorentzframe = fRdGeoTab->AddTab("Lorentz Angle");
  TGHorizontalFrame *horizFrameLorentz = new TGHorizontalFrame(Lorentzframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasLorentzEmb = new TRootEmbeddedCanvas("canvasLorentzEmb", horizFrameLorentz, UInt_t(0.45 * width),
      UInt_t(0.65 * height));
  fCanvasLorentz = canvasLorentzEmb->GetCanvas();
  fCanvasLorentz->SetBottomMargin(0.14);
  fCanvasLorentz->SetTopMargin(0.06);  
  



  // *************** SECOND HORIZONTAL FRAME *****************************************/
  fRdEventTab = new TGTab(mainHorizontal2, UInt_t(width), UInt_t(0.50 * height));

  //*****************   Traces TABs  ******************************************************/
  TGCompositeFrame *TraceFrame = fRdEventTab->AddTab("Traces ");
  TRootEmbeddedCanvas *canvasTraceemb = new TRootEmbeddedCanvas("canvasTraceemb", TraceFrame, UInt_t(0.98 * width),
      UInt_t(0.48 * height));
  fCanvasTrace = canvasTraceemb->GetCanvas();

  TGCompositeFrame *SpectrFrame = fRdEventTab->AddTab("Spectrum ");
  TRootEmbeddedCanvas *canvasSpectrumemb = new TRootEmbeddedCanvas("canvasSpectrumemb", SpectrFrame, UInt_t(0.98 * width),
      UInt_t(0.48 * height));
  fCanvasSpectrum = canvasSpectrumemb->GetCanvas();

  TGCompositeFrame *FieldFrame = fRdEventTab->AddTab("2D-Field");
  TRootEmbeddedCanvas *canvasFieldemb = new TRootEmbeddedCanvas("canvasFieldemb", FieldFrame, UInt_t(0.98 * width),
      UInt_t(0.48 * height));
  fCanvasField = canvasFieldemb->GetCanvas();

  TGCompositeFrame *ScintillatorFrame = fRdEventTab->AddTab("Scintillators");
  TRootEmbeddedCanvas *canvasScintemb = new TRootEmbeddedCanvas("canvasScintemb", ScintillatorFrame, UInt_t(0.98 * width),
      UInt_t(0.48 * height));
  fCanvasScint = canvasScintemb->GetCanvas();


  fCanvasSpectrum->SetBottomMargin(0.14);
  fCanvasSpectrum->SetTopMargin(0.14);
  fCanvasTrace->SetBottomMargin(0.14);
  fCanvasTrace->SetTopMargin(0.14);
  fCanvasField->SetBottomMargin(0.14);
  fCanvasField->SetTopMargin(0.14);
  fCanvasScint->SetBottomMargin(0.14);
  fCanvasScint->SetTopMargin(0.14);


  // ********************

  mainHorizontal1->AddFrame(vertical1, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  mainHorizontal1->AddFrame(vertical2, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  mainHorizontal1->AddFrame(fRdGeoTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  //mainHorizontal1->AddFrame(canvasArrayEmb, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
  mainHorizontal2->AddFrame(fRdEventTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  
  vertical1->AddFrame(fRdEventInfoTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));  
  vertical1->AddFrame(arrayButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 3, 3, 3, 3));

  eventInfoFrame->AddFrame(horizFrameInfo, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameInfo->AddFrame(canvasInfoEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  MCInfoFrame->AddFrame(horizFrameMC, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameMC->AddFrame(canMCInfoEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  LDFInfoFrame->AddFrame(horizFrameLDFinfo, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameLDFinfo->AddFrame(canLDFInfoEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  arrayButtons->AddFrame(fArrayZoomButton, new TGLayoutHints(kLHintsBottom | kLHintsCenterY, 3, 3, 3, 3));  
  
  vertical2->AddFrame(fRdStationTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3)); 
  
  stationListFrame->AddFrame(fStationsListBox, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  stationListFrame->AddFrame(canvasStationInfoemb, new TGLayoutHints(kLHintsBottom | kLHintsCenterY, 3, 3, 3, 3));
  
  optionsFrame->AddFrame(vertFrameOption, new TGLayoutHints(kLHintsLeft | kLHintsTop, 3, 3, 3, 3));
  
  vertFrameOption->AddFrame(TraceButtons, new TGLayoutHints(kLHintsLeft, 3, 3, 3, 3));
  vertFrameOption->AddFrame(RdDrawingButtons1, new TGLayoutHints(kLHintsLeft, 3, 3, 3, 3));
  vertFrameOption->AddFrame(RdDrawingButtons2, new TGLayoutHints(kLHintsLeft, 3, 3, 3, 3));
  vertFrameOption->AddFrame(AxisButtons, new TGLayoutHints(kLHintsLeft, 3, 3, 3, 3));
  vertFrameOption->AddFrame(ResidualButtons, new TGLayoutHints(kLHintsLeft, 3, 3, 3, 3));

  Arrayframe->AddFrame(horizframeArray, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizframeArray->AddFrame(canvasArrayEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  TwoDLDFframe->AddFrame(horizFrameTwoDLDF, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameTwoDLDF->AddFrame(canvasTwoDLDFEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  LDFframe->AddFrame(horizFrameLDF, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameLDF->AddFrame(canvasLDFEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  Residualsframe->AddFrame(horizFrameResiduals, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameResiduals->AddFrame(canvasResidualsEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  Lorentzframe->AddFrame(horizFrameLorentz, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameLorentz->AddFrame(canvasLorentzEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  TraceFrame->AddFrame(canvasTraceemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  SpectrFrame->AddFrame(canvasSpectrumemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  FieldFrame->AddFrame(canvasFieldemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  ScintillatorFrame->AddFrame(canvasScintemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  fRdEventTab->SetEnabled(0, fHasStationTraces);
  fRdEventTab->SetEnabled(1, fHasStationTraces);
  fRdEventTab->SetEnabled(2, fHasStationTraces);
//  fRdEventTab->SetEnabled(3, fHasRStations);

}

RdPlots::~RdPlots()
{
  fEventObjects->Delete();
  fPMTObjects->Delete();
  fPlotsObjects->Delete();
  delete fEventObjects;
  delete fPMTObjects;
  delete fPlotsObjects;

  fMain->Cleanup();

}

void RdPlots::Clear()
{
  fPMTObjects->Delete();
  fPlotsObjects->Delete();
  fEventObjects->Delete();
  fTracesObjects->Delete();
  fCanvasInfo->Clear();
  fCanvasInfo->Update();
}

void RdPlots::Update()
{
  fEventObjects->Delete();

  bool HasAxis=true;
  if((*fEvent)->GetSDEvent().GetRecLevel()<eHasSdAxis &&
     !(*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage) && !fIsMC)
      HasAxis=false;

  fHasRStations = (*fEvent)->GetRdEvent().HasRdStations();
  fRdEventTab->SetEnabled(0, fHasStationTraces);
  fRdEventTab->SetEnabled(1, fHasStationTraces);
  fRdEventTab->SetEnabled(2, fHasStationTraces);
  fRdEventTab->SetEnabled(3, false);
  fRdEventInfoTab->SetEnabled(0, true);
  fStationButton->SetEnabled(fHasStationTraces);
  if(!fDrawChannel) {
    fChannelButton->SetState(kButtonUp);
    fStationButton->SetState(kButtonDown);
  }
  fChannelButton->SetEnabled(fHasRdChannelTraces);
  if(fDrawChannel) {
    fRdEventTab->SetEnabled(2, false);
    fChannelButton->SetState(kButtonDown);
    fStationButton->SetState(kButtonUp);
  }
  fRdGeoTab->SetEnabled(1, HasAxis);
  if ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage))
    fRdGeoTab->SetEnabled(2, true);
  else
    fRdGeoTab->SetEnabled(2, false);
  RdEventInfo(fCanvasInfo);
  if(fIsMC) {
    RdMCInfo(fCanvasMCInfo);
    fRdEventInfoTab->SetEnabled(1, true);
    if (!(*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage))
      fDrawMCAxis=true;
  }
  else
    fRdEventInfoTab->SetEnabled(1, false);
  RdLDFInfo(fCanvasLDFInfo);
  if(!(*fEvent)->GetRdEvent().GetRdRecShower().GetRdLDF().size()) {
    fRdEventInfoTab->SetEnabled(2, false);
  }
  else
    fRdEventInfoTab->SetEnabled(2, true);
  if(!((*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis)) {
    fSdAxisButton->SetState(kButtonUp);
    fRadioAxisButton->SetState(kButtonDown);
    fDrawSdAxis = false;
  }
  if((*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis &&
      !(*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage)) {
    fSdAxisButton->SetState(kButtonDown);
    fRadioAxisButton->SetState(kButtonUp);
    fDrawSdAxis = true;
  }
  fSdAxisButton->SetEnabled((*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis);
  if(fDrawSdAxis == true) {
    fSdAxisButton->SetState(kButtonDown);
    fRadioAxisButton->SetState(kButtonUp);
  }
  if(!fIsMC) {
    fMCAxisButton->SetState(kButtonUp);
    fDrawMCAxis = false;
  }
  fMCAxisButton->SetEnabled(fIsMC);
  if(fDrawMCAxis == true) {
    fMCAxisButton->SetState(kButtonDown);
    fRadioAxisButton->SetState(kButtonUp);
  }
  fRadioAxisButton->SetEnabled((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage));

  if(fRdArrayOnStatus) {
    fRdArrayOnStatus = true;
    fArrayPlot->Clear(); // Should reset the zoom
    fArrayPlot->GetMaxAndMinTime();
    UpdateArrayPlot();
  }
  
  //  fRdEventTab->SetTab(0);
  //DrawTimeResiduals();
  UpdateStationsList();
  SelectStation();
  
}

void RdPlots::DoRdReleased()
{
  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eSDZoomToCore:
    fRdArrayOnStatus = true;
    UpdateArrayPlot();
    break;

  default:
    break;
  }
}

void RdPlots::DoRdPressed()
{
  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eSDZoomToCore:
    fRdArrayOnStatus = true;
    break;
  default:
    break;
  }
}
void RdPlots::UpdateStationsList()
{

#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0,maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
#endif

  // get a copy so that we can re-sort the entries
  std::vector<RdRecStation> stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  sort(stations.begin(), stations.end(), RdRecStation::SignalStationsFirst);

  unsigned int firstId = 0;
  unsigned int lastId = 0;

  ostringstream name;
  for(unsigned int iS = 0; iS < stations.size(); ++iS) {

    name.str("");
    int stationId = stations[iS].GetId();
    name << (*fDetectorGeometry)->GetRdStationName(stationId) << "  ";
//    name << stations[iS].GetStationTriggerName(fRecStationClassVersion)<< " ";
    if(stations[iS].HasParameter(revt::eSignalToNoise) && stations[iS].HasParameter(revt::eSignal)) {
      // *1e6 to convert unit to muV/m
      name << round(stations[iS].GetParameter(revt::eSignal)*10.*1e6) / 10.;
      if(stations[iS].HasParameterError(revt::eSignal)) {
        name << "+/-" << round(stations[iS].GetParameterError(revt::eSignal)*10.*1e6) / 10.;
      }
      name  << " muV/m";
      if(stations[iS].HasParameter(revt::eSignalEnergyFluenceMag)) {
        name << "  " << round(stations[iS].GetParameter(revt::eSignalEnergyFluenceMag)*10.) / 10.;
        name <<"+/-";
        name << round(stations[iS].GetParameterError(revt::eSignalEnergyFluenceMag)*10.) / 10.;
        name << " eV/m^2";
      }
      if(stations[iS].HasParameter(revt::eSignalToNoise)) {
        name << "  SNR=" << round(stations[iS].GetParameter(revt::eSignalToNoise)*10.) / 10.;
      }
    } else {
      name << "no reconstructed Signal";
    }
    if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage) ||
       (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis || fIsMC) {
      TVector3 axis;
      TVector3 core;
      if(fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) {
        axis = (*fEvent)->GetSDEvent().GetSdRecShower().GetAxisSiteCS();
        core = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS();
      } else if(fDrawMCAxis && fIsMC) {
        axis = (*fEvent)->GetGenShower().GetAxisSiteCS();
        core = (*fEvent)->GetGenShower().GetCoreSiteCS();
      } else if ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage)) {
        axis = (*fEvent)->GetRdEvent().GetRdRecShower().GetAxisSiteCS();
        core = (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
      }
      //double axisdist=(*fDetectorGeometry)->GetStationAxisDistance(stiter->GetId(),axis,core); // This should work To be checked !!
      double axisdist = (*fDetectorGeometry)->GetStationAxisDistance((*fDetectorGeometry)->GetRdStationPosition(stationId), axis, core);
      name << "  d=" << axisdist << " m";
    }

    // select first non-rejected station with pulse
    if(stations[iS].HasPulse() && !stations[iS].IsRejected() && firstId == 0) {
      firstId = stations[iS].GetId();
      lastId = 0;
    }
    // if no pulse in any station, select first station in list
    else if (iS==stations.size()-1 && firstId==0) {
      firstId = stations[0].GetId();
    }
    fStationsListBox->InsertEntry(name.str().c_str(), stationId, lastId);
    if (stations[iS].IsRejected()) {
      fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::RGB2Pixel(255,128,128));
    } else if (stations[iS].IsSaturated()) {
      fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::RGB2Pixel(255,235,0));
    } else if(!stations[iS].HasPulse()) {
      fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(17));
    }
    lastId = stations[iS].GetId();
  }

  /*  for ( unsigned int iS=0;iS<stations.size();++iS) {
   name <<  stations[iS].GetId() << " ";

   name <<  stations[iS].GetStationTriggerName(fRecStationClassVersion) << " ";
   name <<  round(stations[iS].GetTotalSignal()*10.)/10.;
   int stationId= stations[iS].GetId();
   fStationsListBox->AddEntry(name.str().c_str(), stationId);
   //  fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(18));
   ++n;
   }
   */
  fStationsListBox->MapSubwindows();
  fStationsListBox->Layout();
  fStationsListBox->Select(firstId);
  UpdateTabPlots();
  if(fHasStationTraces) {
    UpdateTraceTabPlots(0);
  }
}

void RdPlots::SelectStation()
{
  unsigned int stationNumber = fStationsListBox->GetSelected();
  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  for(unsigned int iS = 0; iS < stations.size(); ++iS)
    if((stations[iS].GetId()) == (unsigned int) fStationsListBox->GetSelected())
      stationNumber = iS;
  fCurrentStation = stationNumber;

  if(fHasStationTraces) {
    UpdateTraceTabPlots(stationNumber);
  }
  UpdateArrayPlot();
  fArrayPlot->DrawSelectedRStationMarker(stationNumber);
  RdStationInfo(fCanvasStationInfo);
}

void RdPlots::DoRdButton()
{
  if(!*fEvent)
    return;

  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eRDChannel:
    fDrawChannel = true;
    fRdEventTab->SetEnabled(2, false);
    fRdEventTab->SetEnabled(3, true);
    UpdateTraceTabPlots(fCurrentStation); // To be improved to keep the same station selected
    break;
  case eRDStation:
    fDrawChannel = false;
    fRdEventTab->SetEnabled(2, fHasStationTraces);
    fRdEventTab->SetEnabled(3, false);
    UpdateTraceTabPlots(fCurrentStation); // To be improved to keep the same station selected
    break;
  case eRdTriggerWindow:
    fDrawTriggerWindow = fRdTriggerWindowButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdNoiseWindow:
    fDrawNoiseWindow = fRdNoiseWindowButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRDPeakLine:
    fDrawPeakLine = fRdPeakLineButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdVertPolarization:
    fDrawVertPolarization = fRdVertPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdEastPolarization:
    fDrawEastPolarization = fRdEastPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdNorthPolarization:
    fDrawNorthPolarization = fRdNorthPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdVxBPolarization:
      fDrawVxBPolarization = fRdVxBPolarizationButton->IsDown();
      UpdateTraceTabPlots(fCurrentStation);
      break;
  case eRdVxVxBPolarization:
    fDrawVxVxBPolarization = fRdVxVxBPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdVPolarization:
    fDrawVPolarization = fRdVPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eResAxis:
    fDrawResAxis = true;
    UpdateTabPlots();
    break;
  case eResStation:
    fDrawResAxis = false;
    UpdateTabPlots();
    break;
  case eRadioAxis:
    fDrawSdAxis = false;
    fDrawMCAxis = false;
    UpdateTabPlots();
    break;
  case eSdAxis:
    fDrawSdAxis = true;
    fDrawMCAxis = false;
    UpdateTabPlots();
    break;
  case eMCAxis:
    fDrawMCAxis = true;
    fDrawSdAxis = false;
    UpdateTabPlots();
    break;
  default:
    break;
  }

}

void RdPlots::UpdateTraceTabPlots(unsigned int stNumber)
{
  fPMTObjects->Delete();
  if(!(*fEvent)->GetRdEvent().HasRdStations()) {
    cout << "WARNING: Event has no Radio Stations" << endl;
    return;
  }
  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  if(stNumber > stations.size())
    return;
  fCanvasTrace->Clear();
  fCanvasSpectrum->Clear();
  fCanvasField->Clear();
  fCanvasScint->Clear();
  const RdRecStation& recStation = stations[stNumber];
  fCanvasSpectrum->SetRightMargin(0.261663);
  fCanvasTrace->SetRightMargin(0.261663);
  fCanvasField->SetRightMargin(0.50);
  fCanvasScint->SetRightMargin(0.261663);
  if(!fDrawChannel) {
    DrawAllTraces(recStation);
    DrawSpectrum(recStation);
    Draw2DField(recStation);
  } else if(fHasRdChannelTraces) {
    DrawChannelTraces(recStation);
    DrawChannelSpectrum(recStation);
    DrawScintillators(recStation);
  }
  fCanvasTrace->GetCanvas()->Modified();
  fCanvasTrace->GetCanvas()->Update();
  fCanvasSpectrum->GetCanvas()->Modified();
  fCanvasSpectrum->GetCanvas()->Update();
  fCanvasField->GetCanvas()->Modified();
  fCanvasField->GetCanvas()->Update();
  fCanvasScint->GetCanvas()->Modified();
  fCanvasScint->GetCanvas()->Update();
}

void RdPlots::UpdateTabPlots()
{
  fPlotsObjects->Delete();
  if(!(*fEvent)->GetRdEvent().HasRdStations()) {
    cout << "WARNING: Event has no Radio Stations" << endl;
    return;
  }

  fCanvasTwoDLDF->Clear();
  DrawTwoDLDF();
  fCanvasTwoDLDF->GetCanvas()->Modified();
  fCanvasTwoDLDF->GetCanvas()->Update();

  fCanvasLDF->Clear();
  DrawLDF();
  fCanvasLDF->GetCanvas()->Modified();
  fCanvasLDF->GetCanvas()->Update();

  fCanvasResiduals->Clear();
  DrawResiduals();
  fCanvasResiduals->GetCanvas()->Modified();
  fCanvasResiduals->GetCanvas()->Update();

  fCanvasLorentz->Clear();
  DrawLorentz();
  fCanvasLorentz->GetCanvas()->Modified();
  fCanvasLorentz->GetCanvas()->Update();

}

void RdPlots::DrawChannelSpectrum(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;
  const int start = 0;
  float maxtr = 0;
  float mintr = 0;
  float minfreq = 0;
  float maxfreq = 0;
  float specbinning = 0;
  fCanvasSpectrum->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  TH1F *first_spect = NULL;
  for(RdRecChannels::const_iterator it=recStation.GetRdChannelVector().begin(); it!=recStation.GetRdChannelVector().end(); ++it) {
    try {
      if(it->IsScintillatorTop() || it->IsScintillatorBottom())
        continue;
      RdTrace tra = it->GetRdTrace();
      const int end = tra.GetAbsoluteFreqSpectrum().size();
      minfreq = min(tra.GetMinFreq(), tra.GetMaxFreq());
      maxfreq = max(tra.GetMinFreq(), tra.GetMaxFreq());
      specbinning = (maxfreq-minfreq)/(end-1);
      ostringstream trname;
      trname << "spch_" << it->GetId();
      TH1F *hsp = new TH1F(trname.str().c_str(), " ", end - start, minfreq-0.5*specbinning, maxfreq+0.5*specbinning);
      fPMTObjects->Add(hsp);

      hsp->GetYaxis()->SetTitle("Signal [#muV/MHz]");
      hsp->GetXaxis()->SetTitle("#nu [MHz]");
      hsp->SetLineWidth(1);
      for(int i = start; i < end; ++i)
        hsp->Fill(tra.Bin2Freq(i), tra.GetAbsoluteFreqSpectrum()[i]);
      int color = 0;
      TLegendEntry *entry;
      ostringstream legname;
      legname.str("");
      legname << "channel " << it->GetId();
      switch(it->GetId()) {
      case 1:
        color = kBlue;
        break;
      case 2:
        color = kRed;
        break;
      case 3:
        color = kCyan;
        break;
      case 4:
        color = kMagenta;
        break;
      }
      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(color);
      hsp->SetLineColor(color);
      if(it == recStation.GetRdChannelVector().begin()) {
        first_spect = hsp;
        hsp->Draw();
      } else {
        hsp->Draw("SAME");
      }
      float thismax = hsp->GetMaximum();
      float thismin = hsp->GetMinimum();
      if(thismin != 0) {
        if(mintr == 0)
          mintr = thismin;
        else
          mintr = min(thismin, mintr);
      }
      maxtr = max(thismax, maxtr);
      if(first_spect != NULL) {
        first_spect->GetYaxis()->SetRangeUser(max(mintr * .9, 0.1), maxtr * 1.1);
        first_spect->GetXaxis()->SetRangeUser(max(float(25.), minfreq), min(float(85.), maxfreq));
      }
    } catch(std::out_of_range & e) {
      cerr << " RdPlots::DrawChannelSpectrum :: Caught std::out_of_range \n";
      cerr << e.what() << endl;
      cerr << "Keep Looping " << endl;
    }
    legend->Draw("SAME");
  }
}
void RdPlots::DrawSpectrum(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;

  const int start = 0;
  float maxtr(0), mintr(0);
  float thisVEM(0);
  float minthistrace(0);

  // ------------- Station Spectrum --------------
  fCanvasSpectrum->cd();
  //fCanvasSpectrum->SetLogy(); // the beauty comes with the Log scaling for data
  TLegend *legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  TH1F *first_spect = NULL;

  for(int pol = 0; pol < 3; ++pol) {
    const vector<float>& spectrum = recStation.GetRdTrace(pol).GetAbsoluteFreqSpectrum();
    const int end = spectrum.size();
    const bool goodtrace = bool(spectrum.size());
    float minfreq = min(recStation.GetRdTrace(pol).GetMinFreq(), recStation.GetRdTrace(pol).GetMaxFreq());
    float maxfreq = max(recStation.GetRdTrace(pol).GetMinFreq(), recStation.GetRdTrace(pol).GetMaxFreq());
    float specbinning = (maxfreq-minfreq)/(end-1);
    ostringstream histName;
    histName << "Spectr" << pol;
    TH1F *hspect = new TH1F(histName.str().c_str(), " ", (end-start), minfreq-0.5*specbinning, maxfreq+0.5*specbinning);
    fPMTObjects->Add(hspect);

    hspect->GetYaxis()->SetTitle("Signal [#muV/m/MHz]");
    hspect->GetXaxis()->SetTitle("#nu [MHz]");
    hspect->SetLineWidth(1);
    if(goodtrace) {
      for(int j = start; j < end; ++j) {
        hspect->Fill(recStation.GetRdTrace(pol).Bin2Freq(j), spectrum[j]);
      }
    }

    hspect->SetLineColor(pol + 1);
    if(pol + 1 == 3)
      hspect->SetLineColor(4);
    hspect->GetYaxis()->SetTitleOffset(0.5);
    if(first_spect == NULL) {
      first_spect = hspect;
      hspect->GetXaxis()->SetRangeUser(max(float(25.), minfreq), min(float(85.), maxfreq)); // Set by hand the range from 25 to 85 Mhz, the automatic setting gives ugly histogram if up-sampling is used
      hspect->Draw("AXIS");
      if (fDrawEastPolarization && pol==0)
        hspect->Draw("same");
      thisVEM = hspect->GetMaximum();
      minthistrace = hspect->GetMinimum();
      maxtr = max(thisVEM, maxtr);
      if(mintr == 0)
        mintr = minthistrace;
      else if(minthistrace != 0)
        mintr = min(minthistrace, mintr);
    } else {
      if(pol == 2) {
        if(fDrawVertPolarization) { // Button for vertical polarization
          hspect->Draw("same");
          thisVEM = hspect->GetMaximum();
          minthistrace = hspect->GetMinimum();
          maxtr = max(thisVEM, maxtr);
          if(mintr == 0)
            mintr = minthistrace;
          else if(minthistrace != 0)
            mintr = min(minthistrace, mintr);
        }
      } else if (fDrawNorthPolarization && pol==1) {
        hspect->Draw("same");
        thisVEM = hspect->GetMaximum();
        minthistrace = hspect->GetMinimum();
        maxtr = max(thisVEM, maxtr);
        if(mintr == 0)
          mintr = minthistrace;
        else if(minthistrace != 0)
          mintr = min(minthistrace, mintr);
      }
    }

  } //pol

//Write Legend and statistics in the legend
  if(first_spect != NULL) {
    first_spect->GetYaxis()->SetRangeUser(max(0.01, mintr * 0.9), maxtr * 1.1);
  } // max() necessary in order to avoid problems in axis scaling with log

  TString name;
  ostringstream legname;
  name = "Spectra ";
  TLegendEntry *entry; //= legend->AddEntry("",name,"");
  for(int pol = 0; pol < 3; ++pol) {
    legname.str("");
    legname << "polarisation " << GetPolarisationName(pol);
    if(pol == 2) {
      if(fDrawVertPolarization) {
        entry = legend->AddEntry("", legname.str().c_str(), "");
        entry->SetTextColor(4);
      }
    } else {
      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pol + 1);
    }
  }
  legend->Draw();

}

void RdPlots::DrawChannelTraces(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;
  const int start = 0;
  float maxtr = 0;
  float mintr = 0;
  fCanvasTrace->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  TH1F *first_trace = NULL;
  for(RdRecChannels::const_iterator it=recStation.GetRdChannelVector().begin(); it!=recStation.GetRdChannelVector().end(); ++it) {
    try {
      if(it->IsScintillatorTop() || it->IsScintillatorBottom())
        continue;
      RdTrace tra = it->GetRdTrace();
      float timeBinning = tra.GetSamplingRate();
      const int end = tra.GetTimeTrace().size();
      ostringstream trname;
      trname << "ch_" << it->GetId();
      TH1F *htrace = new TH1F(trname.str().c_str(), " ", end - start, (start-0.5) * timeBinning, (end-0.5) * timeBinning);
      htrace->Reset();
      fPMTObjects->Add(htrace);

      htrace->GetYaxis()->SetTitle("Signal [#muV]");
      htrace->GetXaxis()->SetTitle("t [ns]");
      htrace->SetLineWidth(1);
      for(int i = start; i < end; ++i)
        htrace->Fill(i * timeBinning, tra.GetTimeTrace()[i]);
      int color = 0;
      TLegendEntry *entry;
      ostringstream legname;
      legname.str("");
      legname << "channel " << it->GetId();
      switch(it->GetId()) {
      case 1:
        color = kBlue;
        break;
      case 2:
        color = kRed;
        break;
      case 3:
        color = kCyan;
        break;
      case 4:
        color = kMagenta;
        break;
      }
      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(color);
      htrace->SetLineColor(color);
      if(it == recStation.GetRdChannelVector().begin()) {
        first_trace = htrace;
        htrace->Draw();
      } else {
        htrace->Draw("SAME");
      }
      float thismax = htrace->GetMaximum();
      float thismin = htrace->GetMinimum();
      if(thismin != 0) {
        if(mintr == 0)
          mintr = thismin;
        else
          mintr = min(thismin, mintr);
      }
      maxtr = max(thismax, maxtr);
    } catch(std::out_of_range & e) {
      cerr << " RdPlots::DrawChannelTraces :: Caught std::out_of_range \n";
      cerr << e.what() << endl;
      cerr << "Keep Looping " << endl;
      continue;
    }
  }
  legend->Draw("SAME");
  first_trace->GetYaxis()->SetRangeUser(mintr * 1.05, maxtr * 1.05);
  first_trace->Draw("SAME");
//    first_trace->GetXaxis()->SetRangeUser(min(mintr*.9,mintr*1.1),maxtr*1.1);
} //DrawChannelTraces

void RdPlots::DrawAllTraces(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;

  const int start = 0;
  float maxtr = 0;
  float mintr = 0;

  // ------------- Time trace --------------
  fCanvasTrace->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  TH1F *first_trace = NULL;

  for(int pol = 0; pol < 3; ++pol) {
    float timeBinning = recStation.GetRdTrace(pol).GetSamplingRate();
    const int end = recStation.GetRdTrace(pol).GetTimeTrace().size();
    const vector<float>& trace = recStation.GetRdTrace(pol).GetTimeTrace();
    const bool goodtrace = bool(trace.size());
    ostringstream histName;
    histName << "Trace" << pol;
    TH1F *htrace = new TH1F(histName.str().c_str(), " ", end - start, (start-0.5) * timeBinning, (end-0.5) * timeBinning);
    fPMTObjects->Add(htrace);

    htrace->GetYaxis()->SetTitle("Signal [#muV/m]");
    htrace->GetXaxis()->SetTitle("t [ns]");
    htrace->SetLineWidth(1);
    if(goodtrace) {
      for(int j = start; j < end; ++j) {
        htrace->Fill(j * timeBinning, trace[j]);
      }
    }

    htrace->SetLineColor(pol + 1);
    if(pol + 1 == 3)
      htrace->SetLineColor(4);

    htrace->GetYaxis()->SetTitleOffset(0.5);
    if(first_trace == NULL) {
      first_trace = htrace;
      htrace->Draw("AXIS");
      if(fDrawEastPolarization && pol == 0)
        htrace->Draw("same");
    } else {
      if(fDrawNorthPolarization && pol == 1)
         htrace->Draw("same");
      if(fDrawVertPolarization && pol == 2)
        htrace->Draw("same");

    }

    float thisVEM = htrace->GetMaximum();
    float thismin = htrace->GetMinimum();
    if(thismin != 0) {
      if(mintr == 0)
        mintr = thismin;
      else
        mintr = min(thismin, mintr);
    }
    maxtr = max(thisVEM, maxtr);
  } //pol
  for(int pol = 0; pol < 3; ++pol) {
    if((fDrawVxBPolarization && pol == 0) or (fDrawVxVxBPolarization && pol == 1) or (fDrawVPolarization && pol == 2)) {
      if(!recStation.HasRdTraceShowerPlane(pol)) {
        continue;
      }
      float timeBinning = recStation.GetRdTraceShowerPlane(pol).GetSamplingRate();
      const int end = recStation.GetRdTraceShowerPlane(pol).GetTimeTrace().size();
      const vector<float>& trace = recStation.GetRdTraceShowerPlane(pol).GetTimeTrace();
      const bool goodtrace = bool(trace.size());
      ostringstream histName;
      histName << "Trace_ShowerPlane" << pol;
      TH1F *htrace = new TH1F(histName.str().c_str(), " ", end - start, (start-0.5) * timeBinning, (end-0.5) * timeBinning);
      histName.str("");
      histName << "Trace_Analytic" << pol;
      fPMTObjects->Add(htrace);

      htrace->GetYaxis()->SetTitle("Signal [#muV/m]");
      htrace->GetXaxis()->SetTitle("t [ns]");
      htrace->SetLineWidth(1);
      if(goodtrace) {
        for(int j = start; j < end; ++j) {
          htrace->Fill(j * timeBinning, trace[j]);
        }
      }

      htrace->SetLineColor(pol + 1);
      if(pol + 1 == 3)
        htrace->SetLineColor(4);
      htrace->GetYaxis()->SetTitleOffset(0.5);
      if(first_trace == NULL) {
        first_trace = htrace;
        htrace->Draw("AXIS");
      }
      htrace->Draw("same");
      if(pol < 2 and recStation.HasRdTimeTraceAnalyticSignal(pol)) {
        TH1F *htrace2 = new TH1F(histName.str().c_str(), " ", end - start, (start-0.5) * timeBinning, (end-0.5) * timeBinning);
        fPMTObjects->Add(htrace2);
        const vector<float>& trace2 = recStation.GetRdTimeTraceAnalyticSignal(pol);
        double start2 = recStation.GetParameter(revt::eSignalTime)
            - recStation.GetParameter(revt::eTraceStartTime)
            - 0.5 * recStation.GetParameter(revt::eSignalIntegrationTime);
        for(unsigned int j = 0; j < trace2.size(); ++j) {
          htrace2->Fill(start2 + j * timeBinning, trace2[j]);
        }
        htrace2->SetLineColor(6);
        htrace2->Draw("same");
      }

      float thisVEM = htrace->GetMaximum();
      float thismin = htrace->GetMinimum();
      if(thismin != 0) {
        if(mintr == 0)
          mintr = thismin;
        else
          mintr = min(thismin, mintr);
      }
      maxtr = max(thisVEM, maxtr);

    }
  }

//Write Legend and statistics in the legend
  if(first_trace != NULL)
    first_trace->GetYaxis()->SetRangeUser(mintr * 1.1, maxtr * 1.1);

  TString name;
  ostringstream legname;
  name = "Trace ";
  TLegendEntry *entry;
  for(int pmt = 0; pmt < 3; ++pmt) {
    legname.str("");
    legname << " polarisation " << GetPolarisationName(pmt);

    if(fDrawVertPolarization && pmt == 2) {                        // Button

      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pmt + 2);
    }

    if(pmt != 2) {

      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pmt + 1);

    }

  }
  try {
    if(recStation.GetParameter(revt::eSignalTime) != 0) {
      float LineTime = recStation.GetParameter(revt::eSignalTime) - recStation.GetParameter(revt::eTraceStartTime);
      float peakx[] = { LineTime };
      float peaky[] = { 0. };
      float peakex[] = { 0. };
      float peakey[] = { (float)1.1 * max(maxtr, abs(mintr)) };
      TGraphErrors *PeakLine = new TGraphErrors(1, peakx, peaky, peakex, peakey); // It's not a real line, but TGraph clips to the frame boundary
      fPMTObjects->Add(PeakLine);
      PeakLine->SetLineColor(kMagenta);
      PeakLine->SetLineWidth(1);
      PeakLine->SetLineStyle(2);
      if(fDrawPeakLine) // Button
        PeakLine->Draw("Z");
    }
  }

  catch(const std::out_of_range & e) {
    cerr << " RdPlots::DrawAllTraces :: Caught std::out_of_range when drawing pulse position \n";
    cerr << e.what() << endl;
  }
  try {
    float signalstarttime = recStation.GetParameter(revt::eSignalSearchWindowStart);
    float signalstoptime = recStation.GetParameter(revt::eSignalSearchWindowStop);
    float signalx[] = { signalstarttime, signalstoptime };
    float signaly[] = { 0., 0. };
    float signalex[] = { 0., 0. };
    float signaley[] = { (float)1.1 * max(maxtr, abs(mintr)), (float)1.1 * max(maxtr, abs(mintr)) };
    TGraphErrors *bxSignal = new TGraphErrors(2, signalx, signaly, signalex, signaley); // It's not a real box, but TGraph clips to the frame boundary
    fPMTObjects->Add(bxSignal);
    bxSignal->SetFillColor(kGreen);
    bxSignal->SetFillStyle(3315);
    if(fDrawTriggerWindow)      //Button
      bxSignal->Draw("3");

    float noisestarttime = recStation.GetParameter(revt::eNoiseWindowStart);
    float noisestoptime = recStation.GetParameter(revt::eNoiseWindowStop);
    float noisex[] = { noisestarttime, noisestoptime };
    float noisey[] = { 0., 0. };
    float noiseex[] = { 0., 0. };
    float noiseey[] = { (float)1.1 * max(maxtr, abs(mintr)), (float)1.1 * max(maxtr, abs(mintr)) };
    TGraphErrors *bxNoise = new TGraphErrors(2, noisex, noisey, noiseex, noiseey); // It's not a real box, but TGraph clips to the frame boundary
    bxNoise->SetFillColor(kOrange + 2);
    bxNoise->SetFillStyle(3351);
    fPMTObjects->Add(bxNoise);
    if(fDrawNoiseWindow)    //Button
      bxNoise->Draw("3");

  } catch(...) {
    cerr << " RdPlots::DrawAllTraces :: Caught exception when drawing signal/noise search window\n";
  }

  legend->Draw();

}

void RdPlots::Draw2DField(const RdRecStation& recStation)
{
  const float windowsizens = 100.; // 100 ns !
//  const int graphsize(80); // Number of points for the graph/ should instead define a time window
  const vector<float>& traceX = recStation.GetRdTrace(0).GetTimeTrace();
  const vector<float>& traceY = recStation.GetRdTrace(1).GetTimeTrace();
  vector<float> X;
  vector<float> Y;
  fCanvasField->cd();
  int peakposition = 2000;
  try {
    peakposition = TMath::Floor(
        (recStation.GetParameter(revt::eSignalTime) - recStation.GetParameter(revt::eTraceStartTime))
            / recStation.GetRdTrace(0).GetSamplingRate());
  } catch(const std::out_of_range & e) {
    cerr << " RdPlots::Draw2DField :: Caught std::out_of_range when searching for pulse\n";
    cerr << e.what();
    cerr << " Trying to draw field from an arbitrary position (2000 bins)" << endl;
  }
  try {
    int graphsize = TMath::Floor(windowsizens / recStation.GetRdTrace(0).GetSamplingRate()); // Number of the point for the graph windowssizens/binsize
    if(peakposition <= 0)
      return;
    for(int i = (peakposition - graphsize / 2); i < (peakposition + graphsize / 2); ++i) {
      X.push_back(traceX[i]);
      Y.push_back(traceY[i]);
    }
    TGraph *gr_field = new TGraph(X.size(), &X.front(), &Y.front());
    fPMTObjects->Add(gr_field);
    ostringstream title;
    float xmin, xmax;
    title.str("");
    title << "Station " << (*fDetectorGeometry)->GetRdStationName(recStation.GetId());
    gr_field->SetTitle("Electric Field around the peak (2D view)");
    gr_field->GetXaxis()->SetTitle("X component");
    gr_field->GetYaxis()->SetTitle("Y component");
    gr_field->SetMarkerStyle(6);
    gr_field->SetLineColor(kGray + 1);
    xmin = min(gr_field->GetXaxis()->GetXmin(), gr_field->GetYaxis()->GetXmin());
    //  ymin=gr_field->GetYaxis()->GetXmin(),;
    //  ymin=gr_field->GetMinimum();
    xmax = max(gr_field->GetXaxis()->GetXmax(), gr_field->GetYaxis()->GetXmax());
    //  ymax=gr_field->GetYaxis()->GetXmax();
    //  ymax=gr_field->GetMaximum();
    //gr_field->SetMinimum(min(xmin,ymin));
    // gr_field->SetMaximum(max(xmax,ymax));
    TH2F *H_axis = new TH2F("2D Field", "2Dfield", 100, xmin, xmax, 100, xmin, xmax);
    fPMTObjects->Add(H_axis);
    H_axis->Draw("");
    H_axis->GetXaxis()->SetTitle("X Field [#mu V/m]");
    H_axis->GetYaxis()->SetTitle("Y Field [#mu V/m]");
    gr_field->Draw("PC SAME");

    TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
    fPMTObjects->Add(legend);
    legend->SetFillColor(0);
    legend->SetLineColor(0);
    legend->SetFillStyle(0);
    legend->SetBorderSize(0);
    legend->AddEntry("", title.str().c_str(), "");
    legend->Draw();
  }

  catch(const std::out_of_range & e) {
    cerr << "RdPlots::Draw2DField :: Get std::out_of_range when trying to get the trace\n";
    cerr << e.what();
    cerr << " I give up " << endl;
  }
}

void RdPlots::DrawScintillators(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;
  const int start = 0;
  float maxtr = 0;
  float mintr = 0;
  fCanvasScint->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  TH1F *first_trace = NULL;
  int first=0;
  bool HasScintillator = false;
  for(RdRecChannels::const_iterator it = recStation.GetRdChannelVector().begin(); it != recStation.GetRdChannelVector().end(); ++it) {
    if(!it->IsScintillatorTop() && !it->IsScintillatorBottom())
      continue;
    HasScintillator = true;
    RdTrace tra = it->GetRdTrace();
    float timeBinning = tra.GetSamplingRate();
    const int end = tra.GetTimeTrace().size();
    ostringstream trname;
    trname << "ch_" << it->GetId();
    TH1F *htrace = new TH1F((trname.str()+"_scint").c_str(), " ", end - start, (start-0.5) * timeBinning, (end-0.5) * timeBinning);
    htrace->Reset();
    fPMTObjects->Add(htrace);
    htrace->GetYaxis()->SetTitle("Signal [ADC counts]");
    htrace->GetXaxis()->SetTitle("t [ns]");
    htrace->SetLineWidth(1);
    for(int i = start; i < end; ++i)
      htrace->Fill(i * timeBinning, tra.GetTimeTrace()[i]/1e6);
    int color = 0;
    TLegendEntry *entry;
    ostringstream legname;
    legname.str("");
    if (it->IsScintillatorTop()) {
      color = kCyan;
      legname << "Scintillator top";
    }
    if (it->IsScintillatorBottom()) {
      color = kMagenta;
      legname << "Scintillator bottom";
    }
    legname << " (ch " << it->GetId() << ")";
    entry = legend->AddEntry("", legname.str().c_str(), "");
    entry->SetTextColor(color);
    htrace->SetLineColor(color);
    if(first==0) {
      first_trace = htrace;
      htrace->Draw();
      first=1;
    } else {
      htrace->Draw("SAME");
    }
    float thismax = htrace->GetMaximum();
    float thismin = htrace->GetMinimum();
    if(thismin != 0) {
      if(mintr == 0)
        mintr = thismin;
      else
        mintr = min(thismin, mintr);
    }
    maxtr = max(thismax, maxtr);
  }
  if (HasScintillator == true) {
    fRdEventTab->SetEnabled(3, true);
    legend->Draw("SAME");
    first_trace->GetYaxis()->SetRangeUser(mintr-(maxtr-mintr)*0.05, maxtr +(maxtr-mintr)*0.05);
    first_trace->Draw("SAME");
  }
  else
    fRdEventTab->SetEnabled(3, false);
}

void RdPlots::RdEventInfo(TCanvas* myCanvas)
{

  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const RdEvent &rdevent = (*fEvent)->GetRdEvent();

  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.06;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);

  y -= 0.5 * dy;

  ostringstream info;
  info << "Run " << rdevent.GetRdRunNumber();
  info << "  Event " << rdevent.GetRdEventId();
  info << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  const int lGPSsec = rdevent.GetGPSSecond();
  const int lGPSnsec = rdevent.GetGPSNanoSecond();
  info << "GPS Time " << lGPSsec << " s " << lGPSnsec << " ns";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  int yymmdd = (*fEvent)->GetYYMMDD();
  int hhmmss = (*fEvent)->GetHHMMSS();
  int year = yymmdd / 10000;
  int month = (yymmdd % 10000) / 100;
  int day = (yymmdd % 100);
  int hour = (int) (hhmmss / 10000.);
  int minute = (hhmmss % 10000) / 100;
  int second = (hhmmss % 100);
  info << "UTC Date: 20";
  if(year > 9) {
    info << year;
  } else {
    info << "0" << year;
  }
  if(month > 9) {
    info << "/" << month;
  } else {
    info << "/0" << month;
  }
  if(day > 9) {
    info << "/" << day;
  } else {
    info << "/0" << day;
  }
  if(hour > 9) {
    info << "   " << hour;
  } else {
    info << "   0" << hour;
  }
  if(minute > 9) {
    info << ":" << minute;
  } else {
    info << ":0" << minute;
  }
  if(second > 9) {
    info << ":" << second;
  } else {
    info << ":0" << second;
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");
  double recStage = 0;
  if(rdevent.GetRdRecShower().HasParameter(revt::eRecStage)) {
    recStage = rdevent.GetRdRecShower().GetParameter(revt::eRecStage);
    info << "RecStage = " << GetRecStage(recStage);
  } else
    info << "RecStage undefined";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");
  try {
    float theta = TMath::RadToDeg()
        * acos(rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisZ) / rdevent.GetRdRecShower().GetRadius());
    float thetaError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithError();
    float phi = atan2(rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisY),
        rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisX));
    float phiError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthError();
    if(phi < 0)
      phi += 2 * TMath::Pi();
    phi *= TMath::RadToDeg();
    info << "#theta = " << 1. * TMath::Nint(theta * 100) / 100;
    if(recStage >= 1.1 and not isnan(thetaError)) //
      info << "#pm" << 1. * TMath::Nint(thetaError * 100) / 100;
    info << " deg  #phi = " << 1. * TMath::Nint(phi * 100) / 100;
    if(recStage >= 1.1 and not isnan(phiError))  //
      info << "#pm" << 1. * TMath::Nint(phiError * 100) / 100 << " deg";
  } catch(...) {
    info << " #theta and #phi not defined ";
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");
  
  if(rdevent.GetRdRecShower().HasParameter(revt::eRadiationEnergy)) {
    info << "radiation energy: ";
    info << setprecision(3) << rdevent.GetRdRecShower().GetParameter(revt::eRadiationEnergy);
    info << " +/- " << rdevent.GetRdRecShower().GetParameterError(revt::eRadiationEnergy);
    info << " eV";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }

  if(rdevent.GetRdRecShower().HasParameter(revt::eRadiationEnergy)) {
    info << "sigma (2D LDF): ";
    info << setprecision(2) << rdevent.GetRdRecShower().Get2dLDFFitResult().Parameter(3);
    info << " +/- " << rdevent.GetRdRecShower().Get2dLDFFitResult().GetErrors()[1];
    info << " m";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(rdevent.GetRdRecShower().HasParameter(revt::eRadiationEnergy)) {
    info << "core x, y = ";
    info << rdevent.GetRdRecShower().Get2dLDFFitResult().Parameter(1);
//    info << " +/- " << rdevent.GetRdRecShower().Get2dLDFFitResult().Error(1);
    info << " m, ";

    info << rdevent.GetRdRecShower().Get2dLDFFitResult().Parameter(2);
//    info << " +/- " << rdevent.GetRdRecShower().Get2dLDFFitResult().Error(2);
    info << " m";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }


  info << "Stations: ";
  if(rdevent.GetRdRecShower().HasParameter(revt::eNumberOfStationsWithPulseFound))
    info << rdevent.GetRdRecShower().GetParameter(revt::eNumberOfStationsWithPulseFound);
  else
    info << "not set";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");  

  if(rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisX)
      && rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisY)
      && rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisZ)) {
    float thetaPre = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithPreFit();
    float thetaPreError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithPreFitError();
    float phiPre = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthPreFit();
    float phiPreError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthPreFitError();
    info << "PreFit: #theta = " << 1. * TMath::Nint(thetaPre * 10) / 10 << "#pm" << 1. * TMath::Nint(thetaPreError * 100) / 100
         << " deg  #phi = " << 1. * TMath::Nint(phiPre * 10) / 10 << "#pm" << 1. * TMath::Nint(phiPreError * 100) / 100 << " deg";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 1.2) {
    //This quantities make no sense if the fit is plane or not chi^{2} based
    double radius = rdevent.GetRdRecShower().GetRadius();
    double radiusError = rdevent.GetRdRecShower().GetRadiusError();
    info << "radius = " << radius << " #pm " << radiusError << " m";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");

    double convergedFit = 0;
    double FitSuccess = 0;
    if(rdevent.GetRdRecShower().HasParameter(revt::eFitConvergence))
      convergedFit = rdevent.GetRdRecShower().GetParameter(revt::eFitConvergence);
    if(rdevent.GetRdRecShower().HasParameter(revt::eFitSuccess))
      FitSuccess = rdevent.GetRdRecShower().GetParameter(revt::eFitSuccess);
    info << "FitStatus = ";
    if(convergedFit)
      info << "converged";
    else if(!convergedFit && FitSuccess)
      info << "successful";
    else
      info << "failed / unknown";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 1.6) {
    if(rdevent.GetRdRecShower().HasParameter(revt::eRho)) {
        double rho = TMath::RadToDeg() * rdevent.GetRdRecShower().GetParameter(revt::eRho);
        double rhoError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetParameterError(revt::eRho);
        info << "rho = " << 1. * TMath::Nint(rho * 100) / 100 << " #pm " << 1. * TMath::Nint(rhoError * 100) / 100 << " deg";
        slegend->DrawLatex(x1, y, info.str().c_str());
        y -= dy;
        info.str("");
    }
  }
  if(recStage > 1.1) {
    if(rdevent.GetRdRecShower().HasParameter(revt::eWaveFitChi2) && rdevent.GetRdRecShower().HasParameter(revt::eWaveFitNDF)) {
      info << "Chi2/NDF = " << setprecision(3);
      if (rdevent.GetRdRecShower().GetParameter(revt::eWaveFitChi2) > 0.01)
        info << rdevent.GetRdRecShower().GetParameter(revt::eWaveFitChi2);
      else
        info << "(< 0.01)";
      info << " / "  << rdevent.GetRdRecShower().GetParameter(revt::eWaveFitNDF);
    }
    else
      info << "Chi2/NDF undefined";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 0.0) {
    info << "x = " << setprecision(4) << rdevent.GetRdRecShower().GetCoreSiteCS().X() / 1000 << " km, y = "
         << rdevent.GetRdRecShower().GetCoreSiteCS().Y() / 1000 << " km"; // one day this should also display errors
  } else {
    info << " x and y not defined";
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  if(recStage >= 2.0) {
    if(rdevent.GetRdRecShower().HasParameter(revt::eEnergy)) {
      info << "Energy = " << setprecision(4) << rdevent.GetRdRecShower().GetParameter(revt::eEnergy) << " eV";
      slegend->DrawLatex(x1, y, info.str().c_str());
      y -= dy;
    }
  }
  info.str("");

  if(not isnan(rdevent.GetRdRecShower().GetZenith())) {
    double zenith = rdevent.GetRdRecShower().GetZenith();
    double azimuth = rdevent.GetRdRecShower().GetAzimuth();
    TVector3 bfield = rdevent.GetRdRecShower().GetMagneticFieldVector();
    TVector3 showeraxis = TVector3(1.,0.,0.);
    showeraxis.SetTheta(zenith);
    showeraxis.SetPhi(azimuth);
    double alpha = TMath::RadToDeg() * showeraxis.Angle(bfield);
    info << "#alpha = " << alpha << "#circ";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(rdevent.IsRejected()) {
    info << "Rejected: ";
    for(unsigned int i = 1; i<32; ++i) {
      if(rdevent.GetRejectionStatus() & int(pow(2,i))) {
        info << "("<< i << ")" << ", ";
      }
    }
    slegend->DrawLatex(x1, y, info.str().c_str());
    // y -= dy; // useless here
    info.str("");
  }

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}

void RdPlots::RdMCInfo(TCanvas* myCanvas)
{
  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const GenShower & genShower = (*fEvent)->GetGenShower();

  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);

  y -= 0.5 * dy;
  ostringstream info;
  info.str("");
  info << "MC Event ";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  float theta = genShower.GetZenith() / view::Consts::degree;
  float phi = genShower.GetAzimuth() / view::Consts::degree;

  info << setprecision(4) << "#theta = " << theta << "deg  #phi = " << phi << " deg";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << setprecision(4) << "Energy = " << genShower.GetEnergy() / 1e18 << " EeV " << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << setprecision(5) << "XmaxGH = " << genShower.GetXmaxGaisserHillas()
       << " g/cm^{2}" << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << setprecision(5) << "RmaxGH = " << genShower.GetDistanceOfShowerMaximum()
       << " cm" << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << "Primary particle: " << genShower.GetPrimaryName() << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  const TVector3& showerCore = genShower.GetCoreSiteCS();
  const double coreX = showerCore.X()/1000;
  const double coreY = showerCore.Y()/1000;

  info << setprecision(4) << "Core: x = " << coreX << " km, y = " << coreY << " km" << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  // y -= dy; //useless here
  info.str("");

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}

void RdPlots::RdLDFInfo(TCanvas* myCanvas)
{
  /* #FIXME need scroll */
  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);

  ostringstream info("");

  /* starting loop through functions */
  const vector<TF1>& ldfR = (*fEvent)->GetRdEvent().GetRdRecShower().GetRdLDF();
  vector<TF1>::const_iterator ldf_it;
  for(ldf_it = ldfR.begin(); ldf_it != ldfR.end(); ++ldf_it) {
    info << ldf_it->GetName();
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
    info << ldf_it->GetExpFormula();
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
    for(int i = 0; i < ldf_it->GetNpar(); ++i) {
      info << "[" << i << "] " << ldf_it->GetParName(i) << " = " << ldf_it->GetParameter(i) << " #pm " << ldf_it->GetParError(i);
      slegend->DrawLatex(x1, y, info.str().c_str());
      y -= dy;
      info.str("");
    }
    info << "#chi^2/NDF = " << ldf_it->GetChisquare() << "/" << ldf_it->GetNDF();
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= 2*dy;
    info.str("");
  }

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();



}

void RdPlots::RdStationInfo(TCanvas* myCanvas)
{

  fEventObjects->Delete();

  if(!(*fEvent)->GetRdEvent().HasRdStations()) {
    cout << "WARNING: Event has no Radio Stations" << endl;
    return;
  }
  
  myCanvas->cd();
  myCanvas->Clear();

  unsigned int sId = fStationsListBox->GetSelected();
  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  for(unsigned int iS = 0; iS < stations.size(); ++iS)
    if((stations[iS].GetId()) == sId)
      sId = iS;
  
  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.085);

  y -= 0.5 * dy;

  ostringstream info;
  info << (*fDetectorGeometry)->GetRdStationName((unsigned int) fStationsListBox->GetSelected());
  info << "    #beta = " ;
  if(stations[sId].HasParameter(revt::eAngleToExpectedEFieldVector)) {
    info << round(TMath::RadToDeg()*stations[sId].GetParameter(revt::eAngleToExpectedEFieldVector)*10.) / 10.;
    if(stations[sId].HasParameterError(revt::eAngleToExpectedEFieldVector))
      info << " +/- " << round(TMath::RadToDeg()*stations[sId].GetParameterError(revt::eAngleToExpectedEFieldVector)*10.) / 10.;
    info << " deg";
  }
  else
    info << "not calculated"; 
  info << "    Time Residual = ";
  if(stations[sId].HasParameter(revt::eTimeResidual)) {
    info << round(stations[sId].GetParameter(revt::eTimeResidual)*10.) / 10.;
    if(stations[sId].HasParameterError(revt::eTimeResidual))
      info << " +/- " << round(stations[sId].GetParameterError(revt::eTimeResidual)*10.) / 10.;
    info << " ns";
  }
  else
    info << "not set";  
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= 2*dy;
  info.str("");
  
  info << "Rejection Status: ";
  if(stations[sId].GetRejectionStatus() != 0) {
    info << "rejected (" << stations[sId].GetRejectionStatus() << ")" << endl;
  }
  else
    info << "not rejected" << endl;
  info << "    Saturation Status: ";
  if(stations[sId].IsSaturated())
    info << "saturated" << endl;
  else
    info << "not saturated" << endl;  
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= 2*dy;
  info.str("");
 
  
  info << "Signal Peak = ";
  if(stations[sId].HasParameter(revt::eSignalTime) && stations[sId].HasParameter(revt::eTraceStartTime))
    info << round((stations[sId].GetParameter(revt::eSignalTime) - stations[sId].GetParameter(revt::eTraceStartTime))*10.)/10. << " ns ";
  else
    info << "not set ";
  info << "   Signal Window = [ ";
  if(stations[sId].HasParameter(revt::eSignalSearchWindowStart))
    info << round(stations[sId].GetParameter(revt::eSignalSearchWindowStart)*10.)/10. << " ns ";
  else
    info << "not set "; 
  info << "... ";
  if(stations[sId].HasParameter(revt::eSignalSearchWindowStop))
    info << round(stations[sId].GetParameter(revt::eSignalSearchWindowStop)*10.)/10. << " ns ";
  else
    info << "not set ";
  info << "]";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= 2*dy;
  info.str("");  
  
  info << "Time Correction by GPS | Beacon | Calibration: ";
  if(stations[sId].HasParameter(revt::eTraceStartTimeCorrectionByGPSPosition))
    info << round(stations[sId].GetParameter(revt::eTraceStartTimeCorrectionByGPSPosition)*10.) / 10. << " ns";
  else 
    info << " not set";
  info << " | ";
  if(stations[sId].HasParameter(revt::eTraceStartTimeCorrectionByBeacon))
    info << round(stations[sId].GetParameter(revt::eTraceStartTimeCorrectionByBeacon)*10.) / 10. << " ns";
  else 
    info << " not set";
  info << " | ";
   if(stations[sId].HasParameter(revt::eTraceStartTimeCorrectionByTimeCalibration))
    info << round(stations[sId].GetParameter(revt::eTraceStartTimeCorrectionByTimeCalibration)*10.) / 10. << " ns";
  else 
    info << " not set"; 
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= 2*dy;
  info.str("");  

  info << "Polarization | Observ Angle: ";
  if (stations[sId].HasParameter(revt::ePolarizationAngle)) {
     info << round(TMath::RadToDeg()*stations[sId].GetParameter(revt::ePolarizationAngle)*10.) / 10.;  
     if(stations[sId].HasParameterError(revt::ePolarizationAngle))
       info << " +/- " << round(TMath::RadToDeg()*stations[sId].GetParameterError(revt::ePolarizationAngle)*10.) / 10. << " deg ";
  } else
      info << " not calculated ";
  info << " | ";
    if (stations[sId].HasParameter(revt::eObserverAngle)) 
      info << round(TMath::RadToDeg()*stations[sId].GetParameter(revt::eObserverAngle)*10.) / 10. << " deg ";
    else
      info << " not calculated ";
  info << " a: ";
  if (stations[sId].HasParameter(revt::eCxxFraction)) {
    info << round((stations[sId].GetParameter(revt::eCxxFraction))*100.) / 100.;
    if(stations[sId].HasParameterError(revt::eCxxFraction))
      info << " +/- " << round((stations[sId].GetParameterError(revt::eCxxFraction))*100.) / 100.; 
  } else
      info << " not calculated";
  slegend->DrawLatex(x1, y, info.str().c_str());
  //y -= dy; // useless here
  info.str("");

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
  
}


std::string RdPlots::PrintPostScript()
{

  const int evId = (*fEvent)->GetRdEvent().GetRdEventId();
  ostringstream arrayFileStream;
  arrayFileStream << "/tmp/tmp" << evId << "_Rarray.eps";
  fCanvasArray->cd();
  fCanvasArray->Print(arrayFileStream.str().c_str());

  ostringstream traceFileStream;
  traceFileStream << "/tmp/tmp" << evId << "_Rtrace.eps";
  fCanvasTrace->cd();
  fCanvasTrace->Print(traceFileStream.str().c_str());

  ostringstream spectrFileStream;
  spectrFileStream << "/tmp/tmp" << evId << "_Rspectr.eps";
  fCanvasSpectrum->cd();
  fCanvasSpectrum->Print(spectrFileStream.str().c_str());

  ostringstream infoFileStream;
  infoFileStream << "/tmp/tmp" << evId << "_Rinfo.eps";
  fCanvasInfo->cd();
  fCanvasInfo->SaveAs(infoFileStream.str().c_str());

  ostringstream filenameStream;
  filenameStream << "RdEvent_" << evId << ".ps";
  const char* filename = filenameStream.str().c_str();
  ostringstream commandStream;

  commandStream << ADST_BIN_DIR << "/RdEvent2ps.csh " << evId << " " << filename;

  const char* command = commandStream.str().c_str();
  int retvalue = system(command);
  if(retvalue != 0)
    cout << " Something wrong occured during RdPlots Saving" << endl;
  return string(filename);
}

void RdPlots::UpdateArrayPlot()
{
  fArrayPlot->Draw(EventBrowserConfig::Get(cfg::eRdShowSd), EventBrowserConfig::Get(cfg::eRdShowFd), fIsMC);
}

void RdPlots::HandleArrayClicked(Int_t event, Int_t px, Int_t py, TObject* /*sel*/)
{
  TCanvas *c = (TCanvas *) gTQSender;
  TPad *pad = (TPad *) c->GetSelectedPad();
  if(event == kButton1Down || event == kButton1Double) {

    if(fRdArrayOnStatus) {
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      const int stid = (*fDetectorGeometry)->GetClosestRdStationId(ClickX * 1000., ClickY * 1000.);
      if(stid != 0) {
        const std::vector<RdRecStation>& stations = (*fEvent)->GetRdEvent().GetRdStationVector();

        fStationsListBox->Select(stid);
        RdStationInfo(fCanvasStationInfo);
        for(unsigned int iS = 0; iS < stations.size(); ++iS) {
          if(int(stations[iS].GetId()) == stid) {
            if(fHasStationTraces)
              UpdateTraceTabPlots(iS);

            UpdateArrayPlot();
            fArrayPlot->DrawSelectedRStationMarker(iS);
            break;
          }
        }
      }
    } // if array on

  } else if(event == kButton2Down || event == kButton2Double) {

    if(fRdArrayOnStatus) {
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      fArrayPlot->SetZoomCenter(ClickX, ClickY);
      UpdateArrayPlot();
    }
  }
}

void RdPlots::DrawTwoDLDF(){

      /*
        Please note that for this first version the color of the markers only corresponds to the colorbar as long as (0,0) is inside the plotted X-,Y-range.
        */


    if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage) and
        (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eRecStage)>=2) {

    fCanvasTwoDLDF->cd();
    fCanvasTwoDLDF->SetRightMargin(0.18);
    const RdEvent& radioevt = (*fEvent)->GetRdEvent();
    const RdRecShower& radiosho = radioevt.GetRdRecShower();
    TFitResult r =  radiosho.Get2dLDFFitResult();
    TF2 *LDF2DFit = new TF2("LDF2DFit",
      "[0]*TMath::Exp(-((x-([1]+[5]))**2+(y-[2])**2)/[3]**2)-[6]*[0]*TMath::Exp(-((x-([1]+[4]))**2+(y-[2])**2)/TMath::Exp([7]+[8]*[3])**2)",
      -1000, 1000,-1000,1000);
    for(int j=0;j<LDF2DFit->GetNumberFreeParameters();++j){
            LDF2DFit->SetParameter(j,r.Parameter(j));
    }
    int Xbins = 400;
    int Ybins = 400;
    LDF2DFit->SetNpx(Xbins);
    LDF2DFit->SetNpy(Ybins);
    fPlotsObjects->Add(LDF2DFit);
    const UInt_t NRGBs = 256;
    Double_t Stops[NRGBs] = 
      { 0.        ,  0.00392157,  0.00784314,  0.01176471,  0.01568627,
        0.01960784,  0.02352941,  0.02745098,  0.03137255,  0.03529412,
        0.03921569,  0.04313725,  0.04705882,  0.05098039,  0.05490196,
        0.05882353,  0.0627451 ,  0.06666667,  0.07058824,  0.0745098 ,
        0.07843137,  0.08235294,  0.08627451,  0.09019608,  0.09411765,
        0.09803922,  0.10196078,  0.10588235,  0.10980392,  0.11372549,
        0.11764706,  0.12156863,  0.1254902 ,  0.12941176,  0.13333333,
        0.1372549 ,  0.14117647,  0.14509804,  0.14901961,  0.15294118,
        0.15686275,  0.16078431,  0.16470588,  0.16862745,  0.17254902,
        0.17647059,  0.18039216,  0.18431373,  0.18823529,  0.19215686,
        0.19607843,  0.2       ,  0.20392157,  0.20784314,  0.21176471,
        0.21568627,  0.21960784,  0.22352941,  0.22745098,  0.23137255,
        0.23529412,  0.23921569,  0.24313725,  0.24705882,  0.25098039,
        0.25490196,  0.25882353,  0.2627451 ,  0.26666667,  0.27058824,
        0.2745098 ,  0.27843137,  0.28235294,  0.28627451,  0.29019608,
        0.29411765,  0.29803922,  0.30196078,  0.30588235,  0.30980392,
        0.31372549,  0.31764706,  0.32156863,  0.3254902 ,  0.32941176,
        0.33333333,  0.3372549 ,  0.34117647,  0.34509804,  0.34901961,
        0.35294118,  0.35686275,  0.36078431,  0.36470588,  0.36862745,
        0.37254902,  0.37647059,  0.38039216,  0.38431373,  0.38823529,
        0.39215686,  0.39607843,  0.4       ,  0.40392157,  0.40784314,
        0.41176471,  0.41568627,  0.41960784,  0.42352941,  0.42745098,
        0.43137255,  0.43529412,  0.43921569,  0.44313725,  0.44705882,
        0.45098039,  0.45490196,  0.45882353,  0.4627451 ,  0.46666667,
        0.47058824,  0.4745098 ,  0.47843137,  0.48235294,  0.48627451,
        0.49019608,  0.49411765,  0.49803922,  0.50196078,  0.50588235,
        0.50980392,  0.51372549,  0.51764706,  0.52156863,  0.5254902 ,
        0.52941176,  0.53333333,  0.5372549 ,  0.54117647,  0.54509804,
        0.54901961,  0.55294118,  0.55686275,  0.56078431,  0.56470588,
        0.56862745,  0.57254902,  0.57647059,  0.58039216,  0.58431373,
        0.58823529,  0.59215686,  0.59607843,  0.6       ,  0.60392157,
        0.60784314,  0.61176471,  0.61568627,  0.61960784,  0.62352941,
        0.62745098,  0.63137255,  0.63529412,  0.63921569,  0.64313725,
        0.64705882,  0.65098039,  0.65490196,  0.65882353,  0.6627451 ,
        0.66666667,  0.67058824,  0.6745098 ,  0.67843137,  0.68235294,
        0.68627451,  0.69019608,  0.69411765,  0.69803922,  0.70196078,
        0.70588235,  0.70980392,  0.71372549,  0.71764706,  0.72156863,
        0.7254902 ,  0.72941176,  0.73333333,  0.7372549 ,  0.74117647,
        0.74509804,  0.74901961,  0.75294118,  0.75686275,  0.76078431,
        0.76470588,  0.76862745,  0.77254902,  0.77647059,  0.78039216,
        0.78431373,  0.78823529,  0.79215686,  0.79607843,  0.8       ,
        0.80392157,  0.80784314,  0.81176471,  0.81568627,  0.81960784,
        0.82352941,  0.82745098,  0.83137255,  0.83529412,  0.83921569,
        0.84313725,  0.84705882,  0.85098039,  0.85490196,  0.85882353,
        0.8627451 ,  0.86666667,  0.87058824,  0.8745098 ,  0.87843137,
        0.88235294,  0.88627451,  0.89019608,  0.89411765,  0.89803922,
        0.90196078,  0.90588235,  0.90980392,  0.91372549,  0.91764706,
        0.92156863,  0.9254902 ,  0.92941176,  0.93333333,  0.9372549 ,
        0.94117647,  0.94509804,  0.94901961,  0.95294118,  0.95686275,
        0.96078431,  0.96470588,  0.96862745,  0.97254902,  0.97647059,
        0.98039216,  0.98431373,  0.98823529,  0.99215686,  0.99607843,  
        1.         };

      Double_t Red[NRGBs]   = 
        { 1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          0.99571078,  0.98345588,  0.97120098,  0.95894608,  0.94669118,
          0.93443627,  0.92218137,  0.90992647,  0.89767157,  0.88541667,
          0.87316176,  0.86090686,  0.84865196,  0.83639706,  0.82414216,
          0.81188725,  0.79963235,  0.78737745,  0.77512255,  0.76286765,
          0.75061275,  0.73835784,  0.72610294,  0.71384804,  0.70159314,
          0.68933824,  0.67708333,  0.66482843,  0.65257353,  0.64031863,
          0.62806373,  0.61580882,  0.60355392,  0.59129902,  0.57904412,
          0.56678922,  0.55453431,  0.54227941,  0.53002451,  0.51776961,
          0.50551471,  0.4932598 ,  0.4810049 ,  0.46875   ,  0.4564951 ,
          0.4442402 ,  0.43198529,  0.41973039,  0.40747549,  0.39522059,
          0.38296569,  0.37071078,  0.35845588,  0.34620098,  0.33394608,
          0.32169118,  0.30943627,  0.29718137,  0.28492647,  0.27267157,
          0.26041667,  0.24816176,  0.23590686,  0.22365196,  0.21139706,
          0.19914216,  0.18688725,  0.17463235,  0.16237745,  0.15012255,
          0.13786765,  0.12561275,  0.11335784,  0.10110294,  0.08884804,
          0.07659314,  0.06433824,  0.05208333,  0.03982843,  0.02757353,
          0.01531863,  0.00306373,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.         }; 
          
      Double_t Green[NRGBs] = 
        { 1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  0.99529412,  0.98745098,  0.97960784,  0.97176471,
          0.96392157,  0.95607843,  0.94823529,  0.94039216,  0.93254902,
          0.92470588,  0.91686275,  0.90901961,  0.90117647,  0.89333333,
          0.8854902 ,  0.87764706,  0.86980392,  0.86196078,  0.85411765,
          0.84627451,  0.83843137,  0.83058824,  0.8227451 ,  0.81490196,
          0.80705882,  0.79921569,  0.79137255,  0.78352941,  0.77568627,
          0.76784314,  0.76      ,  0.75215686,  0.74431373,  0.73647059,
          0.72862745,  0.72078431,  0.71294118,  0.70509804,  0.6972549 ,
          0.68941176,  0.68156863,  0.67372549,  0.66588235,  0.65803922,
          0.65019608,  0.64235294,  0.6345098 ,  0.62666667,  0.61882353,
          0.61098039,  0.60313725,  0.59529412,  0.58745098,  0.57960784,
          0.57176471,  0.56392157,  0.55607843,  0.54823529,  0.54039216,
          0.53254902,  0.52470588,  0.51686275,  0.50901961,  0.50117647,
          0.49333333,  0.4854902 ,  0.47764706,  0.46980392,  0.46196078,
          0.45411765,  0.44627451,  0.43843137,  0.43058824,  0.4227451 ,
          0.41490196,  0.40705882,  0.39921569,  0.39137255,  0.38352941,
          0.37568627,  0.36784314,  0.36      ,  0.35215686,  0.34431373,
          0.33647059,  0.32862745,  0.32078431,  0.31294118,  0.30509804,
          0.2972549 ,  0.28941176,  0.28156863,  0.27372549,  0.26588235,
          0.25803922,  0.25019608,  0.24235294,  0.2345098 ,  0.22666667,
          0.21882353,  0.21098039,  0.20313725,  0.19529412,  0.18745098,
          0.17960784,  0.17176471,  0.16392157,  0.15607843,  0.14823529,
          0.14039216,  0.13254902,  0.12470588,  0.11686275,  0.10901961,
          0.10117647,  0.09333333,  0.0854902 ,  0.07764706,  0.06980392,
          0.06196078,  0.05411765,  0.04627451,  0.03843137,  0.03058824,
          0.0227451 ,  0.01490196,  0.00705882,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.         };
          
      Double_t Blue[NRGBs]  = 
        { 1.        ,  0.95098039,  0.90196078,  0.85294118,  0.80392157,
          0.75490196,  0.70588235,  0.65686275,  0.60784314,  0.55882353,
          0.50980392,  0.46078431,  0.41176471,  0.3627451 ,  0.31372549,
          0.26470588,  0.21568627,  0.16666667,  0.11764706,  0.06862745,
          0.01960784,  0.00470588,  0.01254902,  0.02039216,  0.02823529,
          0.03607843,  0.04392157,  0.05176471,  0.05960784,  0.06745098,
          0.07529412,  0.08313725,  0.09098039,  0.09882353,  0.10666667,
          0.1145098 ,  0.12235294,  0.13019608,  0.13803922,  0.14588235,
          0.15372549,  0.16156863,  0.16941176,  0.1772549 ,  0.18509804,
          0.19294118,  0.20078431,  0.20862745,  0.21647059,  0.22431373,
          0.23215686,  0.24      ,  0.24784314,  0.25568627,  0.26352941,
          0.27137255,  0.27921569,  0.28705882,  0.29490196,  0.3027451 ,
          0.31058824,  0.31843137,  0.32627451,  0.33411765,  0.34196078,
          0.34980392,  0.35764706,  0.3654902 ,  0.37333333,  0.38117647,
          0.38901961,  0.39686275,  0.40470588,  0.41254902,  0.42039216,
          0.42823529,  0.43607843,  0.44392157,  0.45176471,  0.45960784,
          0.46745098,  0.47529412,  0.48313725,  0.49098039,  0.49882353,
          0.50666667,  0.5145098 ,  0.52235294,  0.53019608,  0.53803922,
          0.54588235,  0.55372549,  0.56156863,  0.56941176,  0.5772549 ,
          0.58509804,  0.59294118,  0.60078431,  0.60862745,  0.61647059,
          0.62431373,  0.63215686,  0.64      ,  0.64784314,  0.65568627,
          0.66352941,  0.67137255,  0.67921569,  0.68705882,  0.69490196,
          0.7027451 ,  0.71058824,  0.71843137,  0.72627451,  0.73411765,
          0.74196078,  0.74980392,  0.75764706,  0.7654902 ,  0.77333333,
          0.78117647,  0.78901961,  0.79686275,  0.80470588,  0.81254902,
          0.82039216,  0.82823529,  0.83607843,  0.84392157,  0.85176471,
          0.85960784,  0.86745098,  0.87529412,  0.88313725,  0.89098039,
          0.89882353,  0.90666667,  0.9145098 ,  0.92235294,  0.93019608,
          0.93803922,  0.94588235,  0.95372549,  0.96156863,  0.96941176,
          0.9772549 ,  0.98509804,  0.99294118,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  1.        ,  1.        ,  1.        ,
          1.        ,  1.        ,  0.98823529,  0.97254902,  0.95686275,
          0.94117647,  0.9254902 ,  0.90980392,  0.89411765,  0.87843137,
          0.8627451 ,  0.84705882,  0.83137255,  0.81568627,  0.8       ,
          0.78431373,  0.76862745,  0.75294118,  0.7372549 ,  0.72156863,
          0.70588235,  0.69019608,  0.6745098 ,  0.65882353,  0.64313725,
          0.62745098,  0.61176471,  0.59607843,  0.58039216,  0.56470588,
          0.54901961,  0.53333333,  0.51764706,  0.50196078,  0.48627451,
          0.47058824,  0.45490196,  0.43921569,  0.42352941,  0.40784314,
          0.39215686,  0.37647059,  0.36078431,  0.34509804,  0.32941176,
          0.31372549,  0.29803922,  0.28235294,  0.26666667,  0.25098039,
          0.23529412,  0.21960784,  0.20392157,  0.18823529,  0.17254902,
          0.15686275,  0.14117647,  0.1254902 ,  0.10980392,  0.09411765,
          0.07843137,  0.0627451 ,  0.04705882,  0.03137255,  0.01568627,
          0.        };

    Int_t nb=104;
    TColor::CreateGradientColorTable(NRGBs,Stops,Red,Green,Blue,nb);
    gStyle->SetNumberContours(104);
    TH2D *plot_Histogram = (TH2D*)LDF2DFit->GetHistogram()->Clone("plot_Histogram");
    fPlotsObjects->Add(plot_Histogram);
    plot_Histogram->SetTitle("");
    plot_Histogram->GetXaxis()->SetTitle("position in #vec{v}x#vec{B}-direction [m]");
    plot_Histogram->GetYaxis()->SetTitle("position in #vec{v}x(#vec{v}x#vec{B})-direction [m]");
    plot_Histogram->GetYaxis()->SetTitleOffset(1.3);
    plot_Histogram->GetZaxis()->SetTitle("energy density [eV/m^{2}]");
    const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
    double maximum = plot_Histogram->GetBinContent(plot_Histogram->GetMaximumBin());
    for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {
      if(!stiter->HasParameter(revt::eLDFFitStationPositionVxB) or !stiter->HasParameter(revt::eLDFFitStationPositionVxVxB)){
        continue;
      }
      if(stiter->IsSaturated()){
        continue;
      }
      if(stiter->IsRejected()){
        continue;
      }
      if(!stiter->HasPulse()){
        continue;
      }
      if(stiter->GetParameter(revt::eSignalEnergyFluenceMag)>maximum){
        maximum = stiter->GetParameter(revt::eSignalEnergyFluenceMag);
      }
    }
    maximum = maximum+0.01*maximum;
    plot_Histogram->SetBinContent(Xbins/2,Ybins/2,maximum);
    plot_Histogram->SetBinContent(Xbins/2+1,Ybins/2+1,0);
    plot_Histogram->Draw("COLZ");
    TGraph *Core = new TGraph();
    Core->SetPoint(0,0.,0.);
    fPlotsObjects->Add(Core);
    Core->SetMarkerStyle(3);
    Core->SetMarkerSize(1.5);
    Core->SetMarkerColor(kGray+2);
    Core->Draw("sameP");
    TGraph *RdCore = new TGraph();
    RdCore->SetPoint(0,r.Parameter(1),r.Parameter(2));
    fPlotsObjects->Add(RdCore);
    RdCore->SetMarkerStyle(3);
    RdCore->SetMarkerSize(1.5);
    RdCore->SetMarkerColor(38);
    RdCore->Draw("sameP");
    gPad->Update();
    TPaletteAxis *palette = (TPaletteAxis*)plot_Histogram->GetListOfFunctions()->FindObject("palette");
    palette->GetAxis();
    TGraph *StationSignal[v_stat.size()];
    TGraph *StationSignalcont[v_stat.size()];
    unsigned int pcount = 0;
    for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {
      if(!stiter->HasParameter(revt::eLDFFitStationPositionVxB) or !stiter->HasParameter(revt::eLDFFitStationPositionVxVxB)){
              continue;
      }
      StationSignal[pcount]=new TGraph();
      StationSignal[pcount]->SetPoint(0,stiter->GetParameter(revt::eLDFFitStationPositionVxB),stiter->GetParameter(revt::eLDFFitStationPositionVxVxB));
      fPlotsObjects->Add(StationSignal[pcount]);
      StationSignalcont[pcount]=new TGraph();
      StationSignalcont[pcount]->SetPoint(0,stiter->GetParameter(revt::eLDFFitStationPositionVxB),stiter->GetParameter(revt::eLDFFitStationPositionVxVxB));
      fPlotsObjects->Add(StationSignalcont[pcount]);
      if(stiter->IsRejected()){
        StationSignalcont[pcount]->SetMarkerStyle(5);
        StationSignalcont[pcount]->SetMarkerSize(2.);
        StationSignalcont[pcount]->SetMarkerColor(kGray+2);
        StationSignalcont[pcount]->Draw("sameP");
      }
      else if(!stiter->HasPulse()){
        StationSignalcont[pcount]->SetMarkerStyle(2);
        StationSignalcont[pcount]->SetMarkerSize(2.);
        StationSignalcont[pcount]->SetMarkerColor(kGray+2);
        StationSignalcont[pcount]->Draw("sameP");
      }
      else if(stiter->IsSaturated()){
        StationSignalcont[pcount]->SetMarkerStyle(20);
        StationSignalcont[pcount]->SetMarkerSize(2.);
        StationSignalcont[pcount]->SetMarkerColor(kGray+2);
        StationSignalcont[pcount]->Draw("sameP");

        StationSignal[pcount]->SetMarkerColor(9);
        StationSignal[pcount]->SetMarkerStyle(20);
        StationSignal[pcount]->SetMarkerSize(1.8);
        StationSignal[pcount]->Draw("sameP");
      } else {
        double value = stiter->GetParameter(revt::eSignalEnergyFluenceMag);
        int stationcolor = palette->GetValueColor(value);
        TColor *c = gROOT->GetColor(stationcolor);
        float x(0), y(0), z(0);
        c->GetRGB(x,y,z);
        StationSignalcont[pcount]->SetMarkerStyle(20);
        StationSignalcont[pcount]->SetMarkerSize(2.);
        StationSignalcont[pcount]->SetMarkerColor(kGray+2);
        StationSignalcont[pcount]->Draw("sameP");
        StationSignal[pcount]->SetMarkerColor(c->GetColor(x,y,z));
        StationSignal[pcount]->SetMarkerStyle(20);
        StationSignal[pcount]->SetMarkerSize(1.8);
        StationSignal[pcount]->Draw("sameP");
      }
      ++pcount;
    }
    plot_Histogram->GetXaxis()->SetRangeUser(-500,500);
    plot_Histogram->GetYaxis()->SetRangeUser(-500,500);
    gPad->Modified();
    gPad->Update();
  } else {
    TText text;
    text.SetTextSize(0.035);
    text.DrawTextNDC(0.4, 0.5, "No 2D-LDF available");
  }
}


void RdPlots::DrawLDF(const int pol)
{
  /*
   This function is still at debug stage and should not be trusted for physics
   TODO
   + Error calculation
   + Check DetectorGeometry->GetRdStationPosition()
   */

  fCanvasLDF->cd();
  // This should be updated to make all the button usable but this is a first version
  int count = 0;
  int noisecount = 0;
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const RdRecShower& rshower = radioevt.GetRdRecShower();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  double axisdistmax = 0.0;
  double amplitudemax = 0.0;
  TGraphErrors *gr_LDF = new TGraphErrors(v_stat.size());
  TGraphErrors *gr_LDFNoise = new TGraphErrors(v_stat.size());

  /*  int nFit = 1000;
  double xFit[nFit], yFit[nFit];
  bool plotLdfFunc = false;
  if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eFitAmplitude) && (*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eFitSlope)) {
    plotLdfFunc = true;
    double fitAmplitude = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eFitAmplitude);
    double fitSlope = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eFitSlope);
    for(int ii = 0; ii < nFit; ++ii) {
      xFit[ii] = ii;
      yFit[ii] = fitAmplitude*exp(-ii/fitSlope)*1e6;
    }
  }
  TGraph *ldfFit = new TGraph(nFit,xFit,yFit); */
  fPlotsObjects->Add(gr_LDF);
  fPlotsObjects->Add(gr_LDFNoise);
  TVector3 axis;
  TVector3 core;
  if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage) ||
     (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis || fIsMC) {
    if(fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) {
      axis = (*fEvent)->GetSDEvent().GetSdRecShower().GetAxisSiteCS();
      core = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS();
    }
    else if(fDrawMCAxis && fIsMC) {
      axis = (*fEvent)->GetGenShower().GetAxisSiteCS();
      core = (*fEvent)->GetGenShower().GetCoreSiteCS();
    }
    else if ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage)){
      axis = radioevt.GetRdRecShower().GetAxisSiteCS();
      core = radioevt.GetRdRecShower().GetCoreSiteCS();
    }
    for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {
      if (stiter->IsRejected()) {
        continue; // Do not draw stations which are rejected
      }
      float amplitude = 0;
      float amplitudeError = 0;
      try {
        if(pol == 0) {
          amplitude = stiter->GetParameter(revt::eSignal)*1e6;
          amplitudeError = stiter->GetParameterError(revt::eSignal)*1e6;
        } else if(pol == 1) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeEW)*1e6;
        } else if(pol == 2) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeNS)*1e6;
        } else if(pol == 3) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeV)*1e6;
        } else if(pol == 4) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeMag)*1e6;
        }
      } catch(...) {
  //      cerr << " RdPlots::DrawLDF :: Caught std::invalid_argument when asking for pulse maximum\n";
      }
      //double axisdist=(*fDetectorGeometry)->GetStationAxisDistance(stiter->GetId(),axis,core); // This should work To be checked !!
      double axisdist = (*fDetectorGeometry)->GetStationAxisDistance((*fDetectorGeometry)->GetRdStationPosition(stiter->GetId()),
          axis, core);
      if(axisdist > axisdistmax)
        axisdistmax = axisdist;
      if(amplitude > amplitudemax)
        amplitudemax = amplitude;
      if (stiter->HasPulse()) {
        gr_LDF->SetPoint(count, axisdist, amplitude);
        gr_LDF->SetPointError(count, 0, amplitudeError);
        count++;
      }
      else {
        gr_LDFNoise->SetPoint(noisecount, axisdist, amplitude);
        gr_LDFNoise->SetPointError(noisecount, 0, amplitudeError);
        noisecount++;
      }
    } // for stiter
    axisdistmax += 0.2 * axisdistmax;
    amplitudemax += 0.2 * amplitudemax;
    ostringstream title;
    title.str("");
    title << " Lateral distribution for polarization " << GetPolarisationNameLDF(pol);
    TH2F *H_ldfaxis = new TH2F("LDF", title.str().c_str(), 300, 0.01, axisdistmax, 300, 0.01, amplitudemax);
    fPlotsObjects->Add(H_ldfaxis);
    if (fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) H_ldfaxis->GetXaxis()->SetTitle("Distance to Sd shower axis [m]");
    else if (fDrawMCAxis && fIsMC) H_ldfaxis->GetXaxis()->SetTitle("Distance to MC shower axis [m]");
    else H_ldfaxis->GetXaxis()->SetTitle("Distance to radio shower axis [m]");
    H_ldfaxis->GetYaxis()->SetTitle("Amplitude [#muV/m]");
    H_ldfaxis->Draw("");
    gr_LDF->SetMarkerStyle(24);
    gr_LDF->Draw("P SAME");
    gr_LDFNoise->SetMarkerStyle(24);
    gr_LDFNoise->SetMarkerColor(kGray);
    gr_LDFNoise->SetLineColor(kGray);
    gr_LDFNoise->Draw("P SAME");
    vector<TGraph*> ldfFitResults;
    const vector<TF1>& ldfR = rshower.GetRdLDF();
    unsigned int ldfc = 0;
    const unsigned int nFit = 1000;
    unsigned int pc = 0;
    double xFit[nFit], yFit[nFit];
    for(ldfc = 0; ldfc < ldfR.size(); ++ldfc) {
      for(pc = 0; pc < nFit; ++pc) {
        xFit[pc] = (axisdistmax / nFit) * pc;
        yFit[pc] = ldfR[ldfc].Eval(xFit[pc])*1e6;
      }
      ldfFitResults.push_back(new TGraph(nFit,xFit,yFit));
      ldfFitResults[ldfFitResults.size()-1]->SetLineColor(ldfR[ldfc].GetLineColor());
    }
    for(ldfc = 0; ldfc < ldfFitResults.size(); ++ldfc) {
      fPlotsObjects->Add(ldfFitResults[ldfc]);
    }
    for(ldfc = 0; ldfc < ldfFitResults.size(); ++ldfc) {
      ldfFitResults[ldfc]->Draw("C");
    }
  } else {
    TText text;
    text.SetTextSize(0.035);
    text.DrawTextNDC(0.4, 0.5, "no LDF available");
  }
  fCanvasLDF->Update();
}

void RdPlots::DrawResiduals()
{
  fCanvasResiduals->cd();
  TGraphErrors *gr_Residuals = new TGraphErrors();
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  fPlotsObjects->Add(gr_Residuals);
  bool hasResiduum = false;
  for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {
    if((stiter->IsRejected()) || !stiter->HasPulse()) {
      continue; // do not draw residuals for rejected or non-signal stations
    }
    if(stiter->HasParameter(revt::eTimeResidual)) {
      hasResiduum = true;
      if(fDrawResAxis) {
        TVector3 axis;
        TVector3 core;
        if(fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) {
          axis = (*fEvent)->GetSDEvent().GetSdRecShower().GetAxisSiteCS();
          core = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS();
        }
        else if(fDrawMCAxis && fIsMC) {
          axis = (*fEvent)->GetGenShower().GetAxisSiteCS();
          core = (*fEvent)->GetGenShower().GetCoreSiteCS();
        }
        else {
          axis = radioevt.GetRdRecShower().GetAxisSiteCS();
          core = radioevt.GetRdRecShower().GetCoreSiteCS();
        }
        double axisdist = (*fDetectorGeometry)->GetStationAxisDistance((*fDetectorGeometry)->GetRdStationPosition(stiter->GetId()), axis, core);
        gr_Residuals->SetPoint(gr_Residuals->GetN(), axisdist, stiter->GetParameter(revt::eTimeResidual));
      }
      else gr_Residuals->SetPoint(gr_Residuals->GetN(), stiter->GetId() , stiter->GetParameter(revt::eTimeResidual));
      if(stiter->HasParameterCovariance(revt::eTimeResidual, revt::eTimeResidual)) {
        gr_Residuals->SetPointError(gr_Residuals->GetN() - 1, 0, stiter->GetParameterError(revt::eTimeResidual));
      } else {
        cout << "WARNING: ParameterError eTimeResidual not set" << endl;
        gr_Residuals->SetPointError(gr_Residuals->GetN() - 1, 0, 0);
      }
      // keeping error output lower
   /*   if(not stiter->HasParameterError(revt::eSignal)) {
        cout << "WARNING ParameterError eSignal not set" << endl;
      }*/
    }
  } // for stiter

  if(hasResiduum) {
    if(!fDrawResAxis) gr_Residuals->GetXaxis()->SetTitle("Station Id");
    else if (fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) gr_Residuals->GetXaxis()->SetTitle("Distance to Sd shower axis [m]");
    else if (fDrawMCAxis && fIsMC) gr_Residuals->GetXaxis()->SetTitle("Distance to MC shower axis [m]");
    else gr_Residuals->GetXaxis()->SetTitle("Distance to radio shower axis [m]");
    gr_Residuals->GetYaxis()->SetTitle("time offset [ns]");
    gr_Residuals->SetMarkerStyle(8);
    gr_Residuals->SetMarkerColor(4);
    // adjust y-range
    double max = TMath::Max(gr_Residuals->GetHistogram()->GetMaximum(), abs(gr_Residuals->GetHistogram()->GetMinimum()));
    gr_Residuals->GetYaxis()->SetRangeUser(-max, max);
    gr_Residuals->Draw("AP");
    fCanvasResiduals->SetGridy();
  } else {
    TText text;
    text.SetTextColor(2);
    text.SetTextSizePixels(30);
    text.SetTextAngle(40);
    text.DrawTextNDC(0.30, 0.40, "No data available");

    text.SetTextColor(1);
    text.SetTextSizePixels(12);
    text.SetTextAngle(0);
    text.DrawTextNDC(0.17, 0.20, "use Module RdWaveFit or RdPlaneFit to reconstruct this quantity");
  }

  fCanvasResiduals->Update();
}

void RdPlots::DrawLorentz()
{
  fCanvasLorentz->cd();
  TH1D *hLorentz = new TH1D("hLorentz", "", 9, 0, 90);
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  fPlotsObjects->Add(hLorentz);
  bool hasLorentz = false;
  for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {
    if( stiter->IsRejected() || !stiter->HasPulse()) {
      continue;
    }
    if(stiter->HasParameter(revt::eAngleToExpectedEFieldVector)) {
        hLorentz->Fill(TMath::RadToDeg() * stiter->GetParameter(revt::eAngleToExpectedEFieldVector));
        hasLorentz = true;
    }
  } // for stiter

  hLorentz->GetXaxis()->SetTitle("#angle(#vec{E}_{measured},#vec{E}_{expected}) [deg]");
  hLorentz->GetYaxis()->SetTitle("Entries");
  hLorentz->Draw();

  if(!hasLorentz) {
    TText text;
    text.SetTextColor(2);
    text.SetTextSizePixels(30);
    text.SetTextAngle(40);
    text.DrawText(40, 0.3, "No data available");

    text.SetTextColor(1);
    text.SetTextSizePixels(12);
    text.SetTextAngle(0);
    text.DrawText(17, 0.2, "use Module RdStationEFieldVectorCalculator");
    text.DrawText(17, 0.17, "to reconstruct this quantity");
  }

  fCanvasLorentz->Update();
}




 string RdPlots::GetPolarisationNameLDF(const int pol)
    {
    switch(pol) {
      case 0:
        return "used in Reconstruction";
      case 1:
        return "East";
      case 2:
        return "North";
      case 3:
        return "Vertical";
      default:
        return "unknown";
  }
}


string RdPlots::GetPolarisationName(const int pol)
{
  switch(pol) {
  case 0:
    return "East";
  case 1:
    return "North";
  case 2:
    return "Vertical";
  default:
    return "unknown";
  }
}

string RdPlots::GetRecStage(const double recStage)
{
  // convert recstage to an int to use a switch statement
  const int nRecStage = int(recStage * 100);
  switch(nRecStage) {
  case 0:
    return "unsuccessful/none";
  case 50:
    return "BaryCenter";
  case 100:
    return "PrePlaneFit";
  case 105:
    return "PlaneFitLinear";
  case 110:
    return "PlaneFitLinear2";
  case 120:
    return "PlaneFit3d";
  case 150:
    return "SphericalWaveFit";
  case 160:
    return "SphericalWaveFitVarC";
  case 170:
    return "ConicalWaveFit";
  case 180:
    return "LDFFit1d";
  case 190:
    return "HyperbolicWaveFit";
  case 200:
    return "LDFFit2d";
  case 220:
    return "LDFFit2dWithCore";
  default:
    stringstream sstr;
    sstr << "unknown = " << recStage;
    return sstr.str();
  }
}

