#ifndef _include_StyleManager_h__
#define _include_StyleManager_h__

#include <map>
#include <string>
#include <vector>

class StyleManager  {

public:
  StyleManager();
  ~StyleManager();

  bool IsInitialized() const {return fIsInitialized;} ///< true if correctly initialized

  int GetStartUpTab() const { return fStartUpTab;}   ///<  tab to focus at startup
  int GetNormalFontType() const { return fNormalFontType;}   ///<  global ROOT font type
  int GetBoldFontType() const { return fBoldFontType;}   ///<  global ROOT font type for bold text

  double GetFDTimeFitDataSize() const { return fFDTimeFitDataSize;}  ///<  size of time fit markers
  double GetFDTimeFitNoiseSize() const { return fFDTimeFitNoiseSize;}

  double GetSDTimeFitDataSize() const { return fSDTimeFitDataSize;}  ///<  size of time fit markers
  int GetSDTimeFitDataType() const { return fSDTimeFitDataType;}  ///<  type of time fit markers
  int GetSDTimeFitStationType() const { return fSDTimeFitStationType;}  ///<  type of time fit markers
  int GetFDTimeFitDataType() const { return fFDTimeFitDataType;}  ///<  type of time fit markers
  int GetFDTimeFitNoiseType() const { return fFDTimeFitNoiseType;}
  int GetFDTimeFitLineColor() const { return  fFDTimeFitLineColor;} ///< color of time fit line
  int GetSDTimeFitLineColor() const { return  fSDTimeFitLineColor;} ///< color of time fit line
  int GetFDTimeMCLineColor() const { return  fFDTimeMCLineColor;}
  double GetProfileDataSize() const { return fProfileDataSize; }
  int GetProfileDataType() const { return fProfileDataType; }
  int    GetProfileFitLineColor() const { return fProfileFitLineColor; }
  int    GetProfileFitErrorColor() const { return fProfileFitErrorColor; }
  int    GetProfileFitErrorFillStyle() const { return fProfileFitErrorFillStyle; }
  bool   ShowFittedXmax() const { return fShowFittedXmax; }
  double GetFittedXmaxSize() const { return fFittedXmaxSize; }
  bool   ShowGeneratedXmax() const { return fShowGeneratedXmax; }
  bool   DrawProfileFitLegend() const { return fDrawProfileFitLegend; }
  double GetGeneratedXmaxSize() const  { return fGeneratedXmaxSize; }
  int    GetGeneratedProfileColor() const { return fGeneratedProfileColor; }
  int    GetAerosolProfileColor() const { return fAerosolProfileColor; }
  int    GetAerosolProfileType() const { return fAerosolProfileType; }
  double GetApertureDataSize(const unsigned int no) const;
  int    GetApertureDataType(const unsigned int no) const;
  int    GetLightFitLineSize() const   { return fLightFitLineSize;}
  int    GetLightMCLineSize() const    { return fLightMCLineSize;}
  int    GetTotalLightColor() const    { return fTotalLightColor;}
  int    GetFluorLightColor() const    { return fFluorLightColor;}
  int    GetMieCLightColor() const     { return fMieCLightColor;}
  int    GetMultScattLightColor() const { return fMultScattLightColor;}
  int    GetRayCLightColor()     const  { return fRayCLightColor;}
  int    GetDirectCLightColor()  const  { return fDirectCLightColor;}
  int    GetRayleighFillStyle()  const {return fRayCumulativeFillStyle;}
  int    GetMieFillStyle()       const {return fMieCumulativeFillStyle;}
  int    GetMultScattFillStyle() const {return fMultScattCumulativeFillStyle;}
  int    GetDirectFillStyle()    const {return fDirCumulativeFillStyle;}

  int    GetEyeLightWithLCEffColor() const {return fEyeLightWithLCEffColor;}
  int    GetTelLightWithLCEffColor() const {return fTelLightWithLCEffColor;}

  int    GetSpotRecTraceColor() const  { return fSpotRecTraceColor;}
  int    GetPixelBorderColor() const {return fPixelBorderColor;}
  int    GetBadPixelBorderColor() const {return fBadPixelBorderColor;}
  int    GetMismatchedPixelBorderColor() const {return fMismatchedPixelBorderColor;}
  int    GetDefaultPixelColor() const  { return fDefaultPixelColor;}
  int    GetPulseRecPixelColor() const  { return fPulseRecPixelColor;}
  int    GetTriggeredPixelColor() const { return fTriggeredPixelColor;}
  int    GetDefaultPixelMarkerColor() const { return fDefaultPixelMarker;}
  int    GetSaturatedPixelFillStyle() const { return fSaturatedPixelFillStyle;}
  int    GetSourceColor() const  { return fSourceColor;}
  int    GetSDColor() const  { return fSDColor;}
  int    GetMCColor() const  { return fMCColor;}
  int    GetFDEyeColor(int iEye) const;
  double GetStartUpZoom() const {return fStartUpZoom;}
  double GetAxisProjectionLength() const {return  fAxisProjectionLength;}
  int    GetTankInDAQColor() const {return  fTankInDAQColor;}
  int    GetTankDefaultColor() const {return  fTankDefaultColor;}
  int    GetTankNoiseColor() const {return  fTankNoiseColor;}
  int    GetTankBadColor() const {return fTankBadColor;}
  int    GetSdGroundTimeStartColor() const {return fSdGroundTimeStartColor;}
  int    GetSdGroundTimeStopColor() const {return fSdGroundTimeStopColor;}
  int    GetSdGroundTimeResidualStartColor() const {return fSdGroundTimeStartColor;}
  int    GetSdGroundTimeResidualStopColor() const {return fSdGroundTimeStopColor;}
  int    GetSdShowerPlaneAzimuthStartColor() const {return fSdShowerPlaneAzimuthStartColor;}
  int    GetSdShowerPlaneAzimuthStopColor() const {return fSdShowerPlaneAzimuthStopColor;}
  int    GetTankTOTStyle() const {return  fTankTOTStyle;}
  int    GetTankDefaultStyle() const {return  fTankDefaultStyle;}
  double GetTankInDAQSize() const {return  fTankInDAQSize;}
  double GetTankBadSize() const {return fTankBadSize;}
  int    GetDefaultEyeColor() const {return  fDefaultEyeColor;}
  double GetEyeRadius() const {return  fEyeRadius;}
  int    GetFDSDPLineColor() const {return fFDSDPLineColor;}
  int    GetSDSDPLineColor() const {return fSDSDPLineColor;}
  int    GetMCSDPLineColor() const {return fMCSDPLineColor;}
  int    GetT3SDPLineColor() const {return fT3SDPLineColor;}
  int    GetLDFFuncColor() const {return fLDFFuncColor;}
  int    GetLDFSilColor() const {return fLDFSilColor;}
  int    GetLDFAccColor() const {return fLDFAccColor;}
  int    GetLDFSatColor() const {return fLDFSatColor;}
  int    GetLDFSatRecColor() const {return fLDFSatRecColor;}
  int    GetLDFCandColor() const {return fLDFCandColor;}
  int    GetLDFOnArrayColor() const {return fLDFOnArrayColor;}

  int    Get3DBackgroundColor() const {return f3DBackgroundColor;}
  int    Get3DColorStationActive() const {return f3DColorStationActive;}
  int    Get3DColorStationInactive() const {return f3DColorStationInactive;}

  double GetLDFMarkerSize() const {return fLDFMarkerSize;}

  int GetRiseTimeColor() const {return fRiseTimeColor;}
  int GetFallTimeColor() const {return fFallTimeColor;}
  int GetTimeResColor() const {return fTimeResColor;}

  int GetPhotonColor() const {return   fPhotonColor; }
  int GetElectronColor() const {return   fElectronColor;}
  int GetMuonColor() const {return   fMounColor; }
  int GetOtherPartColor() const {return   fOtherPartColor; }

  int GetPhotonStyle() const   {return   fPhotonStyle;  }
  int GetElectronStyle() const {return   fElectronStyle;}
  int GetMuonStyle() const     {return   fMounStyle;    }
  int GetOtherPartStyle() const {return   fOtherPartStyle; }

  int GetTankDenseColor() const {return   fTankDenseColor;}
  int GetTankBackgroundColor() const {return  fTankBackgroundColor;}
  int GetMaxZoom() const {return   fMaxZoom;}
  bool FdColorPalette() const {return fFdColorPalette;}
  bool ThreeDColorPalette() const {return f3DColorPalette;}
  void UpdateMuonPalette();
  int  CalculateMuonMapColor(const int contourIter, const int noOfContours) const;
  void ReadStyleFile(char * fileName = NULL);    ///< read user specific options

  void StripComments(std::string& line);

private:

  void SetGlobalStyle();  ///< global plotting style


  bool fIsInitialized;
  int fStartUpTab;
  int fNormalFontType;
  int fBoldFontType;

  // SDP
  int fPixelBorderColor;
  int fBadPixelBorderColor;
  int fMismatchedPixelBorderColor;
  int fDefaultPixelColor;
  int fPulseRecPixelColor;
  int fTriggeredPixelColor;
  int fDefaultPixelMarker;
  int fSaturatedPixelFillStyle;
  int fFDSDPLineColor;
  int fSDSDPLineColor;
  int fMCSDPLineColor;
  int fT3SDPLineColor;
  bool fFdColorPalette;
  bool f3DColorPalette;

  // time fit
  double fFDTimeFitDataSize;
  double fSDTimeFitDataSize;
  double fFDTimeFitNoiseSize;
  int fFDTimeFitDataType;
  int fSDTimeFitDataType;
  int fSDTimeFitStationType;
  int fFDTimeFitNoiseType;
  int fFDTimeFitLineColor;
  int fSDTimeFitLineColor;
  int fFDTimeMCLineColor;

  // dEdX and electrons
  double fProfileDataSize;
  int fProfileDataType;
  int fProfileFitLineColor;
  int fProfileFitErrorColor;
  int fProfileFitErrorFillStyle;
  bool fShowFittedXmax;
  double fFittedXmaxSize;
  bool fShowGeneratedXmax;
  bool fDrawProfileFitLegend;
  double fGeneratedXmaxSize;
  int fGeneratedProfileColor;
  int fAerosolProfileColor;
  int fAerosolProfileType;


  // aperture
  std::vector<double> fApertureDataSize;
  std::vector<int> fApertureDataType;
  int fLightMCLineSize;
  int fLightFitLineSize;
  int fTotalLightColor;
  int fFluorLightColor;
  int fMieCLightColor;
  int fMultScattLightColor;
  int fRayCLightColor;
  int fDirectCLightColor;
  int fRayCumulativeFillStyle;
  int fMieCumulativeFillStyle;
  int fMultScattCumulativeFillStyle;
  int fDirCumulativeFillStyle;

  int fEyeLightWithLCEffColor;
  int fTelLightWithLCEffColor;

  //ADC traces
  int fSpotRecTraceColor;

  // color for source catalogue entries
  int fSourceColor;

  // Auger plot detector colors
  int fSDColor;
  int fMCColor;
  std::map<int,int> fFDEyeColor;
  double fStartUpZoom;

  // array plot options
  double fAxisProjectionLength;
  int fTankInDAQColor;
  int fTankDefaultColor;
  int fTankNoiseColor;
  int fTankBadColor;
  int fSdGroundTimeStartColor;
  int fSdGroundTimeStopColor;
  int fSdGroundTimeResidualStartColor;
  int fSdGroundTimeResidualStopColor;
  int fSdShowerPlaneAzimuthStartColor;
  int fSdShowerPlaneAzimuthStopColor;
  int fTankTOTStyle;
  int fTankDefaultStyle;
  double fTankInDAQSize;
  double fTankBadSize;
  int fDefaultEyeColor;
  double fEyeRadius;

  int fLDFFuncColor;
  int fLDFSilColor;
  int fLDFAccColor;
  int fLDFSatColor;
  int fLDFSatRecColor;
  int fLDFCandColor;
  int fLDFOnArrayColor;
  double fLDFMarkerSize;
  int fRiseTimeColor;
  int fFallTimeColor;
  int fTimeResColor;

  bool fMuonColorPalette;

  // 3D display
  int f3DBackgroundColor;
  int f3DColorStationActive;
  int f3DColorStationInactive;

  //monte carlo SD
  int fPhotonColor;
  int fElectronColor;
  int fMounColor;
  int fOtherPartColor;

  int fPhotonStyle;
  int fElectronStyle;
  int fMounStyle;
  int fOtherPartStyle;

  int fTankDenseColor;
  int fTankBackgroundColor;
  int fMaxZoom;

  int fMuonMapColorRangeStart;
  int fMuonMapColorRangeLength;
};



#endif
