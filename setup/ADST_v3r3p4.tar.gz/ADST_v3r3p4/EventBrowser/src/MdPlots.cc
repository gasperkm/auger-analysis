#include "MdPlots.h"
#include "ArrayPlot.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserConfig.h"

#include "RecEvent.h"
#include "Detector.h"
#include "DetectorGeometry.h"

#include "Detector.h"
#include "SDEvent.h"

#include "StyleManager.h"

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TH1F.h>
#include <TH2F.h>
#include <TH2Poly.h>
#include <TArrow.h>

#include <TClass.h>
#include <TProfile.h>
#include <TLegend.h>
#include <TLegendEntry.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TLatex.h>
#include <TGSlider.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TMarker.h>
#include <TArc.h>
#include <TTimeStamp.h>
#include <TText.h>
#include <TColor.h>
#include <TGDoubleSlider.h>
#include <TPaveText.h>
#include <TStyle.h>
#include <TROOT.h>

#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>

#include <iomanip>

using namespace std;
using namespace view::Consts;


ClassImp(MdPlots);


//#define round(x) (x < 0 ? ceil((x)-0.5) : floor((x) + 0.5))


UInt_t LOWERHEIGHT;
const double lowerLimitNMu = 0.001; // NMu lower than this -> no muons in counter

// Only kept for backward compatibility: signal error needs to be set in the energy reconstruction module
inline
double
StationSignalError(const double signal)
{
  return 1.06*sqrt(signal);
}


inline
void
EnlargeMinMax(const vector<double>& x, const vector<double>& xerr,
              double& tempMin, double& tempMax)
{
  // compute the min,max range according to the values in x
  if (x.empty() || x.size() != xerr.size())
    return;
  for (size_t i = 0, n = x.size(); i < n; ++i) {
    const double currentMax = x[i] + xerr[i];
    const double currentMin = x[i] - xerr[i];
    tempMax = max(currentMax, tempMax);
    tempMin = min(currentMin, tempMin);
  }
}


MdPlots::MdPlots(TGCompositeFrame* const main,
                 const StyleManager* const * styleManager,
                 const DetectorGeometry* const * geom,
                 const RecEvent* const * event,
                 const bool& isMC) :
  fStyleManager(styleManager),
  fEvent(event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fArrayPlot(0)
{
  fSdMdCombinedView = false;

  fTracesObjects= new TObjArray();
  fTracesObjects->SetOwner(kTRUE);
  fEventObjects= new TObjArray();
  fEventObjects->SetOwner(kTRUE);
  fArrayObjects= new TObjArray();
  fArrayObjects->SetOwner(kTRUE);

  fMain= main;
  fMain->SetCleanup(kDeepCleanup);

  fHasFADCTraces=false;
  fHasVEMTraces=false;

  const UInt_t width = UInt_t(main->GetWidth());
  const UInt_t height = UInt_t(main->GetHeight());

  const UInt_t upperHeight = UInt_t(0.58*height);
  const UInt_t lowerHeight = UInt_t(0.46*height);
  LOWERHEIGHT = UInt_t(0.46*height);
  const UInt_t arrayWidth = UInt_t(0.4*width);
  const UInt_t statWidth = UInt_t(0.27*width);
  const UInt_t statHeight = UInt_t(0.7*upperHeight);
  const UInt_t infoHeight = UInt_t(0.5*upperHeight);
  const UInt_t infoWidth = UInt_t(0.3*width);


  TGLayoutHints* mainHorLayout = new TGLayoutHints(kLHintsExpandX
                                                   |kLHintsExpandY,
                                                   1, 1, 1, 1);
  TGLayoutHints* centered= new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,
                                             1,1,1,1);

  TGLayoutHints* centeredX= new TGLayoutHints(kLHintsCenterX,
                                              1,1,1,1);

  TGLayoutHints* centeredExpandXY = new TGLayoutHints(kLHintsExpandX|
                                                      kLHintsExpandY|
                                                      kLHintsCenterX|
                                                      kLHintsCenterY,
                                                      1,1,1,1);

  TGLayoutHints* expandXY = new TGLayoutHints(kLHintsExpandX|
                                              kLHintsExpandY,
                                              1,1,1,1);

  TGLayoutHints* expandY = new TGLayoutHints(kLHintsExpandY,
                                             1,1,1,1);

  TGHorizontalFrame* mainHor1 = new TGHorizontalFrame(main,
                                                      UInt_t(width),
                                                      upperHeight);
  TGHorizontalFrame* mainHor2 = new TGHorizontalFrame(main,
                                                      UInt_t(width),
                                                      lowerHeight);

  main->AddFrame(mainHor1, mainHorLayout);
  main->AddFrame(mainHor2, mainHorLayout);

  TGVerticalFrame* vertical1 = new TGVerticalFrame(mainHor1,
                                                   infoWidth,
                                                   upperHeight);

  mainHor1->AddFrame(vertical1, expandY);
  //================> event info frame <=======================
  fMDEventInfoTab = new TGTab(vertical1, infoWidth, infoHeight);
  TGCompositeFrame *eventInfoFrame = fMDEventInfoTab->AddTab("Event Info");
  TRootEmbeddedCanvas *canvInfoEmb = new TRootEmbeddedCanvas("canvInfoEmb",
                                                             eventInfoFrame,
                                                             infoWidth,
                                                             infoHeight);
  eventInfoFrame->AddFrame(canvInfoEmb, expandY);
  fCanvasInfo= canvInfoEmb->GetCanvas();

  vertical1->AddFrame(fMDEventInfoTab, expandXY);

  /*fArrayZoomButton=new TGHSlider(vertical1, 200,
                                 kSlider2 | kScaleBoth, eSDZoomToCore);
  //fArrayZoomButton->Connect("Pressed()", "SdPlots", this, "DoSdPressed()");
  //fArrayZoomButton->Connect("Released()", "SdPlots", this, "DoSdReleased()");
  fArrayZoomButton->SetRange(0,1000);
  fArrayZoomButton->SetPosition(700);
  vertical1->AddFrame(fArrayZoomButton, centeredX);*/

  // fTracesSlider = new TGDoubleHSlider(horizFrameLDF, 100,
  //                                  kDoubleScaleBoth, 2000,
  //                                  kHorizontalFrame,TColor::Number2Pixel(16),
  //                                  kFALSE, kFALSE);
  // fTracesSlider->Connect("PositionChanged()", "SdPlots", this,
  // "DoTracesSlider()");
  // horizFrameLDF->AddFrame(fTracesSlider,   new TGLayoutHints(
  // kLHintsCenterY |kLHintsRight,3,3,3,3));
  // fTracesSlider->SetRange(-1000,1000);
  // fTracesSlider->SetPosition(-900, 900);
  // fTracesSlider->SetEnabled(false);

  //================> arrray frame <===========================
  TGVerticalFrame* vertical3 = new TGVerticalFrame(mainHor1,
                                                   arrayWidth,
                                                   upperHeight);
  mainHor1->AddFrame(vertical3, /*centered*/expandY);
  TRootEmbeddedCanvas* const canvArrayEmb =
    new TRootEmbeddedCanvas("canvArrayEmb", vertical3, arrayWidth, upperHeight);
  vertical3->AddFrame(canvArrayEmb, centered);
  fCanvasArray= canvArrayEmb->GetCanvas();
  fCanvasArray->SetBottomMargin(0.14);
  fCanvasArray->SetTopMargin(0.06);
  fCanvasArray->GetCanvas()->SetEditable(false);

  /*  const UInt_t ldfWidth = UInt_t(0.48*width);
  TRootEmbeddedCanvas* const canvasLDFEmb =
    new TRootEmbeddedCanvas("canvasLDFEmb", horizFrameldf, ldfWidth, lowerHeight);
  horizFrameldf->AddFrame(canvasLDFEmb, centeredExpandXY);
  fCanvasLDF= canvasLDFEmb->GetCanvas();
  fCanvasLDF->SetBottomMargin(0.14);
  fCanvasLDF->SetTopMargin(0.04);
  fCanvasLDF->SetRightMargin(0.5);*/

  TGVerticalFrame* const vertical2 =
    new TGVerticalFrame(mainHor1, statWidth, upperHeight);
  mainHor1->AddFrame(vertical2, expandXY);

  TGTab* const fSDStatInfoTab = new TGTab(vertical2, infoWidth, infoHeight);
  vertical2->AddFrame(fSDStatInfoTab, expandXY);

  //================> stations frame <=========================
  TGCompositeFrame* const statInfoFrame = fSDStatInfoTab->AddTab("Stations");

  fStationsListBox = new TGListBox(statInfoFrame, 89);
  fStationsListBox->Connect("Selected(Int_t)", "MdPlots", this, "SelectStation()");
  //fStationsListBox->Resize(statWidth, statHeight);
  statInfoFrame->AddFrame(fStationsListBox, expandXY);

  //================> options frame <==========================
  TGCompositeFrame* const optFrame = fSDStatInfoTab->AddTab("Options");
  TGHorizontalFrame* const statHFrame =
    new TGHorizontalFrame(optFrame, statWidth, statHeight);

  optFrame->AddFrame(statHFrame, expandY);

  TGVButtonGroup* const eventButtons = new TGVButtonGroup(statHFrame,"SD");
  statHFrame->AddFrame(eventButtons, centeredX);

  fEventShowCombinedView =
    new TGCheckButton(eventButtons, new TGHotString("MD/SD combined view"), eSDMDCombinedView);

  fEventShowCombinedView->Connect("Clicked()", "MdPlots", this, "DoMdButton()");
  fEventShowCombinedView->SetToolTipText("Show combined view for SD & MD (map, time residuals, ldf)");

  //================> LDF and time residuals frame <===========
  fMDEventTab = new TGTab(mainHor2, UInt_t(width), lowerHeight);
  mainHor2->AddFrame(fMDEventTab, expandXY);

  TGCompositeFrame* const ldfandTResFrame = fMDEventTab->AddTab("LDF and Time");
  TGHorizontalFrame* const horizFrameldf =
    new TGHorizontalFrame(ldfandTResFrame, UInt_t(width), lowerHeight);
  ldfandTResFrame->AddFrame(horizFrameldf, centeredExpandXY);

  const UInt_t ldfWidth = UInt_t(0.48*width);
  TRootEmbeddedCanvas* const canvasLDFEmb =
    new TRootEmbeddedCanvas("canvasLDFEmb", horizFrameldf, ldfWidth, lowerHeight);
  horizFrameldf->AddFrame(canvasLDFEmb, centeredExpandXY);
  fCanvasLDF= canvasLDFEmb->GetCanvas();
  fCanvasLDF->SetBottomMargin(0.14);
  fCanvasLDF->SetTopMargin(0.04);
  fCanvasLDF->SetRightMargin(0.5);

  TRootEmbeddedCanvas* const canvasTResEmb =
    new TRootEmbeddedCanvas("canvasTResEmb", horizFrameldf, ldfWidth, lowerHeight);

  horizFrameldf->AddFrame(canvasTResEmb, centeredExpandXY);
  fCanvasTRes= canvasTResEmb->GetCanvas();
  fCanvasTRes->SetBottomMargin(0.14);
  fCanvasTRes->SetTopMargin(0.04);

  //================> RAW traces frame <=======================
  TGCompositeFrame* const rawTracesFrame = fMDEventTab->AddTab("RAW Traces");

  TGVerticalFrame* const vertFrameRawTraces = new TGVerticalFrame(rawTracesFrame, UInt_t(width), lowerHeight);
  rawTracesFrame->AddFrame(vertFrameRawTraces, centeredExpandXY);

  const UInt_t buttonsHeight = 10;//UInt_t(0.05*lowerHeight);

  TRootEmbeddedCanvas* const canvRawTracesEmb =
    new TRootEmbeddedCanvas("canvRawTracesEmb", vertFrameRawTraces, width, lowerHeight);

  vertFrameRawTraces->AddFrame(canvRawTracesEmb, centeredExpandXY);

  // Horizontal panel for the prev and next buttons
  TGHorizontalFrame *horFrameRawTraces = new TGHorizontalFrame(vertFrameRawTraces, UInt_t(width), buttonsHeight);
  vertFrameRawTraces->AddFrame(horFrameRawTraces, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  // Prev and Next buttons
  fPrevRawTraces = new TGTextButton(horFrameRawTraces, "<<");
  fPrevRawTraces->Connect("Clicked()", "MdPlots", this, "PrevHisto()");
  horFrameRawTraces->AddFrame(fPrevRawTraces, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));
  fPrevRawTraces->SetEnabled(kFALSE);
  fNextRawTraces = new TGTextButton(horFrameRawTraces, ">>");
  fNextRawTraces->Connect("Clicked()","MdPlots", this, "NextHisto()");
  horFrameRawTraces->AddFrame(fNextRawTraces, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  fCanvasRAWTraces = canvRawTracesEmb->GetCanvas();
  fCanvasRAWTraces->SetBottomMargin(0.14);
  fCanvasRAWTraces->SetTopMargin(0.14);//0.15


  //================> RAW traces frame <=======================
  TGCompositeFrame* const rawTracesChannelFrame = fMDEventTab->AddTab("RAW Traces per Channel");

  TGVerticalFrame* const vertFrameRawTracesChannel = new TGVerticalFrame(rawTracesChannelFrame, UInt_t(width), lowerHeight);
  rawTracesChannelFrame->AddFrame(vertFrameRawTracesChannel, centeredExpandXY);

  TRootEmbeddedCanvas* const canvRawTracesChannelEmb =
    new TRootEmbeddedCanvas("canvRawTracesChannelEmb", vertFrameRawTracesChannel, width, lowerHeight);

  vertFrameRawTracesChannel->AddFrame(canvRawTracesChannelEmb,centeredExpandXY);

  // Horizontal panel for the prev and next buttons
  TGHorizontalFrame *horFrameRawTracesChannel = new TGHorizontalFrame(vertFrameRawTracesChannel, UInt_t(width), buttonsHeight);
  vertFrameRawTracesChannel->AddFrame(horFrameRawTracesChannel, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  // Prev and Next buttons
  fPrevRawTracesChannel = new TGTextButton(horFrameRawTracesChannel, "<<");
  fPrevRawTracesChannel->Connect("Clicked()", "MdPlots", this, "PrevHisto()");
  horFrameRawTracesChannel->AddFrame(fPrevRawTracesChannel, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));
  fPrevRawTracesChannel->SetEnabled(kFALSE);
  fNextRawTracesChannel = new TGTextButton(horFrameRawTracesChannel, ">>");
  fNextRawTracesChannel->Connect("Clicked()", "MdPlots", this, "NextHisto()");
  horFrameRawTracesChannel->AddFrame(fNextRawTracesChannel, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  fCanvasRAWTracesChannel = canvRawTracesChannelEmb->GetCanvas();
  fCanvasRAWTracesChannel->SetBottomMargin(0.14);
  fCanvasRAWTracesChannel->SetTopMargin(0.14);


  //================> Counting histo <========================
  TGCompositeFrame* const countHistoFrame = fMDEventTab->AddTab("Counting Histo");

  TGVerticalFrame* const vertFrameCountHisto = new TGVerticalFrame(countHistoFrame, UInt_t(width), lowerHeight);
  countHistoFrame->AddFrame(vertFrameCountHisto, centeredExpandXY);

  TRootEmbeddedCanvas* const canvCountHistoEmb =
    new TRootEmbeddedCanvas("canvCountHistoEmb", vertFrameCountHisto, width, lowerHeight);

  vertFrameCountHisto->AddFrame(canvCountHistoEmb,centeredExpandXY);

  // Horizontal panel for the prev and next buttons
  TGHorizontalFrame *horFrameCountHisto = new TGHorizontalFrame(vertFrameCountHisto, UInt_t(width), buttonsHeight);
  vertFrameCountHisto->AddFrame(horFrameCountHisto, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  // Prev and Next buttons
  fPrevCountHisto = new TGTextButton(horFrameCountHisto, "<<");
  fPrevCountHisto->Connect("Clicked()", "MdPlots", this, "PrevHisto()");
  horFrameCountHisto->AddFrame(fPrevCountHisto, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));
  fPrevCountHisto->SetEnabled(kFALSE);
  fNextCountHisto = new TGTextButton(horFrameCountHisto, ">>");
  fNextCountHisto->Connect("Clicked()", "MdPlots", this, "NextHisto()");
  horFrameCountHisto->AddFrame(fNextCountHisto, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));

  fCanvasCountHisto = canvCountHistoEmb->GetCanvas();
  fCanvasCountHisto->SetBottomMargin(0.14);
  fCanvasCountHisto->SetTopMargin(0.14);


  //================> Dummy <========================
  /*There is a bug here. The pads in the last tab doesn't properly flush when changing the station.
  This problem appears only in the last tab.
  Adding a new tab after counting histo solves it.
  After too much time lost trying to properly fix this, we decided to keep it this way.*/

  /*TGCompositeFrame* const dummyFrame = new TGCompositeFrame(); //It's only virtual

  TGVerticalFrame* const vertFrameDummy = new TGVerticalFrame(dummyFrame, UInt_t(width), lowerHeight);
  dummyFrame->AddFrame(vertFrameDummy, centeredExpandXY);

  TRootEmbeddedCanvas* const canvDummyEmb =
    new TRootEmbeddedCanvas("canvDummyEmb", vertFrameDummy, width, lowerHeight);

  vertFrameDummy->AddFrame(canvDummyEmb, centeredExpandXY);
  TGHorizontalFrame* const horFrameDummy = new TGHorizontalFrame(vertFrameDummy, UInt_t(width), buttonsHeight);
  vertFrameDummy->AddFrame(horFrameDummy, new TGLayoutHints(kLHintsExpandX, 1,1,1,1));
  fCanvasDummy = canvDummyEmb->GetCanvas();*/


}


MdPlots::~MdPlots()
{
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();
  if (fEventObjects->GetEntriesFast())
    fTracesObjects->Delete();
  if (fEventObjects->GetEntriesFast())
    fArrayObjects->Delete();
  delete fEventObjects;
  delete fTracesObjects;
  delete fArrayObjects;

  fMain->Cleanup();
}


void
MdPlots::Clear()
{
  if (fTracesObjects->GetEntriesFast())
    fTracesObjects->Delete();
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();
  if (fArrayObjects->GetEntriesFast())
     fArrayObjects->Delete();

  fCanvasLDF->Clear();
  fCanvasTRes->Clear();
  fCanvasInfo->Clear();
 // fArrayObjects->Clear();
  fCanvasCountHisto->Clear();
  fCanvasRAWTracesChannel->Clear();
  fCanvasRAWTraces->Clear();
  //fCanvasDummy->Clear();

  fCanvasArray->Update();
  fCanvasLDF->Update();
  fCanvasTRes->Update();
  fCanvasInfo->Update();
  fCanvasCountHisto->Update();
  fCanvasRAWTracesChannel->Update();
  fCanvasRAWTraces->Update();
  //fCanvasDummy->Update();
}

void
MdPlots::Update()
{
	Update(true);
}

void
MdPlots::Update(bool selectFirstStation)
{
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();
  if (fArrayObjects->GetEntriesFast())
    fArrayObjects->Delete();

  if (!*fEvent)
    return;

  fMDEventTab->SetEnabled(1, true);
  fMDEventTab->SetEnabled(2, true);
  fMDEventTab->SetEnabled(3, true);
  fMDEventTab->SetEnabled(4, true);

  fMDEventInfoTab->SetEnabled(1, fIsMC);

  MdEventInfo(fCanvasInfo);

  GetMaxAndMinTime();

  //if (fMdArrayOnStatus) {
    //fMdArrayOnStatus = true;
    UpdateArrayPlot();
  //}

  DrawLDF();
  DrawTimeResiduals();
  UpdateStationsList(selectFirstStation);
  SelectStation();
}


/**
 * Update the list of the MD stations in the event.
 *
 * @author sgaravano
 */
void
MdPlots::UpdateStationsList(bool selectFirstStation)
{

 int currentStation = -1;
 if(!selectFirstStation) currentStation=fStationsListBox->GetSelected();

#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0, maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
  fStationsListBox->Layout();
#endif

  MDEvent mdEvent = (*fEvent)->GetMDEvent();
  unsigned int firstId = 0;
  unsigned int lastId = 0;

  fStationsListBox->InsertEntry("LSID | good | bad | area | #muons", headerId, -1);
  fStationsListBox->GetEntry(headerId)->SetBackgroundColor(TColor::Number2Pixel(15));
  fStationsListBox->GetEntry(headerId)->Activate(0);

  for (MDEvent::CounterIterator it = mdEvent.CountersBegin(); it != mdEvent.CountersEnd(); ++it) {
    ostringstream name;
    name.setf(std::ios::fixed, std::ios::floatfield);
    name.precision(1);
    int stationId = it->GetId();
    name << stationId;
    //Good and bad modules
    unsigned int good = 0;
    unsigned int bad = 0;
    for (MdRecCounter::ModuleIterator mi = it->ModulesBegin(); mi != it->ModulesEnd(); ++mi) {
      if (mi->IsRejected()) {
        ++bad;
      } else {
        ++good;
      }
    }

    const double counterArea = it->GetActiveArea();
    const double lowMuonLimit = it->GetNumberOfMuonsLowLimit();
    const double numberOfMuons = it->GetNumberOfMuons();
    name << " " << good << " " << bad;
    //Module area
    name << " " << counterArea << " m2 ";
    //Module muons
    if (!it->IsSaturated()) {
      name << numberOfMuons << " muons";
    } else {
      name << "> " << std::setprecision(0) << lowMuonLimit << " muons (saturated)";
    }
    if (firstId == 0 && it->GetNumberOfMuons() > 0) {
      firstId = stationId;
      lastId = 0;
    }

    fStationsListBox->InsertEntry(name.str().c_str(), stationId, lastId);
    if (it->GetNumberOfMuons() == 0 || !it->HasModules()) {
      fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(18));
    }
    lastId = stationId;
  }

  fStationsListBox->MapSubwindows();
  fStationsListBox->Layout();
  selectFirstStation ? fStationsListBox->Select(firstId) : fStationsListBox->Select(currentStation);
}


/**
 * Load the selected station and update all the traces for the event.
 */
void
MdPlots::SelectStation()
{
  int stationNumber = fStationsListBox->GetSelected();

  if (stationNumber != headerId) {

    //Reset the first histogram
    fCurrentFirstHisto = 0;
    const std::vector<SdRecStation>& stations = (*fEvent)->GetSDEvent().GetStationVector();
    for (unsigned int iS = 0; iS < stations.size(); ++iS)
      if (stations[iS].GetId() == (unsigned int)(fStationsListBox->GetSelected()))
        stationNumber = stations.at(iS).GetId();

    if (stationNumber >= 0) {
      UpdateTracesPlots(stationNumber);
    }
    lastStationId = stationNumber;
  } else {
    fStationsListBox->Select(lastStationId);
  }
}


void
MdPlots::DoMdButton()
{
  if (!*fEvent)
    return;

  TGButton* const button = (TGButton*)(gTQSender);
  UInt_t id = button->WidgetId();
  switch (id) {
  case eSDMDCombinedView:
    fSdMdCombinedView = fEventShowCombinedView->IsDown();
    Update(false);
    //fMDEventTab->SetTab(0);
    break;
  default:
    break;
  }
}

/**
 * Update all the traces for the given station number
 */
void
MdPlots::UpdateTracesPlots(int stNumber)
{
    //Clean all the TCanvas buffers
	RestartTraceCanvas(fCanvasRAWTraces);
	RestartTraceCanvas(fCanvasRAWTracesChannel);
	RestartTraceCanvas(fCanvasCountHisto);
    fTracesObjects->Clear();


    if (!(*fEvent)->GetSDEvent().HasTriggeredStations()){
        DrawLegend(fEventObjects, "no triggered stations",  0.2, 3.0);
        return;
    }

    MDEvent theMdEvent = (*fEvent)->GetMDEvent();

    //For raw traces tab
    vector<TH1I*> histos;
    vector<int> pads;
    vector<double> startTimeForMuon;
    //For counting histo tab
    vector<TH1I*> countingHistos;

    Bool_t isFirst = true; //First Pad with data
    int nroPad = 1; //1 Pad per module

    for (MDEvent::CounterIterator counter = theMdEvent.CountersBegin(); counter != theMdEvent.CountersEnd(); ++counter) {

        const int counterId = counter->GetId();

        if (counterId!=stNumber) {
           continue;
        }

        //Set maximuim Y scale for all Histograms.
        int maximumNormal = 0;
        int maximumNormalCountingHitso = 0;

        int counterSize = counter->GetNumberOfModules();
        fLastHisto = counterSize-1;
        //Enable or disable the histogram navigation buttons
        counterSize <= 4 ? EnableNavigationButtonsTraces(kFALSE) : EnableNavigationButtonsTraces(kTRUE); //Revisar, no cierra, debería ser mas inteligente.

        SDEvent theSdEvent = (*fEvent)->GetSDEvent();
        unsigned int stationId = counter->GetSdPartnerId();
        const SdRecStation* const theSdStation = theSdEvent.GetStationById(stationId);

        /*----------------------------------------------------------------------------------------------------------------------
        |  Reference start second and nano for this counter. Used for the startTimeCorrection. Reference value taken from SD.  |
		-----------------------------------------------------------------------------------------------------------------------*/

		const TVector3 position0 = (*fDetectorGeometry)->GetStationPosition(stNumber);
		const double sdSamplingNanos(25); //Should get this from SD... cannot find it; had to hardcode it.
		double traceStartSecond0(0);
		unsigned int sdSignalStartSlot(0);
    	double sdSignal2TraceStartNano(0);
		double sdSignalStartNano(0);
		double traceStartNano0(0);

		if(theSdStation!=NULL){
			traceStartSecond0 = theSdStation->GetTimeSecond();
			sdSignalStartSlot = theSdStation->GetSignalStartSlot();
	    	sdSignal2TraceStartNano  = (sdSignalStartSlot-.5)*sdSamplingNanos;
			sdSignalStartNano = theSdStation->GetTimeNSecond();
			traceStartNano0 = sdSignalStartNano-sdSignal2TraceStartNano;

		}



        //Last module to show
        int lastModuleToShow = std::min(4, counterSize);

        for (MdRecCounter::ModuleIterator module = (counter->ModulesBegin() + fCurrentFirstHisto); module != (counter->ModulesBegin() + fCurrentFirstHisto + lastModuleToShow); ++module ) {

            int moduleId = module->GetId();

            //If the module is not candidate; prints label 'no data'
            if(!module->IsCandidate() || module->IsRejected()) {
            	DrawNoTracesLegend(nroPad);
            }
            else {

                //----------------------------
                // Build the data for the graphs
                //----------------------------

                // Correction applied to the trace start time of the module. needed for xAxis.
                double startTimeCorrection = GetTimeCorrectionForTrace(counter->GetModule(moduleId), theSdEvent, traceStartSecond0, traceStartNano0, position0);
                //unsigned int firstBin = 99999;

                //Get all traces SUM for traces tab
                vector<unsigned int> traceSum;
                //vectors for traces by channel tab
                vector<int> bins;
                vector<int> channels;

                GetTraceData(counter->GetModule(moduleId), &traceSum, &bins, &channels , startTimeCorrection);

                unsigned int traceSize = traceSum.size();

                std::ostringstream hname;
                hname << "rawTraces_" << counterId << " " <<moduleId;
                DeleteObject(hname.str().c_str()); //Avoid memory leaks

                std::ostringstream htitle;
                htitle << "Station: " << counterId << " - Module: " << moduleId;

                std::ostringstream hnamePerChannel;
                hnamePerChannel << "rawPerChannel_" << counterId << " " <<moduleId;
                DeleteObject(hnamePerChannel.str().c_str()); //Avoid memory leaks

                std::ostringstream hnameCounting;
                hnameCounting << "counting_" << counterId << " " <<moduleId;
                DeleteObject(hnameCounting.str().c_str()); //Avoid memory leaks

                //Histograms limits
                double binning = module->GetSampleTime();
                double xlow = startTimeCorrection-0.5*binning;
                double xhigh = startTimeCorrection+(traceSize-1)*binning+0.5*binning;

                //Get Histo for TraceSum
                TH1I* h1 = new TH1I(hname.str().c_str(),htitle.str().c_str(), traceSize, xlow, xhigh);

                for (unsigned int i=0; i<traceSize; ++i) {
                    h1->SetBinContent(i+1,traceSum.at(i)); // beware shift between vector and histogram index
                }

                double maximum = h1->GetMaximum();

                //module was candidate but had no traces (Yes, it happens).
                if(maximum == 0.) {
                	DrawNoTracesLegend(nroPad);
                }
                else {
                    //---------------------
                    //Create Counting Histo
                    //----------------------
                    std::vector<unsigned int> channelsOn = module->GetChannelsOn();
                    unsigned int nroChanelsOn = channelsOn.size();

                    TH1I* h3 = new TH1I(hnameCounting.str().c_str(),htitle.str().c_str(), nroChanelsOn, xlow, xhigh);

                    for(unsigned int i=0; i < nroChanelsOn; ++i) {
                        if(channelsOn.at(i) != 0) {
                            h3->SetBinContent(i+1, channelsOn.at(i));
                        }
                    }
                    //-------------------------------
                    //Get Graph for Traces by channel
                    //-------------------------------
                    TGraph *h2 = new TGraph(bins.size(), &(bins[0]), &(channels[0]));

                    //-------------------------------
                    //Format Histos
                    //-------------------------------
                    double startBin = module->GetLeadingMuonTime() + startTimeCorrection;
                    double xmin;
                    double xmax;

                    //SD Traces wider than MD.
                    if(fSdMdCombinedView){
                    	xmin = startBin-500;//check
						xmax = startBin+1400;

                    }else{
                        xmin = startBin-100;//check
						xmax = startBin+700;
                    }

                    startTimeForMuon.push_back(startBin);

                    SetTracesHistoAtrr(h1, xmin, xmax, "Samples", isFirst);
                    SetTracesHistoAtrr(h3, xmin, xmax, "Muons", isFirst);
                    SetTracesGraphAtrr(h2,htitle.str().c_str(),hnamePerChannel.str().c_str(),xmin,xmax,isFirst);
                    if(isFirst) isFirst = kFALSE;


                    //Maximum Y for all histogram
                    if(maximumNormal < h1->GetMaximum()) {
                        maximumNormal = h1->GetMaximum();
                    }
                    if(maximumNormalCountingHitso < h3->GetMaximum()) {
                        maximumNormalCountingHitso = h3->GetMaximum();
                    }

                    pads.push_back(nroPad);
                    histos.push_back(h1);
                    countingHistos.push_back(h3);

                    fCanvasRAWTracesChannel->cd(nroPad);
                    h2->Draw("ALP");
                    fTracesObjects->Add(h2);
                }
            }
            nroPad++;

        }


        bool isLast = false;
        bool isFirst = false;
        //Set Maximum Y and Draw
        for (unsigned int i = 0; i < pads.size(); ++i) {

        	//I only draw Y axis title in the first pad for MD and in the last pad for SD
        	i == pads.size()-1 ? isLast = true : isLast = false;
        	i == 0 ? isFirst = true : isFirst = false;

            //Raw Traces
            histos.at(i)->SetMaximum(maximumNormal);
            DrawHisto(fCanvasRAWTraces, histos.at(i), theSdStation, startTimeForMuon.at(i), sdSignal2TraceStartNano, pads.at(i), isFirst, isLast);
            fTracesObjects->Add(histos.at(i));

            //Counting Histos
            countingHistos.at(i)->SetMaximum(maximumNormalCountingHitso);
            DrawHisto(fCanvasCountHisto, countingHistos.at(i), theSdStation, startTimeForMuon.at(i), sdSignal2TraceStartNano, pads.at(i), isFirst, isLast);
            fTracesObjects->Add(countingHistos.at(i));

        }

    }
    UpdateCanvas(fCanvasRAWTraces);
    UpdateCanvas(fCanvasRAWTracesChannel);
    UpdateCanvas(fCanvasCountHisto);

}

//Draw MD & SD (if it's combined view) raw traces and counting histos.
void
MdPlots::DrawHisto(TCanvas* myCanvas, TH1 * histo, const SdRecStation* const theSdStation, double startTimeForMuon, double
		sdSignal2TraceStartNano, int nroPad, Bool_t isFirst, Bool_t isLast){

	//Trying to put the histos title above the frame. No success.
	/*myCanvas->SetTopMargin(0.0);
	myCanvas->cd(nroPad);
	gPad->SetTopMargin(0.0);
	TPad *pad1 = new TPad("pad1","",0,0,1,1);
	pad1->SetLeftMargin(0);
	pad1->SetRightMargin(0);
	pad1->SetTopMargin(0);
	//pad1->SetBottomMargin(0);

	pad1->Draw();
	pad1->cd();
	DrawLegend(fTracesObjects, histo->GetTitle(), 0.0, 1.0, 0.045);*/
	//myCanvas->SetTopMargin(0.15);

	myCanvas->cd(nroPad);

	//If it's combined view, two pads are needed to overlap the SD and MD histos.

    if(fSdMdCombinedView) {

    	TPad *pad2 = new TPad("pad2","",0,0,1,1);
		pad2->SetLeftMargin(0);
		pad2->SetRightMargin(0);
		pad2->SetTopMargin(0);
        if(isLast){
        	gPad->SetRightMargin(0.16);
        	pad2->SetRightMargin(0.16);
        }else if(isFirst) {
        	gPad->SetLeftMargin(0.14);
        	pad2->SetLeftMargin(0.14);
        }
		pad2->Draw();
		pad2->cd();
		histo->Draw();

		if(theSdStation!=NULL){
			myCanvas->cd(nroPad);
			DrawSDTraces(startTimeForMuon, sdSignal2TraceStartNano, theSdStation, histo, isFirst, isLast);
		}

    }else{
    	//If it's not combined view, I can draw the histo directly.
        if(isLast) gPad->SetRightMargin(0.14);
    	histo->Draw();
    }

}

//Draw SD Average trace (from the 3 PMTs) over the MD histos.
//Time sync explained at GAP 2015-75
void
MdPlots::DrawSDTraces(Double_t mdSignalStartNano, Double_t sdSignalStartNano, const SdRecStation* const theSdStation, TH1* mdHisto, bool isFirst, bool isLast)
{

	  TPad *pad3 = new TPad("pad3","",0,0,1,1);
	  pad3->SetLeftMargin(0);

	  //Margins are a nightmare.
	  if(isFirst){
		  pad3->SetLeftMargin(0.14);
	  }else{
		  pad3->SetLeftMargin(0);
	  }

	  if(isLast){
		  pad3->SetRightMargin(0.16);
	  }else{
		  pad3->SetRightMargin(0);
	  }

	  pad3->SetTopMargin(0);
	  pad3->Draw();
	  pad3->cd();
	  pad3->SetFillStyle(0);  // make pad transparent
	  pad3->SetFrameFillStyle(0); // make pad transparent

	  TH1D* sdHisto = GetAverageSdTrace(theSdStation);

	  if(sdHisto){
		  sdHisto->GetXaxis()->SetRangeUser(mdSignalStartNano-500,mdSignalStartNano+1400);
		  sdHisto->GetXaxis()->SetTickLength(0);
                  //		  sdHisto->GetXaxis()->SetTickSize(0);
		  sdHisto->GetYaxis()->SetNdivisions(7);

		  sdHisto->SetLineColor(kRed);
		  std::ostringstream hname;
		  hname << mdHisto->GetName() << "__SDTrace";
		  sdHisto->SetName(hname.str().c_str());


		  //Draw arrows to show startTime
		  // Plot the SD start time
		  double ymax = sdHisto->GetMaximum();
		  //sdHisto->SetMaximum(ymax);
		  sdHisto->SetMinimum(0);
		  TArrow *arrow1 = new TArrow(sdSignalStartNano, ymax, sdSignalStartNano, 0, 0.005);
		  arrow1->SetLineColor(kGreen+2);
		  arrow1->Draw();

		  // Plot the MD start time
		  double ymax2 = mdHisto->GetMaximum()*.2;
		  TArrow *arrow2 = new TArrow(mdSignalStartNano, -ymax2, mdSignalStartNano, 0, 0.005);
		  arrow2->SetLineColor(kGreen+2);
		  arrow2->Draw();

		  // Legend and Y axis for SD. Only in the last pad
		  if(isLast){
			  sdHisto->GetYaxis()->SetTitle("Signal (VEM)");
			  sdHisto->GetYaxis()->SetTitleSize(0.05);
			  sdHisto->GetYaxis()->SetTitleOffset(1.1);
			  sdHisto->GetYaxis()->CenterTitle();

			  TLegend* const leg = new TLegend(0.25, 0.75, 0.4, 0.9, NULL, "brNDC");
			  leg->AddEntry(sdHisto,"SD","L");
			  leg->AddEntry(mdHisto,"MD","L");
			  leg->SetFillColor(0);
			  leg->SetLineColor(0);
			  leg->Draw("SAME");
			  fTracesObjects->Add(leg);
		  }

		  sdHisto->Draw("X+Y+");
		  fTracesObjects->Add(sdHisto);
	  }

}

// Get the average VEM histogram over all working PMTs
TH1D*
MdPlots::GetAverageSdTrace(const SdRecStation* theSdStation) {

	TH1D* hSdTrace(NULL);
	unsigned int numberOfPmts(0);
	for(unsigned short pmtId=1; pmtId<=3; ++pmtId) {

		if (!theSdStation->HasPMTTraces(eTotalTrace,pmtId)) {
			continue;
		}
		const Traces& sdTrace = theSdStation->GetPMTTraces(eTotalTrace, pmtId);

		const std::vector<float>& vSdTrace = sdTrace.GetVEMComponent();

		if (vSdTrace.size()==0) {
			continue;
		}

		// create a histogram with sd trace values assigned to bin centres
		if (hSdTrace==NULL) {
			unsigned int sdTraceSize = vSdTrace.size();
			const double sdSamplingNanos(25); //Should get this from SD... cannot find it; had to hardcode it.
			double xmin = -.5*sdSamplingNanos;
			double xmax = (sdTraceSize-1+0.5)*sdSamplingNanos;
			hSdTrace = new TH1D("", "", sdTraceSize, xmin, xmax);
		}

		// Move SD data to the histogram
		for(unsigned int i=0; i<vSdTrace.size(); ++i) {
			int bin = i+1;
			hSdTrace->AddBinContent(bin, vSdTrace[i]);
		}

		++numberOfPmts;

	}
	if(numberOfPmts > 0) hSdTrace->Scale(1./double(numberOfPmts));

	return hSdTrace;
}

//Delete object from global. Avoid potential memory leaks.
void
MdPlots::DeleteObject(TString name){
	TObject *obj = ((TObject *)(gROOT->FindObject(name)));
	if ( obj !=NULL) { delete obj;}

}

//Clean the canvas and regenerate the pads.
void
MdPlots::RestartTraceCanvas(TCanvas* myCanvas)
{
    //Clean all the TCanvas buffers
	myCanvas->SetEditable(true);
	myCanvas->Clear();

    myCanvas->SetLeftMargin(0.12);//0.15
    myCanvas->SetRightMargin(0.1);//0.15

    //We fix in the standard canvas size, 4 graphs. If the counter has more than 4 modules, you can scroll.
    myCanvas->Divide(4,1,0.1,0);
}

void
MdPlots::UpdateCanvas(TCanvas* myCanvas)
{
	myCanvas->Modified();
	myCanvas->Update();
}

//Draw Legend and add it to ObjArray.
TLatex*
MdPlots::DrawLegend(TObjArray* objArray, TString text, Double_t x, Double_t y, Double_t size)
{
    TLatex* erlegend=new TLatex();
    erlegend->SetNDC(kFALSE);
    erlegend->SetTextAlign(12);
    erlegend->SetTextSize(size);
    erlegend->DrawLatex(x,y,text);
    objArray->Add(erlegend);
    return erlegend;
}

//If the module is not candidate or isempty (apparently may not be both), draw a label in all the tabs for the module's pad.
void
MdPlots::DrawNoTracesLegend(Int_t nroPad)
{
    fCanvasRAWTraces->cd(nroPad);
    gPad->SetFillStyle(0);
    gPad->SetFrameFillStyle(0);
    TLatex* erlegend = DrawLegend(fTracesObjects, "no trace data");

    fCanvasRAWTracesChannel->cd(nroPad);
    gPad->SetFillStyle(0);
    gPad->SetFrameFillStyle(0);
    erlegend->DrawLatex(0.4,0.5,"no trace data");

    fCanvasCountHisto->cd(nroPad);
    gPad->SetFillStyle(0);
    gPad->SetFrameFillStyle(0);
    erlegend->DrawLatex(0.4,0.5,"no trace data");

}


void
MdPlots::EnableNavigationButtonsTraces(Bool_t enable)
{


    fNextRawTraces->SetEnabled(enable);
    fNextRawTracesChannel->SetEnabled(enable);
    fNextCountHisto->SetEnabled(enable);

    if(!enable){
    	fPrevRawTraces->SetEnabled(enable);
    	fPrevRawTracesChannel->SetEnabled(enable);
    	fPrevCountHisto->SetEnabled(enable);
    }

}

//Formatting for histos.
void
MdPlots::SetTracesHistoAtrr(TH1* h, UInt_t xmin, UInt_t xmax, TString title, Bool_t isFirst)
{

	 h->GetXaxis()->SetRangeUser(xmin,xmax);
	 h->GetXaxis()->SetNdivisions(6);
	 h->GetYaxis()->SetNdivisions(6);
	 h->SetLineColor(kBlue);
     //Set Labels only for the first Pad
	 if (isFirst) {
		 h->GetYaxis()->SetTitle(title);
		 h->GetYaxis()->SetTitleSize(0.05);
		 //h->GetYaxis()->SetTitleOffset(1.1);
		 h->GetYaxis()->CenterTitle();
		 h->GetXaxis()->SetTitle("Time (ns)");
		 h->GetXaxis()->CenterTitle();

	 }
	 h->GetXaxis()->SetLabelSize(0.04);
}

//Formatting for tarces per channel graph.
void
MdPlots::SetTracesGraphAtrr(TGraph* h, TString htitle, TString hname, UInt_t xmin, UInt_t xmax, Bool_t isFirst)
{

	h->GetXaxis()->SetRangeUser(xmin,xmax);
	h->GetXaxis()->SetNdivisions(6);
	h->GetYaxis()->SetNdivisions(6);
    h->SetTitle(htitle);
    h->SetLineColor(0);
    h->SetMarkerStyle(21);
    h->SetMarkerColor(kRed);
    h->SetMarkerSize(0.5);
    h->SetMaximum(65);
    h->SetMinimum(0);
    h->SetName(hname);
    //Set Labels only for the first Pad
	 if (isFirst) {
		 h->GetYaxis()->SetTitle("Channel");
		 h->GetYaxis()->SetTitleSize(0.05);
		 h->GetYaxis()->CenterTitle();
		 h->GetXaxis()->SetLabelSize(0.04);
		 h->GetXaxis()->SetTitle("Time (ns)");
		 h->GetXaxis()->CenterTitle();

	 }
}

//Get the sum of al the channels from the modules for the raw traces tab, and the data for the raw traces per channel tab.
//Raw traces per channel is a TGraph. Bin,channel are x,y dots for this TGraph.
void
MdPlots::GetTraceData(MdRecModule* module, std::vector<unsigned int>* traceSum,std::vector<int>* bins ,std::vector<int>* channels, double startTimeCorrection){

    //vectors for traces by channel tab
    unsigned int traceSize = 0;

    for (MdRecModule::ChannelIterator channel = module->ChannelsBegin(); channel != module->ChannelsEnd(); ++channel ) {

        if(!channel->HasTrace()) continue;
        const std::vector<char>& adstTrace = channel->GetTrace();

        // initialize sum
        if (traceSize == 0) {
            // Initialize
            traceSize = adstTrace.size();
            for(unsigned int i=0; i<traceSize; ++i) {
                traceSum->push_back(adstTrace.at(i));
            }
        }
        else {
            if(adstTrace.size()==traceSize) {
            	double binning = module->GetSampleTime();
                for(unsigned int i=0; i<traceSize; ++i) {
                    //For traces histo
                    if(adstTrace.at(i)!=char(0)) {
                        traceSum->at(i) += adstTrace.at(i);
                        bins->push_back(startTimeCorrection+i*binning);
                        channels->push_back(channel->GetId());
                    }
                    //For traces per channel histo
                }
            }
        }
    } // end channel loop

}

//Gets the time correction for each module. The reference time is given by the SD station time.
double
MdPlots::GetTimeCorrectionForTrace(MdRecModule* module, SDEvent theSdEvent, const double traceStartSecond0, const double traceStartNano0, const TVector3 position0)
{

	//return value
	double startTimeCorrection(0);

    unsigned long traceStartSecond = module->GetChannelsOnStartSecond();
    double traceStartNano = module->GetChannelsOnStartNano();
    TVector3 position2 = module->GetPosition();

    // Nanoseconds between the start of this module traces wrt to the first module
    double relTraceStartNano = (traceStartSecond-traceStartSecond0)+(traceStartNano-traceStartNano0);

    startTimeCorrection += relTraceStartNano;

    const TVector3& showerAxis = theSdEvent.GetSdRecShower().GetAxisSiteCS();
    double c = 0.3; // speed of light in m/ns
    double s = (position2-position0).Dot(showerAxis);
    double positionCorrectionNanos = s/c;

    startTimeCorrection += positionCorrectionNanos;

    return startTimeCorrection;
}

/**
 * Perform the previous histogram action.
 */
void
MdPlots::PrevHisto()
{
  if (fCurrentFirstHisto > 0) {
    --fCurrentFirstHisto;
    fPrevRawTraces->SetEnabled(kTRUE);
    fPrevRawTracesChannel->SetEnabled(kTRUE);
    fPrevCountHisto->SetEnabled(kTRUE);
    UpdateTracesPlots(fStationsListBox->GetSelected());
  } else {
    fPrevRawTraces->SetEnabled(kFALSE);
    fPrevRawTracesChannel->SetEnabled(kFALSE);
    fPrevCountHisto->SetEnabled(kFALSE);
  }
}


/**
 * Perform the next histogram action.
 */
void
MdPlots::NextHisto()
{
  if (fCurrentFirstHisto < fLastHisto-3) {
    ++fCurrentFirstHisto;
    fNextRawTraces->SetEnabled(kTRUE);
    fNextRawTracesChannel->SetEnabled(kTRUE);
    fNextCountHisto->SetEnabled(kTRUE);
    fPrevRawTraces->SetEnabled(kTRUE);
    fPrevRawTracesChannel->SetEnabled(kTRUE);
    fPrevCountHisto->SetEnabled(kTRUE);

    UpdateTracesPlots(fStationsListBox->GetSelected());


  } else {
    fNextRawTraces->SetEnabled(kFALSE);
    fNextRawTracesChannel->SetEnabled(kFALSE);
    fNextCountHisto->SetEnabled(kFALSE);
    fPrevRawTraces->SetEnabled(kTRUE);
    fPrevRawTracesChannel->SetEnabled(kTRUE);
    fPrevCountHisto->SetEnabled(kTRUE);
  }
}


/**
 * Read the event information and puts it in the information canvas.
 */
void
MdPlots::MdEventInfo(TCanvas* const myCanvas)
{
  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const float x1 = 0.03;
  const float x2 = 0.05;
  // const float x3 = 0.7;
  const float dy = 0.055;
  float y = 0.95;

  const SDEvent &sdEvent = (*fEvent)->GetSDEvent();
  const MDEvent &mdEvent = (*fEvent)->GetMDEvent();

  TLatex latex;
  latex.SetTextSize(0.045);

  ostringstream info;

  //Event ID
  info << "Event " << (*fEvent)->GetAugerId();
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex(x1, y, info.str().c_str());
  y -= dy;

  //UTC Time
  const unsigned int yymmdd = (*fEvent)->GetYYMMDD();
  const unsigned int hhmmss = (*fEvent)->GetHHMMSS();
  const unsigned int year = yymmdd / 10000 + 2000;
  const unsigned int month = (yymmdd % 10000) / 100;
  const unsigned int day = yymmdd % 100;
  const unsigned int hour = int(hhmmss / 10000.);
  const unsigned int minute = (hhmmss % 10000) / 100;
  const unsigned int second = hhmmss % 100;
  {
    ostringstream info;
    info << "Time (UTC): " << year << '/' << month << '/' << day << ' '
         << setw(2) << setfill('0') << hour << ':'
         << setw(2) << setfill('0') << minute << ':'
         << setw(2) << setfill('0') << second << ' ';
    latex.SetTextFont((*fStyleManager)->GetNormalFontType());
    latex.DrawLatex(x2, y, info.str().c_str());
    y -= dy;
  }

  //GPS time
  const int lGPSsec = sdEvent.GetGPSSecond();
  const int lGPSnsec = sdEvent.GetGPSNanoSecond();
  info.str("");
  info << "Time (GPS): " << lGPSsec << " s " << lGPSnsec << " ns";
  latex.DrawLatex(x2, y, info.str().c_str());
  y -= dy;

  //Number of counters
  const unsigned int counters = mdEvent.GetNumberOfCounters();
  info.str("");
  info << "Counters: " << counters;
  latex.DrawLatex(x2, y, info.str().c_str());
  y -= dy;

  info.str("");
  info << "Reconstruction:";
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex(x1, y, info.str().c_str());
  y -= dy;

  //Get SD Recostruction shower
  //const SdRecShower& sdRecShower= sdEvent.GetSdRecShower();
  //Get MD Recostruction shower
  const MdRecShower& mdRecShower= mdEvent.GetMdRecShower();

  //Check if the event is recostructed
  if (mdRecShower.IsReconstructed()) {
    //NMuRef
    {
      ostringstream info;
      info << showpoint << setiosflags(ios::fixed) << setprecision(2)
           << "#rho(450) = " << mdRecShower.GetNMuRef();
      if (mdRecShower.GetNMuRefError() > 0)
        info << " #pm " << mdRecShower.GetNMuRefError();
      info << " #mu/m^{2}";
      latex.SetTextFont((*fStyleManager)->GetNormalFontType());
      latex.DrawLatex(x2, y, info.str().c_str());
      y -= dy;
    }

    //Beta
    {
      ostringstream info;
      info << showpoint << setiosflags(ios::fixed) << setprecision(2)
           << "#beta = " << mdRecShower.GetBeta();
      if (mdRecShower.GetBetaError() > 0)
        info << " #pm " << mdRecShower.GetBetaError();
      else
        info << " (fixed)";
      latex.DrawLatex(x2, y, info.str().c_str());
      y -= dy;
    }

    //Angles from SD
    if (sdEvent.HasAxis()) {
      ostringstream info;
      info << showpoint << setiosflags(ios::fixed) << setprecision(1)
           << "(#theta, #phi) = ( " << mdRecShower.GetZenith()/degree << " #pm "
           << mdRecShower.GetZenithError()/degree << ", "
           << mdRecShower.GetAzimuth()/degree << " #pm "
           << mdRecShower.GetAzimuthError()/degree << " ) deg (from SD)";
      latex.DrawLatex(x2, y, info.str().c_str());
      y -= dy;
    }

    const TVector3& showerCore = mdRecShower.GetCoreSiteCS();
    const double xC = showerCore.X() / 1000;
    const double yC = showerCore.Y() / 1000;
    const double xC_err = mdRecShower.GetCoreEastingError() / 1000;
    const double yC_err = mdRecShower.GetCoreNorthingError() / 1000;
    ostringstream info;
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "(x,y) = ("
         << xC << " #pm " << xC_err
         <<", " << yC << " #pm "
         << yC_err << ") km (from SD)";
    latex.DrawLatex(x2, y, info.str().c_str());
    y -= dy;
  } else {
    info.str("");
    info << showpoint << "Not Reconstructed.";
    latex.SetTextFont((*fStyleManager)->GetNormalFontType());
    latex.DrawLatex(x2, y, info.str().c_str());
    y -= dy;
  }
  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}


void
MdPlots::DrawLDF()
{
  fCanvasLDF->cd();
  fCanvasLDF->Clear();
  fCanvasLDF->SetLogy();

  gStyle->SetPadLeftMargin(0.12);
  gStyle->SetPadRightMargin(0.11);

  TPad* pad1 = new TPad("pad1","",0,0,1,1);
  pad1->Draw();
  pad1->cd();
  pad1->SetLogy();

  MDEvent theMdEvent = (*fEvent)->GetMDEvent();

  const MdRecShower& mdRecShower= theMdEvent.GetMdRecShower();
  if (!mdRecShower.IsReconstructed()) {
  	  DrawLegend(fEventObjects, "Event not reconstructed", 0.2, 3.0);
  	  fCanvasLDF->GetCanvas()->Modified();
  	  fCanvasLDF->GetCanvas()->Update();

  	  return;
  }
  if (theMdEvent.HasLDF()) {
  //if (true) {

	MdRecShower& MdRecShower = theMdEvent.GetMdRecShower();

	//Check if the event is reconstructed

    const double cosZenith = MdRecShower.GetCosZenith();

    if(cosZenith < 0.2){
  	  DrawLegend(fEventObjects, "Zenith > 80#circ; Wrong reconstruction", 0.2, 3.0);
  	  fCanvasLDF->GetCanvas()->Modified();
  	  fCanvasLDF->GetCanvas()->Update();

  	  return;
    }

    std::vector<double> vx, vy, vxe, vyehigh, vyelow;

    for (MDEvent::CounterIterator counter = theMdEvent.CountersBegin(); counter != theMdEvent.CountersEnd(); ++counter) {

      if (!counter->IsCandidate())
        continue;

      const double distance = counter->GetSPDistance();

      const double density = counter->GetMuonDensity() / cosZenith;
      const double densityEHigh = counter->GetMuonDensityErrorHigh() / cosZenith;
      const double densityELow = counter->GetMuonDensityErrorLow() / cosZenith;

      vx.push_back(distance);
      vy.push_back(density);
      vyehigh.push_back(densityEHigh);
      vyelow.push_back(densityELow);
      //Draw silents
      if (counter->IsSilent() || counter->GetNumberOfMuons() < lowerLimitNMu) {//Tried to make this better; sorry... I couldn't. Should have a flag from reconstruction
         TArrow* ar1 = new TArrow(distance, 0.5, distance, 0.3, 0.02);
         ar1->SetLineColor(kGreen + 2);
         fEventObjects->Add(ar1);
         ar1->Draw();
      }
    }

    //If there're no candidates we should not be here; but just in case, let's avoid any possible crash...
    if (vx.empty() || vy.empty()){

        DrawLegend(fEventObjects, "no ldf",  0.2, 3.0);

    }else{
        // TGraph for the detector positions
        TGraphAsymmErrors* grMd = new TGraphAsymmErrors(vx.size(), &(vx[0]), &(vy[0]), &(vxe[0]), &(vxe[0]), &(vyehigh[0]), &(vyelow[0]));

        const double vyMax = *std::max_element(vy.begin(), vy.end());
        const double vyMin = *std::min_element(vy.begin(), vy.end());
        grMd->SetMaximum(10.*vyMax);
        grMd->SetMinimum(vyMin*0.1);

        // plot style settings
        unsigned int colors[] = { kBlue, kRed };
        unsigned int markers[] = { kFullCircle, kFullSquare };
        unsigned int lines[] = { 1, 2 };

        // Set titles
        grMd->SetTitle("");
        grMd->GetXaxis()->SetTitle("Distance (m)");
        grMd->GetYaxis()->SetTitle("Muon density (m^{-2})");
        grMd->GetYaxis()->SetTitleOffset(0.95);

        // xrange
        double xmin, xmax;

        // Set axis limits
        xmin = grMd->GetXaxis()->GetXmin()*0.9;
        xmax = grMd->GetXaxis()->GetXmax()*1.1;

        grMd->GetXaxis()->SetLimits(xmin,xmax);

        grMd->SetMarkerStyle(markers[0]);
        grMd->SetMarkerColor(colors[0]);
        grMd->SetLineStyle(lines[0]);
        grMd->SetLineColor(colors[0]);

        grMd->Draw("AP");
        fEventObjects->Add(grMd);

        // Build a TF1 with the LDF
        TF1* const ldfMd = new TF1("ldfMd1", MdRecShower, xmin, xmax, 0);
        ldfMd->SetLineColor(colors[0]);
        ldfMd->SetLineStyle(lines[0]);
        ldfMd->SetLineWidth(1);

        fEventObjects->Add(ldfMd);
        ldfMd->Draw("SAME");

        //Draw SD Ldf if it's a combined view
        SDEvent theSdEvent = (*fEvent)->GetSDEvent(); //Just in case, check LDF in SDEvent
        if (fSdMdCombinedView && theSdEvent.HasLDF()) {
          std::vector<double> vxSd, vySd, vxeSd, vyeSd;

          SdRecShower& theSdRecShower = theSdEvent.GetSdRecShower();

          for (MDEvent::CounterIterator counter=theMdEvent.CountersBegin(); counter != theMdEvent.CountersEnd(); ++counter) {

            unsigned int id = counter->GetSdPartnerId();
            if(!theSdEvent.HasStation(id)) continue;

            const SdRecStation* station = theSdEvent.GetStationById(id);
            const double distance = station->GetSPDistance();
            const double distanceError = station->GetSPDistanceError();

            if (!station->IsCandidate()) continue;  // skip not candidate stations

            double signal, signalError;
            if(station->IsLowGainSaturated()) {
              signal = station->GetRecoveredSignal();
              signalError = station->GetRecoveredSignalError();
            } else {  // not staturated
              signal = station->GetTotalSignal();
              signalError = station->GetTotalSignalError();
            }

            vxSd.push_back(distance);
            vxeSd.push_back(distanceError);
            vySd.push_back(signal);
            vyeSd.push_back(signalError);

          }

          // Draw SD Data
          // make a transparent pad to superpose the sd and md data
          fCanvasLDF->cd();
          TPad *pad2 = new TPad("pad2","",0,0,1,1);
          pad2->Draw();
          pad2->cd();
          pad2->SetLogy();
          pad2->SetFillStyle(0);  // make pad transparent
          pad2->SetFrameFillStyle(0); // make pad transparent

          // TGraph for the detector positions
          TGraphErrors *grSd = new TGraphErrors(vxSd.size(), &(vxSd[0]), &(vySd[0]), 0, &(vyeSd[0]));

          double vyMax = *std::max_element(vySd.begin(), vySd.end());
          double vyMin = *std::min_element(vySd.begin(), vySd.end());
          grSd->SetMaximum(2.*vyMax);
          grSd->SetMinimum(vyMin/2);
          grSd->SetTitle("");
          grSd->GetYaxis()->SetTitle("Signal (VEM)");
          grSd->GetYaxis()->SetTitleOffset(.93);
          grSd->GetXaxis()->SetLimits(xmin,xmax);
          grSd->SetMarkerStyle(markers[1]);
          grSd->SetMarkerColor(colors[1]);
          grSd->SetLineColor(colors[1]);
          grSd->Draw("APEY+");
          fEventObjects->Add(grSd);

          TF1 *ldfSd = new TF1(theSdRecShower.GetLDF().GetFunction(eNKG));
          ldfSd->SetLineColor(colors[1]);
          ldfSd->SetLineStyle(lines[1]);
          ldfSd->SetLineWidth(1);
          fEventObjects->Add(ldfSd);
          ldfSd->Draw("SAME");

          //And create legend
          TLegend *leg = new TLegend(0.70,0.75,0.85,0.9,NULL,"brNDC");
          leg->AddEntry(grSd,"SD","p");
          leg->AddEntry(grMd,"MD","p");
          leg->SetFillColor(0);
          leg->SetLineColor(0);
          leg->Draw();

        }
    }
  }else{

	  DrawLegend(fEventObjects, "no ldf",  0.2, 3.0);
  }


  fCanvasLDF->GetCanvas()->Modified();
  fCanvasLDF->GetCanvas()->Update();
}


void
MdPlots::DrawTimeResiduals()
{
  fCanvasTRes->cd();
  fCanvasTRes->Clear();

  SDEvent theSdEvent = (*fEvent)->GetSDEvent();

  if(theSdEvent.HasAxis()){

	  MDEvent theMdEvent = (*fEvent)->GetMDEvent();

	  const MdRecShower& mdRecShower= theMdEvent.GetMdRecShower();
	  if (!mdRecShower.IsReconstructed()) {
	  	  DrawLegend(fEventObjects, "Event not reconstructed", 0.2, 3.0);
	  	  fCanvasLDF->GetCanvas()->Modified();
	  	  fCanvasLDF->GetCanvas()->Update();

	  	  return;
	  }
	  // Get the data of the core reconstructed by the SD
	  SdRecShower& theSdRecShower = theSdEvent.GetSdRecShower();
	  const double lightSpeedMetresOverNanos(.3);

	  const TVector3& corePosition = theSdRecShower.GetCoreSiteCS();
	  const TVector3& showerAxis = theSdRecShower.GetAxisSiteCS();
	  unsigned long coreTimeSecond = theSdRecShower.GetCoreTimeSecond();
	  unsigned long coreTimeNano = theSdRecShower.GetCoreTimeNanoSecond();

	  std::vector<double> xMd; // distance from the MD counter to the shower plane
	  std::vector<double> yMd;  // time measured by the MD counter
	  std::vector<double> xSd;
	  std::vector<double> ySd;
	  std::vector<double> ySdError; // error in the time measured by the SD station
	  std::vector<int> sdIds; // save the ids to plot them

	  for (MDEvent::CounterIterator counter = theMdEvent.CountersBegin(), end = theMdEvent.CountersEnd();
		   counter != end; ++counter) {

			// skip if no muons
			if (counter->GetNumberOfMuons() < lowerLimitNMu)//Tried to make this better; sorry... I couldn't. Should have a flag from reconstruction
			  continue;

			unsigned int stationId = counter->GetSdPartnerId();
			const SdRecStation* const theSdStation = theSdEvent.GetStationById(stationId);

			if (!theSdStation)
			  continue;

			// Station delay
			const TVector3& sdPosition = (*fDetectorGeometry)->GetStationPosition(stationId);
			TVector3 sdRelPosition = sdPosition-corePosition;
			const double sdDistance = theSdStation->GetSPDistance();

			sdIds.push_back(stationId);
			double counterSignalNano = 0;
			double counterDelay = 0;

			for (MdRecCounter::ModuleIterator module = counter->ModulesBegin(), end = counter->ModulesEnd();
				 module != end; ++module) {

				  if (!module->IsCandidate() || !module->HasPatternMatches())
					continue;

				  // Counter delay wrt the shower plane
				  const TVector3 modulePosition = module->GetPosition();
				  const TVector3 moduleRelPosition = modulePosition-corePosition;
				  const double heigth = -moduleRelPosition.Dot(showerAxis);
				  const double delay = heigth/lightSpeedMetresOverNanos;

				  // Counter to core distance measured in the shower plante
				  //const double distance = moduleRelPosition.Cross(showerAxis).Mag();

				  // Get the signal time
				  const unsigned long traceStartSecond = module->GetChannelsOnStartSecond();
				  const double traceStartNano = module->GetChannelsOnStartNano();
				  const double leadingMuonNano = module->GetLeadingMuonTime();
				  const double moduleTimeNano = traceStartNano + leadingMuonNano;

				  // Calculate the interval wrt the core time
				  const double moduleSignalNano =
					(traceStartSecond - coreTimeSecond)*1e9 + (moduleTimeNano - coreTimeNano);

				  // Find the earlier module
				  if (module == counter->ModulesBegin() || moduleSignalNano < counterSignalNano) {
					counterSignalNano = moduleSignalNano;
					counterDelay = delay;
				  }

				  //double area = module->GetActiveArea();
				  //double numberOfMuons = module->GetNumberOfEstimatedMuons();

				  // Output some data
				  //std::cout << counter->GetId() << "\t" << module->GetId() << "\t" << distance << "\t" << area << "\t" << numberOfMuons << "\t";
				  //std::cout << delay << "\t" << moduleSignalNano << std::endl;

		} // end module loop

		// save counter data
		xMd.push_back(sdDistance);
		const double timeResidual = counterSignalNano - counterDelay;
		yMd.push_back(timeResidual);

		//Save SD Time residuals

		const double sdHeigth = -sdRelPosition.Dot(showerAxis);
		const double sdDelay = sdHeigth/lightSpeedMetresOverNanos;

		// Interval between the signal start and the core times
		const double sdTraceStartSecond = theSdStation->GetTimeSecond();
		const double sdSignalStartNano = theSdStation->GetTimeNSecond();
		const double sdSignalNano = (sdTraceStartSecond - coreTimeSecond)*1e9 +
		  (sdSignalStartNano - coreTimeNano);

		// Time error
		const double theta = theSdRecShower.GetZenith();

		const double sdSignalTimeError = sqrt(theSdStation->GetSignalTimeSigma2Intrinsic(theta));
		xSd.push_back(sdDistance);
		ySd.push_back(sdSignalNano-sdDelay);
		ySdError.push_back(sdSignalTimeError);

	} // end counter loop

	 //If there're no candidates we should not be here; but just in case, let's avoid any possible crash...
	if (xSd.empty() || xMd.empty()){
			DrawLegend(fEventObjects, "no data",  0.2, 3.0);
	}else{

		  // Draw empty frame with desired x and y ranges
		  const double stretch = 1.2;
		  double xmin = *std::min_element(xMd.begin(), xMd.end());
		  const double xmax = *std::max_element(xMd.begin(), xMd.end()) * stretch;
		  const double yminMd = *std::min_element(yMd.begin(), yMd.end());
		  const double yminSd = *std::min_element(ySd.begin(), ySd.end()) / stretch;
		  double ymin = std::min(yminMd, yminSd);   // use the minimum among MD and SD
		  ymin<0 ? ymin *= stretch : ymin /=stretch; //Some weird cases; not OK, but I still want to see them.
		  xmin<0 ? xmin *= stretch : xmin /=stretch; //Some weird cases; not OK, but I still want to see them.
		  ymin = std::min(0.0, ymin);  // ensure min<=0
		  xmin = std::min(0.0, xmin);
		  const double ymax = *std::max_element(yMd.begin(),yMd.end())*stretch;
		  TH1F* const htemp = fCanvasTRes->DrawFrame(xmin, ymin, xmax, ymax);
		  htemp->GetXaxis()->SetTitle("Core Distance (m)");
		  htemp->GetYaxis()->SetTitle("Time Residual (ns)");
		  htemp->GetYaxis()->SetTitleOffset(1.2);

		  TGraph* const grMd = new TGraph(xMd.size(), &xMd[0], &yMd[0]);

		  grMd->SetTitle("");
		  grMd->SetMarkerStyle(kFullCircle);
		  grMd->SetMarkerColor(kBlue);
		  grMd->Draw("P");
		  fEventObjects->Add(grMd);

		  //Draw SD time residuals if it's a combined view
		  if (fSdMdCombinedView) {

			TGraphErrors* const grSd = new TGraphErrors(xSd.size(), &xSd[0], &ySd[0], NULL, &ySdError[0]);
			grSd->SetMarkerStyle(kFullSquare);
			grSd->SetMarkerColor(kRed);
			grSd->Draw("PESAME");

			fEventObjects->Add(grSd);
			// Legend
			TLegend* const leg = new TLegend(0.25, 0.75, 0.4, 0.9, NULL, "brNDC");
			leg->AddEntry(grSd, "SD", "P");
			leg->AddEntry(grMd, "MD", "P");
			leg->SetFillColor(0);
			leg->SetLineColor(0);
			leg->Draw();
			fEventObjects->Add(leg);

		  }

		  // Draw the station ids
		  for (unsigned int i = 0, n = xMd.size(); i < n; ++i) {
			    std::stringstream text1;
				text1 << sdIds.at(i);
				TLatex* stationIdLabel;
				if(fSdMdCombinedView){
				  stationIdLabel = new TLatex(xSd.at(i)+125,ySd.at(i)-5,text1.str().c_str());
				} else {
					stationIdLabel = new TLatex(xMd.at(i)+125,yMd.at(i)-5,text1.str().c_str());
				}
				stationIdLabel = new TLatex(xMd.at(i)+xmax*0.01, yMd.at(i)+ymax*0.01, text1.str().c_str());
				stationIdLabel->SetTextAlign(11);
				stationIdLabel->SetTextFont(42);
				stationIdLabel->SetTextSize(.04);
				//stationIdLabel->SetTextColor(38);
				stationIdLabel->Draw();
				fEventObjects->Add(stationIdLabel);
		  }
	  }
  }else{

			  DrawLegend(fEventObjects, "no SD Axis",  0.2, 3.0);

  }
  fCanvasTRes->GetCanvas()->Modified();
  fCanvasTRes->GetCanvas()->Update();
}


std::string
MdPlots::PrintPostScript()
{
  const int evId = (*fEvent)->GetSDEvent().GetEventId();

  ostringstream oss;

  oss << "/tmp/tmp" << evId << "_array.eps";
  fCanvasArray->cd();
  fCanvasArray->Print(oss.str().c_str());

  oss.str("");
  oss << "/tmp/tmp" << evId << "_ldf.eps";
  fCanvasLDF->cd();
  fCanvasLDF->Print(oss.str().c_str());

  oss.str("");
  oss << "/tmp/tmp" << evId << "_time.eps";
  fCanvasTRes->cd();
  fCanvasTRes->Print(oss.str().c_str());

  oss.str("");
  oss << "/tmp/tmp" << evId << "_info.eps";
  fCanvasInfo->cd();
  fCanvasInfo->Print(oss.str().c_str());

  oss.str("");
  oss << "SdEvent_" << evId << ".ps";
  const string filename = oss.str();

  oss.str("");
  oss << ADST_BIN_DIR << "/SdEvent2ps.csh " << evId << ' ' << filename;
  const int res = system(oss.str().c_str());

  return res ? "" : filename;
}


void MdPlots::UpdateArrayPlot() {
  fArrayObjects->Delete();
  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);
  fCanvasArray->Clear();

  

  MDEvent theMdEvent = (*fEvent)->GetMDEvent();
  MdRecShower MdRecShower = theMdEvent.GetMdRecShower();

  SDEvent theSdEvent = (*fEvent)->GetSDEvent();
  SdRecShower theSdRecShower = theSdEvent.GetSdRecShower();
  const TVector3& showerAxis = theSdRecShower.GetAxisSiteCS();

  //const int xsize(550), ysize(450);
  const int xsize(380), ysize(300);

  fCanvasArray->SetCanvasSize(xsize,ysize);
  fCanvasArray->SetFillColor(10);
  fCanvasArray->SetBorderMode(0);
  gPad->Range(-1050, -1200, 1550, 900);

  //This works for the unitary cell. Ids and positions are hardcoded so far, we have no data to test a non-static designation.
  const unsigned int nstations(7);
  unsigned int stationIds[nstations] = { 93, 688, 1570, 1574, 1622, 1764, 1773 };
  double stationXs[nstations] = { -370.9,379.4,-373.0,-749.5,0,746,367.5 };
  double stationYs[nstations] = { -628.1, 654.9, 653.3, 10.4, 0, 3.1, -649.6 };
  const double x0(-26986.2);
  //const double x0(-16986.2);
  const double y0(15445.5);

  // use pointer for unique name ...
  ostringstream title; title << "sdarr" << this << endl;
  TH2Poly* cc = new TH2Poly(title.str().c_str(),";x (km);y (km)",
                            -1.1, 1.1,
                            -1.1, 1.1);
  cc->GetZaxis()->SetLabelSize(0.02);
  cc->GetZaxis()->SetTitleSize(0.03);
  cc->GetXaxis()->SetTitleOffset(0.7);
  cc->GetYaxis()->SetTitleOffset(0.5);
  fArrayObjects->Add(cc);
  cc->Draw();
  fCanvasArray->SetRightMargin(0.08);/*Margenes mapa!*/
  fCanvasArray->SetTopMargin(0.05);
  fCanvasArray->SetBottomMargin(0.08);
  fCanvasArray->SetLeftMargin(0.1);

  // Draw MD array
  for (unsigned int i = 0; i < nstations; ++i) {
    unsigned int stationId = stationIds[i];
    const double x = stationXs[i] / 1000; //Km
    const double y = stationYs[i] / 1000; //Km

    // flag if counter is in the event
    MdRecCounter* const counter = theMdEvent.GetCounterBySdPartnerId(stationId);
    const bool hasCounter = (counter != NULL && counter->IsCandidate());

    // Position marker
    TMarker* const stationMarker = new TMarker(x,y,kFullCircle);
    stationMarker->SetMarkerColor(hasCounter ? kBlack : kGray);

    stationMarker->Draw("AP");

    // Buffer for written text
    std::stringstream text1;
    text1.setf(std::ios::fixed, std::ios::floatfield);
    text1.precision(1);

    // Station id
    text1.str("");
    text1 << stationId;
    TLatex* const stationIdText = new TLatex(x, y+0.05/*50*/, text1.str().c_str());
    stationIdText->SetTextAlign(21);
    stationIdText->SetTextSize(.04);
    stationIdText->SetTextColor(hasCounter ? kBlack : kGray);
    stationIdText->Draw();

    // Position text
    TPaveText* const positionText = new TPaveText(x-0.225/*225*/, y-0.035/*25*/, x+0.05/*50*/, y-0.3/*200*/);
    positionText->SetFillColor(kWhite);
    positionText->SetLineColor(kWhite);
    positionText->SetShadowColor(kWhite);
    positionText->SetTextAlign(32);
    positionText->SetTextFont(42);
    positionText->SetTextSize(.03);
    positionText->SetTextColor(kBlue);

    // Counter area & number of muons
    if (hasCounter) {
      text1.str("");
      const double counterArea = counter->GetActiveArea();
      text1 << counterArea << " m^{2}";
      positionText->AddText(text1.str().c_str());
      text1.str("");
      if (counter->IsSaturated()) {
        const double lowMuonLimit = counter->GetNumberOfMuonsLowLimit();
        text1 << ">" << std::setprecision(0) << lowMuonLimit << " #mu (saturated)";
      } else {
        const double numberOfMuons = counter->GetNumberOfMuons();
        text1 <<  numberOfMuons << " #mu ";
      }
      positionText->AddText(text1.str().c_str());
    }
    fArrayObjects->Add(positionText);
    positionText->Draw();

  }

  // Plot core position
  const TVector3& corePosition = theSdRecShower.GetCoreSiteCS();
  const double xcore = (corePosition.X() - x0)/1000;
  const double ycore = (corePosition.Y() - y0)/1000;

  TMarker* const impactPoint = new TMarker(xcore, ycore, kMultiply);
  impactPoint->SetMarkerColor(kRed);
  impactPoint->SetMarkerSize(2);
  impactPoint->Draw();
  fArrayObjects->Add(impactPoint);
  // Plot azimuth line
  const double phi = showerAxis.Phi();
  const double x2 = /*400*/0.4*TMath::Cos(phi);
  const double y2 = /*400*/0.4*TMath::Sin(phi);
  TLine* const azimuthLine = new TLine(xcore, ycore, x2+xcore, y2+ycore);
  azimuthLine->SetLineColor(kRed);
  azimuthLine->SetLineWidth(2);
  azimuthLine->SetLineStyle(2);
  azimuthLine->Draw();
  fArrayObjects->Add(azimuthLine);

  //Draw SD markers if it's a combined view
  if (fSdMdCombinedView) {
	  DrawSDMarkers();
  }

  // update canvas
  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
}

void MdPlots::DrawSDMarkers() {

	vector<TMarker*> accidentalMarker;
	vector<TMarker*> denseMarker;
	vector<TMarker*> candidateMarker;
	vector<TArc*> densePmtMarker;
	vector<TArc*> candidatePmtMarker;

	const unsigned int nstations(7);
	unsigned int stationIds[nstations] = { 93, 688, 1570, 1574, 1622, 1764, 1773 };
	double stationXs[nstations] = { -370.9,379.4,-373.0,-749.5,0,746,367.5 };
	double stationYs[nstations] = { -628.1, 654.9, 653.3, 10.4, 0, 3.1, -649.6 };

	SDEvent theSdEvent = (*fEvent)->GetSDEvent();
	SdRecShower theSdRecShower = theSdEvent.GetSdRecShower();
	//const TVector3& showerAxis = theSdRecShower.GetAxisSiteCS();

	for (unsigned int iS = 0; iS < nstations; ++iS) {
		const unsigned int id = stationIds[iS];
		if (!theSdEvent.HasStation(id))
			continue;

		const double X = stationXs[iS] / 1000;//Km
		const double Y = stationYs[iS] / 1000;//Km

		const SdRecStation* const station = theSdEvent.GetStationById(id);

		if (station->IsDoublet() && !station->IsCandidate())
			continue;

		const bool tot = fRecStationClassVersion < 18 ?
		station->IsThreshold() : station->IsTOT();
		const int stationMarker = tot ?
		(*fStyleManager)->GetTankTOTStyle() :
		(*fStyleManager)->GetTankDefaultStyle();
		const double signal = station->GetTotalSignal();

		TMarker* const stationPlot = new TMarker(X, Y, stationMarker);
		fArrayObjects->Add(stationPlot);
		//stationPlot->SetMarkerStyle(kOpenCircle);

		stationPlot->SetMarkerSize(1.2*(*fStyleManager)->GetTankInDAQSize());

		if (station->IsAccidental() && !station->IsDense()) {
			stationPlot->SetMarkerColor((*fStyleManager)->GetTankNoiseColor());
			accidentalMarker.push_back(stationPlot);
		} else if (station->IsCandidate() || station->IsDense()) {
			int color = 0;
			if (station->IsDense()) {
				if (!EventBrowserConfig::Get(cfg::eShowMC))
					continue;
				color = (*fStyleManager)->GetTankDenseColor();
			} else {
				const double timeSec= station->GetTimeSecond();
				const double timeNSec = station->GetTimeNSecond();
				const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);

				color = GetColor(stationTime);
			}
#if ROOT_VERSION_CODE < ROOT_VERSION(5,34,19)
                        stationPlot->SetMarkerColor(color);
#else
                        stationPlot->SetMarkerColorAlpha(color, 0.5);
#endif
			short nPMTsDrawn = 0;
			if (EventBrowserConfig::Get(cfg::eSdShowPMTSignals)) {
				for (unsigned short iPmt = 0; iPmt < 3; ++iPmt) {
					const Traces& traces = station->GetPMTTraces(eTotalTrace, iPmt+1);
					const vector<float>& vemTrace = traces.GetVEMComponent();
					double pmtSignal = 0;
					if (vemTrace.empty()) {
						// use only if trace is empty; beware: GetVEMSignal was broken in the past (HD)
						pmtSignal = traces.GetVEMSignal();
						if (!pmtSignal)
							continue;
					} else {
						const int startSlot = station->GetSignalStartSlot() > 0 ? station->GetSignalStartSlot() : 0;
						const int endSlot = station->GetSignalEndSlot() < vemTrace.size() ? station->GetSignalEndSlot() : vemTrace.size();
						for (int j = startSlot; j < endSlot; ++j)
							pmtSignal += vemTrace[j];
							pmtSignal *= traces.GetPeak()/traces.GetCharge();
					}
					const float size = (0.01 + 0.1*fmax(0.,log10(signal)))*pmtSignal/signal*sqrt(0);
					TArc* const pmtArc = new TArc(X, Y, size, -30 - iPmt*120, 90 - iPmt*120);
					fArrayObjects->Add(pmtArc);
					pmtArc->SetFillColor(color);
					pmtArc->SetLineColor(TColor::GetColorBright(color));
					++nPMTsDrawn;
					if (station->IsDense())
						densePmtMarker.push_back(pmtArc);
					else
						candidatePmtMarker.push_back(pmtArc);
				}
			} // draw PMT wedges

			if (nPMTsDrawn == 0) {
				const double size = (*fStyleManager)->GetTankInDAQSize() + 0.85*fmax(0., log10(signal - 2));
				stationPlot->SetMarkerSize(size);
			}

			if (station->IsDense())
				denseMarker.push_back(stationPlot);
			else
				candidateMarker.push_back(stationPlot);
		} // isCandidate
	} // loop over stations
	// for zorder of markers
	for (size_t i = 0; i < accidentalMarker.size(); ++i)
	accidentalMarker[i]->Draw("SAME");
	for (size_t i = 0; i < denseMarker.size(); ++i)
	denseMarker[i]->Draw("SAME");
	for (size_t i = 0; i < densePmtMarker.size(); ++i)
	 densePmtMarker[i]->Draw("SAME");
	for (size_t i = 0; i < candidateMarker.size(); ++i)
	candidateMarker[i]->Draw("SAME");
	for (size_t i = 0; i < candidatePmtMarker.size(); ++i)
	candidatePmtMarker[i]->Draw("SAME");

}


int
MdPlots::GetColor(Long64_t x) //, double y, double z)
{
  int color = (*fStyleManager)->GetTankDefaultColor();
  const double minCol = (*fStyleManager)->GetSdShowerPlaneAzimuthStartColor();
  const double maxCol = (*fStyleManager)->GetSdShowerPlaneAzimuthStopColor();
  if ((fMaxTime - fMinTime) > 0)
     color = int(minCol + (maxCol - minCol) * (x - fMinTime) / (fMaxTime - fMinTime));

  return color;
}


void
MdPlots::GetMaxAndMinTime()
{
  Long64_t maxT = 0;
  Long64_t minT = 0;
  double maxTRes = 0;
  double minTRes = 0;
  Long64_t stationTime = 0;
  int nT = 0;
  const std::vector<SdRecStation>& stations = (*fEvent)->GetSDEvent().GetStationVector();
  for (unsigned int iS = 0; iS < stations.size(); ++iS) {
    if (!stations[iS].IsCandidate())
      continue;

    const double timeSec  = stations[iS].GetTimeSecond();
    const double timeNSec = stations[iS].GetTimeNSecond();
    stationTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);

    const double tres = stations[iS].GetPlaneTimeResidual();
    if (stationTime > maxT || nT == 0)
      maxT = stationTime;
    if (stationTime<minT || nT == 0)
      minT = stationTime;
    if (tres > maxTRes || nT == 0)
      maxTRes = tres;
    if (tres < minTRes || nT == 0)
      minTRes = tres;
    ++nT;
  }
  fMaxTime = maxT;
  fMinTime = minT;
  fMaxTimeRes = maxTRes;
  fMinTimeRes = minTRes;
}
