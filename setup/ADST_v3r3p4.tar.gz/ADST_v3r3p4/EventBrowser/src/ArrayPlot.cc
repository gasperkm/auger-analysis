#include "ArrayPlot.h"
#include "RecEvent.h"
#include "MuonMap.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserConfig.h"
#include "DetectorGeometry.h"
#include "EyeGeometry.h"
#include "StyleManager.h"
#include "StationStatus.h"
#include "RdRecStation.h"

#include <TBox.h>
#include <TCanvas.h>
#include <TPolyLine.h>
#include <TH2Poly.h>
#include <TMarker.h>
#include <TGraph.h>
#include <TObjArray.h>
#include <TEllipse.h>
#include <TPaletteAxis.h>
#include <TLine.h>
#include <TF1.h>
#include <TGSlider.h>
#include <TBits.h>
#include <TLatex.h>
#include <TArc.h>
#include <TArrow.h>
#include <TStyle.h>
#include <TColor.h>
#include <TVector3.h>

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;
using namespace view::Consts;

ClassImp (ArrayPlot);

ArrayPlot::ArrayPlot(const RecEvent* const * event,
                     const DetectorGeometry* const * detectorGeometry,
                     const StyleManager* const * styleManager,
                     const TGHSlider* arrayZoomButton,
                     TCanvas* arrayCanvas) :
  fEvent(event),
  fDetectorGeometry(detectorGeometry),
  fStyleManager(styleManager),
  fArrayZoomButton(arrayZoomButton),
  fCanvasArray(arrayCanvas),
  fSdColorStatus(eSDGroundTimeColors),
  fZoomDX(-1.),
  fHasZoomCenter(false),
  fCoreAltitude(0), 
  fUseRadio(false)
{
  fArrayObjects= new TObjArray();
  fArrayObjects->SetOwner(kTRUE);
  fZoomBox = new TBox(0., 0., 1., 1.);
}

ArrayPlot::~ArrayPlot()
{
  fArrayObjects->Delete();
  delete fArrayObjects;
  if ( fZoomBox != NULL )
    delete fZoomBox;
}

void
ArrayPlot::SetCoreAltitude()
{
  if (!*fEvent)
    return;

  if ((*fEvent)->GetSDEvent().HasLDF())
  {
    fCoreAltitude = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS().Z();
    return;
  }
  else
  {
    fCoreAltitude = 0;
    size_t n = 0;
    for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
          eyeIter < (*fEvent)->EyesEnd();
          ++eyeIter )
    {
      if (eyeIter->GetRecLevel()>=eHasAxis)
      {
        const FdRecShower& theShower = eyeIter->GetFdRecShower();
        const size_t sId = (*fDetectorGeometry)->GetClosestStationId(
          theShower.GetCoreSiteCS().X(),
          theShower.GetCoreSiteCS().Y()
        );

        fCoreAltitude += (*fDetectorGeometry)->GetStationPosition(sId).Z();
        ++n;
      }
    }
    fCoreAltitude /= n;
    return;
  }

  fCoreAltitude =  0;
}

void
ArrayPlot::DrawFDOnArray()
{

  for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
        eyeIter < (*fEvent)->EyesEnd();
        ++eyeIter ) {
    if(eyeIter->GetRecLevel()>=eHasAxis) {

      int color = (*fStyleManager)->GetFDEyeColor(eyeIter->GetEyeId());

      const TVector3& showerCore=
        eyeIter->GetFdRecShower().GetCoreAtAltitudeSiteCS(fCoreAltitude);
      const double xC=showerCore.X()/km;
      const double yC=showerCore.Y()/km;
      unsigned int iEye= eyeIter->GetEyeId();
      const EyeGeometry& eye = (*fDetectorGeometry)->GetEye(iEye);
      const TVector3&  eyePos = eye.GetEyePos();
      const double xEye=eyePos.X()*1.e-3;
      const double yEye=eyePos.Y()*1.e-3;
      const double dx=xC-xEye;
      const double dy=yC-yEye;

      // draw axis projection
      const double phi = eyeIter->GetFdRecShower().GetAzimuth();
      const double coreLength = fmin((*fStyleManager)->GetAxisProjectionLength(),
                                     0.8*fZoomDX);
      TLine* coreLine= new TLine(xC,yC,xC + coreLength*cos(phi),
                                 yC+coreLength*sin(phi));
      coreLine->SetLineColor(color);
      coreLine->SetLineWidth(1);
      coreLine->Draw();
      fArrayObjects->Add(coreLine);

      const double R = eyeIter->GetFdRecGeometry().GetCoreEyeDistance()/km;

      // draw SDP and its error
      for ( int i=-1;i<2;i+=2) {
        const double phi=atan2(dy,dx)+ (double) i *
          eyeIter->GetFdRecGeometry().GetSDPPhiError();
        const double x2=xEye+cos(phi)*R*1.6;
        const double y2=yEye+sin(phi)*R*1.6;
        double xStart, xStop;
        if(dx>0.) {
          xStart=xEye;
          xStop=100.;
        }
        else {
          xStart=-100.;
          xStop=xEye;
        }

        TF1* a = new TF1("tmp","[0]+[1]*x",xStart,xStop);
        const double slope=(yEye-y2)/(xEye-x2);
        const double y0=y2-slope*x2;
        a->SetParameters(y0,slope);

        fArrayObjects->Add(a);
        a->Draw("SAME");
        a->SetLineColor(color);
        a->SetLineWidth(1);
      }

      const double Rerr =
        eyeIter->GetFdRecGeometry().GetCoreEyeDistanceError()/km;
      const double phi1=atan2(dy,dx)+
        eyeIter->GetFdRecGeometry().GetSDPPhiError();
      const double phi2=atan2(dy,dx)-
        eyeIter->GetFdRecGeometry().GetSDPPhiError();
      const double xx1=xEye+cos(phi1)*R;
      const double yy1=yEye+sin(phi1)*R;
      const double xx2=xEye+cos(phi2)*R;
      const double yy2=yEye+sin(phi2)*R;
      const double dist=sqrt( (xx1-xx2)*(xx1-xx2)+(yy1-yy2)*(yy1-yy2) );
      const double perpErr=dist/2.;

      TEllipse* cc = new TEllipse(xC,yC,Rerr,perpErr,
                                  0.,360.,atan2(dy,dx)*180./M_PI);
      cc->SetFillColor(color);
      cc->SetLineColor(color);
      cc->SetFillStyle(3017);
      cc->Draw("F");
      fArrayObjects->Add(cc);

      // draw T3 SDP

      if (EventBrowserConfig::Get(cfg::eFdShowT3Sdp) && eyeIter->HasT3Reconstruction() ) {
        const double azi = eyeIter->GetT3Azimuth();
        const double slope=tan(azi);
        double xStart, xStop;
        if(dx>0.) {
          xStart=xEye;
          xStop=100.;
        }
        else {
          xStart=-100.;
          xStop=xEye;
        }

        TF1* a = new TF1("tmpT3","[0]+[1]*(x-[2])",xStart,xStop);
        a->SetParameters(yEye,slope,xEye);
        fArrayObjects->Add(a);
        a->Draw("SAME");
        a->SetLineColor(color);
        a->SetLineWidth(1);
        a->SetLineStyle(2);
      }
    }
  }
}


void
ArrayPlot::DrawSDOnArray(float x1, float x2, float y1, float y2)
{
  const Detector& det = (*fEvent)->GetDetector();
  const std::vector<SdRecStation>& stations=
    (*fEvent)->GetSDEvent().GetStationVector();

  vector<TMarker*> accidentalMarker;
  vector<TMarker*> denseMarker;
  vector<TMarker*> candidateMarker;
  vector<TArc*> densePmtMarker;
  vector<TArc*> candidatePmtMarker;

  for ( unsigned int iS=0;iS<stations.size();iS++) {

    const unsigned int id = stations[iS].GetId();

    double X;
    double Y;

    if(stations[iS].IsDense()){
      X= det.GetStationPosition(id).X()/km;
      Y= det.GetStationPosition(id).Y()/km;
    }
    else{
      X = (*fDetectorGeometry)->GetStationPosition(id).X()/km;
      Y = (*fDetectorGeometry)->GetStationPosition(id).Y()/km;
    }

    if ( X < x1 || X > x2 || Y < y1 || Y > y2 )
      continue;

    if (stations[iS].IsDoublet() && !stations[iS].IsCandidate())
      continue;

    const bool tot= fRecStationClassVersion<18?
      stations[iS].IsThreshold():stations[iS].IsTOT();
    const int stationMarker = tot ?
      (*fStyleManager)->GetTankTOTStyle() :
      (*fStyleManager)->GetTankDefaultStyle();
    const double signal = stations[iS].GetTotalSignal();

    TMarker* stationPlot = new TMarker(X,Y,stationMarker);
    fArrayObjects->Add(stationPlot);
    stationPlot->SetMarkerSize(1.2*(*fStyleManager)->GetTankInDAQSize());

    if (stations[iS].IsAccidental() && !stations[iS].IsDense()) {
      stationPlot->SetMarkerColor((*fStyleManager)->GetTankNoiseColor());
      accidentalMarker.push_back(stationPlot);
    } else
    if (stations[iS].IsCandidate() || stations[iS].IsDense()) {
      int color = 0;

      if (stations[iS].IsDense()) {
        if (!EventBrowserConfig::Get(cfg::eShowMC))
          continue;
        color = (*fStyleManager)->GetTankDenseColor();
      }
      else {
        const double timeSec  = stations[iS].GetTimeSecond();
        const double timeNSec = stations[iS].GetTimeNSecond();
        const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);
        color = GetColor(stationTime,
                         stations[iS].GetPlaneTimeResidual(),
                         stations[iS].GetAzimuthSP());
        // This is used to draw Sd in the radio plots
        if (EventBrowserConfig::Get(cfg::eRdShowSd)) {
          Long64_t MaxTimeSD=0;
          Long64_t MinTimeSD=0;
          Long64_t sTime=0;
          int nT=0;
          const std::vector<SdRecStation>& sstations=
            (*fEvent)->GetSDEvent().GetStationVector();
          for ( unsigned int iSt=0;iSt<sstations.size();iSt++) {
            if (!sstations[iSt].IsCandidate())
              continue;
            const double timeSec  = sstations[iSt].GetTimeSecond();
            const double timeNSec = sstations[iSt].GetTimeNSecond();
            sTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);
            if ( sTime>MaxTimeSD || nT==0)
              MaxTimeSD= sTime;
            if ( sTime<MinTimeSD || nT==0)
              MinTimeSD= sTime;
            ++nT;
          }
          const double minCol= 60.;
          const double maxCol= 80.;
          color = (*fStyleManager)->GetTankDefaultColor();
          if ( stationTime > 0 && (MaxTimeSD-MinTimeSD) > 0 )
            color = (int)(minCol+ (maxCol- minCol)*(stationTime-MinTimeSD)/(MaxTimeSD-MinTimeSD));
        }
      }

      stationPlot->SetMarkerColor(color);

      short nPMTsDrawn = 0;
      if (EventBrowserConfig::Get(cfg::eSdShowPMTSignals) && 0 < fZoomDX && fZoomDX <= (*fStyleManager)->GetMaxZoom()) {
        for (unsigned short iPmt = 0; iPmt < 3; ++iPmt)
        {
          const Traces& traces = stations[iS].GetPMTTraces(eTotalTrace, iPmt+1);
          const vector<float>& vemTrace = traces.GetVEMComponent();
          double pmtSignal = 0;
          if (vemTrace.empty()) {
            // use only if trace is empty; beware: GetVEMSignal was broken in the past (HD)
            pmtSignal = traces.GetVEMSignal();
            if (!pmtSignal)
              continue;
          } else {
            const int startSlot = stations[iS].GetSignalStartSlot() > 0 ?
              stations[iS].GetSignalStartSlot() : 0;
            const int endSlot = stations[iS].GetSignalEndSlot() < vemTrace.size() ?
              stations[iS].GetSignalEndSlot() : vemTrace.size();
            for (int j = startSlot; j < endSlot; ++j)
              pmtSignal += vemTrace[j];
            pmtSignal *= traces.GetPeak()/traces.GetCharge();
          }

          const float size = (0.01 + 0.1*fmax(0.,log10(signal)))*pmtSignal/signal*sqrt(fZoomDX);
          TArc* pmtArc = new TArc(X, Y, size, -30-iPmt*120, 90-iPmt*120);
          fArrayObjects->Add(pmtArc);
          pmtArc->SetFillColor(color);
          pmtArc->SetLineColor(TColor::GetColorBright(color));
          ++nPMTsDrawn;
          if (stations[iS].IsDense())
            densePmtMarker.push_back(pmtArc);
          else
            candidatePmtMarker.push_back(pmtArc);
        }
      } // draw PMT wedges

      if (nPMTsDrawn == 0 && 0 < fZoomDX && fZoomDX <= (*fStyleManager)->GetMaxZoom())
      {
        const double size = (*fStyleManager)->GetTankInDAQSize()+0.85*fmax(0.,log10(signal-2.));
        stationPlot->SetMarkerSize(size);
      }

      if (stations[iS].IsDense())
        denseMarker.push_back(stationPlot);
      else
        candidateMarker.push_back(stationPlot);
    } // isCandidate
  } // loop over stations

  // for zorder of markers
  for (size_t i = 0; i < accidentalMarker.size(); ++i)
    accidentalMarker[i]->Draw();
  for (size_t i = 0; i < denseMarker.size(); ++i)
    denseMarker[i]->Draw();
  for (size_t i = 0; i < densePmtMarker.size(); ++i)
    densePmtMarker[i]->Draw();
  for (size_t i = 0; i < candidateMarker.size(); ++i)
    candidateMarker[i]->Draw();
  for (size_t i = 0; i < candidatePmtMarker.size(); ++i)
    candidatePmtMarker[i]->Draw();

  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();
  if(!sdEvent.HasAxis())
    return;

  const SdRecShower& sdShower = sdEvent.GetSdRecShower();
  const TVector3 showerCore = sdShower.GetCoreAtAltitudeSiteCS(fCoreAltitude);
  const double coreX = showerCore.X()/km;
  const double coreY = showerCore.Y()/km;
  const double coreXErr = sdShower.GetCoreEastingError()/km;
  const double coreYErr = sdShower.GetCoreNorthingError()/km;
  const double coreXYcorrelation = sdShower.GetCoreNorthingEastingCorrelation();

  const double sizeFactor = 1.51; // to get 68 % coverage for one sigma intervals in 2D
  const double sx2 = coreXErr*coreXErr;
  const double sy2 = coreYErr*coreYErr;
  const double sxy = coreXErr*coreYErr*coreXYcorrelation;
  const double errorEllipseAngle = 0.5*atan2(2*sxy,sx2-sy2);
  const double sa = sin(errorEllipseAngle);
  const double ca = cos(errorEllipseAngle);
  const double ru = sizeFactor*sqrt(sx2*ca*ca+2*sxy*sa*ca+sy2*sa*sa);
  const double rv = sizeFactor*sqrt(sx2*sa*sa-2*sxy*sa*ca+sy2*ca*ca);

  TEllipse* cc = new TEllipse(coreX,coreY,ru,rv,
                              0.,360.,errorEllipseAngle*180./M_PI);
  fArrayObjects->Add(cc);
  cc->SetFillColor((*fStyleManager)->GetSDColor());
  cc->SetLineColor((*fStyleManager)->GetSDColor());
  cc->SetFillStyle(3017);
  cc->Draw("F");

  const double phi= sdShower.GetAzimuth();

  const double coreLength = fmin((*fStyleManager)->GetAxisProjectionLength(),0.8*fZoomDX);
  TLine* coreLine= new TLine(coreX, coreY, coreX + coreLength*cos(phi), coreY + coreLength*sin(phi));
  fArrayObjects->Add(coreLine);
  coreLine->SetLineColor((*fStyleManager)->GetSDColor());
  coreLine->SetLineWidth(1);
  coreLine->Draw();
}


void
ArrayPlot::DrawLDFOnArray()
{
  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();
  const SdRecShower& sdShower = sdEvent.GetSdRecShower();

  const TVector3 core = sdShower.GetCoreAtAltitudeSiteCS(fCoreAltitude);
  const double cx = core.X()/km;
  const double cy = core.Y()/km;
  const double cosTheta = sdShower.GetCosZenith();
  const double phi = sdShower.GetAzimuth();

  for (int i = 0; i < 4; ++i) {
    const double r = sdShower.GetLDF().EvaluateInverted(TMath::Power(10,i), EventBrowserConfig::GetLDFType())/km;
    if (r < 1e-2)
      break;
    TEllipse* e = new TEllipse(cx, cy, r/cosTheta, r, 0, 360, phi/(2*M_PI)*360);
    e->SetLineColor((*fStyleManager)->GetLDFOnArrayColor());
    e->SetFillStyle(0);
    e->SetLineWidth(1+i);
    e->Draw();
    fArrayObjects->Add(e);
  }
}


void
ArrayPlot::DrawMuonMapOnArray()
{

  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();
  const SdRecShower& sdShower = sdEvent.GetSdRecShower();
  const MuonMap::ContourList myContours = sdEvent.GetMuonMap().GetContours();
  const double deltaCoreAltitude = sdShower.GetCoreSiteCS().Z();
  const double phi= sdShower.GetAzimuth();
  const double theta= sdShower.GetZenith();

  vector<double> contX;
  vector<double> contY;
  TGraph* muonContour;
  int muonMapNo= 0;
  int noOfContours= myContours.size();
  for(MuonMap::ConstContourIterator theCont = myContours.begin();
      theCont != myContours.end(); theCont++) {
    ostringstream contourName;
    ostringstream checkContourName;
    contX.clear();
    contY.clear();

    const double contMuSignal = theCont->GetContourSignal();
    int i = 0;
    const MuonMapContour::PointsList myPoints = theCont->GetPoints();
    for(MuonMapContour::ConstPointsIterator thePoint = myPoints.begin();
      thePoint != myPoints.end(); thePoint++) {
      if( sdEvent.HasAxis()) {
        contX.push_back((thePoint->GetX()+deltaCoreAltitude*cos(phi)*tan(theta))/km);
        contY.push_back((thePoint->GetY()+deltaCoreAltitude*sin(phi)*tan(theta))/km);
      } else {
        contX.push_back(thePoint->GetX()/km);
        contY.push_back(thePoint->GetY()/km);
      }
      i++;
    }
    contX.push_back(contX.front());
    contY.push_back(contY.front());

    muonContour = new TGraph(contX.size(), &contX.front(), &contY.front());
    contourName << "muSignal" << contMuSignal << "VEM";
    muonContour->SetName(contourName.str().c_str());
    muonContour->SetLineColor((*fStyleManager)->CalculateMuonMapColor(muonMapNo, noOfContours));
    muonContour->SetLineStyle(1);
    muonContour->SetLineWidth(1);
    muonContour->Draw("L");
    fArrayObjects->Add(muonContour);
    ++muonMapNo;
  }

}

void
ArrayPlot::DrawMCOnArray()
{

  const TVector3& showerCore=
    (*fEvent)->GetGenShower().GetCoreAtAltitudeSiteCS(fCoreAltitude);
  const double coreX = showerCore.X()/km;
  const double coreY = showerCore.Y()/km;
  TGraph* mcCore = new TGraph(1,&coreX,&coreY);
  mcCore->SetMarkerSize(0.8);
  mcCore->SetMarkerColor((*fStyleManager)->GetMCColor());
  mcCore->SetMarkerStyle(20);
  mcCore->Draw("P");

  fArrayObjects->Add(mcCore);
  const double phi= (*fEvent)->GetGenShower().GetAzimuth();
  const double coreLength =
    fmin((*fStyleManager)->GetAxisProjectionLength(),0.8*fZoomDX);
  TLine* coreLine=
    new TLine(coreX, coreY, coreX + coreLength*cos(phi),
              coreY + coreLength*sin(phi));
  coreLine->SetLineColor((*fStyleManager)->GetMCColor());
  coreLine->SetLineWidth(1);
  coreLine->Draw();
  fArrayObjects->Add(coreLine);
}

void
ArrayPlot::Clear()
{
  fHasZoomCenter=false;
  fArrayObjects->Delete();
  fCanvasArray->GetCanvas()->SetEditable(true);
  fCanvasArray->Clear();
  fCanvasArray->GetCanvas()->SetEditable(false);
}

void
ArrayPlot::DrawShowerPlaneArray(bool /*drawSD*/,
                                bool /*drawFD*/,
                                bool /*drawMC*/)
{
  fArrayObjects->Delete();
  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);
  fCanvasArray->Clear();

  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();
  if( sdEvent.HasAxis()) {

    const SdRecShower& sdShower = sdEvent.GetSdRecShower();
    vector<unsigned int> stationList;
    vector<unsigned int> stationAcList;
    vector<double> x;
    vector<double> y;
    const TVector3& axis= sdShower.GetAxisSiteCS();
    const TVector3& core= sdShower.GetCoreSiteCS();

    const std::vector<SdRecStation>& stations= sdEvent.GetStationVector();
    for ( unsigned int iS=0;iS<stations.size();++iS) {
      if(stations[iS].IsDense())
        continue;

      x.push_back((*fDetectorGeometry)->GetStationShowerPosition(stations[iS].GetId(), axis, core).X()/km);
      y.push_back((*fDetectorGeometry)->GetStationShowerPosition(stations[iS].GetId(), axis, core).Y()/km);

    }
    if ( ! x.empty() ) {

      TGraph* stationPlot = new TGraph(x.size(), &x.front(), &y.front());
      stationPlot->SetMarkerColor(4);
      stationPlot->SetMarkerSize(3);
      stationPlot->SetMarkerStyle(20);
      stationPlot->Draw("aP");
      fArrayObjects->Add(stationPlot);
    }
    if( sdShower.GetLDF().GetLDFStatus() >= 13.)
      DrawMuonMapOnArray();
    if (fUseRadio) {
      DrawRadioInShowerPlaneArray(true);
    }
  } // if HasAxis
  else {
    if (fUseRadio)
      DrawRadioInShowerPlaneArray(false);
  }
  // update canvas
  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
}


void
ArrayPlot::Draw(const bool drawSD, const bool drawFD, const bool drawMC)
{

  fArrayObjects->Delete();
  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);
  fCanvasArray->Clear();

  if (!*fDetectorGeometry || !*fEvent)
    return;

  const DetectorGeometry* detGeom = *fDetectorGeometry;
  const Detector& det = (*fEvent)->GetDetector();
  const TBits& stationIsInCommission = det.GetActiveStations();
  const TBits& eyes  = det.GetActiveEyes();
  SetCoreAltitude();
  const double kBorder = 60.; // [km]
  const double km = 1000.;
  double minXrange = detGeom->GetMinX()/km-kBorder;
  double maxXrange = detGeom->GetMaxX()/km+kBorder;
  double minYrange = detGeom->GetMinY()/km-kBorder;
  double maxYrange = detGeom->GetMaxY()/km+kBorder;
  // keep aspect ratio --> square
  const double xLength = fabs(maxXrange - minXrange);
  const double yLength = fabs(maxYrange - minYrange);

  if (xLength > yLength) {
    minYrange -= (xLength-yLength)/2.;
    maxYrange += (xLength-yLength)/2.;
  }
  else {
    minXrange -= (yLength-xLength)/2.;
    maxXrange += (yLength-xLength)/2.;
  }

  // use pointer for unique name ...
  ostringstream title; title << "sdarr" << this << endl;
  TH2Poly* cc = new TH2Poly(title.str().c_str(),";x [km];y [km]",
                            minXrange, maxXrange,
                            minYrange, maxYrange);
  cc->GetZaxis()->SetLabelSize(0.02);
  cc->GetZaxis()->SetTitleSize(0.03);
  cc->GetZaxis()->SetTitleOffset(1.1);
  fArrayObjects->Add(cc);

  string drawOption;
  if (EventBrowserConfig::Get(cfg::eAtmoShowCloudsOnArray)) {
    fCanvasArray->SetRightMargin(0.12);
    if ((*fEvent)->GetDetector().HasCloudMap()) {
      cc->GetZaxis()->SetTitle("cloud probability");
      FillClouds(*cc, km);
      drawOption = "COLZ";
    }
  }
  else
    fCanvasArray->SetRightMargin(0.05);

  cc->Draw(drawOption.c_str());

  if (EventBrowserConfig::Get(cfg::eAtmoShowCloudsOnArray) &&
      !(*fEvent)->GetDetector().HasCloudMap()) {
    TLatex l;
    l.SetTextAlign(23);
    l.SetTextSize(0.03);
    l.SetTextColor(kRed);
    l.SetNDC(true);
    fArrayObjects->Add(l.DrawLatex(0.8, 0.988, "no cloud data"));
  }

  // default coordinates in middle of array
  double coreX = 0.5*(minXrange+maxXrange);
  double coreY = 0.5*(minYrange+maxYrange);

  // if there are stations with signals, focus on them
  const std::vector<SdRecStation>& stations = (*fEvent)->GetSDEvent().GetStationVector();
  if (!stations.empty()) {
    coreX = 0;
    coreY = 0;
    size_t count = 0;
    for (size_t iS=0;iS<stations.size();++iS)
    {
      if(stations[iS].IsDense())
        continue;
      coreX += (*fDetectorGeometry)->GetStationPosition(stations[iS].GetId()).X()/km;
      coreY += (*fDetectorGeometry)->GetStationPosition(stations[iS].GetId()).Y()/km;
      ++count;
    }

    coreX /= count;
    coreY /= count;
  }

  if ( fHasZoomCenter ) {
    coreX=fZoomCenterX;
    coreY=fZoomCenterY;
  }
  // We want a zoom on the reconstructed core and not on the Sim one (To much difference between the two with the current reconstruction
  else if (fUseRadio && true) {  // Again Later will became if HasRdEvent etc...
    if ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage) and
        (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eRecStage) > 1.5) {
      const TVector3 showerCore = (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
      const double cX=showerCore.X()/km;
      const double cY=showerCore.Y()/km;
      if ( cX > detGeom->GetMinX()/km &&
           cX < detGeom->GetMaxX()/km &&
           cY > detGeom->GetMinY()/km &&
           cY < detGeom->GetMaxY()/km ) {
        coreX = cX;
        coreY = cY;
      }
    }
    else {
      const std::vector<RdRecStation>& rstations = (*fEvent)->GetRdEvent().GetRdStationVector();
      coreX = 0;
      coreY = 0;
      size_t rcount = 0;
      for (size_t iS=0;iS<rstations.size();++iS) {
        coreX += (*fDetectorGeometry)->GetRdStationPosition(rstations[iS].GetId()).X()/km;
        coreY += (*fDetectorGeometry)->GetRdStationPosition(rstations[iS].GetId()).Y()/km;
        ++rcount;
      }
      coreX /= rcount;
      coreY /= rcount;
    }
  }
  else if ((*fEvent)->GetSDEvent().HasAxis())
    {
      const TVector3& showerCore =
        (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreAtAltitudeSiteCS(fCoreAltitude);
      const double cX=showerCore.X()/km;
      const double cY=showerCore.Y()/km;
      if ( cX > detGeom->GetMinX()/km &&
           cX < detGeom->GetMaxX()/km &&
           cY > detGeom->GetMinY()/km &&
           cY < detGeom->GetMaxY()/km ) {
        coreX = cX;
        coreY = cY;
      }
    }
  else { // try FD
    pair<double,double> average;
    pair<double,double> avError;
    double avCorrel;
    if ( (*fEvent)->CalculatePairAverage(RecEvent::eFDs,RecEvent::eCoreSiteCS,
                                         average,avError,avCorrel) ) {
      const double cX= average.first/km;
      const double cY= average.second/km;
      if ( cX > detGeom->GetMinX()/km &&
           cX < detGeom->GetMaxX()/km &&
           cY > detGeom->GetMinY()/km &&
           cY < detGeom->GetMaxY()/km ) {
        coreX = cX;
        coreY = cY;
      }
    }
  }

  SetZoomCenter(coreX, coreY);

  double x1,x2,y1,y2;
  if(fArrayZoomButton->GetPosition()!=fArrayZoomButton->GetMinPosition()) {

    if(fZoomDX==-1) {
      const double dZoom = (double) ( fArrayZoomButton->GetMaxPosition() -
                                      fArrayZoomButton->GetMinPosition());
      const double zoomFactor = 1. - (double) fArrayZoomButton->GetPosition() / dZoom;
      const double dx=( detGeom->GetMaxX()/km-
                        detGeom->GetMinX()/km)/2.*zoomFactor;
      const double dy=( detGeom->GetMaxY()/km-
                        detGeom->GetMinY()/km)/2.*zoomFactor;
      fZoomDX=fmax(dx,dy);
    }

    x1 = fmax(minXrange,coreX-fZoomDX);
    x2 = fmin(maxXrange,coreX+fZoomDX);
    y1 = fmax(minYrange,coreY-fZoomDX);
    y2 = fmin(maxYrange,coreY+fZoomDX);
  }
  else {
    const double kBorder2 = 6.;
    x2 = detGeom->GetMaxX()/km+kBorder2;
    x1 = detGeom->GetMinX()/km-kBorder2;
    y2 = detGeom->GetMaxY()/km+kBorder2;
    y1 = detGeom->GetMinY()/km-kBorder2;
  }


  // keep aspect ratio --> square
  const double dxLength = fabs(x1-x2);
  const double dyLength = fabs(y1-y2);

  if ( dxLength > dyLength ) {
    y1 -= (dxLength-dyLength)/2.;
    y2 += (dxLength-dyLength)/2.;
  }
  else {
    x1 -= (dyLength-dxLength)/2.;
    x2 += (dyLength-dxLength)/2.;
  }

  cc->GetXaxis()->SetRangeUser(x1,x2);
  cc->GetYaxis()->SetRangeUser(y1,y2);

  if (drawSD) {
    const size_t n = stationIsInCommission.GetNbits();
    TBits stationIsInactive(n);
    for (size_t i=0;i<n;++i)
      stationIsInactive[i] = !stationIsInCommission[i];

    TBits stationIsBad(n);
    const std::vector<SdBadStation>& badStations =
      (*fEvent)->GetSDEvent().GetBadStationVector();
    for (size_t i=0;i<badStations.size();++i)
      if ((badStations[i].GetReason() & eOffGrid) || (badStations[i].GetReason() & eEngineeringArray))
        stationIsInactive[badStations[i].GetId()] = true;
      else
        stationIsBad[badStations[i].GetId()] = true;
    const TBits stationIsActive = stationIsInCommission & ~stationIsBad & ~stationIsInactive;

    DrawArray(stationIsInactive,
              (*fStyleManager)->GetTankInDAQColor(),
              -1,
              (*fStyleManager)->GetTankInDAQSize());
    if (EventBrowserConfig::Get(cfg::eSdShowBadStations))
      DrawArray(stationIsBad,
                (*fStyleManager)->GetTankBadColor(),
                kGray,
                (*fStyleManager)->GetTankBadSize());
    else
      DrawArray(stationIsBad,
                (*fStyleManager)->GetTankInDAQColor(),
                -1,
                (*fStyleManager)->GetTankInDAQSize());
    DrawArray(stationIsActive,
              (*fStyleManager)->GetTankInDAQColor(),
              kBlack,
              (*fStyleManager)->GetTankInDAQSize());

#ifdef _AMIGACONTOUR_
    {
      // this hack will break whenever the ADST coordinate system changes
      const int knAmiga=13;
      const double amigaX[knAmiga]={9508.91,8741.54,9487.37,10229.4,11727.4,
                                    13218.9,13989,14751.1,14013.4,13263.8,
                                    11761,10263.9,9508.91};
      const double amigaY[knAmiga]={55195.6,53899.7,52594.8,51294.8,51283.6,
                                    51248.9,52567.2,53864.1,55165.3,56464.7,
                                    56484.5,56490.9,55195.6};

      for ( int j=0;j<knAmiga;j++) {
        amigaX[j]/=1000.;
        amigaY[j]/=1000.;
      }

      TPolyLine* amiga = new TPolyLine(knAmiga,amigaX,amigaY);
      amiga->SetLineColor(kBlue);
      amiga->Draw("SAME L");
      fArrayObjects->Add(amiga);
    }
#endif
  }

  if (drawFD)
    DrawEyes(&eyes,x1,x2,y1,y2);

  if (fUseRadio) {
    if(EventBrowserConfig::Get(cfg::eRdShowSd))
      DrawSDOnArray(x1,x2,y1,y2);

    // Here the RADIO is drawn
    vector<double> X;
    vector<double> Y;
    for (DetectorGeometry::StationPosMapConstIterator iStation =
           detGeom->GetRdStationsBegin();
         iStation != detGeom->GetRdStationsEnd();
         ++iStation)
    {
      X.push_back(iStation->second.X()/km);
      Y.push_back(iStation->second.Y()/km);
    }

    if (!X.empty()) {
      TGraph* RdGraph=new TGraph(X.size(),&X.front(),&Y.front());
      RdGraph->SetMarkerSize((*fStyleManager)->GetTankInDAQSize());
      RdGraph->SetMarkerStyle(2);
      RdGraph->SetMarkerColor(kGray+3);
      RdGraph->Draw("P SAME");
      fArrayObjects->Add(RdGraph);
    }
  }
  if (drawSD && !fUseRadio) {
    if (EventBrowserConfig::Get(cfg::eSdShowLDFOnArray) && (*fEvent)->GetSDEvent().HasLDF())
      DrawLDFOnArray();

    DrawSDOnArray(x1,x2,y1,y2);
  }

  if  (drawFD && (*fEvent)->GetNEyes())
    DrawFDOnArray();

  if (fUseRadio)
    DrawRdOnArray();

  if (drawMC && (*fEvent)->GetGenShower().GetPrimary())
    DrawMCOnArray();


  // update canvas
  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
  }

void
ArrayPlot::DoSdZoom(Int_t iZoom)
{
  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);

  if (!*fDetectorGeometry)
    return;

  const DetectorGeometry* detGeom = *fDetectorGeometry;

  const double dZoom = (double) ( fArrayZoomButton->GetMaxPosition() -
                                  fArrayZoomButton->GetMinPosition());
  const double zoomFactor = 1. - (double) iZoom / dZoom;

  const double xHalf=( detGeom->GetMaxX()/km-
                       detGeom->GetMinX()/km)/2.;
  const double yHalf=( detGeom->GetMaxY()/km-
                       detGeom->GetMinY()/km)/2.;
  // default coordinates in middle of array
  double xC = detGeom->GetMinX()/km+xHalf;
  double yC = detGeom->GetMinY()/km+yHalf;

  if ( fHasZoomCenter ) {
    xC=fZoomCenterX;
    yC=fZoomCenterY;
  }
  else if ((*fEvent)->GetSDEvent().HasAxis()) {
    const TVector3& showerCore = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreAtAltitudeSiteCS(fCoreAltitude);
    xC=showerCore.X()/km;
    yC=showerCore.Y()/km;
    SetZoomCenter(xC,yC);
  }
  else if(true ) { // This will Become RdEvent.HShower (later)
    const TVector3 showerCore = (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
    xC=showerCore.X()/km;
    yC=showerCore.Y()/km;
    SetZoomCenter(xC,yC);
  }
  else { // try FD

    pair<double,double> average;
    pair<double,double> avError;
    double avCorrel;
    if ( (*fEvent)->CalculatePairAverage(RecEvent::eFDs,RecEvent::eCoreSiteCS,
                                         average,avError,avCorrel) ) {
      xC = average.first/km;
      yC = average.second/km;
      SetZoomCenter(xC,yC);
    }
  }

  const double dx= xHalf*zoomFactor;
  const double dy= yHalf*zoomFactor;

  fZoomDX=fmax(dx,dy);
  //  if ( fZoomBox != NULL ){ delete fZoomBox;}
  // fZoomBox = new TBox(xC-fZoomDX,yC-fZoomDX,xC+fZoomDX,yC+fZoomDX);
  fZoomBox->SetFillStyle(0);
  fZoomBox->SetLineColor(kRed);
  fZoomBox->SetLineWidth(2);
  fZoomBox->SetX1(xC-fZoomDX);
  fZoomBox->SetX2(xC+fZoomDX);
  fZoomBox->SetY1(yC-fZoomDX);
  fZoomBox->SetY2(yC+fZoomDX);
  fZoomBox->Draw();
  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
}

int
ArrayPlot::GetColor(Long64_t x, double y, double z)
{
  int color = (*fStyleManager)->GetTankDefaultColor();
  switch (fSdColorStatus) {
  case eSDGroundTimeColors: {
    const double minCol = (*fStyleManager)->GetSdGroundTimeStartColor();
    const double maxCol = (*fStyleManager)->GetSdGroundTimeStopColor();
    if ((fMaxTime - fMinTime) > 0)
      color = int(minCol + (maxCol- minCol)*(x-fMinTime)/(fMaxTime-fMinTime));
    break;
  }
  case eSDGroundResidualColors: {
    const double minCol = (*fStyleManager)->GetSdGroundTimeResidualStartColor();
    const double maxCol = (*fStyleManager)->GetSdGroundTimeResidualStopColor();
    if ((fMaxTimeRes - fMinTimeRes) > 0)
      color = int(minCol + (maxCol-minCol)*(y-fMinTimeRes)/(fMaxTimeRes-fMinTimeRes));
    break;
  }
  case eSDShowerPlaneAzimuthColors: {
    const double minCol = (*fStyleManager)->GetSdShowerPlaneAzimuthStartColor();
    const double maxCol = (*fStyleManager)->GetSdShowerPlaneAzimuthStopColor();
    if (z < 0) z += 2*TMath::Pi();
    color = int(maxCol+(minCol-maxCol)*z/(2*TMath::Pi()));
    break;
  }
  case eSDNoColors:
  default:
    break;
  }
  return color;
}

void
ArrayPlot::GetMaxAndMinTime()
{
  Long64_t maxT=0;
  Long64_t minT=0;
  double maxTRes=0;
  double minTRes=0;
  Long64_t stationTime=0;
  int nT=0;
  const std::vector<SdRecStation>& stations=
    (*fEvent)->GetSDEvent().GetStationVector();
  for ( unsigned int iS=0;iS<stations.size();iS++) {
    if (!stations[iS].IsCandidate())
      continue;

    const double timeSec  = stations[iS].GetTimeSecond();
    const double timeNSec = stations[iS].GetTimeNSecond();
    stationTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);

    const double tres=stations[iS].GetPlaneTimeResidual();
    if ( stationTime>maxT || nT==0)
      maxT= stationTime;
    if ( stationTime<minT || nT==0)
      minT= stationTime;
    if (tres>maxTRes || nT==0)
      maxTRes=tres;
    if (tres<minTRes || nT==0)
      minTRes=tres;
    ++nT;
  }
  if (fUseRadio) {
    maxT=0;
    minT=0;
    int nT=0;
    const vector<RdRecStation>& vantenna= (*fEvent)->GetRdEvent().GetRdStationVector();
    //const double eventTsec = (*(*fEvent))->GetRdEvent().GetGPSSecond();
    for (vector<RdRecStation>::const_iterator viter=vantenna.begin();viter!=vantenna.end();++viter) {
      const double tSec=1;
      double tNSec=0;
      if(viter->HasParameter(revt::eSignalTime)) {
        tNSec=viter->GetParameter(revt::eSignalTime);
      }
      //    if (tSec<eventTsec) continue;
      Long64_t stationTime = Long64_t(tSec)*Long64_t(1e9) + Long64_t(tNSec);
      if (stationTime>maxT || nT==0) maxT=stationTime;
      if (stationTime<minT ||nT==0) minT=stationTime;
      ++nT;
    } // for viter
  } // if fUseRadio
  fMaxTime= maxT;
  fMinTime= minT;
  fMaxTimeRes= maxTRes;
  fMinTimeRes= minTRes;
}


/// superimpose array given station-bits on existing histogram
void
ArrayPlot::DrawArray(const TBits& stationArray,
                     const int color,
                     const int markerEdgeColor,
                     const double size)
  const
{
  const DetectorGeometry* detGeom = *fDetectorGeometry;

  vector<unsigned int> stationList;
  vector<unsigned int> stationAcList;
  vector<double> X;
  vector<double> Y;

  for (DetectorGeometry::StationPosMapConstIterator iStation =
         detGeom->GetStationsBegin();
       iStation != detGeom->GetStationsEnd();
       ++iStation)
  {
    if (stationArray.TestBitNumber(iStation->first))
    {
      stationList.push_back (iStation->first);
      X.push_back (iStation->second.X()/km);
      Y.push_back (iStation->second.Y()/km);
    }
  }

  if (X.empty())
    return;

  TGraph* stationPlot = new TGraph (X.size(), &X.front(), &Y.front());
  stationPlot->SetMarkerColor(color);
  stationPlot->SetMarkerSize(size);
  stationPlot->SetMarkerStyle(20);
  stationPlot->Draw("P");
  fArrayObjects->Add(stationPlot);

  if (markerEdgeColor>=0)
  {
    TGraph* stationPlot2 = new TGraph (X.size(), &X.front(), &Y.front());
    stationPlot2->SetMarkerColor(markerEdgeColor);
    stationPlot2->SetMarkerSize(size);
    stationPlot2->SetMarkerStyle(24);
    stationPlot2->Draw("P");
    fArrayObjects->Add(stationPlot2);
  }
}

/// superimpose FDs given eye-bits on existing histogram
void
ArrayPlot::DrawEyes(const TBits* eyeArray,
                    double x1, double x2,double y1, double y2)
  const
{

  const Detector& det = (*fEvent)->GetDetector();
  const DetectorGeometry* detGeom = *fDetectorGeometry;

  for (DetectorGeometry::ConstEyeIterator eyeIter = detGeom->EyesBegin();
       eyeIter != detGeom->EyesEnd();
       ++eyeIter) {
    const int eyeId = eyeIter->first;
    const EyeGeometry& eyeGeom = eyeIter->second;

    int defaultColor = (*fStyleManager)->GetDefaultEyeColor();

    const double x = eyeGeom.GetEyePos()[0]/km;
    const double y = eyeGeom.GetEyePos()[1]/km;

    // draw only if in range!
    if ( x < x1 || x > x2 || y < y1 || y > y2 )
      continue;

    const double R1=(*fStyleManager)->GetEyeRadius()/km*2./3.;
    const double R2=(*fStyleManager)->GetEyeRadius()/km;
    const double back_wall = eyeGeom.GetBackWallAngle();

    // draw all eyes in default color ...
    for ( EyeGeometry::ConstTelescopeIterator telIter = eyeIter->second.TelescopesBegin();
          telIter != eyeIter->second.TelescopesEnd();
          ++telIter ) {
      const int telId = telIter->first;
      const double R = (det.HasCorrectorRing(eyeId, telIter->first) ? R2 : R1);
      const TString telPointingId = det.GetPointingId(eyeId, telId);
      const double phi = (telIter->second.GetAzimuth(telPointingId) + back_wall) / degree;
      TArc* bay = new TArc(x, y, R, phi-15., phi+15.);
      bay->Draw();
      bay->SetLineColor(defaultColor);
      bay->SetFillStyle(0);
      fArrayObjects->Add(bay);
    }

    // ... and superimpose in color if there is data
    if ( eyeArray->TestBitNumber(eyeId) ) {

      int eyeColor = (*fStyleManager)->GetFDEyeColor(eyeId);

      for ( EyeGeometry::ConstTelescopeIterator telIter = eyeIter->second.TelescopesBegin();
            telIter != eyeIter->second.TelescopesEnd();
            ++telIter ) {

        int telId = telIter->first;

        if ( det.IsInDAQ(eyeId, telId) ) {

          const double R = (det.HasCorrectorRing(eyeId, telIter->first) ? R2 : R1);
          const TString telPointingId = det.GetPointingId(eyeId, telId);
          const double phi = (telIter->second.GetAzimuth(telPointingId) + back_wall)/degree;
          TArc* bay = new TArc(x, y, R, phi-15., phi+15.);
          bay->Draw();
          bay->SetLineColor(eyeColor);
          bay->SetFillStyle(0);
          bay->SetLineWidth(2);

          if ((*fEvent)->HasEye(eyeId)) {

            const TBits& eventBits =
              (*fEvent)->GetEye (eyeId).GetMirrorsInEvent();

            if ( eventBits.TestBitNumber(telId) ) {

              bay->SetFillColor(eyeColor);
              bay->SetFillStyle(3001);
            }
          }

          fArrayObjects->Add(bay);
        }
      }
    }
  }
}

void
ArrayPlot::SetZoomCenter(double x, double y)
{

  fHasZoomCenter=true;
  fZoomCenterX=x;
  fZoomCenterY=y;

}


void
ArrayPlot::DrawSelectedStationMarker(int stationNumber)
{

  if(!(*fEvent)->GetSDEvent().HasTriggeredStations())
    return;

  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);

  const std::vector<SdRecStation>& stations = (*fEvent)->GetSDEvent().GetStationVector();

  int stationMarker;
  const bool tot= fRecStationClassVersion<18?stations[stationNumber].IsThreshold():stations[stationNumber].IsTOT();

  if(tot)
    stationMarker = (*fStyleManager)->GetTankTOTStyle();
  else
    stationMarker = (*fStyleManager)->GetTankDefaultStyle();

  unsigned int id = stations[stationNumber].GetId();
  double X;
  double Y;
  const Detector& det = (*fEvent)->GetDetector();
  if(stations[stationNumber].IsDense()){
    X= det.GetStationPosition(id).X()/km;
    Y= det.GetStationPosition(id).Y()/km;
  }
  else{
    const DetectorGeometry* detGeom = *fDetectorGeometry;
    X = detGeom->GetStationPosition(id).X()/km;
    Y = detGeom->GetStationPosition(id).Y()/km;
  }

  TMarker* stationPlot=new TMarker(X,Y,stationMarker);
  stationPlot->SetMarkerSize(1.2*(*fStyleManager)->GetTankInDAQSize());
  if( stations[stationNumber].IsAccidental() )
    stationPlot->SetMarkerColor(kBlack);
  else if(stations[stationNumber].IsCandidate())
    stationPlot->SetMarkerColor(kBlack);

  stationPlot->Draw();

  fArrayObjects->Add(stationPlot);

  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
}

void
ArrayPlot::FillClouds(TH2Poly& hist, const double meterToPlot)
  const
{
  const DetectorGeometry& detGeom = *(*fDetectorGeometry);
  const Detector& detector = (*fEvent)->GetDetector();

  const double dX = detGeom.GetCloudPixelWidthX() / 2 / meterToPlot;
  const double dY = detGeom.GetCloudPixelWidthY() / 2 / meterToPlot;

  typedef vector<TVector3>::const_iterator PixelPosIter;
  const vector<TVector3>& pixelCenters = detGeom.GetCloudPixelCenters();
  int currPix = 0;

  for (PixelPosIter iter = pixelCenters.begin(); iter != pixelCenters.end(); ++iter) {
    if (detector.HasCloudFraction(currPix)) {
      const double xC = iter->X() / meterToPlot;
      const double yC = iter->Y() / meterToPlot;
      const unsigned int n = 5;
      double x[n] = { xC - dX, xC + dX, xC + dX, xC - dX, xC - dX};
      double y[n] = { yC - dY, yC - dY, yC + dY, yC + dY, yC - dY};
      const int binId = hist.AddBin(n, x, y);
      hist.SetBinContent(binId, detector.GetCloudFraction(currPix));
    }
    ++currPix;
  }

  // two dummy bins to define the scale (SetRangeUser() is not working for TH2Poly?)
  const unsigned int n = 4;
  double farAway = -2e6;
  double x[n] = { farAway / meterToPlot, (farAway+1) / meterToPlot,
                  (farAway+1) / meterToPlot, farAway / meterToPlot};
  double y[n] = {  farAway / meterToPlot, (farAway+1) / meterToPlot,
                  (farAway+1) / meterToPlot, farAway / meterToPlot};
  const int binId1 = hist.AddBin(n, x, y);
  hist.SetBinContent(binId1, 1.);
  const int binId2 = hist.AddBin(n, x, y);
  hist.SetBinContent(binId2, 0.);

}


void
ArrayPlot::DrawRadioInShowerPlaneArray(bool hasdrawnSDalready)
{
  (hasdrawnSDalready)?cout <<  "true":cout <<"false"<< endl;
  vector<double> x;
  vector<double> y;
  const DetectorGeometry* detGeom = *fDetectorGeometry;
  const TVector3& axis = (*fEvent)->GetRdEvent().GetRdRecShower().GetAxisSiteCS();
  const TVector3& core = (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
  const vector<RdRecStation>& vecRstat = (*fEvent)->GetRdEvent().GetRdStationVector();
  for(vector<RdRecStation>::const_iterator stiter=vecRstat.begin();stiter!=vecRstat.end();++stiter) {
    x.push_back(detGeom->GetRdStationShowerPosition(stiter->GetId(), axis, core).X()/km);
    y.push_back(detGeom->GetRdStationShowerPosition(stiter->GetId(), axis, core).Y()/km);
    //     x.push_back(detGeom->GetRdStationPosition(stiter->GetId()).X()/km);
    //     y.push_back(detGeom->GetRdStationPosition(stiter->GetId()).Y()/km);
  } //stiter
  TGraph* RStationPlot = new TGraph(x.size(),&x.front(),&y.front());
  RStationPlot->SetMarkerColor(kBlue);
  RStationPlot->SetMarkerSize(3);
  RStationPlot->SetMarkerStyle(2);
  fArrayObjects->Add(RStationPlot);
  if (hasdrawnSDalready)
    RStationPlot->Draw(" P ");
  else
    RStationPlot->Draw("AP");
  TMarker* RcoreMarker = new TMarker(core.X()/1000,core.Y()/1000,29);
  RcoreMarker->SetMarkerColor(kMagenta);
  fArrayObjects->Add(RcoreMarker);
  RcoreMarker->Draw("SAME");

} // DrawRadioInShowerPlaneArray

void
ArrayPlot::DrawRdOnArray()
{

  const vector<RdRecStation>& vecRstat = (*fEvent)->GetRdEvent().GetRdStationVector();
  const DetectorGeometry* detGeom = *fDetectorGeometry;
  for (vector<RdRecStation>::const_iterator stiter = vecRstat.begin();
       stiter!=vecRstat.end();++stiter) {
    float signalEW=0;
    float signalNS=0;

    const TVector3& antennaPosition =
    detGeom->GetRdStationPosition(stiter->GetId());
    const double x = antennaPosition.X()/km;
    const double y = antennaPosition.Y()/km;
    Long64_t stationTime=0;

    try {
      double signalTime = stiter->GetParameter(revt::eSignalTime);
      stationTime = signalTime + 1.e9;
      signalEW = stiter->GetParameter(revt::ePeakAmplitudeEW) * 1e6; // +1e6 so convert to the correct units
      signalNS = stiter->GetParameter(revt::ePeakAmplitudeNS) * 1e6;
    }// catch(const std::exception& e) {
      //cerr << e.what();
      //cerr << " Did you call the RdStationSignalReconstructor ?" << endl;
    //}
    catch(...) {
    //  cerr << "eSignalTime, ePeakAmplitudeEW or ePeakAmplitudeNS not set. Did you call the RdStationSignalReconstructor ?" << endl;
    }

    if((signalEW>0) || (signalNS>0)) {
      // Preliminary formula from logrithmic marker scalling
      double signalDrawingNS = TMath::Log10(signalNS)/40.;
      double signalDrawingEW = TMath::Log10(signalEW)/40.;

      TLine* signalNSline = new TLine(x,y-signalDrawingNS,x,y+signalDrawingNS);
      TLine* signalEWline = new TLine(x-signalDrawingEW,y,x+signalDrawingEW,y);
      signalNSline->SetLineWidth(2);
      signalEWline->SetLineWidth(2);
      if (stiter->HasPulse() && !stiter->IsRejected()) {
        signalNSline->SetLineColor(GetColor(stationTime,1.,1.));
        signalEWline->SetLineColor(GetColor(stationTime,1.,1.));
      }
      else if (stiter->IsRejected()) {
        signalNSline->SetLineColor(kBlack);
        signalEWline->SetLineColor(kBlack);
      }
      else { // in case the signals are below the SNR cut (no pulse)
        signalNSline->SetLineColor(kGray+1);
        signalEWline->SetLineColor(kGray+1);
      }
      fArrayObjects->Add(signalNSline);
      fArrayObjects->Add(signalEWline);
      signalNSline->Draw("SAME");
      signalEWline->Draw("SAME");
    }
    else { // mark stations in case no signal reconstructor is performed
      TLine* signalNSline = new TLine(x,y-0.03,x,y+0.03);
      TLine* signalEWline = new TLine(x-0.03,y,x+0.03,y);
      signalNSline->SetLineWidth(2);
      signalEWline->SetLineWidth(2);
      signalNSline->SetLineColor(kGray+1);
      signalEWline->SetLineColor(kGray+1);
      fArrayObjects->Add(signalNSline);
      fArrayObjects->Add(signalEWline);
      signalNSline->Draw("SAME");
      signalEWline->Draw("SAME");
    }

    // Lets draw a square at the BLS location
    // This is our principle noise source
    if (stiter->GetId()==1) {
      TMarker* BlsMark= new TMarker(x+12.04/km,y+36.1/km,25);
      BlsMark->SetMarkerColor(kGray+2);
      fArrayObjects->Add(BlsMark);
      BlsMark->Draw("SAME");
    }
  } // for stiter
  // only draw shower core and axis if there is a reconstructed shower
  if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage)) {
    const TVector3& core= (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
    TMarker* RcoreMarker = new TMarker(core.X()/1000,core.Y()/1000,29);
    RcoreMarker->SetMarkerColor(kBlack);
    fArrayObjects->Add(RcoreMarker);
    RcoreMarker->Draw("SAME");
    //const double phi= (*fEvent)->GetRdEvent().GetRdRecShower().GetAzimuth();
    double phi=0;
    if ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eShowerAxisY)
      && (*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eShowerAxisX))
      phi=atan2((*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eShowerAxisY),
        (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eShowerAxisX));
    if (phi<0)
      phi+=2*TMath::Pi();

    const double coreLength =
      fmin((*fStyleManager)->GetAxisProjectionLength(),0.8*fZoomDX);
    TLine* rdcoreLine=
      new TLine(core.X()/1000, core.Y()/1000, core.X()/1000 + coreLength*cos(phi), core.Y()/1000 + coreLength*sin(phi));
    rdcoreLine->SetLineColor(kBlack);
    rdcoreLine->SetLineWidth(1.5);
    fArrayObjects->Add(rdcoreLine);
    rdcoreLine->Draw("SAME");
  }

  // set core altitude if not set from SD (for MC core position
  if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eCoordinateOriginZ)) {
    fCoreAltitude = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eCoordinateOriginZ);
  }



  // plot radio core error ellipse
  if  (  ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage))
      && ((*fEvent)->GetRdEvent().GetRdRecShower().GetParameter(revt::eRecStage) >= 2.0)
      && ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameterCovariance(revt::eCoreX, revt::eCoreX))
      && ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameterCovariance(revt::eCoreY, revt::eCoreY))
      && ((*fEvent)->GetRdEvent().GetRdRecShower().HasParameterCovariance(revt::eCoreX, revt::eCoreY)))
  {
    const TVector3& core= (*fEvent)->GetRdEvent().GetRdRecShower().GetCoreSiteCS();
    const double coreX = core.X() / km;
    const double coreY = core.Y() / km;
    const double coreXErr = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameterError(revt::eCoreX)
        / km;
    const double coreYErr = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameterError(revt::eCoreY)
        / km;

    const double sizeFactor = 1.51; // to get 68 % coverage for one sigma intervals in 2D
    const double sx2 = coreXErr * coreXErr;
    const double sy2 = coreYErr * coreYErr;
    const double sxy = (*fEvent)->GetRdEvent().GetRdRecShower().GetParameterCovariance(revt::eCoreX,
        revt::eCoreY) / km / km;
    const double errorEllipseAngle = 0.5 * atan2(2 * sxy, sx2 - sy2);
    const double sa = sin(errorEllipseAngle);
    const double ca = cos(errorEllipseAngle);
    const double ru = sizeFactor * sqrt(sx2 * ca * ca + 2 * sxy * sa * ca + sy2 * sa * sa);
    const double rv = sizeFactor * sqrt(sx2 * sa * sa - 2 * sxy * sa * ca + sy2 * ca * ca);

    TEllipse* cc = new TEllipse(coreX, coreY, ru, rv, 0., 360., errorEllipseAngle * 180. / M_PI);
    fArrayObjects->Add(cc);
    cc->SetFillColor((*fStyleManager)->GetSDColor());
    cc->SetLineColor((*fStyleManager)->GetSDColor());
    cc->SetFillStyle(3017);
    cc->Draw("F");
  }

}


void
ArrayPlot::DrawSelectedRStationMarker(int stationNumber)
{
  // Based on the SD one but Addapted for Rd (Because)
  fCanvasArray->cd();
  fCanvasArray->GetCanvas()->SetEditable(true);

  const std::vector<RdRecStation>& stations=
    (*fEvent)->GetRdEvent().GetRdStationVector();

  const int stationMarker = 7; // Will be added in the StyleManager later

  const unsigned int id = stations[stationNumber].GetId();
  const DetectorGeometry* detGeom = *fDetectorGeometry;
  const double X = detGeom->GetRdStationPosition(id).X()/km;
  const double Y = detGeom->GetRdStationPosition(id).Y()/km;

  TMarker* stationPlot=new TMarker(X,Y,stationMarker);
  stationPlot->SetMarkerSize(0.5*(*fStyleManager)->GetTankInDAQSize());
  stationPlot->SetMarkerColor(kBlack);
  stationPlot->Draw("");

  fArrayObjects->Add(stationPlot);

  fCanvasArray->GetCanvas()->Modified();
  fCanvasArray->GetCanvas()->Update();
  fCanvasArray->GetCanvas()->SetEditable(false);
}


