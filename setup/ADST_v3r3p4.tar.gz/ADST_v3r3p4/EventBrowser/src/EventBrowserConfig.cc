#include "EventBrowserConfig.h"

using namespace cfg;

EventBrowserConfig&
EventBrowserConfig::GetInstance()
{
  static EventBrowserConfig gConfig;
  return gConfig;
}

bool
EventBrowserConfig::Get(const EventBrowserSwitch sw)
{
  return GetInstance().fBits[int(sw)];
}

void
EventBrowserConfig::Set(const EventBrowserSwitch sw, bool value)
{
  GetInstance().fBits.set(int(sw),value);
}

ELDFType
EventBrowserConfig::GetLDFType()
{
  return GetInstance().fLDFType;
}

void
EventBrowserConfig::SetLDFType(const ELDFType type)
{
  GetInstance().fLDFType = type;
}
