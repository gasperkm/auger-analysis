// #include <config.h>
/*
   Martin Maur
   20 Apr 2012
*/

#ifndef __MdSimScintillator_h_
#define __MdSimScintillator_h_

#include <TObject.h>
#include <vector>
#include <cmath>


class MdSimScintillator : public TObject {

public:
  //structure holds information about single photo electron pulses before amplification
  struct SPEPulse {
    double fMu;  //time
    double fSigma;  //width in time, std (depends on setting of pulseParametrization in MModelConfig!!)
    double fAmplitude;  //charge (depends on setting of pulseParametrization in MModelConfig!!)
    unsigned int fDestPixelId; // id of pixel where the spe goes after crosstalk, is not necessary the one that is retrieved by ScintillatorToPixelId() !
    double GetCharge() const {  //auger base unit for charge is e+
      return fSigma * fAmplitude * sqrt(2*3.1415926);
    }
  };

  MdSimScintillator();
  virtual ~MdSimScintillator() { }

  void SetId(const unsigned int id) { fId = id; }
  unsigned int GetId() const { return fId; }

  void SetModuleId(const unsigned int id) { fModuleId = id; }
  unsigned int GetModuleId() const { return fModuleId; }

  void SetChannelId(const unsigned int id) { fChannelId = id; }
  unsigned int GetChannelId() const { return fChannelId; }

  void SetPixelId(const unsigned int id) { fPixelId = id; }
  unsigned int GetPixelId() const { return fPixelId; }

  unsigned int GetNumberOfInjectedMuons() const { return fNumberOfInjectedMuons; }
  void SetNumberOfInjectedMuons(unsigned int noMuons) { fNumberOfInjectedMuons = noMuons; }

  double GetEnergyDeposit() const { return fEnergyDeposit; }
  void SetEnergyDeposit(double energy) { fEnergyDeposit = energy; }

  double GetMuonEnergyDeposit() const { return fMuonEnergyDeposit; }
  void SetMuonEnergyDeposit(const double energy) { fMuonEnergyDeposit = energy; }

  const MdSimScintillator::SPEPulse* GetSPEPulse(const unsigned int i) const;
  const std::vector<MdSimScintillator::SPEPulse>& GetSPEPulseVector() const { return fSPEPulses; }
  bool HasSPEPulses() const { return !fSPEPulses.empty(); }

  void AddSPEPulse(const double mu, const double sigma, const double amplitude, const unsigned int destPixelId);

  double GetTotalCharge() const;

private:
  unsigned int fId;
  unsigned int fChannelId;
  unsigned int fPixelId;
  unsigned int fModuleId;

  unsigned int fNumberOfInjectedMuons;

  double fEnergyDeposit;
  double fMuonEnergyDeposit;

  std::vector<MdSimScintillator::SPEPulse> fSPEPulses;

  ClassDef(MdSimScintillator, 1);

};


#endif // __MdSimScintillator_h_
