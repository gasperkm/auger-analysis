#include "MdSimScintillator.h"

/*
   Martin Maur
   20 Apr 2012
*/


using namespace std;


ClassImp(MdSimScintillator);


MdSimScintillator::MdSimScintillator() :
  fId(0),
  fChannelId(0),
  fPixelId(0),
  fModuleId(0),
  fNumberOfInjectedMuons(0),
  fEnergyDeposit(0),
  fMuonEnergyDeposit(0)
{ }


const MdSimScintillator::SPEPulse*
MdSimScintillator::GetSPEPulse(const unsigned int i)
  const
{
  if (i >= fSPEPulses.size())
    return NULL;
  return &fSPEPulses[i];
}


void
MdSimScintillator::AddSPEPulse(const double mu, const double sigma, const double amplitude,
                               const unsigned int destPixelId)
{
  const MdSimScintillator::SPEPulse newSPEPulse =
    { mu, sigma, amplitude, destPixelId };
  fSPEPulses.push_back(newSPEPulse);
}


double 
MdSimScintillator::GetTotalCharge()
  const
{
  double charge = 0;
  for (unsigned int i = 0; i != fSPEPulses.size(); ++i) {
    charge += fSPEPulses[i].GetCharge();
  }
  return charge;
}

