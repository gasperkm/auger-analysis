#include <MdRecShower.h>
#include <algorithm>
#include <iostream>
#include <cmath>
using namespace std;

ClassImp(MdRecShower);

MdRecShower::MdRecShower() :
  fBeta(0),
  fBetaError(0),
  fBetaSystematics(0),
  fNMuRef(0),
  fNMuRefError(0),
  fNMuRefSystematics(0),
  fMLDFChi2(0),
  fMLDFNdof(0),
  fMLDFLikelihood(0),
  fReferenceDistance(0),
  fMLDFRecStage(0)
{
}

double MdRecShower::TabulatedFunction(const double r) const {

  if (fRhos.empty()) return 0;

  const size_t i = upper_bound(fRhos.begin(),fRhos.end(), r) - fRhos.begin();

  if (i<1)
    return fValues.front();

  if (i >= fRhos.size())
    return 0.0;

  const double a = log(fRhos[i-1]);
  const double b = log(fRhos[i]);
  const double fa = log(fValues[i-1]);
  const double fb = log(fValues[i]);

  const double z = (log(r)-a)/(b-a);

  return exp(fa*(1.0-z) + fb*z);

}
