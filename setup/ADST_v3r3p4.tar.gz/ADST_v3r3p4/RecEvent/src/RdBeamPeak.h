#ifndef __RdBeamPeak_H
#define __RdBeamPeak_H

#include <TObject.h>

class RdBeamPeak : public TObject {
 public:
  RdBeamPeak();
  
  Double_t GetHeight() const { return height; }
  Double_t GetRMS() const { return RMS; }
  Double_t GetOffset() const { return offset; }
  Double_t GetTime() const { return time; }
  
  
  void SetHeight(Double_t h) { height = h; }
  void SetRMS(Double_t rms) { RMS = rms; }
  void SetOffset(Double_t ofs) { offset = ofs; }
  void SetTime(Double_t t) { time = t; }
 protected:
  Double_t height;
  Double_t time; 
  Double_t RMS;
  Double_t offset;

  ClassDef(RdBeamPeak,1);
};

#endif
