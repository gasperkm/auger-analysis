// $Id: LDF.cc 26624 2014-09-25 11:42:27Z maris $

#include <LDF.h>

#include <algorithm>
#include <functional>
#include <iostream>
#include <cmath>

using namespace std;


ClassImp(LDF);


LDF::LDF() :
  fReferenceDistance(1000),  // for backward compatibility
  fShowerSizeLabel("S1000"), // for backward compatibility
  fS1000(0),                 // general shower size, but called fS1000 for backward compatibility
  fS1000Error(0),
  fS1000BetaSys(0),
  fSizeWeather(0),
  fSizeWeatherEr(0),         
  fSizeGeomagnetic(0),        
  fSizeGeomagneticEr(0),
  fBeta(0),                  // LDF parameters
  fBetaError(0),
  fBetaSys(0),
  fGamma(0),
  fGammaError(0),
  fLDFChi2(0),
  fLDFLikelihood(0),
  fLDFNdof(0),
  fLDFStatus(0)
{ }


double
LDF::NKGFunction(const double r)
  const
{
  const double k1000m = GetReferenceDistance(); //*meter;

  return fS1000*pow(r/k1000m, fBeta)*pow((700 + r)/(700. + k1000m), fGamma + fBeta);
}


double
LDF::NKGFermiFunction(const double r)
  const
{
  const double k1000m = GetReferenceDistance(); //*meter;

  return fS1000*pow(r/k1000m, fBeta)*pow((700 + r)/(k1000m + 700.), fGamma + fBeta) /
    (exp((r - fNKGFermiMu) / fNKGFermiTau) + 1);
}


double
LDF::PowerLawFunction(const double r)
  const
{
  const double kNearRadius = 300;  //*meter;
  const double k1000m = GetReferenceDistance();  //*meter;
  const double nearCore = kNearRadius / k1000m;
  const double relR = r / k1000m;

  if (relR > nearCore)
    return fS1000*pow(relR, fBeta + fGamma*log(relR));

  const double gf = fGamma*log(nearCore);

  return fS1000*pow(relR, fBeta + 2*gf) * pow(nearCore, -gf);
}


double
LDF::TabulatedFunction(const double r)
  const
{
  if (fRhos.empty())
    return 0;

  const size_t i = upper_bound(fRhos.begin(), fRhos.end(), r) - fRhos.begin();

  if (i < 1)
    return fS1000*fValues.front();

  if (i >= fRhos.size())
    return 0;

  const double a = log(fRhos[i - 1]);
  const double b = log(fRhos[i]);
  const double fa = log(fValues[i - 1]);
  const double fb = log(fValues[i]);

  const double z = (log(r) - a) / (b - a);

  return fS1000*exp(fa*(1 - z) + fb*z);
}


double
LDF::InvertedTabulatedFunction(const double s)
  const
{
  if (fRhos.empty())
    return 0;

  // we assume that LDF is monotonously falling
  const size_t i = upper_bound(fValues.begin(), fValues.end(), s/fS1000, greater<double>()) - fValues.begin();

  if (i < 1)
    return fRhos.front();

  if (i >= fRhos.size())
    return fRhos.back();

  const double a = log(fRhos[i - 1]);
  const double b = log(fRhos[i]);
  const double fa = log(fValues[i - 1]);
  const double fb = log(fValues[i]);
  const double z = (log(s/fS1000) - fa) / (fb - fa);
  return exp(a*(1 - z) + b*z);
}


std::string
LDF::ReturnLDFName(const ELDFType type)
  const
{
  switch (type) {
  case ePL:
    return "PL";
  case eNKG:
    return "NKG";
  case eNKGFermi:
    return "NKG+ Fermi";
  case eTabulated:
    return "Tabulated";
  default:
    return "Unknown";
  };
}

std::string
LDF::ReturnReconstructionStatus()
  const
{
  std::string result;

  if (fLDFStatus == 0.5)
    result = "Partial reco. (barycenter)";
  else if (fLDFStatus < 2)
    result = "Partial reco. (plane fit)";
  else if (fLDFStatus == 2)
    result = "Partial reco. (LDF est.)";
  else if (fLDFStatus == 2.5)
    result = "Partial reco. (LDF and curvature est.)";
  else if (fLDFStatus  < 4)
    result = "Partial reco. (wo not-triggered st.)";
  else if (fLDFStatus  == 4)
    result = "Partial reco. (wo curvature)";
  else if (fLDFStatus == 4.5)
    result = "Full reconstruction";
  else if (fLDFStatus == 4.501)
    result = "Full reconstruction (+limit)";
  else if (fLDFStatus == 4.6)
    result = "Full reconstruction (#beta free)";
  else if (fLDFStatus == 4.61)
    result = "Full reconstruction (#beta, #gamma free)";
  else if (fLDFStatus == 4.51)
    result = "Full reconstruction (#gamma free)";
  else if (fLDFStatus == 4.601)
    result = "Full reco (#beta free+limit)";
  else if (fLDFStatus == 4.611)
    result = "Full reconstruction (#beta, #gamma free + limit))";
  else if (fLDFStatus == 4.511)
    result = "Full reconstruction (#gamma free +limit)";
  else if (fLDFStatus == 5)
    result = "Global reconstruction (LDF + axis)";
  else
    result = "Unknown reco. status";

  return result;
}

double
LDF::Evaluate(const double r, const ELDFType type)
  const
{
  switch (type) {
  case ePL:
    return PowerLawFunction(r);
  case eNKG:
    return NKGFunction(r);
  case eNKGFermi:
    return NKGFermiFunction(r);
  case eTabulated:
    return TabulatedFunction(r);
  default:
    cerr << "Error: no handler for requested LDF type" << endl;
  };

  return 0;
}


double
LDF::EvaluateInverted(const double signal, const ELDFType type)
  const
{
  if (type == eTabulated)
    return InvertedTabulatedFunction(signal);

  // find the inverse with false-position method on log(LDF(r)/S)

  // get initial bracket; assume that LDF is monotonously falling
  double xl = 1e3;
  double xh = 1e3;
  double yl = 0, yh = 0;
  for (int i = 0; i < 4 && (yh = log(Evaluate(xh, type)/signal)) < 0; ++i)
    xh /= 10.;
  for (int i = 0; i < 3 && (yl = log(Evaluate(xl, type)/signal)) > 0; ++i)
    xl *= 10.;

  if (yl*yh > 0)
    return 0.0; // no bracket

  // yields relative error on radius < 0.001 with 5 to 10 iterations
  for (int iter = 0; iter < 50; ++iter) {
    const double x = xl+(xh-xl)*yl/(yl-yh);
    const double y = log(Evaluate(x, type)/signal);
    if (abs(y) < 1e-3 || y == 0.0)
      return x; // convergence
    if (y < 0.0) {
      xl = x;
      yl = y;
    } else {
      xh = x;
      yh = y;
    }
  }

  return 0; // no convergence
}


double
TF1PowerLawFunction(const double* const x, const double* const par)
{
  const double r = x[0];
  const double s1000 = par[0];
  const double beta = par[1];
  const double gamma = par[2];
  const double k1000m = par[3];
  const double kNearRadius = 300;//*meter;
  const double nearCore = kNearRadius / k1000m;
  const double relR = r / k1000m;

  if (relR > nearCore)
    return s1000*pow(relR, beta + gamma*log(relR));

  const double gf = gamma*log(nearCore);
  return  s1000*pow(relR, beta + 2*gf) * pow(nearCore, -gf);
}


double
TF1NKGFunction(const double* const x, const double* const par)
{
  const double r = x[0];
  const double s1000 = par[0];
  const double beta = par[1];
  const double gamma = par[2];
  const double k1000 = par[3];
  return s1000*pow(r/k1000, beta)*pow((700 + r)/(k1000 + 700.), gamma + beta);  //(exp((r - 2660) / 242) + 1);
}


double
TF1NKGFermiFunction(const double* const x, const double* const par)
{
  const double r = x[0];
  const double s1000 = par[0];
  const double beta = par[1];
  const double gamma = par[2];
  const double mu = par[3];
  const double tau = par[4];
  const double k1000 = par[5];

  return s1000*pow(r/k1000, beta)*pow((700 + r)/(k1000 + 700.), gamma + beta) / (exp((r - mu) / tau) + 1);
}


TF1
LDF::GetFunction(const ELDFType type)
  const
{
  const double refDistance = GetReferenceDistance(); //*meter;
  switch (type) {
  case eNKG: {
    TF1 f("LDF_function", TF1NKGFunction, 10,  6000, 4);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, refDistance);
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    return f;
  }
  case ePL: {
    TF1 f("LDF_function", TF1PowerLawFunction, 10, 6000, 4);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, refDistance);
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    return f;
  }
  case eHP: {
    cout << "Not Implemeted yet !!" << endl;
    break;
  }
  case eNKGFermi: {
    TF1 f("LDF_function", TF1NKGFermiFunction, 10,  6000, 6);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, fNKGFermiMu);
    f.SetParameter(4, fNKGFermiTau);
    f.SetParameter(5, refDistance);
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    f.SetParameter(3, 0);
    f.SetParameter(4, 0);
    return f;
  }
  case eLOG: {
    cout << "Not Implemeted yet !!" << endl;
    break;
  }
  case eTabulated: {
    cout << "GetFunction(...) cannot be called for tabulated LDF" << endl;
    break;
  }
  };
  return TF1("dummy", "1");
}


void
LDF::DumpASCII(ostream& o)
  const
{
  o << "  ShowerSize            " << fS1000 << " (+/- " << fS1000Error << ")\n";
}
