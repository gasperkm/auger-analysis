// $Id: SdRecStation.h 27046 2014-11-28 20:43:31Z darko $
#ifndef __SdRecStation_h_
#define __SdRecStation_h_

#include <StationStatus.h> // for the enums
#include <TraceType.h>     // for the enums
#include <RecStation.h>
#include <Traces.h>

#include <TObject.h>

#include <vector>


//  Station data definition

class SdRecStation : public RecStation {

public:
  SdRecStation();

  // ------------------ setters ----------------------------------------------

  /// set  id of station i

  void SetTime(const double s, const double ns)
  { fTimeNSecond = ns; fTimeSecond = s; }
  double GetTimeSecond() const { return fTimeSecond; }       ///< get time of station
  double GetTimeNSecond() const { return fTimeNSecond; }     ///< get time

  void SetRecoveredSignal(const double c, const double e)
  { fRecoveredSignal = c; fRecoveredSignalError = e; }
  double GetRecoveredSignal() const { return fRecoveredSignal; }
  double GetRecoveredSignalError() const { return fRecoveredSignalError; }

  void SetSPDistance(const double c, const double e)
  { fSPDistance = c; fSPDistanceError = e; } ///< set plane distance to the core
  double GetSPDistance() const { return fSPDistance; }         ///< get the shower plane distance to the core
  double GetSPDistanceError() const { return fSPDistanceError; } ///< get the shower plane distance to the core

  void SetPlaneTimeResidual(const double c)
  { fPlaneTimeResidual = c; } ///< set the time residual of the plane fit
  double GetPlaneTimeResidual() const { return fPlaneTimeResidual; }       ///< get the time-residual of plane fit

  void SetTimeVariance(const double timeVariance) { fTimeVariance = timeVariance; } ///> set the time uncertainty from the time variance model
  double GetTimeVariance() const { return fTimeVariance;} ///> get the time uncertainty from the time variance model

  void SetCurvatureTimeResidual(const double c)
  { fCurvatureTimeResidual = c; } ///< set the time residual of the plane fit or curvature fit
  double GetCurvatureTimeResidual() const { return fCurvatureTimeResidual; }       ///< get the time-residual of plane fit

  void SetLDFResidual(const double c) { fLDFResidual = c; } ///< set the residual of LDF
  double GetLDFResidual() const { return fLDFResidual; }       ///< get the residual of LDF

  void SetRiseTime(const double c, const double e) { fRiseTime = c; fRiseTimeRMS = e; } ///< set the rise time
  double GetRiseTime() const { return fRiseTime; }            ///< get the rise time
  double GetRiseTimeRMS() const { return  fRiseTimeRMS; }     ///< get the rise time spread from the 3 pmts

  void SetCorrRiseTime(const double c, const double e) { fCorrRiseTime = c; fCorrRiseTimeError = e; } ///< set the rise time
  double GetCorrRiseTime() const { return fCorrRiseTime; }            ///< get the rise time as provided by UCLA
  double GetCorrRiseTimeRMS() const { return  fCorrRiseTimeError; }     ///< get the rise time error as provided by UCLA

  void SetFallTime(const double c, const  double e) { fFallTime = c; fFallTimeRMS = e; } ///< set the fall time
  double GetFallTime() const { return fFallTime; }
  double GetFallTimeRMS() const { return fFallTimeRMS; }       ///< get the fall time

  void SetTime50(const double t, const double e) { fTime50 = t; fTime50RMS = e; }
  double GetTime50() const { return fTime50; }
  double GetTime50RMS() const { return fTime50RMS; }

  void SetAzimuthSP(const double c) { fAzimuthShowerPlane = c; } ///< set the azimuth in SP coord
  double GetAzimuthSP() const { return fAzimuthShowerPlane; }  ///< get the azimuth in SP coord

  void SetShapeParameter(const double sp, const double sprms) { fShapeParameter = sp; fShapeParameterRMS = sprms; } ///< set the shape parameter
  double GetShapeParameter() const { return fShapeParameter; }  ///< get the shape parameter
  double GetShapeParameterRMS() const { return fShapeParameterRMS; }  ///< get the shape parameter

  void SetMuonComponent(const double c) { fMuonComponent = c; } ///< set muon component
  double GetMuonComponent() const { return fMuonComponent; }  ///< returns the  muon signal[number of muons]

  /// Set the saturation
  void SetLowGainSaturated() { fSaturationStatus = eLowGainSaturated; }
  void SetHighGainSaturated() { fSaturationStatus = eHighGainSaturated; }
  void SetNoSaturation() { fSaturationStatus = eNoSaturation; }

  ///ask for saturation status
  bool IsLowGainSaturated() const { return fSaturationStatus == eLowGainSaturated; }
  bool IsHighGainSaturated() const { return fSaturationStatus == eHighGainSaturated; }
  bool IsNoSaturation() const { return fSaturationStatus == eNoSaturation; }

  void SetRiseTimeRejectCode(const unsigned short inRejectCode) { fRejectCode = inRejectCode; }
  UShort_t GetRejectCode() { return fRejectCode; }

  void SetIsDense(const bool is = true) { fIsDense = is; }
  bool IsDense() const { return fIsDense; }
  void SetSignalStartAndEnd(const UShort_t start, const UShort_t end)
  { fSignalStartSlot = start; fSignalEndSlot = end; }
  UShort_t GetSignalStartSlot() const { return fSignalStartSlot; }
  UShort_t GetSignalEndSlot() const { return fSignalEndSlot; }

  double GetAssymCorrRiseTime(const double zenith) const;          ///< get the corrected rise time according to Leeds
  double GetAssymCorrRiseTimeKG(const double zenith) const;          ///< get the corrected rise time according to Karen Mora
  double GetAssymCorrRiseTimeError(const double zenith) const;     ///< get the corrected rise time uncertainty, according to Lecce
  double GetAssymCorrRiseTimeErrorKG(const double zenith) const;     ///< get the corrected rise time uncertainty, according to Karen Mora
  double GetSignalTimeSigma2Intrinsic(const double zenith) const;

  void AddPMTTraces(const Traces& what) { fTraces.push_back(what); }
  const std::vector<Traces>& GetPMTTraces() const { return fTraces; }

  bool HasPMTTraces(const ETraceType type, const UShort_t pmtId) const;
  const Traces& GetPMTTraces(const ETraceType type, const UShort_t pmtId) const;

  double GetTraceSignal(const ETraceType type) const;

  double GetMuonSignal() const { return GetTraceSignal(eMuonTrace); }
  double GetElectronSignal() const { return GetTraceSignal(eElectronTrace); }
  double GetPhotonSignal() const { return GetTraceSignal(ePhotonTrace); }

  void SetMPDDepth(const std::vector<double>& depth, const std::vector<double>& depthEr)
  { fMPDDepth = depth; fMPDDepthError = depthEr; }

  void SetMPDSignal(const std::vector<double>& signal, const std::vector<double>& signalEr)
  { fMPDSignal = signal; fMPDSignalError = signalEr; }

  bool HasMPD() const { return !fMPDDepth.empty(); }

  const std::vector<double>& GetMPDDepth()const { return fMPDDepth; }
  const std::vector<double>& GetMPDDepthError() const { return fMPDDepthError; }
  const std::vector<double>& GetMPDSignal() const { return fMPDSignal;}
  const std::vector<double>& GetMPDSignalError() const { return fMPDSignalError; }
  bool IsUsedInGlobalMPD() const { return fIsUsedInGlobalMPD; }
  void SetUsedInGlobalMPD(const bool is) { fIsUsedInGlobalMPD = is; }

  // ========> these functions will disapear soon
  // warning IM PMT related functions and variables are to be found in
  // Traces class

  float GetCharge(const int pmtNo) const;   ///< get the charge
  float GetChargeError(const int pmtNo) const; ///< get the charge error
  float GetPeak(const int pmtNo) const;
  float GetPeakError(const int pmtNo) const;
  float GetDynodeAnodeRatio(const int pmtNo) const;
  double GetBaseline(const int pmtNo) const; ///< returns the baseline of pmtNo
  double GetBaselineRMS(const int pmtNo) const;
  double GetBaselineLG(const int pmtNo) const; ///< returns the baseline of pmtNo
  double GetBaselineLGRMS(const int pmtNo) const;

  const std::vector<UShort_t>& GetLowGainTrace(const int pmtNo) const;
  const std::vector<UShort_t>& GetHighGainTrace(const int pmtNo) const;
  const std::vector<float>& GetVEMTrace(const int pmtNo) const;

  // <====== up to here

private:
  bool HasTraces() const { return !fTraces.empty(); }

  ESaturationStatus fSaturationStatus;

  double fTimeSecond;
  double fTimeNSecond;
  double fRecoveredSignal;
  double fRecoveredSignalError;

  double fSPDistance;
  double fSPDistanceError;
  double fLDFResidual;           ///< from LDF fit
  double fTimeVariance;          ///> the time variance from the time variance model
  double fPlaneTimeResidual;     ///< from plane fit
  double fCurvatureTimeResidual; ///< from plane fit or from the curvature fit
  double fRiseTime;
  double fRiseTimeRMS;
  double fFallTime;
  double fFallTimeRMS;
  double fTime50;
  double fTime50RMS;
  double fAzimuthShowerPlane;
  double fShapeParameter;
  double fShapeParameterRMS;
  double fMuonComponent;

  UShort_t fSignalStartSlot;
  UShort_t fSignalEndSlot;

  //these should disapear in the near future

  float fVEMPeak[3], fVEMCharge[3];
  float fVEMPeakEr[3], fVEMChargeEr[3];
  float fDynodeAnodeRatio[3];
  float fBaseline[3];
  float fBaselineRMS[3];
  float fBaselineLG[3];
  float fBaselineLGRMS[3];

  std::vector<UShort_t> fHighGainTrace1;
  std::vector<UShort_t> fLowGainTrace1;
  std::vector<float> fVEMTrace1;

  std::vector<UShort_t> fHighGainTrace2;
  std::vector<UShort_t> fLowGainTrace2;
  std::vector<float> fVEMTrace2;

  std::vector<UShort_t> fHighGainTrace3;
  std::vector<UShort_t> fLowGainTrace3;
  std::vector<float> fVEMTrace3;
  // up to here

  std::vector<Traces> fTraces;

  UShort_t fRejectCode;
  double fCorrRiseTime;
  double fCorrRiseTimeError;
  bool fIsDense;

  std::vector<double> fMPDDepth;
  std::vector<double> fMPDDepthError;
  std::vector<double> fMPDSignal;
  std::vector<double> fMPDSignalError;
  bool fIsUsedInGlobalMPD;

  ClassDef(SdRecStation, 28);

};


#endif
