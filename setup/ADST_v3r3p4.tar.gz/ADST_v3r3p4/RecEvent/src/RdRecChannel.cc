#include <RdRecChannel.h>

#include <iostream>
#include <vector>
#include <cmath>
#include <TMath.h>
#include <stdexcept>
#include <sstream>

using namespace std;


ClassImp(RdRecChannel);


//=============================================================================
/*!
  \class   RdRecChannel
  \brief   Data of reconstructed Radio Channels

  \version 2.5
  \date    December 2013
  \author  Tim Huege
*/
//=============================================================================

RdRecChannel::RdRecChannel() :
  fId(0),
  fADCSignalThreshold(0),
  fADCNoiseThreshold(0),
  fIsSaturated(false),
  fIsScintillatorTop(false),
  fIsScintillatorBottom(false)
{ }


RdRecChannel::~RdRecChannel()
{ }

UInt_t
RdRecChannel::GetId() const
{
  return fId;
}

void
RdRecChannel::SetId(const UInt_t id)
{
  fId = id;
}


void
RdRecChannel::SetRdTimeTrace(const vector<Float_t>& timeTrace)
{
  fTrace.SetTimeTrace(timeTrace);
}


void
RdRecChannel::SetRdAbsSpectrum(const vector<Float_t>& freqTrace)
{
  fTrace.SetAbsoluteFreqSpectrum(freqTrace);
}


void
RdRecChannel::SetRdTrace(const RdTrace& trace)
{
  fTrace = trace;
}


const vector<Float_t>&
RdRecChannel::GetRdTimeTrace()
  const
{
  return fTrace.GetTimeTrace();
}


const vector<Float_t>&
RdRecChannel::GetRdAbsSpectrum()
  const
{
  return fTrace.GetAbsoluteFreqSpectrum();
}


const RdTrace&
RdRecChannel::GetRdTrace()
  const
{
  return fTrace;
}


RdTrace&
RdRecChannel::GetRdTrace()
{
  return fTrace;
}


UInt_t
RdRecChannel::GetADCSignalThreshold()
  const
{
  return fADCSignalThreshold;
}


UInt_t
RdRecChannel::GetADCNoiseThreshold()
  const
{
  return fADCNoiseThreshold;
}


void
RdRecChannel::SetADCSignalThreshold(const UInt_t thresh)
{
  fADCSignalThreshold = thresh;
}


void
RdRecChannel::SetADCNoiseThreshold(const UInt_t thresh)
{
  fADCSignalThreshold = thresh;
}


void
RdRecChannel::SetSaturated(const bool chanSaturated)
{
  fIsSaturated = chanSaturated;
}


bool
RdRecChannel::IsSaturated()
  const
{
  return fIsSaturated;
}

void
RdRecChannel::SetScintillatorTop(const bool chanScintillatorTop)
{
  fIsScintillatorTop = chanScintillatorTop;
}

bool
RdRecChannel::IsScintillatorTop()
  const
{
  return fIsScintillatorTop;
}

void
RdRecChannel::SetScintillatorBottom(const bool chanScintillatorBottom)
{
  fIsScintillatorBottom = chanScintillatorBottom;
}

bool
RdRecChannel::IsScintillatorBottom()
  const
{
  return fIsScintillatorBottom;
}
