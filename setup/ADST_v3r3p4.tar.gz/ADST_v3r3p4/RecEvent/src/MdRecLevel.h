// #include <config.h>
#ifndef __MdRecLevel_h
#define __MdRecLevel_h

enum EMdRecLevel {

  /// no Md event found
  eNoMdEvent = 0,

  /// Md has triggered stations
  eHasTriggeredMdStations = 1,

  /// LDF fit
  eHasMdLDF = 2,

  /// axis reconstructed
 // eHasMdAxis = 3,

};

#endif
