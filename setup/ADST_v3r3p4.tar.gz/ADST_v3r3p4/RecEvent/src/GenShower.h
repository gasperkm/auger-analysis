#ifndef _INCLUDE_GEN_SHOWER_H_
#define _INCLUDE_GEN_SHOWER_H_

#include <Shower.h>

#include <vector>


//  MC shower data definition

class GenShower : public Shower  {

public:
  GenShower();
  virtual ~GenShower() { }

  // getters

  Int_t GetPrimary() const { return fIDPrim; }  ///< 22=photon, 2212=proton, ... 1000026056=iron
  std::string GetPrimaryName() const;           ///< human readable name of primary
  std::string GetShortPrimaryName() const;      ///< human readable name of primary

  Double_t GetElecEnergy() const { return fE_em; }  ///< get electromagnetic energy [eV] (a.k.a. calorimetric energy)
  Double_t GetX1() const { return fX1; }            ///< get point of first interaction [g/cm^2]

  /** 'true' shower maximum obtained from parabolic
      interpolation of the three points aroind the maxium
      profile point  */
  Double_t GetXmaxInterpolated() const { return fXmax; }        ///< get shower maximum [g/cm^2]
  Double_t GetdEdXmaxInterpolated() const { return fdEdXmax; }  ///< get energy depost at Xmax

  /** shower maximum from fitting a Gaisser-Hillas function (from
      generator, e.g. CORSIKA, Aires */
  Double_t GetXmaxGaisserHillas() const { return fXmaxGH; }  ///< get shower maximum [g/cm^2]
  Double_t GetNmaxGaisserHillas() const { return fNmaxGH; }  ///< get shower size at Xmax

  Double_t GetDistanceOfShowerMaximum() const { return fDistanceOfShowerMax; }  ///< get distance to shower maximum

  Double_t GetNmu() const { return fNmu; }
  Double_t GetXmaxMu() const { return fXmaxMu; }

  Double_t GetMagneticFieldAzimuth() const { return fMagneticFieldDeclination + 1.570796327; }

  Double_t GetMagneticFieldZenith() const
  { return 1.570796327 + (fMagneticFieldInclination < 0 ? 1 : -1) * fMagneticFieldInclination; }

  Double_t GetMagneticFieldInclination() const { return fMagneticFieldInclination; }
  Double_t GetMagneticFieldDeclination() const { return fMagneticFieldDeclination; }
  Double_t GetMagneticFieldStrength() const { return fMagneticFieldStrength; }

  ///returns number of muons at ground level
  Double_t GetMuonNumber() const { return fNMuons; }

  ///returns muon weight scale
  Double_t GetMuonWeightScale() const { return fMuonWeightScale; }

  ///returns pointer to number of charged particles at shower track
  const std::vector<Double_t>& GetElectrons() const { return fElectrons; }

  ///returns pointer to energy deposit at shower track at shower track \f$[GeV]\f$
  const std::vector<Double_t>& GetEnergyDeposit() const { return fEnergyDeposit; }

  ///returns pointer to slant depth \f$[g/cm^2]\f$
  const std::vector<Double_t>& GetDepth() const { return fDepth; }

  ///returns vector of approximate shower ages \f$s = 3 / (1 + 2 X_{max}/X)\f$
  std::vector<Double_t> GetShowerAge() const;

  /// get the core GPS nanosecond (override of Shower method for backward compatibility with older productions)
  UInt_t GetCoreTimeNanoSecond() const;

  // setters

  /// set primary particle identifier
  void SetPrimary(const Int_t iPrim) { fIDPrim = iPrim; }

  /// set electromagnetic energy [eV] (a.k.a. calorimetric energy)
  void SetElecEnergy(const Double_t e) { fE_em = e; }
  void SetX1(const Double_t x1) { fX1 = x1; }

  void SetXmaxInterpolated(const double x)  { fXmax = x; }
  void SetdEdXmaxInterpolated(const double x)  { fdEdXmax = x; }
  void SetXmaxGaisserHillas(const double x)  { fXmaxGH = x; }
  void SetNmaxGaisserHillas(const double x)  { fNmaxGH = x; }

  void SetNmu(const Double_t nmu) { fNmu = nmu; }
  void SetXmaxMu(const Double_t xmaxMu) { fXmaxMu = xmaxMu; }

  /// Set slant depth \f$[g/cm^2]\f$
  void SetDepth(const std::vector<Double_t>& dep);

  /// Set number of charged particles  at shower track
  void SetElectrons(const std::vector<Double_t>& elec);

  /// Set number of charged particles  at shower track
  void SetEnergyDeposit(const std::vector<Double_t>& edep);

  /// Set number of muons at ground level
  void SetMuonNumber(const Double_t nmuons) { fNMuons = nmuons; }

  /// Set muon weight scale
  void SetMuonWeightScale(const Double_t scale) { fMuonWeightScale = scale; }

  /// Set distance to shower maximum
  void SetDistanceOfShowerMaximum(const Double_t distanceOfShowerMax)
  { fDistanceOfShowerMax = distanceOfShowerMax; }

  void SetMagneticFieldInclination(const Double_t magInclination)
  { fMagneticFieldInclination = magInclination; }
  void SetMagneticFieldDeclination(const Double_t magDeclination)
  { fMagneticFieldDeclination = magDeclination; }
  void SetMagneticFieldStrength(const Double_t magStrength)
  { fMagneticFieldStrength = magStrength; }

  /// deprecated, do not use anymore
  Double_t GetXmax() const;
  /// deprecated, do not use anymore
  Double_t GetdEdXmax() const;

private:
  Int_t fIDPrim;        // 22: Photon, 2212: Proton, 1000026056: Iron

  Double_t fE_em;       // electromagnetic energy [eV]
  Double_t fX1;

  Double_t fNmu;
  Double_t fXmaxMu;

  /// maximum of dE/dX from profile interpolation
  Double_t fXmax;
  Double_t fdEdXmax;

  /// maximum of N(X) from Gaisser-Hillas (usually directly from generator)
  Double_t fXmaxGH;
  Double_t fNmaxGH;

  ///number of muons at ground level
  Double_t fNMuons;

  ///muon weight scale
  Double_t fMuonWeightScale;

  ///Distance of shower maximum
  Double_t fDistanceOfShowerMax;
  Double_t fMagneticFieldDeclination;
  Double_t fMagneticFieldInclination;
  Double_t fMagneticFieldStrength;

  /// ------ the profile part ----------
  /// Number of entries in profile arrays (slant depth, photons at track, electrons at track)
  ///slant depth \f$[g/cm^2]\f$
  std::vector<Double_t> fDepth;

  ///number of charged particle at shower track
  std::vector<Double_t> fElectrons;

  ///energy deposit at shower track \f$[GeV]\f$
  std::vector<Double_t> fEnergyDeposit;

  // for backward compatibility... (ClassDef < 16)
  unsigned int fCoreTimeNSecond;

  ClassDef(GenShower, 23);

};


#endif
