// $Id: FdRecStation.cc 28772 2016-04-14 09:25:30Z darko $
#include <FdRecStation.h>
#include <StationStatus.h>

#include <iostream>

using namespace std;


ClassImp (FdRecStation)


FdRecStation::FdRecStation() :
  fChi_i(0),
  fTimeEye(0),
  fTime(0),
  fTimeError(0),
  fSignal(0),
  fSignalError(0),
  fTimeResidual(1e20),
  fDistanceToAxis(1e20),
  fAge(0),
  fSlantDepth(0)
{
  //cout << " FdRecStation::FdRecStation " << (int)this << endl;
}


FdRecStation::~FdRecStation()
{
  //cout << " FdRecStation::~FdRecStation " << (int)this << endl;
}
