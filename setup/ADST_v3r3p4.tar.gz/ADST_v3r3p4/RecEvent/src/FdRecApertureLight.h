#ifndef __FdRecApertureLight_H
#define __FdRecApertureLight_H

#include <FdApertureLight.h>


//=============================================================================
//
//  reconstructed profile data definition
//
//=============================================================================

class FdRecApertureLight : public FdApertureLight {

public:
  // class holding all variables dealing with the
  // reconstructed shower light

  FdRecApertureLight();

  // getters

  ///returns the integral of number of photons at aperture
  Double_t GetTotalLightIntegral() const;

  ///returns the uncertainty of the integral of number of photons at aperture
  Double_t GetTotalLightIntegralError() const;

  ///returns pointer to error on time of arrival at camera \f$[ns]\f$
  const std::vector<Double_t>& GetTimeError() const { return fTime_err; }

  ///returns pointer to error on total number of photons at aperture
  const std::vector<Double_t>& GetTotalLightAtApertureError() const
  { return fDia_total_err; }

  /// Get zeta
  Double_t GetZeta() const { return fZeta; }

  /// Returns reference to light collection efficiency for direct fluorescence light
  const std::vector<Double_t>& GetFluorLightCollEfficiency() const { return fLCEff_fluor; }
  /// Returns reference to light collection efficiency uncertainties for direct fluorescence light
  const std::vector<Double_t>& GetFluorLightCollEfficiencyErrors() const { return fLCEff_fluor_err; }

  /// Returns reference to light collection efficiency for direct Cherenkov light
  const std::vector<Double_t>& GetCherLightCollEfficiency() const { return fLCEff_direct_cher; }
  /// Returns reference to light collection efficiency uncertainties for direct Cherenkov light
  const std::vector<Double_t>& GetCherLightCollEfficiencyErrors() const { return fLCEff_direct_cher_err; }

  /// Returns reference to light collection efficiency for Mie scattered Cherenkov light
  const std::vector<Double_t>& GetMieCherLightCollEfficiency() const { return fLCEff_mie_cher; }
  /// Returns reference to light collection efficiency uncertainties for Mie scattered Cherenkov light
  const std::vector<Double_t>& GetMieCherLightCollEfficiencyErrors() const { return fLCEff_mie_cher_err; }

  /// Returns reference to light collection efficiency for Rayleigh scattered Cherenkov light
  const std::vector<Double_t>& GetRayCherLightCollEfficiency() const { return fLCEff_ray_cher; }
  /// Returns reference to light collection efficiency uncertainties for Rayleigh scattered Cherenkov light
  const std::vector<Double_t>& GetRayCherLightCollEfficiencyErrors() const { return fLCEff_ray_cher_err; }

  /*!
    Get highest cloud camera's cloud fraction in zeta pixels. Set
    highElevation to true if only pixels above 5.5 degree should be
    taken into account to avoid false positives from clouds at the
    horizon
  */
  Float_t GetMaxCloudCameraFractionInZeta(const bool highElevation) const
  { return highElevation ? fMaxCloudFractionInZetaHighElev : fMaxCloudFractionInZeta; }

  /*!
    As GetMaxCloudCameraFractionInZeta(), but the height of the cloud layer as
    measured by the lidar is taken into account
  */
  Float_t GetMaxCloudCameraFractionWithLidarInZeta(const bool highElevation)
    const
  { return highElevation ? fMaxCloudFractionWithLidarInZetaHighElev : fMaxCloudFractionWithLidarInZetaHighElev; }

  // setters

  /// Set time of arrival at camera
  void SetTime(const std::vector<Double_t>& tim,
               const std::vector<Double_t>& tim_err);

  /// Set total number of photons arriving at the aperture
  void SetTotalLightAtAperture(const std::vector<Double_t>& phot,
                               const std::vector<Double_t>& phot_err);

  /// Set zeta
  void SetZeta(const Double_t zeta) { fZeta = zeta; }

  /// Set light collection efficiency for direct fluorescence light
  void SetFluorLightCollEfficiency(const std::vector<Double_t>& lceff) { fLCEff_fluor = lceff; }
  /// Set light collection efficiency uncertainties for direct fluorescence light
  void SetFluorLightCollEfficiencyErrors(const std::vector<Double_t>& lcefferr) { fLCEff_fluor_err = lcefferr; }

  /// Set light collection efficiency for direct Cherenkov light
  void SetCherLightCollEfficiency(const std::vector<Double_t>& lceff) { fLCEff_direct_cher = lceff; }
  /// Set light collection efficiency uncertainties for direct Cherenkov light
  void SetCherLightCollEfficiencyErrors(const std::vector<Double_t>& lcefferr) { fLCEff_direct_cher_err = lcefferr; }

  /// Set light collection efficiency for Mie scattered Cherenkov light
  void SetMieCherLightCollEfficiency(const std::vector<Double_t>& lceff) { fLCEff_mie_cher = lceff; }
  /// Set light collection efficiency uncertainties for Mie scattered Cherenkov light
  void SetMieCherLightCollEfficiencyErrors(const std::vector<Double_t>& lcefferr) { fLCEff_mie_cher_err = lcefferr; }

  /// Set light collection efficiency for Rayleigh scattered Cherenkov light
  void SetRayCherLightCollEfficiency(const std::vector<Double_t>& lceff) { fLCEff_ray_cher = lceff; }
  /// Set light collection efficiency uncertainties for Rayleigh scattered Cherenkov light
  void SetRayCherLightCollEfficiencyErrors(const std::vector<Double_t>& lcefferr) { fLCEff_ray_cher_err = lcefferr; }

  /// Set highest cloud camera's cloud fraction in zeta pixels
  void SetMaxCloudCameraFractionInZetaHighElev(const Float_t tmp) { fMaxCloudFractionInZetaHighElev = tmp; }
  void SetMaxCloudCameraFractionInZeta(const Float_t tmp) { fMaxCloudFractionInZeta = tmp; }
  /// Get highest cloud camera's cloud fraction in zeta pixels taking cloud height into account
  void SetMaxCloudCameraFractionWithLidarInZeta(const Float_t tmp) { fMaxCloudFractionWithLidarInZeta = tmp; }
  void SetMaxCloudCameraFractionWithLidarInZetaHighElev(const Float_t tmp) { fMaxCloudFractionWithLidarInZetaHighElev = tmp; }

private:
  /// Error on time of arrival at camera \f$[ns]\f$
  std::vector<Double_t> fTime_err;

  /// Error on total number of photons at aperture/diaphragm
  std::vector<Double_t> fDia_total_err;

  /// Light collection efficiency for direct fluorescence light
  std::vector<Double_t> fLCEff_fluor;
  /// Light collection efficiency uncertainties for direct fluorescence light
  std::vector<Double_t> fLCEff_fluor_err;

  /// Light collection efficiency for direct Cherenkov light
  std::vector<Double_t> fLCEff_direct_cher;
  /// Light collection efficiency uncertainties for direct Cherenkov light
  std::vector<Double_t> fLCEff_direct_cher_err;

  /// Light collection efficiency for Mie scattered Cherenkov light
  std::vector<Double_t> fLCEff_mie_cher;
  /// Light collection efficiency uncertainties for Mie scattered Cherenkov light
  std::vector<Double_t> fLCEff_mie_cher_err;

  /// Light collection efficiency for Rayleigh scattered Cherenkov light
  std::vector<Double_t> fLCEff_ray_cher;
  /// Light collection efficiency uncertainties for Rayleigh scattered Cherenkov light
  std::vector<Double_t> fLCEff_ray_cher_err;

  /// Result of zeta search
  Double_t fZeta;

  /// Integrated number of photons at aperture
  Double_t fDia_Integral;

  /// Highest cloud camera's cloud fraction in zeta pixels
  Float_t fMaxCloudFractionInZeta;
  Float_t fMaxCloudFractionWithLidarInZeta;
  Float_t fMaxCloudFractionInZetaHighElev;
  Float_t fMaxCloudFractionWithLidarInZetaHighElev;

  ClassDef(FdRecApertureLight, 8);

};


#endif
