#include <UnivRecShower.h>

#include <iostream>
using namespace std;


ClassImp(UnivRecShower);


//=============================================================================
/*!
  \class   UnivRecShower
  \brief   Reconstructed shower parameters

  \version 1.0
  \date    Mar 27 2014
  \author  I. Mari&#351;, F. Sch&uuml;ssler, R. Ulrich, M. Unger, D. Maurel

*/
//=============================================================================

UnivRecShower::UnivRecShower() :
  fUnivRecLevel(eNoReconstruction),
  fNmu(0),
  fNmuError(0),
  fXmax(0),
  fXmaxError(0),
  fXmaxMu(0),
  fXmaxMuError(0),
  fTimeModelOffset(0),
  fTimeModelOffsetError(0),
  fNCandShape(0),
  fNCandStartTime(0),
  fNCandLDF(0)
{ }


void
UnivRecShower::DumpASCII(std::ostream& o)
const
{
  Shower::DumpASCII(o);
}
