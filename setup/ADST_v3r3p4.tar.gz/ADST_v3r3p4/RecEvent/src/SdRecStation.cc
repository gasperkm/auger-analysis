// $Id: SdRecStation.cc 23698 2013-05-24 10:28:03Z maurel $
#include <SdRecStation.h>

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <TMath.h>

using namespace std;


ClassImp(SdRecStation);


//=============================================================================
/*!
  \class   SdRecStation
  \brief   Data of reconstructed SD stations

  \version 2.0
  \date    July 2005
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
  \author  Michael Unger

*/
//=============================================================================

SdRecStation::SdRecStation() :
  fSaturationStatus(eNoSaturation),
  fTimeSecond(0),
  fTimeNSecond(0),
  fRecoveredSignal(0),
  fRecoveredSignalError(0),
  fSPDistance(0),
  fSPDistanceError(0),
  fLDFResidual(0),
  fTimeVariance(0),
  fPlaneTimeResidual(0),
  fCurvatureTimeResidual(0),
  fRiseTime(0),
  fRiseTimeRMS(0),
  fFallTime(0),
  fFallTimeRMS(0),
  fTime50(0),
  fTime50RMS(0),
  fAzimuthShowerPlane(0),
  fShapeParameter(0),
  fShapeParameterRMS(0),
  fMuonComponent(0),
  fSignalStartSlot(0),
  fSignalEndSlot(0),
  fRejectCode(0),
  fCorrRiseTime(0),
  fCorrRiseTimeError(0),
  fIsDense(false),
  fIsUsedInGlobalMPD(false)
{
  fill(fVEMPeak, fVEMPeak + 3, 0);
  fill(fVEMCharge, fVEMCharge + 3, 0);
  fill(fVEMPeakEr, fVEMPeakEr + 3, 0);
  fill(fVEMChargeEr, fVEMChargeEr + 3, 0);
  fill(fDynodeAnodeRatio, fDynodeAnodeRatio + 3, 0);
  fill(fBaseline, fBaseline + 3, 0);
  fill(fBaselineRMS, fBaselineRMS + 3, 0);
  fill(fBaselineLG, fBaselineLG + 3, 0);
  fill(fBaselineLGRMS, fBaselineLGRMS + 3, 0);
}


const vector<UShort_t>&
SdRecStation::GetLowGainTrace(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetLowGainComponent();
  else
    switch (pmtNo) {
    case 1: return fLowGainTrace1;
    case 2: return fLowGainTrace2;
    case 3: return fLowGainTrace3;
    default: return fLowGainTrace1;
    }
}


const vector<UShort_t>&
SdRecStation::GetHighGainTrace(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetHighGainComponent();
  else
    switch (pmtNo) {
    case 1: return fHighGainTrace1;
    case 2: return fHighGainTrace2;
    case 3: return fHighGainTrace3;
    default: return fHighGainTrace1;
    }
}


const vector<Float_t>&
SdRecStation::GetVEMTrace(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetVEMComponent();
  else
    switch (pmtNo) {
    case 1: return fVEMTrace1;
    case 2: return fVEMTrace2;
    case 3: return fVEMTrace3;
    default: return fVEMTrace1;
    }
}


double
SdRecStation::GetSignalTimeSigma2Intrinsic(const double theta)
  const
{
  if (fTimeVariance)
    return fTimeVariance;

  const double trackLength =
    ((theta > 1.272) ? 1.35 : (theta*(0.69*theta - 0.55) + 1.2)/1.2);
  const double n = GetTotalSignal() / trackLength;
  const double tx = (fTime50 + 15) / (n + 1);
  return 5*n/(n+2) * tx*tx + 134;
}


double
SdRecStation::GetAssymCorrRiseTime(const double zenith)
  const
{
  /* this is the correction for the rise time as given by
     the photon limit group
     all credits to the people from Leeds*/

  const double sectheta = 1/cos(zenith);
  const double alpha = -66.61 + sectheta*(95.13 - 30.73*sectheta);
  const double gamma =
    -0.0009721 + sectheta*(0.001993 + sectheta*(-0.001259 + 0.0002546*sectheta));

  const double assym = alpha + gamma*fSPDistance*fSPDistance;
  return fRiseTime - assym * cos(fAzimuthShowerPlane);
}


double
SdRecStation::GetAssymCorrRiseTimeError(const double zenith)
  const
{
  const double sectheta = 1/cos(zenith);
  const double k = -16.46*sectheta + 36.16;
  const double j =
    80 + (5.071e-7 + sectheta*(6.48e-4 - 3.051e-4*sectheta))*fSPDistance*fSPDistance;
  return j/GetTotalSignal() + k;
}


double
SdRecStation::GetAssymCorrRiseTimeKG(const double zenith)
  const
{
//   /* this is the correction for the rise time as given by Karen Mora*/
//   const float a_delta1 = 59.7509;
//   const float b_delta1 = 1.5741;
//   const float c_delta1 = 0.187705;
//   const float a_delta2 = 0.00030075;
//   const float b_delta2 = 1.30783;
//   const float c_delta2 = 0.146738;
//   const double distquadrat = pow(fSPDistance, 2);
//   const double secTheta = 1/cos(zenith);
//   const double delta_1 = a_delta1 * TMath::Landau(secTheta, b_delta1, c_delta1);
//   const double delta_2 = a_delta2 * TMath::Landau(secTheta, b_delta2, c_delta2);
//   const double gparameter = delta_1 + delta_2 * distquadrat;
//   return fRiseTime - gparameter*cos(fAzimuthShowerPlane);



  /* this is the correction for the rise time as given by Karen Mora Jun 2012*/
 
  //Default baseline
 
  const float a_delta1 = -0.00105519;
  const float b_delta1 = 0.00213726;
  const float c_delta1 = -0.0013352;
  const float d_delta1 = 0.000267611;

  //Baseline corrected by R.Bruijn's algorithm
//   const float a_delta1 = -0.00109812;
//   const float b_delta1 = 0.00223418;
//   const float c_delta1 = -0.00140286;
//   const float d_delta1 = 0.000282717;


  const double distquadrat = pow(fSPDistance, 2);
  const double secTheta = 1/cos(zenith);

  const double delta_1 =a_delta1+b_delta1*secTheta+c_delta1*pow(secTheta,2)+d_delta1*pow(secTheta,3);
  const double gparameter = delta_1* distquadrat;
  return fRiseTime - gparameter*cos(fAzimuthShowerPlane);


}


double
SdRecStation::GetAssymCorrRiseTimeErrorKG(const double zenith)
  const
{
  /* this is the correction for the rise time as given by Karen Mora*/

 //  const float pJA_0 = 969.111;
//   const float pJA_1 = -491.919;
//   const float pJB_0 = -0.000872009;
//   const float pJB_1 = 0.000527853;
//   const float pJC_0 = 8.17938e-07;
//   const float pJC_1 = -4.45007e-07;
//   const float pK1_0 = -36.1416;
//   const float pK1_1 = 16.5374;
//   const float pK2_0 = 0.0810758;
//   const float pK2_1 = -0.0349458;

//Parameters Jun 2012 Karen Mora (current baseline)
  const float pJA_0=-313.724;
  const float pJA_1=166.872;
  
  const float pJB_0=0.00125723;
  const float pJB_1=-0.000584173;
  
  const float pJC_0=-2.58177e-07;
  const float pJC_1=1.2744e-07;
  
  const float pK1_0=-19.8047;
  const float pK1_1=9.3843;
  
  const float pK2_0=0.0790256;
  const float pK2_1=-0.0343573;



//Parameters Jun 2012 Karen Mora (Baseline corrected by R.Bruijn's algorithm)

//   const float pJA_0 = -189.884;
//   const float pJA_1 = 101.83;
//   const float pJB_0 = 0.00119306;
//   const float pJB_1 = -0.000554442;
//   const float pJC_0 = -1.96462e-07;
//   const float pJC_1 = 9.70452e-08;
//   const float pK1_0 = -23.4863;
//   const float pK1_1 = 11.0905;
//   const float pK2_0 = 0.0750989;
//   const float pK2_1 = -0.031979;

  const double secTheta = 1/cos(zenith);
  const double k = pK1_0 + pK1_1*secTheta + (pK2_0 + pK2_1*secTheta)*fSPDistance;
  const double j =
    pJA_0 + pJA_1*secTheta +
    pow(fSPDistance, 2)*(pJB_0 + pJB_1*secTheta + (pJC_0 + pJC_1*secTheta)*fSPDistance);

  return abs(j/GetTotalSignal() + k);
}


bool
SdRecStation::HasPMTTraces(const ETraceType type, const UShort_t pmtId)
  const
{
  for (vector<Traces>::const_iterator it = fTraces.begin(), end = fTraces.end();
       it != end; ++it)
    if (it->GetPMTId() == pmtId && it->GetType() == type)
      return true;
  return false;
}


const Traces&
SdRecStation::GetPMTTraces(const ETraceType type, const UShort_t pmtId)
  const
{
  for (vector<Traces>::const_iterator it = fTraces.begin(), end = fTraces.end();
       it != end; ++it)
    if (it->GetPMTId() == pmtId && it->GetType() == type)
      return *it;
  static const Traces empty;
  return empty;
}


float
SdRecStation::GetCharge(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetCharge();
  else
    return fVEMCharge[pmtNo-1];
}


float
SdRecStation::GetChargeError(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetChargeError();
  else
    return fVEMChargeEr[pmtNo-1];
}


float
SdRecStation::GetPeak(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetPeak();
  else
    return fVEMPeak[pmtNo-1];
}


float
SdRecStation::GetPeakError(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetPeakError();
  else
    return fVEMPeakEr[pmtNo-1];
}


float
SdRecStation::GetDynodeAnodeRatio(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetDynodeAnodeRatio();
  else
    return fDynodeAnodeRatio[pmtNo-1];
}


double
SdRecStation::GetBaseline(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetBaseline();
  else
    return fBaseline[pmtNo-1];
}


double
SdRecStation::GetBaselineRMS(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetBaselineRMS();
  else
    return fBaselineRMS[pmtNo-1];
}


double
SdRecStation::GetBaselineLG(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetBaselineLG();
  else
    return fBaselineLG[pmtNo-1];
}


double
SdRecStation::GetBaselineLGRMS(const int pmtNo)
  const
{
  if (HasTraces())
    return GetPMTTraces(eTotalTrace, pmtNo).GetBaselineLGRMS();
  else
    return fBaselineLGRMS[pmtNo-1];
}


double
SdRecStation::GetTraceSignal(const ETraceType type)
  const
{
  if (!HasTraces())
    return 0;

  unsigned int nPMT = 0;
  double result = 0;
  for (int pmt = 1; pmt <= 3; ++pmt) {
    const Traces& t = GetPMTTraces(type, pmt);
    if (!t.GetVEMComponent().empty() && t.GetCharge()) {
      result += t.GetVEMSignal();
      ++nPMT;
    }
  }
  return nPMT ? result / nPMT : 0;
}
