#ifndef __FdGenGeometry_h__
#define __FdGenGeometry_h__

#include <FdGeometry.h>


class FdGenGeometry : public FdGeometry {

public:

private:

  ClassDef(FdGenGeometry, 3);

};


#endif
