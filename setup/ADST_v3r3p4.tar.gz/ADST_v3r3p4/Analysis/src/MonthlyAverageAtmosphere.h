#ifndef _MonthlyAverage_H
#define _MonthlyAverage_H

#include <cmath>

namespace UtilityFunctions {

  // structure for Bianca's atmosphere parameters
  struct MonthlyAverageParameters {
    MonthlyAverageParameters(const double l, const double a, const double b, const double c)
      : layerHeight(l), aParam(a), bParam(b), cParam(c) { }
    double GetDensity(const double h) const { return bParam/cParam*exp(-h/cParam); }
    double GetDepth(const double h) const { return aParam+bParam*exp(-h/cParam); }
    double layerHeight; // m
    double aParam;      // g/cm^2
    double bParam;      // g/cm^2
    double cParam;      // m
  };

  /// get array of atmospheric parameters
  const unsigned int gNAvDBMonths = 12;
  const unsigned int gNAvDBLayers = 5;


  typedef MonthlyAverageParameters mAvP;


  static const MonthlyAverageParameters gAvDBParameters[gNAvDBMonths][gNAvDBLayers] =
    {
      {
        mAvP(0e3    , -129.8699 , 1170.0778 , 971950.04e-2    ),
        mAvP(10.7e3 , -13.91258 , 1310.6961 , 682326.92e-2    ),
        mAvP(14.6e3 , 1.137905 , 1490.6967 , 615751.06e-2     ),
        mAvP(36.6e3 , -4.550198E-4 , 503.61357 , 795110.76e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                )
      },

      {
        mAvP(0e3    , -140.0270 , 1177.9949 , 990841.50e-2    ),
        mAvP(9.8e3  , -32.15402 , 1226.5794 , 746882.90e-2    ),
        mAvP(14.3e3 , 1.332422 , 1544.3943 , 608546.43e-2     ),
        mAvP(35.5e3 , -3.475978E-4 , 529.86754 , 787929.88e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                    )
      },

      {
        mAvP(0e3    , -140.7937 , 1177.4425 , 984028.36e-2    ),
        mAvP(9.0e3  , -36.40882 , 1189.0215 , 766300.22e-2    ),
        mAvP(14.5e3 , 1.404265 , 1556.0071 , 604631.06e-2     ),
        mAvP(35.0e3 , -2.458388E-4 , 539.33391 , 782862.58e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                   )
      },

      {
        mAvP(0e3    , -133.8950 , 1174.1385 , 967164.96e-2    ),
        mAvP(9.9e3  , -47.08990 , 1215.7355 , 768155.10e-2    ),
        mAvP(12.1e3 , 0.8327831 , 1425.6919 , 621852.25e-2    ),
        mAvP(38.0e3 , -2.105437E-4 , 503.93170 , 785601.62e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -152.4098 , 1190.3622 , 985619.01e-2    ),
        mAvP(9.5e3  , -12.09555 , 1265.7764 , 681017.98e-2    ),
        mAvP(15.0e3 , 0.8513700 , 1437.9375 , 617989.22e-2    ),
        mAvP(37.5e3 , -4.592849E-5 , 524.79663 , 776008.71e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -187.0166 , 1227.6177 , 1012299.99e-2   ),
        mAvP(7.5e3  , -25.28096 , 1178.8762 , 732521.04e-2    ),
        mAvP(14.5e3 , 0.8943240 , 1445.4602 , 614783.70e-2    ),
        mAvP(37.0e3 , 3.472763E-5 , 535.28753 , 771077.62e-2  ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -136.3486 , 1182.9055 , 947431.22e-2    ),
        mAvP(8.9e3  , -20.91432 , 1213.2534 , 710893.30e-2    ),
        mAvP(14.0e3 , 0.8728037 , 1413.9801 , 619412.06e-2    ),
        mAvP(37.0e3 , 3.732760E-5 , 547.58686 , 769605.80e-2  ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -139.7772 , 1184.5463 , 953640.45e-2    ),
        mAvP(8.8e3  , -25.94899 , 1205.4324 , 723050.32e-2    ),
        mAvP(12.8e3 , 0.7061898 , 1366.0575 , 629158.20e-2    ),
        mAvP(38.3e3 , -9.669983E-6 , 542.40761 , 772372.24e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -158.5464 , 1200.3726 , 986103.78e-2    ),
        mAvP(6.9e3  , -95.11033 , 1165.8523 , 881190.81e-2    ),
        mAvP(11.0e3 , 0.7640841 , 1373.2446 , 628689.50e-2    ),
        mAvP(38.2e3 , -1.513052E-4 , 521.58649 , 781005.59e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -150.1397 , 1189.9867 , 990579.97e-2    ),
        mAvP(9.0e3  , -58.14042 , 1193.1676 , 800597.35e-2    ),
        mAvP(12.0e3 , 0.8731574 , 1422.7443 , 623333.47e-2    ),
        mAvP(38.0e3 , -3.622195E-4 , 490.38375 , 793328.53e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -194.8371 , 1231.0108 , 1042817.57e-2   ),
        mAvP(7.0e3  , -68.14890 , 1164.4301 , 832823.86e-2    ),
        mAvP(12.0e3 , 0.9169753 , 1412.7462 , 624149.14e-2    ),
        mAvP(38.1e3 , -5.928016E-4 , 460.92738 , 805671.78e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                       )
      },

      {
        mAvP(0e3    , -152.9278 , 1190.2312 , 997989.25e-2    ),
        mAvP(8.7e3  , -37.51920 , 1189.4576 , 766606.86e-2    ),
        mAvP(14.5e3 , 1.580088 , 1575.7147 , 599559.45e-2     ),
        mAvP(34.9e3 , -5.905158E-4 , 484.10302 , 802421.45e-2 ),
        mAvP(100e3  , 0.01128292 , 1. , 1e7                   )
      }
    };

}
#endif
