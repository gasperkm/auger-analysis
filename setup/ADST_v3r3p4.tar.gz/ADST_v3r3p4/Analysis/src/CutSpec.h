#ifndef __include_CutSpec_H
#define __include_CutSpec_H

#include <Cut.h>

#include <string>


/*
 * CutSpec's are mostly just a vehicle for the declaration of cuts
 * with their name and function pointer. For an example,
 * see FDSelection.cc.
 *
 */

class CutSpec {
public:
  typedef bool (*CutFunctionPtr)(Cut &);

  /// A cut specification with name, implementation, and number of parameters
  CutSpec(const std::string cutName, CutFunctionPtr cutFunction, int nParams);
  /// A cut specification with name and implementation
  CutSpec(const std::string cutName, CutFunctionPtr cutFunction);

  /// A cut specification with only a name is useful for the END marker.
  CutSpec(const std::string cutName);
  /// An empty cut specification is only useful for placeholders
  CutSpec();

  /// Access the name of the cut
  const std::string& GetCutName() const { return fCutName; }
  /// Access the cut implementation function
  CutFunctionPtr GetCutFunction() const { return fCutFunction; }
  /// Access the number of cut parameters (-1 for 'not defined')
  int GetNParams() const { return fNParams; }

private:
  std::string fCutName;
  CutFunctionPtr fCutFunction;
  int fNParams;
};


#endif
