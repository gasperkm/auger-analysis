
#include <AugerUpTime.h>

#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <TH2I.h>
#include <TBits.h>

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <stdexcept>
#include <cstdlib>
#include <cmath>

using namespace std;


AugerUpTime::~AugerUpTime()
{
  if (fFDLifeFile)
    fFDLifeFile->Close();
  if (fT2LifeFile)
    fT2LifeFile->Close();
}

AugerUpTime::AugerUpTime(const char* const FDLifeFile, const char* const T2LifeFile) :
  fFDLifeFile(NULL),
  fT2LifeFile(NULL)
{
  /********************** FD-LifeTime Tree ****************************/

  if (FDLifeFile && FDLifeFile[0]) {

    fFDLifeFile = new TFile(FDLifeFile, "READ");

    fHeaderTree = (TTree*)fFDLifeFile->Get("Header");
    fUpTimeVer = 0;
    if (fHeaderTree) {
      fUpTimeVerB = fHeaderTree->GetBranch("SoftwareVersion");
      fUpTimeVerB->SetAddress(&fUpTimeVer);
      fHeaderTree->GetEntry(0);
    }

    for (unsigned int tel = 0; tel < kNTelescopes; ++tel) {
      fTelescopeUpFraction[tel] = 0;
      fTelescopeStatus[tel] = 0;
      fMeanVariance[tel] = 0;
      for (unsigned int pix = 0; pix < kNPixelPerTel; ++pix)
        fPixelVariance[tel][pix] = 0;
    }
    for (unsigned int eye = 0; eye < kNTotalEyes; ++eye) {
      fEyeUpFraction[eye] = 0;
      fEyeStatus[eye] = 0;
      fFDASVetoFraction[eye] = 0;
      fCDASConnFraction[eye] = 0;
      fCDASVetoFraction[eye] = 0;
    }
    fCDASUpFraction = 0;
    fCDASStatus = 0;

    tree = (TTree*)fFDLifeFile->Get("AugerUpTime");
    if (!tree) {
      cerr << "\n\n this should never happen: UptimeFile does not contain tree... " << endl;
      exit(0);
    } else {

      fGPSStartB = tree->GetBranch("uptime_gpsStart");
      fGPSStopB = tree->GetBranch("uptime_gpsStop");
      fTelescopeUpFractionB = tree->GetBranch("TelescopeUpFraction");
      fTelescopeStatusB = tree->GetBranch("TelescopeStatus");
      fEyeUpFractionB = tree->GetBranch("EyeUpFraction");
      fEyeStatusB = tree->GetBranch("EyeStatus");
      fMeanVarianceB = tree->GetBranch("MeanVariance");
      fCDASUpFractionB = tree->GetBranch("CDASUpFraction");
      fCDASStatusB = tree->GetBranch("CDASStatus");
      //Only for version > 0
      fFDASVetoFractionB = tree->GetBranch("FDASVetoFraction");
      fCDASConnFractionB = tree->GetBranch("CDASConnFraction");
      fCDASVetoFractionB = tree->GetBranch("CDASVetoFraction");

      fPixelVarianceB = tree->GetBranch("ADCVariance");
      fPixelThresholdB = tree->GetBranch("ADCThreshold");
      fPixelBaselineB = tree->GetBranch("ADCBaseline");

      fGPSStartB->SetAddress(&fGPSStart);
      fGPSStopB->SetAddress(&fGPSStop);
      fTelescopeUpFractionB->SetAddress(&fTelescopeUpFraction);
      fEyeUpFractionB->SetAddress(&fEyeUpFraction);

      if (fCDASUpFractionB)
	fCDASUpFractionB->SetAddress(&fCDASUpFraction);
      if (fTelescopeStatusB)
	fTelescopeStatusB->SetAddress(&fTelescopeStatus);
      if (fEyeStatusB)
	fEyeStatusB->SetAddress(&fEyeStatus);
      if (fCDASStatusB)
	fCDASStatusB->SetAddress(&fCDASStatus);
      if (fMeanVarianceB)
	fMeanVarianceB->SetAddress(&fMeanVariance);

      if (fFDASVetoFractionB)
	fFDASVetoFractionB->SetAddress(&fFDASVetoFraction);
      if (fCDASConnFractionB)
	fCDASConnFractionB->SetAddress(&fCDASConnFraction);
      if (fCDASVetoFractionB)
	fCDASVetoFractionB->SetAddress(&fCDASVetoFraction);

      if (fPixelVarianceB)
        fPixelVarianceB->SetAddress(&fPixelVariance);
      if (fPixelThresholdB)
        fPixelThresholdB->SetAddress(&fPixelThreshold);
      if (fPixelBaselineB)
        fPixelBaselineB->SetAddress(&fPixelBaseline);

    }

    unsigned int TreeEntries = tree->GetEntries();
    unsigned int TreeGPSStart = 0;
    unsigned int TreeGPSStop = 0;
    unsigned int TreeDeltaT = 0;

    if (TreeEntries <= 0) {
      cerr << "AugerUpTime::AugerUpTime tree in file " << FDLifeFile << " does not have entries" << endl;
    } else {
      tree->GetEntry(0);
      TreeGPSStart = fGPSStart;
      TreeDeltaT = fGPSStop-fGPSStart;

      tree->GetEntry(TreeEntries - 1);
      TreeGPSStop = fGPSStop;

      if (TreeGPSStop <= TreeGPSStart)
        cerr << "AugerUpTime::AugerUpTime time ordering is wrong" << endl;

      if ((fGPSStop - fGPSStart) != TreeDeltaT)
        cerr << "AugerUpTime::AugerUpTime time binning is not equidistant" << endl;
    }

    fTiming = new Timing(TreeDeltaT, TreeGPSStart, TreeGPSStop);

  }

  if (T2LifeFile && T2LifeFile[0]) {

    /********************* T2-Life Tree ************************/

    fT2GPSStartB = NULL;
    fT2GPSStopB = NULL;
    fT2StationsB = NULL;
    fT2Stations = NULL;
    fT2GPSStart = 0;
    fT2GPSStop = 0;

    fT2LifeFile = new TFile(T2LifeFile, "READ");
    if (fT2LifeFile->IsZombie()) {
      string errMsg = " AugerUpTime: Error opening " + string(T2LifeFile);
      throw std::runtime_error(errMsg);
    }

    fT2Stations = (TTree*)fT2LifeFile->Get("T2Life");
    fT2GPSStartB = fT2Stations->GetBranch("gpsStart");
    fT2GPSStopB = fT2Stations->GetBranch("gpsStop");
    fT2StationsB = fT2Stations->GetBranch("stationArray");

    fT2GPSStartB->SetAddress(&fT2GPSStart);
    fT2GPSStopB->SetAddress(&fT2GPSStop);
    fT2StationBits = new TBits();
    fT2StationsB->SetAddress(&fT2StationBits);

    // create an index map for fast lookup
    cout << "\n\tinitializing T2 search map " << flush;
    for (unsigned int i = 0; i < (unsigned int)(fT2GPSStartB->GetEntries()); ++i) {
      fT2GPSStartB->GetEntry(i);
      fT2GPSStopB->GetEntry(i);
      unsigned int iCurr1 = fT2GPSStart / fSearchMapBinning;
      unsigned int iCurr2 = fT2GPSStop / fSearchMapBinning;

      if (fT2GPSStart < 756950400 || fT2GPSStop < 756950400) {
        continue;
      }

      vector<unsigned int> iCurr;
      if (iCurr1 == iCurr2)
        iCurr.push_back(iCurr1);
      else
        for (unsigned int iIndex = min(iCurr1, iCurr2);
             iIndex <= max(iCurr1, iCurr2); ++iIndex) {
          iCurr.push_back(iIndex);
        }

      for (unsigned int j = 0; j < iCurr.size(); ++j) {
        if (fFirstT2Index.find(iCurr[j]) == fFirstT2Index.end()) {
          fFirstT2Index[iCurr[j]] = i;
          fLastT2Index[iCurr[j]] = i;
        } else {
          if (i < fFirstT2Index[iCurr[j]])
            fFirstT2Index[iCurr[j]] = i;
          if (i > fLastT2Index[iCurr[j]])
            fLastT2Index[iCurr[j]] = i;
        }
      }
      if (i % (int(fT2GPSStartB->GetEntries()) / 5) == 0)
        cout << '.' << flush;
    }
    cout << endl;

  }
}


/********************************************************************************/

bool
AugerUpTime::FindStationBits(unsigned int iGPS)
{
  // check if we already have this time
  if (iGPS >= fT2GPSStart && iGPS < fT2GPSStop)
    return true;

  // binary search for GPS time in T2 life file
  bool foundit = false;

  // first get bounds ...
  unsigned int iCurr = iGPS / fSearchMapBinning;
  std::map<unsigned int, unsigned int>::const_iterator indexMap =
    fFirstT2Index.find(iCurr);
  if (indexMap == fFirstT2Index.end()) {
    cerr << " AugerUpTime::FindStationBits() - could not find index! "
         << iGPS << ' ' << fSearchMapBinning << ' ' << iCurr << endl;
    return false;
  }

  int lower = fFirstT2Index[iCurr];
  int upper= fLastT2Index[iCurr];
  int nSearch = 0;
  int index = 0;

  while (!foundit && (upper >= lower)) {
    index = lower + (upper - lower) / 2;
    fT2GPSStartB->GetEntry(index);
    fT2GPSStopB->GetEntry(index);
    if (iGPS >= fT2GPSStart && iGPS < fT2GPSStop) {
      foundit = true;
    } else {
      if (iGPS < fT2GPSStart)
        upper = index - 1;
      else
        lower = index + 1;
    }
    ++nSearch;
  }

  if (foundit) {
    if (index > fT2StationsB->GetEntries()-1 || index < 0)
      cerr << " AugerUpTime::FindStationBits() - index out of range "
           << index << ' ' << fT2StationsB->GetEntries() << endl;

    fT2StationsB->GetEntry(index);
  } else {
    cout << " AugerUpTime::FindStationBits(): GPS time "
         << iGPS << " not found ! (iCurr="
         << iCurr << " map:[" << fFirstT2Index[iCurr] << ','
         << fLastT2Index[iCurr] << "]\n"
            "                                "
            "T2 list is from ";
    fT2GPSStartB->GetEntry(1);
    cout << fT2GPSStart;
    fT2GPSStopB->GetEntry(fT2Stations->GetEntries() - 1);
    cout << " to " << fT2GPSStop << endl;
  }

  return foundit;
}


/********************************************************************************/

const TBits*
AugerUpTime::GetArrayStatus(unsigned int iGPS)
{
  if (!FindStationBits(iGPS))
    return NULL;
  else {
    if (!fT2StationBits)
      cerr << " AugerUpTime::GetArrayStatus()  NULL station bits???" << endl;
    return fT2StationBits;
  }
}


/********************************************************************************/

/// get status of station iStation
bool
AugerUpTime::GetStationStatus(unsigned int stationID, unsigned int iGPS)
{
  if (!FindStationBits(iGPS))
    return false;
  else
    return fT2StationBits->TestBitNumber(stationID);
}


/********************************************************************************/

/// get number of statios up at time iGPS [s]
unsigned int
AugerUpTime::GetNT2Stations(unsigned int iGPS)
{
  if (!FindStationBits(iGPS))
    return 0;
  else
    return fT2StationBits->CountBits();
}


/********************************************************************************/

bool
AugerUpTime::HasData(unsigned int GPS)
{
  return GPS >= fTiming->GetFirstGPS() && GPS < fTiming->GetLastGPS();
}


/********************************************************************************/

TH2I*
AugerUpTime::GetPixelVarianceHisto(unsigned int Tel, unsigned int GPS)
{
  char tit[200];
  sprintf(tit, "Background Variance of Telescope %d (GPS= %d)", Tel+1, GPS);
  TH2I* histo = new TH2I("histo", tit, 20, 0, 20, 22, 0, 22);

  if (Tel > kNTelescopes)
    return histo;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    for (unsigned int pix = 0; pix < kNPixelPerTel; ++pix) {
      if (fUpTimeVer > 0)
        histo->Fill(pix / 22, pix % 22, fPixelVariance[Tel][pix] / 1000.);
      else
        histo->Fill(pix / 22, pix % 22, fPixelVariance[Tel][pix]);
    }

  }
  return histo;
}


/********************************************************************************/

double
AugerUpTime::GetMeanPixelVariance(unsigned int Tel, unsigned int GPS)
{
  if (Tel > kNTelescopes)
    return 0;

  double mean = 0;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS) {
      tree->GetEntry(fTiming->GetTimeBin(GPS));
    }
    mean = fMeanVariance[Tel];
//     for(unsigned int pix=0; pix<kNPixelPerTel; pix++) {
//       mean+= fPixelVariance[Tel][pix];
//     }

//     mean/=kNPixelPerTel;
//     if (fUpTimeVer>0) mean/=1000.;

  }
  return mean;
}


/********************************************************************************/

std::vector<unsigned short>
AugerUpTime::GetPixelVariance(unsigned int Tel, unsigned int GPS)
{
  std::vector<unsigned short> variance(kNPixelPerTel);

  if (Tel > kNTelescopes)
    return variance;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    for (unsigned int pix = 0; pix < kNPixelPerTel; ++pix)
      variance[pix] = fPixelVariance[Tel][pix];

  }
  //if (fUpTimeVer>0) variance/=1000.;
  return variance;
}


/********************************************************************************/

std::vector<unsigned short>
AugerUpTime::GetPixelThreshold(unsigned int Tel, unsigned int GPS)
{
  std::vector<unsigned short> threshold(kNPixelPerTel);

  if (Tel > kNTelescopes)
    return threshold;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    for (unsigned int pix = 0; pix < kNPixelPerTel; ++pix)
      threshold[pix] = fPixelThreshold[Tel][pix];

  }
  return threshold;
}


/********************************************************************************/

std::vector<unsigned short>
AugerUpTime::GetPixelBaseline(unsigned int Tel, unsigned int GPS)
{
  std::vector<unsigned short> baseline(kNPixelPerTel);

  if (Tel > kNTelescopes)
    return baseline;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    for (unsigned int pix = 0; pix < kNPixelPerTel; ++pix)
      baseline[pix] = fPixelBaseline[Tel][pix];

  }
  return baseline;
}


/********************************************************************************/

double
AugerUpTime::GetTelescopeUpFraction(unsigned int Tel, unsigned int GPS)
{
  if (Tel > kNTelescopes)
    return 0;

  double upFrac = 0;
  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    upFrac = fTelescopeUpFraction[Tel];
  }

  return upFrac;
}


/********************************************************************************/
unsigned int
AugerUpTime::GetTelescopeStatus(unsigned int Tel, unsigned int GPS)
{
  if (Tel > kNTelescopes)
    return 0;

  unsigned int upStat = 0;
  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    if (fUpTimeVer > 0)
      upStat = int(ceil(fTelescopeUpFraction[Tel]));
    else
      upStat = fTelescopeStatus[Tel];
  }

  return upStat;
}


/********************************************************************************/
double
AugerUpTime::GetEyeUpFraction(unsigned int Eye, unsigned int GPS)
{
  if (Eye > kNTotalEyes)
    return 0;

  double upFrac = 0;
  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    upFrac = fEyeUpFraction[Eye];
  }

  return upFrac;
}


/********************************************************************************/

unsigned int
AugerUpTime::GetEyeStatus(unsigned int Eye, unsigned int GPS)
{
  if (Eye > kNTotalEyes)
    return 0;

  unsigned int upStat = 0;
  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    if (fUpTimeVer > 0)
      upStat = int(ceil(fEyeUpFraction[Eye]));
    else
      upStat = fEyeStatus[Eye];

  }

  return upStat;
}


/********************************************************************************/

double
AugerUpTime::GetFDASVetoFraction(unsigned int Eye, unsigned int GPS)
{
  if (Eye > kNTotalEyes)
    return 0;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    return fUpTimeVer > 0 ? fFDASVetoFraction[Eye] : 1;

  }

  return 0;
}


/********************************************************************************/

double
AugerUpTime::GetCDASVetoFraction(unsigned int Eye, unsigned int GPS)
{
  if (Eye > kNTotalEyes)
    return 0;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    return fUpTimeVer > 0 ? fCDASVetoFraction[Eye] : 1;

  }

  return 0;
}


/********************************************************************************/
double AugerUpTime::GetCDASConnFraction(unsigned int Eye, unsigned int GPS){

  //double upFrac=0.;
  if(HasData(GPS)) {

    if(fGPSStart>GPS || fGPSStop<=GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    return fUpTimeVer>0 ? fCDASConnFraction[Eye] : 1.;
  }

  return 0;
}


/********************************************************************************/

double
AugerUpTime::GetCDASUpFraction(unsigned int GPS)
{
  //double upFrac=1.;

  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    return fUpTimeVer <= 0 ? fCDASUpFraction : 1;
  }

  return 0;
}


/********************************************************************************/

unsigned int
AugerUpTime::GetCDASStatus( unsigned int GPS)
{
  unsigned int upStat = 0;
  if (HasData(GPS)) {

    if (fGPSStart > GPS || fGPSStop <= GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    upStat = fCDASStatus;
  }

  return upStat;
}


/********************************************************************************/

//including Telescope * Eye * CDAS UpFractions and status
double
AugerUpTime::GetTotalTelescopeUpFraction(unsigned int Tel, unsigned int GPS, bool withCDAS)
{
  if (Tel > kNTelescopes)
    return 0;

  unsigned int Eye = Tel / kNTelPerEye;

  double upFrac=0.;
  double upFracTel=0.;
  unsigned int upStatTel=0;
  double upFracEye=0.;
  unsigned int upStatEye=0;
  double upFracCDAS=0.;
  unsigned int upStatCDAS=0;
  double upFracFDASVeto=0.;
  double upFracCDASVeto=0.;
  //  double upFracCDASConn=0.; // unused

  if(HasData(GPS)) {

    if(fGPSStart>GPS || fGPSStop<=GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    upFracTel=fTelescopeUpFraction[Tel];
    if(fTelescopeStatusB != NULL)
      upStatTel=fTelescopeStatus[Tel];
    else if(upFracTel>0.)
      upStatTel = 1;
    upFracEye=fEyeUpFraction[Eye];
    if(fEyeStatusB != NULL)
      upStatEye=fEyeStatus[Eye];
    else if(upFracEye>0.)
      upStatEye = 1;
    if(fCDASUpFractionB != NULL)
      upFracCDAS =fCDASUpFraction;
    if( fCDASStatusB != NULL)
      upStatCDAS=fCDASStatus;

    if(fFDASVetoFractionB != NULL)
      upFracFDASVeto=fFDASVetoFraction[Eye];
    // if(fCDASConnFractionB != NULL)
    //   upFracCDASConn=fCDASConnFraction[Eye];  // unused
    if(fCDASVetoFractionB != NULL) {
      upFracCDASVeto=fCDASVetoFraction[Eye];
    }

    if(withCDAS) {
      if (fUpTimeVer > 0) {
	upFrac=upFracTel * upFracEye * upStatCDAS*upFracFDASVeto*upFracCDASVeto;
      }
      else
	upFrac=upFracTel*upStatTel * upFracEye*upStatEye * upFracCDAS*upStatCDAS;
    }
    else
      if (fUpTimeVer > 0)
	upFrac=upFracTel * upFracEye;
      else
	upFrac=upFracTel*upStatTel * upFracEye*upStatEye;
  }

  // cout<<"AugerUpTime: Tel "<<Tel<<" / GPS: "<<GPS
  //       <<" --> TotalUpFraction= "<<upFrac<<"  ( tel: "<<upFracTel<<" / "<<upStatTel
  //       <<"  eye: "<<upFracEye<<" / "<<upStatEye<<" cdas: "
  //       <<upFracCDAS<<" / "<<upStatCDAS<<" "<<endl;

  return upFrac;
}

/********************************************************************************/
//vector of telescopes including Telescope * Eye * CDAS UpFractions and status
std::vector<double> AugerUpTime::GetTotalFDUpFraction(unsigned int GPS, bool withCDAS) {

  std::vector<double>  upFrac(kNTelescopes);

  if(HasData(GPS)) {

    if(fGPSStart>GPS || fGPSStop<=GPS)
      tree->GetEntry(fTiming->GetTimeBin(GPS));

    for(unsigned int Tel=0; Tel<kNTelescopes; Tel++) {

      unsigned int Eye=Tel/kNTelPerEye;

      double upFracTel=0.;
      unsigned int upStatTel=0;
      double upFracEye=0.;
      unsigned int upStatEye=0;
      double upFracCDAS=0.;
      unsigned int upStatCDAS=0;
      double upFracFDASVeto=0.;
      double upFracCDASVeto=0.;
      //      double upFracCDASConn=0.; // unused

      upFracTel=fTelescopeUpFraction[Tel];
      upFracEye=fEyeUpFraction[Eye];
      upFracFDASVeto=fFDASVetoFraction[Eye];
      // upFracCDASConn=fCDASConnFraction[Eye]; // unused
      upFracCDASVeto=fCDASVetoFraction[Eye];
      upStatEye=fEyeStatus[Eye];
      upStatTel=fTelescopeStatus[Tel];
      upFracCDAS =fCDASUpFraction;
      upStatCDAS=fCDASStatus;


      if(withCDAS)
	if (fUpTimeVer > 0)
	  upFrac[Tel]=upFracTel * upFracEye * upStatCDAS*upFracFDASVeto*upFracCDASVeto;
	else
	  upFrac[Tel]=upFracTel*upStatTel * upFracEye*upStatEye * upFracCDAS*upStatCDAS;
      else
	if (fUpTimeVer > 0)
	  upFrac[Tel]=upFracTel * upFracEye;
	else
	  upFrac[Tel]=upFracTel*upStatTel * upFracEye*upStatEye;
    }
  }

  return upFrac;
}

/********************************************************************************/
bool AugerUpTime::TelescopeIsOn(unsigned int Tel, unsigned int GPS, bool withCDAS) {

  if (Tel > kNTelescopes)
    return false;

  if(GetTotalTelescopeUpFraction(Tel, GPS, withCDAS) > 0)
    return true;
  else
    return false;
}



/********************************************************************************/
unsigned int AugerUpTime::GetClosestDataTaking(unsigned int Tel, unsigned int GPS) {
//for a given GPS time -> look for nearest data-taking period
//#warning highly experimental

  GPS=fTiming->GetBinStart(fTiming->GetTimeBin(GPS));

  unsigned int forwardGPS=GPS;
  unsigned int backwardGPS=GPS;
  unsigned int closestGPS=fTiming->GetFirstGPS();

  if(GPS<=fTiming->GetFirstGPS())
    GPS=fTiming->GetFirstGPS();

  if(GPS>=fTiming->GetLastGPS())
    GPS=fTiming->GetLastGPS() - fTiming->GetTimeBinSeconds();

  while (GetTotalTelescopeUpFraction(Tel, forwardGPS) == 0 && fGPSStart<= forwardGPS && fGPSStop>forwardGPS) {
    forwardGPS+=fTiming->GetTimeBinSeconds();
  }

  while (GetTotalTelescopeUpFraction(Tel, backwardGPS) == 0 && fGPSStart<= backwardGPS && fGPSStop>backwardGPS) {
    backwardGPS-=fTiming->GetTimeBinSeconds();
  }

  unsigned int DeltaForward=forwardGPS-GPS;
  unsigned int DeltaBackward=GPS-backwardGPS;

  if(DeltaForward >= DeltaBackward)
    closestGPS=forwardGPS;
  else
    closestGPS=backwardGPS;

  return closestGPS;
}

/********************************************************************************/
unsigned int AugerUpTime::GetNightStart(unsigned int Tel, unsigned int GPS) {
//for a given GPS time during a data-taking period -> look for start of night
//#warning highly experimental
  GPS=fTiming->GetBinStart(fTiming->GetTimeBin(GPS));

  if(GPS<=fTiming->GetFirstGPS())
    GPS=fTiming->GetFirstGPS();

  if(GPS>=fTiming->GetLastGPS())
    GPS=fTiming->GetLastGPS() - fTiming->GetTimeBinSeconds();

  while (GetTotalTelescopeUpFraction(Tel, GPS) > 0 && fGPSStart<= GPS && fGPSStop>GPS) {
    GPS-=fTiming->GetTimeBinSeconds();
  }

  return GPS;

}


/********************************************************************************/
unsigned int AugerUpTime::GetNightStop(unsigned int Tel, unsigned int GPS) { //for a given GPS time during a data-taking period -> look for end of night
//#warning highly experimental
  GPS=fTiming->GetBinStart(fTiming->GetTimeBin(GPS));

  if(GPS<=fTiming->GetFirstGPS())
    GPS=fTiming->GetFirstGPS();

  if(GPS>=fTiming->GetLastGPS())
    GPS=fTiming->GetLastGPS() - fTiming->GetTimeBinSeconds();

  while (GetTotalTelescopeUpFraction(Tel, GPS) > 0 && fGPSStart<= GPS && fGPSStop>GPS) {
    GPS+=fTiming->GetTimeBinSeconds();
  }

  return GPS;

}

void AugerUpTime::Print(unsigned int gpsTime) {

  cout << setiosflags(ios::fixed) << setprecision(2);
  cout << "\tCDAS: " << setw(4)
       << GetCDASUpFraction(gpsTime)
       << " (" << GetCDASStatus(gpsTime) << ")" << endl;

  string hrule("\t-----------+-------------------------------------"
               "----------------------");

  cout << hrule << endl;
  cout << "\t Eye       | Telescopes " << endl;
  cout << hrule << endl;
  for ( unsigned int i=0;i<kNEyes;i++ ) {
    cout << "\t" << i+1 << setw(5) << GetEyeUpFraction(i,gpsTime)
         << " (" << GetEyeStatus(i,gpsTime) << ") |";
    for ( unsigned int j=0;j<kNTelPerEye;j++ )
      cout << setw(5) << GetTelescopeUpFraction(i*kNTelPerEye+j,gpsTime)
           << " (" << GetTelescopeStatus(i*kNTelPerEye+j,gpsTime) << ") ";
    cout << endl;
  }
  cout << hrule << endl;

}
