#ifndef __include_Cut_H
#define __include_Cut_H

#include <TH1F.h>

#include <string>
#include <vector>


class Cut {

public:
  Cut(const std::string& name, const std::vector<double>& parameters, bool isAntiCut,
      bool storeHisto, int nBins, double xMin, double xMax);
  Cut(const std::string& name, double value, double slope = 0, bool isAntiCut = false,
      bool storeHisto = true, int nBins = 100, double xMin = 0, double xMax = 0);
  ~Cut();
  Cut(const Cut& p);
  const Cut& operator=(const Cut& x);

  std::string Info();

  const std::string& GetName() const { return fName; }

  /// Returns whether the cut is negated, i.e. an anti-cut
  bool IsAntiCut() const { return fIsAntiCut; }

  bool GetNormalOrAnti(const bool condition) { return fIsAntiCut ^ condition; }

  /// Get the vector of cut parameters. First value is the former "cut value", second potentially the former "cut slope".
  const std::vector<double>& GetCutParameters() const { return fParameters; }
  /// Set the vector of the currently processed events' cut values.
  void SetCurrValues(std::vector<double>& cutValues) { fCurrValues = cutValues; }
  /// Get the vector of the currently processed events' cut values.
  const std::vector<double>& GetCurrValues() { return fCurrValues; }

  /// Check whether there are any parameters and if so, warn about it since boolean cuts do not take parameters. Should be called from all boolean cut functions
  void IsBooleanCut();

  /// Set the current value of the first cut parameter (the former "cut value"), vaguely deprecated, see SetCurrValues
  void SetCurrValue(double val);

  /// Access the first cut parameter (the former "cut value"), vaguely deprecated, see GetCutParameters
  double GetCutValue() const { return fParameters.empty() ? 0 : fParameters[0]; }
  /// Access the first cut parameter (the former "cut value"), vaguely deprecated, see GetCutParameters
  double GetCurrValue() const { return fCurrValues.empty() ? 0 : fCurrValues[0]; }
  /// Access the second cut parameter (the former "cut slope"), vaguely deprecated, see GetCutParameters
  double GetCutSlope() const { return fParameters.size() <= 1 ? 0 : fParameters[1]; }

  void FillNMinusOne(const double weight = 1) { fHisto->Fill(GetCurrValue(), weight); }
  void Write() { fHisto->BufferEmpty(1); fHisto->Write(); }
  void SetNMinusOne(const bool what) { fIsNMinusOne = what; }
  bool IsNMinusOne() const { return fIsNMinusOne; }
  void IncrementEventCounter(const double weight = 1) { fNEvents += weight; }
  double GetNEvents() const { return fNEvents; }

private:
  Cut();

  std::vector<double> fParameters;
  std::vector<double> fCurrValues;
  TH1F* fHisto;
  std::string fName;
  bool fWarnedAboutBooleanCut;
  bool fIsNMinusOne;
  bool fIsAntiCut;
  double fNEvents;

};


#endif
