#include <T2TriggerProb.h>
#include <AnalysisConsts.h>

#include <DetectorGeometry.h>
#include <Shower.h>

#include <TBits.h>

#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <cmath>

using namespace std;

T2TriggerProb::T2TriggerProb(const DetectorGeometry* const* geom):
  fDetectorGeometry(geom)
{
}

T2TriggerProb::~T2TriggerProb()
{
}

double
T2TriggerProb::GetBrassProb(const Shower& theShower,
                            const TBits& arrayStatus,
                            const int iPrim,
                            const ELTPFunctions ltpFunction)
  const
{
  const TVector3& axis = theShower.GetAxisSiteCS();
  const TVector3& core = theShower.GetCoreSiteCS();

  // find all active stations within maxDist SP distance

  vector<double> stationDists;
  const double maxDist = 5000.;

  for (DetectorGeometry::StationPosMapConstIterator iStation =
         (*fDetectorGeometry)->GetStationsBegin();
       iStation != (*fDetectorGeometry)->GetStationsEnd();
       ++iStation) {
    const unsigned int id = iStation->first;
    if (arrayStatus.TestBitNumber(id)) {
      const double distance =
        (*fDetectorGeometry)->GetStationAxisDistance(iStation->second,
                                                     axis,
                                                     core);
      if (distance < maxDist)
        stationDists.push_back(distance);

    }
  }

  if (stationDists.empty())
    return 0;
  else {
    const double cosTheta = theShower.GetCosZenith();
    const double lgE = log10(theShower.GetEnergy());

    double notTrigProb = 1.;
    for (unsigned int i = 0; i <stationDists.size(); ++i) {
      const double pTrig = (ltpFunction == ePerrone ?
                            GetTOTprob(stationDists[i],lgE,cosTheta,iPrim) :
                            GetT2Prob(lgE,stationDists[i],cosTheta,iPrim));
      notTrigProb *= (1.-pTrig);
    }
    return 1.-notTrigProb;
  }

}

double
T2TriggerProb::GetT2Prob(double lgE, double r, double cosTheta, int iPrim)
  const
{
  if (iPrim == kPhotonID)
    return 1.;

  const double xGround = 840. / cosTheta;
  const double xMax = MeanXmax(lgE, iPrim);
  const double s = 3./(1. + 2.*xMax/xGround);

  return CalcT2Prob(iPrim, s, lgE, r);
}


double
T2TriggerProb::CalcT2Prob(int iPrim, double age, double lgE, double r)
  const
{
  const double protonR0Pars[4] =     {-1332.4, 0.815649, -4076.57, 268.886};
  const double protonLambdaPars[3] = {-163.344, -3967.38, 250};
  const double ironR0Pars[4] =       {-881.093, 0.63293, -4309.44, 291.587};
  const double ironLambdaPars[3] =   {-142.092, -3960.11, 250};

  const double* pR;
  const double* pL;
  if (iPrim == kProtonID) {
    pR = protonR0Pars;
    pL = protonLambdaPars;
  }
  else if (iPrim == kIronID) {
    pR = ironR0Pars;
    pL = ironLambdaPars;
  }
  else if (iPrim == kPhotonID) {
    return 1;
  }
  else {
    string errMsg = string(" T2TriggerProb::GetT2Prob(): unknown primary ");
    throw std::runtime_error(errMsg);
  }

  const double s = age;
  const double r0 = pR[0]*pow(s-pR[1],2)+pR[2]+lgE*pR[3];
  const double lambda = pL[0]+(pL[1]+lgE*pL[2])*s;

  if (r < r0)
    return 1.;

  const double t1 = exp(-(r-r0)*(r-r0)/lambda/lambda);
  const double t2 = pow(2.*t1,-9.);

  return pow(1.+t2, -1./9.);
}

//=============================================================================
double
T2TriggerProb::MeanXmax(double lgE, int A)
  const
{
  if (A != kProtonID && A != kIronID) {
    ostringstream errMsg;
    errMsg  << " meanXmax(): primary " << A
            << " not implemented ";
    throw std::runtime_error(errMsg.str());
  }
  else {
    if (A == kProtonID)
      return 7.20755e+02 + (lgE-18.)*5.04298e+01;
    else
      return 6.26391e+02 + (lgE-18.)*5.76662e+01;
  }
}


/*=============================================================================

  lorenzo@le.infn.it + mariangela.settimo@le.infn.it
  2007/05/23

  rm: tank distance to shower axis in meter
  logene: log10 of energy in eV
  coszen: cosine of zenith angle
  prim: 1 for proton, 2 for iron, 0 for photon


  =============================================================================*/

double
T2TriggerProb::GetTOTprob(const double rm, const double logene,
                          const double coszen, const int iprim)
  const
{

  const double r = rm/1000;

  double R0 = 0;
  double dR = 0;
  double A = 0;

  if (iprim == kProtonID) {
    double R0tab[3][3];
    R0tab[0][0] = 48.184;
    R0tab[0][1] = -6.882;
    R0tab[0][2] = 0.230;
    R0tab[1][0] = -64.386;
    R0tab[1][1] = 9.444;
    R0tab[1][2] =-0.311;
    R0tab[2][0] = 42.071;
    R0tab[2][1] = -5.895;
    R0tab[2][2] = 0.190;

    double dRtab[3][3];
    dRtab[0][0] =-7.450;
    dRtab[0][1] = 0.842;
    dRtab[0][2] =-0.023 ;
    dRtab[1][0] = 15.572;
    dRtab[1][1] = -1.786;
    dRtab[1][2] = 0.0494;
    dRtab[2][0] = -6.143 ;
    dRtab[2][1] = 0.707 ;
    dRtab[2][2] = -0.019;

    double Atab[3][3];
    Atab[0][0] = -258.717;
    Atab[0][1] = 26.876;
    Atab[0][2] = -0.696;
    Atab[1][0] = -37.734;
    Atab[1][1] = 1.606;
    Atab[1][2] = 0;
    Atab[2][0] = 0;
    Atab[2][1] = 0;
    Atab[2][2] = 0;


    double a = (R0tab[0][0]+R0tab[0][1]*logene+R0tab[0][2]*logene*logene);
    double b = (R0tab[1][0]+R0tab[1][1]*logene+R0tab[1][2]*logene*logene);
    double c = (R0tab[2][0]+R0tab[2][1]*logene+R0tab[2][2]*logene*logene);
    R0 = a+b*coszen+c*coszen*coszen;

    double a1 = (dRtab[0][0]+dRtab[0][1]*logene+dRtab[0][2]*logene*logene);
    double b1 = (dRtab[1][0]+dRtab[1][1]*logene+dRtab[1][2]*logene*logene);
    double c1 = (dRtab[2][0]+dRtab[2][1]*logene+dRtab[2][2]*logene*logene);
    dR = a1+b1*coszen+c1*coszen*coszen;

    double a2 = (Atab[0][0]+Atab[0][1]*logene+Atab[0][2]*logene*logene);
    double b2 = (Atab[1][0]+Atab[1][1]*logene+Atab[1][2]*logene*logene);
    double c2 = (Atab[2][0]+Atab[2][1]*logene+Atab[2][2]*logene*logene);
    A = a2+b2*coszen+c2*coszen*coszen;
  }
  else if (iprim == kPhotonID) {
    double R0tab[3][3];
    R0tab[0][0] = 174.277;
    R0tab[0][1] = -20.6937;
    R0tab[0][2] = 0.604697;
    R0tab[1][0] = -444.296;
    R0tab[1][1] = 51.294;
    R0tab[1][2] = -1.45433;
    R0tab[2][0] = 280.805;
    R0tab[2][1] = -32.0625;
    R0tab[2][2] = 0.900159;

    double dRtab[3][3];
    dRtab[0][0] = 12.879;
    dRtab[0][1] =  -1.46268;
    dRtab[0][2] = 0.0429095;
    dRtab[1][0] = -42.9805;
    dRtab[1][1] = 4.89147;
    dRtab[1][2] = -0.142017;
    dRtab[2][0] = 36.9494;
    dRtab[2][1] =  -4.22136;
    dRtab[2][2] = 0.122153;

    double Atab[3][3];

    Atab[0][0] = -7200.91;
    Atab[0][1] = 802.1;
    Atab[0][2] = -22.21;
    Atab[1][0] = 18783.1;
    Atab[1][1] = -2099.46;
    Atab[1][2] = 58.2629;
    Atab[2][0] = -11562.9;
    Atab[2][1] = 1289.46;
    Atab[2][2] = -35.7143;

    double a = (R0tab[0][0]+R0tab[0][1]*logene+R0tab[0][2]*logene*logene);
    double b = (R0tab[1][0]+R0tab[1][1]*logene+R0tab[1][2]*logene*logene);
    double c = (R0tab[2][0]+R0tab[2][1]*logene+R0tab[2][2]*logene*logene);
    R0 = a+b*coszen+c*coszen*coszen;

    double a1 = (dRtab[0][0]+dRtab[0][1]*logene+dRtab[0][2]*logene*logene);
    double b1 = (dRtab[1][0]+dRtab[1][1]*logene+dRtab[1][2]*logene*logene);
    double c1 = (dRtab[2][0]+dRtab[2][1]*logene+dRtab[2][2]*logene*logene);
    dR = a1+b1*coszen+c1*coszen*coszen;

    double a2 = (Atab[0][0]+Atab[0][1]*logene+Atab[0][2]*logene*logene);
    double b2 = (Atab[1][0]+Atab[1][1]*logene+Atab[1][2]*logene*logene);
    double c2 = (Atab[2][0]+Atab[2][1]*logene+Atab[2][2]*logene*logene);
    A = a2+b2*coszen+c2*coszen*coszen;

  }
  else {

    if (iprim != kIronID)
      cout << "WARNING: T2TriggerProb::GetTOTprob using Primary-ID "
           << iprim << " which is not supported; IRON Model will be used"
	   << endl;

    double R0tab[3][3];
    R0tab[0][0] = 49.0499;
    R0tab[0][1] = -6.96653;
    R0tab[0][2] = 0.233457;
    R0tab[1][0] = -9.23569;
    R0tab[1][1] = 3.07189;
    R0tab[1][2] = -0.130661;
    R0tab[2][0] = -24.4423;
    R0tab[2][1] = 1.69381;
    R0tab[2][2] = -0.0243089;

    double dRtab[3][3];
    dRtab[0][0] = -0.952419;
    dRtab[0][1] =  0.0681017;
    dRtab[0][2] = 0;
    dRtab[1][0] = 1.46683;
    dRtab[1][1] = -0.104445;
    dRtab[1][2] = 0;
    dRtab[2][0] = -0.932367;
    dRtab[2][1] =  0.0636077;
    dRtab[2][2] = 0;

    double Atab[3][3];

    Atab[0][0] = -881.852;
    Atab[0][1] = 95.0638;
    Atab[0][2] = -2.5614;
    Atab[1][0] = 383.308;
    Atab[1][1] = -43.9903;
    Atab[1][2] = 1.23912;
    Atab[2][0] = 0;
    Atab[2][1] = 0;
    Atab[2][2] = 0;

    double a = (R0tab[0][0]+R0tab[0][1]*logene+R0tab[0][2]*logene*logene);
    double b = (R0tab[1][0]+R0tab[1][1]*logene+R0tab[1][2]*logene*logene);
    double c = (R0tab[2][0]+R0tab[2][1]*logene+R0tab[2][2]*logene*logene);
    R0 = a+b*coszen+c*coszen*coszen;

    double a1 = (dRtab[0][0]+dRtab[0][1]*logene+dRtab[0][2]*logene*logene);
    double b1 = (dRtab[1][0]+dRtab[1][1]*logene+dRtab[1][2]*logene*logene);
    double c1 = (dRtab[2][0]+dRtab[2][1]*logene+dRtab[2][2]*logene*logene);
    dR = a1+b1*coszen+c1*coszen*coszen;

    double a2 = (Atab[0][0]+Atab[0][1]*logene+Atab[0][2]*logene*logene);
    double b2 = (Atab[1][0]+Atab[1][1]*logene+Atab[1][2]*logene*logene);
    double c2 = (Atab[2][0]+Atab[2][1]*logene+Atab[2][2]*logene*logene);
    A = a2+b2*coszen+c2*coszen*coszen;

  }

  // else
//       cerr<<"ERROR: T2TriggerProb::GetTOTprob trying to use Primary-ID "
//           <<iprim<<" which is not supported"<<endl;
//       return -1.;
//     }

  double TOT = 0;
  if (r > R0)
    TOT = exp(A*(r-R0)-0.69);
  else {
    const double maxAlpha = 709;
    const double alpha = fmin((r-R0)/dR, maxAlpha);
    TOT = 1. / (1.+exp(alpha));
  }

  return TOT;
}

