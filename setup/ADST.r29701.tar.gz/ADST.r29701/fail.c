#error  ********************************************
#error  * ADSTROOT environment variable not defined! *
#error  * read documentation and fix!              *
#error  ********************************************
