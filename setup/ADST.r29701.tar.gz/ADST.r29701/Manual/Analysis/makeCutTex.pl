#!/usr/bin/env perl
use strict;
use warnings;
use Text::Wrap qw(wrap $columns $huge);

my $infile = shift;
$infile =~ s/\.(cuts|txt).tex$/\.$1/i;
warn $infile;
my $maxlen = 80;

my $startOutput = 0;
open my $fh, '<', $infile or die $!;
while (<$fh>) {
  chomp;
  $startOutput++ if !/^adst cuts/i and !/^\s*(?:#(?!##)|$)/;
  next unless $startOutput;

  s/\s+$//;
  s/\t/        /g;
  
  if (length($_) > $maxlen and /^([^#]+)#(\s*)(.*)$/) {
    my $initial = $1;
    my $spacing = $2;
    my $cmt     = $3;

    $columns = $maxlen-length($initial."#$spacing");
    $_ = wrap("", "", $cmt);
    s/^/(" " x length($initial)) . "#$spacing"/mge;
    s/^\s*#\Q$spacing\E/$initial#$spacing/;
    #$_ = wrap($initial."#$spacing", (" " x length($initial)) . "#$spacing", $cmt);
    s/\t/        /g;
  }

  print $_,"\n";  
}


