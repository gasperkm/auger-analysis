// $Id: FdRecPixel.cc 20046 2011-12-23 21:34:36Z darko $
#include <FdRecPixel.h>
#include <FdRecLevel.h>

#include <iostream>
#include <algorithm>
#include <numeric>
#include <map>
#include <vector>
#include <stdexcept>

using namespace std;


ClassImp(FdRecPixel);


// helper

template<
  typename K, typename D, class O, class A,
  template<typename, typename, typename, typename> class Map
>
inline
D
FindSafe(const Map<K, D, O, A>& map, const K value, const char* const errorMessage)
{
  const typename Map<K, D, O, A>::const_iterator it = map.find(value);
  if (it != map.end())
    return it->second;
  else {
    cerr << errorMessage << endl;
    throw out_of_range(errorMessage);
  }
}


//=============================================================================
/*!
  \class   FdRecPixel
  \brief   Reconstructed pixel pulses

  \version 1.0
  \date    Aug 03 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

FdRecPixel::FdRecPixel() :
  fnPixel(0),
  fnRecPixel(0),
  fnTracePixel(0)
{ }


void
FdRecPixel::SetNumberOfPixels(const int nPx)
{
  if (fnPixel)
    cerr << "FdRecPixel::SetNumberOfPixels - Warning uncleared data members!\n"
            "                                memory leak!\n"
            " NPixels: " << fnPixel << endl;

  fnPixel = nPx;

  fID.resize(nPx);
  fStatus.resize(nPx);
  fTime.resize(nPx);
  fTimeErr.resize(nPx);
  fChi.resize(nPx);
  fCharge.resize(nPx);
  fThreshold.resize(nPx);

  fmeanPixelRMS = 0;
  fmeanADCRMS = 0;

  for (int i = 0; i < fnPixel; ++i) {
    fID[i] = 0;
    fStatus[i] = eBackGroundPix;
    fTime[i] = 0;
    fTimeErr[i] = 0;
    fChi[i] = 0;
    fCharge[i] = 0;
    fThreshold[i] = 0;
  }
}


void
FdRecPixel::SetNumberOfTracePixels(const int nTracePx)
{
  if (fnTracePixel) {
    cerr << "FdRecPixel::SetNumberOfTracePixels - "
            "Warning uncleared data members!\n"
            "                                memory leak!" << endl;
  }
  fnTracePixel = nTracePx;
}


void
FdRecPixel::SetDataTrace(const int i, const vector<double>& trace)
{
  fDataTrace[i] = FdTrace(trace);
}


void
FdRecPixel::SetSpotRecTrace(const int i, const vector<double>& trace)
{
  fSpotRecTrace[i] = FdTrace(trace);
}


double
FdRecPixel::GetTraceSum(const int i, const int iFirst, const int iLast)
  const
{
  const vector<double>& trace = GetTrace(i);

  if (trace.empty() || iFirst < 0 || iLast >= int(trace.size())-1) {
    cerr << " FdRecPixel::GetTraceSum() - Error: request range ["
         << iFirst << ',' << iLast << "] for trace " << i
         << " size=" << trace.size() << endl;
    return 0;
  } else
    return accumulate(trace.begin()+iFirst, trace.begin()+iLast, 0.);
}


double
FdRecPixel::GetSpotRecTraceSum(const int i, const int iFirst, const int iLast)
  const
{
  const vector<double>& trace = GetSpotRecTrace(i);

  if (trace.empty() || iFirst < 0 || iLast >= int(trace.size())) {
    cerr << " FdRecPixel::GetSpotRecTraceSum() - Error: request range ["
         << iFirst << ',' << iLast << "] for trace " << i
         << " size=" << trace.size() << endl;
    return 0;
  } else
    return accumulate(trace.begin()+iFirst, trace.begin()+iLast, 0.);
}


double
FdRecPixel::GetTraceMax(const int i)
  const
{
  const vector<double>& trace = GetTrace(i);
  return trace.empty() ? 0 : *max_element(trace.begin(), trace.end());
}


double
FdRecPixel::GetSpotRecTraceMax(const int i)
  const
{
  const vector<double>& trace = GetSpotRecTrace(i);
  return trace.empty() ? 0 : *max_element(trace.begin(), trace.end());
}


const vector<double>&
FdRecPixel::GetTrace(const int i)
  const
{
  const map<int, FdTrace >::const_iterator traceIter = fDataTrace.find(i);
  if (traceIter != fDataTrace.end())
    return traceIter->second.GetTrace();
  else {
    cerr << " FdRecPixel::GetTrace() - Error: no trace for pixel " << i << endl;
    static const vector<double> empty;
    return empty;
  }
}


const vector<double>&
FdRecPixel::GetSpotRecTrace(const int i)
  const
{
  const map<int, FdTrace >::const_iterator traceIter = fSpotRecTrace.find(i);
  if (traceIter != fSpotRecTrace.end())
    return traceIter->second.GetTrace();
  else {
    cerr << " FdRecPixel::GetSpotRecTrace() - Error: no trace for pixel "
         << i << endl;
    static const vector<double> empty;
    return empty;
  }
}


bool
FdRecPixel::HasSimTrace(const int i, const FdApertureLight::ELightComponent source)
  const
{
  const map<int, FdMultiTrace>::const_iterator it = fSimTraceComponents.find(i);
  return it != fSimTraceComponents.end() && it->second.HasComponent(source);
}


const vector<double>&
FdRecPixel::GetSimTrace(const int i, const FdApertureLight::ELightComponent source)
  const
{
  const map<int, FdMultiTrace>::const_iterator it = fSimTraceComponents.find(i);
  if (it != fSimTraceComponents.end() && it->second.HasComponent(source))
    return it->second.GetComponent(source).GetTrace();
  else {
    cerr << " FdRecPixel::GetSimTrace() - Error: no sim trace for pixel "
         << i << " component " << source << endl;
    static const vector<double> empty;
    return empty;
  }
}


int
FdRecPixel::GetSimTraceOffset(const int iPixel)
  const
{
  return FindSafe<>(fSimTraceComponentsOffset, iPixel,
                    "FdRecPixel::GetSimTraceOffset - Error: pixel not found!");
}


int
FdRecPixel::GetPulseStart(const int i)
  const
{
  return FindSafe<>(fPulseStart, i,
                    "FdRecPixel::GetPulseStart - Error: pixel not found!");
}


int
FdRecPixel::GetPulseStop(const int i)
  const
{
  return FindSafe<>(fPulseStop, i,
                    "FdRecPixel::GetPulseStop - Error: pixel not found!");
}


double
FdRecPixel::GetRMS(const int i)
  const
{
  return FindSafe<>(fRMS, i,
                    "FdRecPixel::GetPulseStop - Error: pixel not found!");
}


double
FdRecPixel::GetCalibrationConstant(const int i)
  const
{
  return FindSafe<>(fCalibConst, i,
                    "FdRecPixel::GetCalibrationConstant - Error: pixel not found!");
}


int
FdRecPixel::GetNumberOfTimeFitPixels()
  const
{
  int timeFitPixels = 0;
  if (!fStatus.empty())
    for (int i = 0; i < fnPixel; ++i)
      if(fStatus[i] >= eTimeFitPix)
        ++timeFitPixels;

  return timeFitPixels;
}


int
FdRecPixel::GetNumberOfSDPFitPixels()
  const
{
  int sdpFitPixels = 0;
  if (!fStatus.empty())
    for (int i = 0; i < fnPixel; ++i)
      if (fStatus[i] >= eSDPRecPix)
        ++sdpFitPixels;

  return sdpFitPixels;
}


double
FdRecPixel:: GetMeanThreshold()
  const
{
  double sum = 0;
  int entries = 0;
  for (unsigned int i = 0, n = fThreshold.size(); i < n; ++i)
    if (fThreshold[i]) {
      sum += fThreshold[i];
      ++entries;
    }

  return entries ? sum / entries : 0;
}


void
FdRecPixel::SetSimTrace(const vector<double>& trace,
                        const int i,
                        const FdApertureLight::ELightComponent source,
                        const int offset)
{
  fSimTraceComponents[i].AddComponent(trace, source);
  fSimTraceComponentsOffset[i] = offset;
}
