#ifndef __StationStatus_H
#define __StationStatus_H


//
//  Station data definition
//


enum EStationStatus {
  eUnknown,
  eSilent,
  eAccidental,
  eCandidate
};

enum EStationTrigger {
  eT1Threshold,
  eT2Threshold,
  eTOT,
  eRandom,
  eNone,
  eTOTd,
  eMoPS
};

// Keep this in sync with Offline/Framework/SEvent/StationConstants.h

enum ERejectionStatus {
  eNoRejection      = 0,
  eLightning        = (1 << 0),
  eBadCompress      = (1 << 1),
  eOutOfTime        = (1 << 2),
  eOffGrid          = (1 << 3),
  eDenseArray       = (1 << 4),
  eRandomR          = (1 << 5),
  eEngineeringArray = (1 << 6),
  eMCInnerRadiusCut = (1 << 7),
  eNoRecData        = (1 << 8),
  eLonely           = (1 << 9),
  eNoTrigger        = (1 << 10),
  eErrorCode        = (1 << 11),
  eNoCalibData      = (1 << 12),
  eNoGPSData        = (1 << 13),
  eBadCalib         = (1 << 14),
  eRegularMC        = (1 << 15), 
  eTOTdRejected     = (1 << 16),
  eMoPSRejected     = (1 << 17),

  eNumRejectionStatusBits = 18
};

#endif
