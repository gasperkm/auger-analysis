#include <FdCloudCameraData.h>
#include <map>
#include <vector>
#include <iostream>

using namespace std;


ClassImp(FdCloudCameraData);


/**
    \class   FdCloudCameraData
    \brief   stores cloud camera's cloud fraction for each telescope and pixel

    \date    Oct 2010
    \author  C. Baus
 */

Bool_t
FdCloudCameraData::HasCloudFraction(const Int_t telId, const Int_t pixelId)
  const
{
  const Int_t vecPixelId = pixelId - 1; //Auger convention
  map<int, vector<Char_t> >::const_iterator it = fCloudMap.find(telId);
  if (it == fCloudMap.end())
    return false;
  if (vecPixelId < 0 || vecPixelId >= Int_t(it->second.size()))
    return false;

  return true;
}


Float_t
FdCloudCameraData::GetCloudFraction(const Int_t telId, const Int_t pixelId)
  const
{
  const Int_t vecPixelId = pixelId - 1; //Auger convention
  map<int, vector<Char_t> >::const_iterator it = fCloudMap.find(telId);
  if (HasCloudFraction(telId, pixelId))
    return Float_t(it->second[vecPixelId]) / 100;
  else
    return -1;
}


void
FdCloudCameraData::SetCloudFraction(const Int_t telId, const Int_t pixelId, const Float_t cloudFraction)
{
  if (pixelId < 1) {
    cerr << "FdCloudCameraData::SetCloudFraction() - "
            " Pixel IDs start at 1 (Auger convention) " << endl;
    return;
  }
  const Int_t vecPixelId = pixelId - 1; //Auger convention
  if (vecPixelId < Int_t(fCloudMap[telId].size()))
    fCloudMap[telId][vecPixelId] = Char_t(cloudFraction * 100);
  else {
    fCloudMap[telId].resize(vecPixelId < 440 ? 440 : vecPixelId, -100); //resize for at least 440 pixels
    fCloudMap[telId][vecPixelId] = Char_t(cloudFraction * 100);
  }
}
