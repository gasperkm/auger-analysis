// $Id: SimInfo.h 20050 2011-12-24 03:07:37Z darko $
#ifndef __SimInfo_h__
#define __SimInfo_h__

#include <TObject.h>


//  header for MC run

class SimInfo : public TObject {

public:
  virtual ~SimInfo() { }

private:  
  ClassDef(SimInfo, 4);

};


#endif
