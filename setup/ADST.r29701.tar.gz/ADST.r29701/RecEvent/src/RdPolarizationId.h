#ifndef RdPolarizationId_H
#define RdPolarizationId_H
enum EPol {
eX=0,  // East
eY=1,  // North
eZ=2,  // Up
eTotal=3,
eCH1=10,
eCH2=11,
eCH3=12,
eCH4=13};
typedef  EPol epol; // Go for Capital E to stick to coding convention but keep the old type for backward compatibility
#endif
