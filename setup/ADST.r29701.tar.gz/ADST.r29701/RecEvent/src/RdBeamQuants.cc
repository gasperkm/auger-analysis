#ifdef AUGER_RADIO_ENABLED
#include <RdBeamQuants.h>

ClassImp(RdBeamQuants)

RdBeamQuants::RdBeamQuants()
: fZenith (0.0), fAzimuth (0.0), fCurvature (0.0), fCone (0.0) {}
#endif
