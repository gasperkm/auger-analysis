#ifndef __RdRecStation_H
#define __RdRecStation_H
#ifdef AUGER_RADIO_ENABLED

#include <RecStation.h> // for the enums
#include <RdTrace.h>
#include <RdPolarizationId.h> // for the polarization enums

#include <TObject.h>

#include "StationRRecDataQuantities.h"
#include "RdRecStationParameterStorageMap.h"

#include <vector>
#include <map>
#include <stdexcept>
using namespace std;
//
//  Station data definition
//


class RdRecStation : public RecStation {
// MM TOADD         : Antenna description ( LPDA/SALLA/Dipole/etc..)

public:
  RdRecStation();
  ~RdRecStation();


  void SetParameter(const revt::StationRRecDataQuantities eIndex,const double value) {
    fStationQuantities.SetParameter(eIndex,value);
  }
  void SetParameterError(const revt::StationRRecDataQuantities eIndex,const double value) {
    fStationQuantities.SetParameterError(eIndex,value);
  }
  void SetParameterCovariance(const revt::StationRRecDataQuantities eIndex1, const revt::StationRRecDataQuantities eIndex2 ,const double value) {
    fStationQuantities.SetParameterCovariance(eIndex1, eIndex2 ,value);
  }
  
  double GetParameter(const revt::StationRRecDataQuantities eIndex)
    const
  {
    return fStationQuantities.GetParameter(eIndex);
  }
  
  double GetParameterError(const revt::StationRRecDataQuantities eIndex)
    const
  {
    return fStationQuantities.GetParameterError(eIndex);
  }
  
  double GetParameterCovariance(const revt::StationRRecDataQuantities eIndex1, const  revt::StationRRecDataQuantities eIndex2)
    const
  {
    return fStationQuantities.GetParameterCovariance(eIndex1,eIndex2);
  }
  
  bool HasParameter(const revt::StationRRecDataQuantities eIndex)
    const
  {
    return fStationQuantities.HasParameter(eIndex);
  }

  bool HasParameterError(const revt::StationRRecDataQuantities eIndex)
  const
  {
    return fStationQuantities.HasParameterCovariance(eIndex,eIndex);
  }
  
  bool HasParameterCovariance(const revt::StationRRecDataQuantities eIndex1, const  revt::StationRRecDataQuantities eIndex2)
    const
  {
    return fStationQuantities.HasParameterCovariance( eIndex1, eIndex2);
  }


  
  // ------------------ setters and getters ----------------------------------------------

  /// set  id of station i

  //Station Timing 
  void SetRdStationTime(const  Int_t s,const  Int_t ns) {fRTimeNSecond=ns; fRTimeSecond=s;}
  
  /// return the Azimuth of the signal arrival direction of this station
  double GetSignalArrivalAzimuth() const ;

  /// return the Zenith of the signal arrival direction of this station
  double GetSignalArrivalZenith() const ;

  /// returns the trace start time
  Int_t GetRdStationTimeSecond() const {
    cout << "WARNING: Outdated interface used: RdRecStation::GetRdStationTimeSecond() \n "
        "use RdRecStation.GetParameter(eTraceStartTime) instead!!!" << endl;
    return fRTimeSecond;
  }
  Int_t GetRdStationTimeNanoSecond() const {
    cout << "WARNING: Outdated interface used: RdRecStation::GetRdStationTimeSecond() \n "
            "use RdRecStation.GetParameter(eTraceStartTime) instead!!!" << endl;
    return fRTimeNSecond;
  }

  void SetHasPulse(bool pulsefound=true) {fPulsefound=pulsefound;}
  bool HasPulse() const {return fPulsefound;}


/** Get trace, Generic Tool, see RdPolarization id for converting int to polarization *
 * 1/2/3 Station level X/Y/Z                                                          *
 * 11/12/13/14 Channel level ch1/ch2/ch3/ch4                                         **/

  void SetRdTimeTrace(const std::vector<Float_t>& timeTrace, int polNb);
  const std::vector<Float_t>& GetRdTimeTrace(int polNb) const throw(std::out_of_range);
  void SetRdAbsSpectrum(const std::vector<Float_t>& freqTrace, int polNb);
  const std::vector<Float_t>& GetRdAbsSpectrum(int polNb) const throw(std::out_of_range) ;
  const RdTrace& GetRdTrace(int polNb) const throw (std::out_of_range);
  RdTrace& GetRdTrace(int polNb) throw(std::out_of_range);
  void SetRdTrace(const RdTrace& trac, int polNb);

/**  Trace/spectrum at the channel level                                           *
 * At the Channel Level  Channel 1/2/3 per station                                 *
 * TODO Create a RdChan object containing the Channel level specific information   *
 * TODO add file RdRecChannel                                                      */

  void SetRdChannelTrace(const std::vector<Float_t>& timeTrace, int chanNb);
  const std::vector<Float_t>& GetRdChannelTrace(int chanNb) const throw(std::out_of_range);
  void SetChannelAbsSpectrum(const std::vector<Float_t>& timeTrace, int chanNb);
  const std::vector<Float_t>& GetChannelAbsSpectrum(int chanNb) const throw (std::out_of_range);

/** E-Field trace at the Station Level                          *
 * At the Station Level Polarisation 1/2/3                      */
  void SetEFieldTimeTrace(const std::vector<Float_t>& timeTrace, int polNb);
  void SetEFieldnAbsSpectrum(const std::vector<Float_t>& timeTrace, int polNb);
  const std::vector<Float_t>& GetEFieldTimeTrace(int polNb) const throw(std::out_of_range);
  const std::vector<Float_t>& GetEFieldnAbsSpectrum(int polNb) const throw (std::out_of_range);

/** Low level information,  In principle they should be         *
 *  Defined for the Channels only                               */

  UInt_t GetADCSignalThreshold(int polNb) const throw (std::out_of_range);
  void SetADCSignalThreshold(UInt_t tresh, int polNb);
  UInt_t GetADCNoiseThreshold(int polNb) const throw (std::out_of_range);
  void SetADCNoiseThreshold(UInt_t tresh,int polNb);
  void SetChannelSaturated(int polNb, bool saturated=true);
  bool IsChannelSaturated(int polNb) const ; ///Channel are by Default non Saturated so if the channel is not defined in the table false will be returned 


  private:

  RdRecStationParameterStorageMap fStationQuantities;
    
//  ESaturationStatus fSaturationStatus;

  Int_t  fRTimeSecond;
  Int_t  fRTimeNSecond;


  /// Radio signal variables

  Int_t fTimePeakPosition_s;
  Int_t fTimePeakPosition_ns;
  Float_t fRdSignal;
  Float_t fPolarizationPhi;
  Float_t fPolarizationTheta;
  Float_t fPolarizationThetaError;
  Float_t fPolarizationPhiError;
  Int_t fSignalWindowStart_s;
  Int_t fSignalWindowStop_s;
  Int_t fNoiseWindowStart_s;
  Int_t fNoiseWindowStop_s;
  Int_t fSignalWindowStart_ns;
  Int_t fSignalWindowStop_ns;
  Int_t fNoiseWindowStart_ns;
  Int_t fNoiseWindowStop_ns;
  Float_t fSNR;
  Float_t fNoise;
  bool fPulsefound;
  Double_t fSignalTimeError;



  std::map<int,Int_t> fTimePeakPosition_smap;
  std::map<int,Int_t> fTimePeakPosition_nsmap;
  std::map<int,Float_t> fRdAmpmap;
  std::map<int,Int_t> fTimePeakMaxmap;
  std::map<int,Int_t> fTimePeakMinmap;
  std::map<int,Float_t> fRMSmap;
  std::map<int,Float_t> fNoiseMeanmap;
  std::map<int,Float_t> fFWHMmap;
  std::map<int,RdTrace > fTraces;
  std::map<int,UInt_t> fADCSignalThreshold;
  std::map<int,UInt_t> fADCNoiseThreshold;
  std::map<int,bool> fIsChannelSaturated;


  ClassDef (RdRecStation,15);
};


#endif
#endif
