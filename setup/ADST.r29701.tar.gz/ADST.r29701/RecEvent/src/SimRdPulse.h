#ifndef __SimRdPulse_H
#define __SimRdPulse_H
#ifdef AUGER_RADIO_ENABLED

#include <TVector3.h>
#include <RdTrace.h>
#include <TObject.h>
#include <RdPolarizationId.h>

#include <vector>
#include <map>
#include <stdexcept>
#include <iostream>


//
//  Shower data definition
//

class SimRdPulse: public TObject {

public:
  SimRdPulse();
  virtual ~SimRdPulse() {}
  void SetId(const UInt_t id) {fId= id;}                ///< set  id of station
  UInt_t   GetId() const {return fId;}                  ///< get  id of station

  void SetRdTime(const  Int_t s,const  Int_t ns) {fRTimeNSecond=ns; fRTimeSecond=s;}
  Int_t GetRdTimeSecond() const {return fRTimeSecond;}       ///< get time of station 
  Int_t GetRdTimeNSecond() const {return fRTimeNSecond;}     ///< get time error

  // Generic Level Station 1/2/3 Channel 11/12/13
  void SetTimeTrace(const std::vector<Float_t>& timeTrace, int polNb);
  const std::vector<Float_t>& GetTimeTrace(int polNb) const throw(std::out_of_range);
  void SetFreqTrace(const std::vector<Float_t>& freqTrace, int polNb);
  const std::vector<Float_t>& GetFreqTrace(int polNb) const throw(std::out_of_range) ;
  const RdTrace& GetRdTrace(int polNb) const throw (std::out_of_range);
  RdTrace& GetRdTrace(int polNb) throw(std::out_of_range);
  void SetRdTrace(const RdTrace& trac, int polNb);

private:
  UInt_t    fId;
  Int_t  fRTimeSecond;
  Int_t  fRTimeNSecond;
  

  /// Radio signal variables
  std::map<int,RdTrace > fTraces;

  ClassDef(SimRdPulse,3);
};

#endif
#endif
