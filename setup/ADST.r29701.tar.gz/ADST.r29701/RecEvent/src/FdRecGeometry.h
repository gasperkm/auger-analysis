#ifndef __FdRecGeometry_h__
#define __FdRecGeometry_h__

#include <FdGeometry.h>

#include <FdRecLevel.h>

class FdRecGeometry : public FdGeometry {


public:
  FdRecGeometry();

  // -------- low level geometry variables ---------

  /// get error of theta of SDP fit [rad]
  Double_t GetSDPThetaError() const {return fSDPThetaError;}   
  /// get error of phi of SDP fit [rad]
  Double_t GetSDPPhiError() const {return fSDPPhiError;}      
  /// get the correlation coefficient between Theta and Phi
  Double_t GetSDPThetaPhiCorrelation() const {return fRhoThetaPhi;}    
  /// get chi2 of SDP fit [rad]
  Double_t GetSDPChi2() const {return fSDPChi2;}     
  /// get NdF of SDP fit [rad]
  UInt_t GetSDPNdF() const {return fSDPNdF;}     

  /// get error of T0  of time fit [ns]
  Double_t GetT0Error() const {return fT0Error;} 
  /// get error of Rp of time fit [m]
  Double_t GetRpError() const {return fRpError;} 
  /// get error of Chi0 of time fit [rad]
  Double_t GetChi0Error() const {return fChi0Error;} 
  /// get the correlation coefficient between Chi0 and T0
  Double_t GetChi0T0Correlation() const {return fRhoChi0T0;}
  /// get the correlation coefficient between Chi0 and Rp
  Double_t GetChi0RpCorrelation() const  {return fRhoChi0Rp;}
  /// get the correlation coefficient between  Rp and T0
  Double_t GetRpT0Correlation() const {return fRhoRpT0;}
  /// get chi2 of hybrid time fit 
  Double_t GetTimeFitChi2() const {return fTimeFitChi2;} 
  /// get chi2 of FD only time fit
  Double_t GetTimeFitFDChi2() const  {return fTimeFitFDChi2;} 
  /// get chi2 of linear fit to FD times
  Double_t GetLinearTimeFitChi2() const  {return fLinearTimeFitChi2;} 
  /// get NdF of time fit
  UInt_t GetTimeFitNdof() const  {return fTimeFitNdF;} 

  /// get the correlation coefficient between northing and easting
  Double_t GetNorthEastCorrelation() const {return fNorthEastCorrelation;}
  /// get the correlation coefficient between northing and theta
  Double_t GetNorthThetaCorrelation() const {return fNorthThetaCorrelation;}
  /// get the correlation coefficient between northing and phi
  Double_t GetNorthPhiCorrelation() const {return fNorthPhiCorrelation;}
  /// get the correlation coefficient between northing and TCore
  Double_t GetNorthTCoreCorrelation() const {return fNorthTCoreCorrelation;}
  /// get the correlation coefficient between easting and theta
  Double_t GetEastThetaCorrelation() const {return fEastThetaCorrelation;}
  /// get the correlation coefficient between easting and phi
  Double_t GetEastPhiCorrelation() const {return fEastPhiCorrelation;}
  /// get the correlation coefficient between easting and TCore
  Double_t GetEastTCoreCorrelation() const {return fEastTCoreCorrelation;}
  /// get the correlation coefficient between theta and phi
  Double_t GetThetaPhiCorrelation() const {return fThetaPhiCorrelation;}
  /// get the correlation coefficient between theta and TCore
  Double_t GetThetaTCoreCorrelation() const {return fThetaTCoreCorrelation;}
  /// get the correlation coefficient between phi and TCore
  Double_t GetPhiTCoreCorrelation() const {return fPhiTCoreCorrelation;}
  /// get chi2 of axis/core fit
  Double_t GetAxisFitChi2() const {return fAxisFitChi2;}
  /// get Ndf of axis/core fit
  UInt_t GetAxisFitNdof() const {return fAxisFitNdF;}

  /// get the number of pixels in the time fit
  UInt_t GetNTimeFitPixels() const {return fNTimeFitPixels;}

  /// get the rec level of the geometry reconstruction
  EFdGeomRecLevel GetGeomRecLevel() const {return fFdGeomRecLevel;}

  /// calculate uncertainty of distance from eye to core
  Double_t GetCoreEyeDistanceError() const;        


  // -------- SD related variables ---------

  /// get number of stations used in hybrid fit
  UInt_t GetNHybridStations() const {return fNTank;}
  /// get the hottest station of hybrid fit
  UInt_t GetHottestStation() const {return fHottestTank;}
  /// get the distance of the hottest station to the axis in SP coords. [m]
  Double_t GetStationAxisDistance() const {return fNTank>0?fAxisDist:1e99;}
  /// get the FD/SD time residual after fit [ns]
  Double_t GetSDFDTimeOffset() const {return fNTank>0?fSDFDdT:1e99;}
  /// get the distance of the hottest station to the SDP [m]
  Double_t GetStationSDPDistance() const {return fNTank>0?fSDPDist:1e99;}


  /// set error of theta of SDP fit [rad]
  void SetSDPThetaError (Double_t arg) { fSDPThetaError=arg;}   
  /// set error of phi of SDP fit [rad]
  void SetSDPPhiError (Double_t arg) { fSDPPhiError=arg;}      
  /// set the correlation coefficient between Theta and Phi
  void SetSDPThetaPhiCorrelation (Double_t arg) {fRhoThetaPhi=arg;}    
  /// set chi2 of SDP fit [rad]
  void SetSDPChi2 (Double_t arg) { fSDPChi2=arg;}     
  /// set NdF of SDP fit [rad]
  void SetSDPNdF (UInt_t arg) { fSDPNdF=arg;}   

  /// set error of T0  of time fit [ns]
  void SetT0Error (Double_t arg) { fT0Error=arg;} 
  /// set error of Rp of time fit [m]
  void SetRpError (Double_t arg) { fRpError=arg;} 
  /// set error of Chi0 of time fit [rad]
  void SetChi0Error (Double_t arg) { fChi0Error=arg;} 
  /// set the correlation coefficient between Chi0 and T0
  void SetChi0T0Correlation (Double_t arg) {fRhoChi0T0=arg;}
  /// set the correlation coefficient between Chi0 and Rp
  void SetChi0RpCorrelation (Double_t arg) {fRhoChi0Rp=arg;}
  /// set the correlation coefficient between  Rp and T0
  void SetRpT0Correlation (Double_t arg) {fRhoRpT0=arg;}
  /// set chi2 of hybrid time fit 
  void SetTimeFitChi2 (Double_t arg) { fTimeFitChi2=arg;} 
  /// set chi2 of FD only time fit
  void SetTimeFitFDChi2 (Double_t arg) { fTimeFitFDChi2=arg;} 
  /// get chi2 of linear fit to FD times
  void SetLinearTimeFitChi2 (Double_t chi2) {fLinearTimeFitChi2=chi2;} 
  /// set NdF of time fit
  void SetTimeFitNdof (UInt_t arg) { fTimeFitNdF=arg;}

  /// set the correlation coefficient between northing and easting
  void SetNorthEastCorrelation (Double_t arg) {fNorthEastCorrelation=arg;}
  /// set the correlation coefficient between northing and theta
  void SetNorthThetaCorrelation (Double_t arg) {fNorthThetaCorrelation=arg;}
  /// set the correlation coefficient between northing and phi
  void SetNorthPhiCorrelation (Double_t arg) {fNorthPhiCorrelation=arg;}
  /// set the correlation coefficient between northing and TCore
  void SetNorthTCoreCorrelation (Double_t arg) {fNorthTCoreCorrelation=arg;}
  /// set the correlation coefficient between easting and theta
  void SetEastThetaCorrelation (Double_t arg) {fEastThetaCorrelation=arg;}
  /// set the correlation coefficient between easting and phi
  void SetEastPhiCorrelation (Double_t arg) {fEastPhiCorrelation=arg;}
  /// set the correlation coefficient between easting and TCore
  void SetEastTCoreCorrelation (Double_t arg) {fEastTCoreCorrelation=arg;}
  /// set the correlation coefficient between theta and phi
  void SetThetaPhiCorrelation (Double_t arg) {fThetaPhiCorrelation=arg;}
  /// set the correlation coefficient between theta and TCore
  void SetThetaTCoreCorrelation (Double_t arg) {fThetaTCoreCorrelation=arg;}
  /// set the correlation coefficient between phi and TCore
  void SetPhiTCoreCorrelation (Double_t arg) {fPhiTCoreCorrelation=arg;}
  /// set chi2 of axis/core fit
  void SetAxisFitChi2 (Double_t arg) {fAxisFitChi2=arg;}
  /// set NdF of axis/core fit
  void SetAxisFitNdof (UInt_t arg) {fAxisFitNdF=arg;}

  /// set the rec level of the geometry reconstruction
  void SetGeomRecLevel(EFdGeomRecLevel arg) {fFdGeomRecLevel=arg;}

  /// set the number of pixels in the time fit
  void SetNTimeFitPixels(UInt_t arg) {fNTimeFitPixels=arg;}

  // -------- SD related variables ---------

  /// set number of stations used in hybrid fit
  void SetNHybridStations(UInt_t arg) { fNTank=arg;}
  /// set the hottest station of hybrid fit
  void SetHottestStation(UInt_t arg) { fHottestTank=arg;}
  /// set the distance of the hottest station to the axis in SP coords. [m]
  void SetStationAxisDistance(Double_t arg) { fAxisDist=arg;}
  /// set the FD/SD time residual after fit [ns]
  void SetSDFDTimeOffset(Double_t arg) { fSDFDdT=arg;}
  /// set the distance of the hottest station to the SDP [m]
  void SetStationSDPDistance(Double_t arg) { fSDPDist=arg;}

private:

  // SDP
  Double_t fSDPThetaError;
  Double_t fSDPPhiError;
  Double_t fRhoThetaPhi;
  Double_t fSDPChi2;
  UInt_t fSDPNdF;

  // axis fit
  Double_t fT0Error;
  Double_t fChi0Error;
  Double_t fRpError;
  Double_t fRhoChi0T0;
  Double_t fRhoChi0Rp;
  Double_t fRhoRpT0;
  Double_t fTimeFitChi2;
  Double_t fTimeFitFDChi2;
  Double_t fLinearTimeFitChi2;
  UInt_t fTimeFitNdF;

  // axis/core fit
  Double_t fNorthEastCorrelation;
  Double_t fNorthThetaCorrelation;
  Double_t fNorthPhiCorrelation;
  Double_t fNorthTCoreCorrelation;
  Double_t fEastThetaCorrelation;
  Double_t fEastPhiCorrelation;
  Double_t fEastTCoreCorrelation;
  Double_t fThetaPhiCorrelation;
  Double_t fThetaTCoreCorrelation;
  Double_t fPhiTCoreCorrelation;
  Double_t fAxisFitChi2;
  UInt_t fAxisFitNdF;

  EFdGeomRecLevel fFdGeomRecLevel;

  UInt_t fNTimeFitPixels;

  // SD related variables
  UInt_t fNTank;
  UInt_t fHottestTank;
  Double_t fAxisDist;
  Double_t fSDFDdT;
  Double_t fSDPDist;

  ClassDef(FdRecGeometry,4);
};

#endif
