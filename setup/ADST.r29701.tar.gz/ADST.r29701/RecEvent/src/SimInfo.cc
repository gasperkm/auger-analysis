// $Id: SimInfo.cc 20050 2011-12-24 03:07:37Z darko $
#include <SimInfo.h>

#include <iostream>

using namespace std;


ClassImp (SimInfo);


//=============================================================================
/*!
  \class   SimInfo
  \brief   Header information for simulated run
  
  \version 1.0
  \date    Sep 03 2004
  \author  I. C. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger

*/
//=============================================================================
