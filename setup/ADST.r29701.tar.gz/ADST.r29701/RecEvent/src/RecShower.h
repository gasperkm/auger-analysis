#ifndef __RecShower_H
#define __RecShower_H

#include <Shower.h>

//
//  Reconstructed shower data definition
//

class RecShower : public Shower {

public:
  RecShower();
  virtual ~RecShower() { }

  /// get uncertainty of northing of shower core [m]
  Double_t GetCoreNorthingError() const  { return fCoreNorthError; }
  /// get uncertainty easting of shower core [m]
  Double_t GetCoreEastingError() const { return fCoreEastError; }
  /// get correlation coefficient between northing and easting
  Double_t GetCoreNorthingEastingCorrelation() const { return fCoreNorthEastCorrelation; }
  /// get uncertainty of total energy [eV]
  Double_t GetEnergyError() const { return fEnergyError; }
  /// get uncertainty of zenith angle in core system [rad]
  Double_t GetZenithError() const { return fZenithError; }
  /// get uncertainty of cos(zenith angle) in core system
  Double_t GetCosZenithError() const;
  /// get uncertainty of azimuth angle in core system [rad]
  Double_t GetAzimuthError() const { return fAzimuthError; }
  /// get correlation between zenith and azimuth angle [rad]
  Double_t GetZenithAzimuthCorrelation() const { return fZenithAzimuthCorrelation; }
  /// get uncertainty of right ascension angle [rad]
  Double_t GetRightAscensionError() const { return fRightAscensionError; }
  /// get uncertainty of declination angle [rad]
  Double_t GetDeclinationError() const { return fDeclinationError; }
  /// get correlation coefficient between right ascension and declination
  Double_t GetRDCorrelation() const { return fRDCorrelation; }
  /// get uncertainty of galactic longitude [rad]
  Double_t GetGalacticLongitudeError() const { return fGalacticLongError; }
  /// get uncertainty galactic latitude [rad]
  Double_t GetGalacticLatitudeError() const { return fGalacticLatError; }
  /// get correlation coefficient between galactic latitude and longitude
  Double_t GetLongLatCorrelation() const { return fLongLatCorrelation; }

  /// set total energy uncertainty [eV]
  void SetEnergyError(const Double_t eE) { fEnergyError = eE; }
  /// set uncertainty of northing of shower core [m]
  void SetCoreNorthingError(const Double_t arg) { fCoreNorthError = arg; }
  /// set uncertainty easting of shower core [m]
  void SetCoreEastingError(const Double_t arg) { fCoreEastError = arg; }
  /// set correlation coefficient between northing and easting
  void SetCoreNorthingEastingCorrelation(const Double_t arg) { fCoreNorthEastCorrelation = arg; }
  /// set uncertainty of zenith angle in core system [rad]
  void SetZenithError(const Double_t arg) { fZenithError = arg; }
  /// set uncertainty of azimuth angle in core system [rad]
  void SetAzimuthError(const Double_t arg) { fAzimuthError = arg; }
  /// set correlation between zenith and azimuth angle [rad]
  void SetZenithAzimuthCorrelation(const Double_t arg) { fZenithAzimuthCorrelation = arg; }
  /// set uncertainty of right ascension angle [rad]
  void SetRightAscensionError(const Double_t arg) { fRightAscensionError = arg; }
  /// set uncertainty of declination angle [rad]
  void SetDeclinationError(const Double_t arg) { fDeclinationError = arg; }
  /// set correlation coefficient between right ascension and declination
  void SetRDCorrelation(const Double_t arg) { fRDCorrelation = arg; }
  /// set uncertainty of galactic longitude [rad]
  void SetGalLongError(const Double_t arg) { fGalacticLongError = arg; }
  /// set uncertainty galactic latitude [rad]
  void SetGalLatError(const Double_t arg) { fGalacticLatError = arg; }
  /// set correlation coefficient between galactic latitude and longitude
  void SetLongLatCorrelation(const Double_t arg) { fLongLatCorrelation = arg; }

private:
  Double_t fEnergyError;
  Double_t fCoreNorthError;
  Double_t fCoreEastError;
  Double_t fCoreNorthEastCorrelation;

  Double_t fZenithError;
  Double_t fAzimuthError;
  Double_t fZenithAzimuthCorrelation;
  Double_t fRightAscensionError;
  Double_t fDeclinationError;
  Double_t fRDCorrelation;
  Double_t fGalacticLongError;
  Double_t fGalacticLatError;
  Double_t fLongLatCorrelation;

  ClassDef(RecShower, 1);
};

#endif
