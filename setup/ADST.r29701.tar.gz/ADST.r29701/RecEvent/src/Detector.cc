// $Id: Detector.cc 23519 2013-04-27 10:48:37Z schulz-a $
#include <Detector.h>
#include <TelescopeGeometry.h>

#include <TBits.h>

#include <iostream>
#include <stdexcept>
#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <set>

using namespace std;


ClassImp(Detector);


//======================================================================
Detector::Detector() :
  fTemperature(0),
  fPressure(0),
  fTemperaturePressureGPSSeconds(0),
  fIsWS(false),
  fHasMieDatabase(false),
  fHasGDASDatabase(false),
  fHasQDB(false),
  fQDBHorizonalUniformity(-1),
  fQDBCloudCoverage(-1),
  fQDBMinCloudBaseHeight(-1),
  fQDBMinCloudBaseDepth(-1),
  fMeteo(0)
{ }


void
Detector::SetDenseStation(const unsigned int iStation,
                          const double x, const double y, const double z)
{
  if (fDenseStations.count(iStation))
    cerr << "Detector::SetDenseStation> overwriting dStation "
         << iStation << endl;

  fDenseStations[iStation] = TVector3(x, y, z);
}


/********************************************************************/
#ifdef AUGER_RADIO_ENABLED
void
Detector::SetRdStation(const unsigned int iStation,
                       const double x, const double y, const double z)
{
  if (fAntennasPos.count(iStation))
    cerr << "Detector::SetRdStation> overwritting RStation "
         << iStation << endl;

  fAntennasPos[iStation] = TVector3(x, y, z);
}


/*********************************************************************/
TVector3&
Detector::GetRdStationPosition(const unsigned int i)
{
  const DenseStPosMap::iterator it = fAntennasPos.find(i);
  if (it != fAntennasPos.end())
    return it->second;
  else {
    cout << "ERROR Detector::GetRdStationPosition(int i) "
            "nonexisting RStation " << i << endl;
    static TVector3 empty(0,0,0);
    return empty;
  }
}


/*******************************************************************/
const TVector3&
Detector::GetRdStationPosition(const unsigned int i)
  const
{
  const DenseStPosMap::const_iterator it = fAntennasPos.find(i);
  if (it != fAntennasPos.end())
    return it->second;
  else {
    cout << "ERROR Detector::GetRdStationPosition(int i) "
            "nonexisting RStation " << i << endl;
    static const TVector3 empty(0,0,0);
    return empty;
  }
}
#endif


/*****************************************************************/
TVector3&
Detector::GetStationPosition(const unsigned int i)
{
  const DenseStPosMap::iterator it = fDenseStations.find(i);
  if (it != fDenseStations.end())
    return it->second;
  else {
    cout << "ERROR Detector::GetStationPosition(int i) "
            "nonexisting dense station " << i << endl;
    static TVector3 empty(0,0,0);
    return empty;
  }
}


/*****************************************************************/
const TVector3&
Detector::GetStationPosition(const unsigned int i)
  const
{
  const DenseStPosMap::const_iterator it = fDenseStations.find(i);
  if (it != fDenseStations.end())
    return it->second;
  else {
    cout << "ERROR DetectorGeometry::GetStationPosition(int i) "
            "nonexisting dense station " << i << endl;
    static const TVector3 empty(0,0,0);
    return empty;
  }
}


/*****************************************************************/
void
Detector::SetActiveStations(const TBits& stationBits)
{
  fActiveStations = stationBits;
}


/*****************************************************************/
void
Detector::SetActiveEyes(const TBits& eyeBits)
{
  fActiveEyes = eyeBits;
}


/*****************************************************************/
double
Detector::GetSDFDTimeOffset(const int iEye)
  const
{
  const map<int, double>::const_iterator it = fSDFDTimeOffset.find(iEye);
  if (it != fSDFDTimeOffset.end())
    return it->second;
  return -1;
}


/*****************************************************************/
void
Detector::SetFDSDTimeOffset(const int iEye, const double offset)
{
  fSDFDTimeOffset[iEye] = offset;
}


/*****************************************************************/
/* LIDAR                                                         */
/*****************************************************************/
bool
Detector::HasLidarData(const int iEye)
  const
{
  return fLidarInformation.find(iEye) != fLidarInformation.end();
}


/*****************************************************************/
bool
Detector::HasLidarData()
  const
{
  return !fLidarInformation.empty();
}


/*****************************************************************/
const FdLidarData&
Detector::GetLidarData(const int iEye)
  const
{
  const map<int, FdLidarData>::const_iterator it = fLidarInformation.find(iEye);
  if (it != fLidarInformation.end())
    return it->second;
  else {
    const string errMsg = "** No Lidar data found!\n" +
      string("please check your configuration file...");
    throw runtime_error(errMsg);
  }
}


/*****************************************************************/
void
Detector::SetLidarData(const int iEye, const FdLidarData& thisData)
{
  fLidarInformation[iEye] = thisData;
}


/*****************************************************************/
/* Cloud Camera                                                  */
/*****************************************************************/
bool
Detector::HasCloudCameraData(const int iEye)
  const
{
  return fCloudCameraInformation.find(iEye) != fCloudCameraInformation.end();
}


/*****************************************************************/
bool
Detector::HasCloudCameraData()
  const
{
  return !fCloudCameraInformation.empty();
}


/*****************************************************************/
const FdCloudCameraData&
Detector::GetCloudCameraData(const int iEye)
  const
{
  const map<int, FdCloudCameraData>::const_iterator it =
    fCloudCameraInformation.find(iEye);
  if (it != fCloudCameraInformation.end())
    return it->second;
  else {
    const string errMsg = "** No CloudCamera data found!\n" +
      string("please check your configuration file...");
    throw runtime_error(errMsg);
  }
}


/*****************************************************************/
void
Detector::SetCloudCameraData(const int iEye, const FdCloudCameraData& thisData)
{
  fCloudCameraInformation[iEye] = thisData;
}


/*****************************************************************/
/* AEROSOLS                                                      */
/*****************************************************************/
bool
Detector::HasAerosolData(const int iEye)
  const
{
  return fAerosols.find(iEye) != fAerosols.end();
}


/*****************************************************************/
bool
Detector::HasAerosolData()
  const
{
  return !fAerosols.empty();
}


/*****************************************************************/
const FdAerosols&
Detector::GetAerosolData(const int iEye)
  const
{
  const map<int, FdAerosols>::const_iterator it = fAerosols.find(iEye);
  if (it != fAerosols.end())
    return it->second;
  else {
    const string errMsg = "** No Aerosol data found!\n" +
      string("please check your configuration file...");
    throw runtime_error(errMsg);
  }
}


/*****************************************************************/
const map<int, FdAerosols>&
Detector::GetAerosolData()
  const
{
  if (fAerosols.empty()) {
    const string errMsg = "** No Aerosol data found!\n" +
      string("please check your configuration file...");
    throw runtime_error(errMsg);
  }
  return fAerosols;
}


/*****************************************************************/
void
Detector::SetAerosolData(const int iEye, const FdAerosols& aerosols)
{
  fAerosols[iEye] = aerosols;
}


/*****************************************************************/
/* Telescope Pointing                                            */
/*****************************************************************/
TString
Detector::GetPointingId(const int iEye, const int iTel)
  const
{
  // Empty string for old ADST files... => default pointing in TelescopeGeomemtry
  if (fTelPointingIds.empty())
    return TString("");

  map<int, EyePointingIdMap>::const_iterator eyeIt = fTelPointingIds.find(iEye);
  if (eyeIt == fTelPointingIds.end())
    return TString("");

  EyePointingIdMap::const_iterator telIt = eyeIt->second.find(iTel);
  if (telIt == eyeIt->second.end())
    return TString("");

  return telIt->second;
}


/*****************************************************************/
void
Detector::SetPointingId(const int iEye, const int iTel, const TString& pointingId)
{
  fTelPointingIds[iEye][iTel] = pointingId;

  /*map<int, EyePointingIdMap>::const_iterator eyeIt = fTelPointingIds.find(iEye);
  if (eyeIt == fTelPointingIds.end()) {
    fTelPointingIds[iEye] = map<int, TString>();
  }

  EyePointingIdMap& telescopes = fTelPointingIds[iEye];
  telescopes[iTel] = pointingId;*/
}


/*****************************************************************/
Detector::EyePointingIdMap
Detector::GetPointingIdsForEye(const int iEye)
  const
{
  if (fTelPointingIds.empty())
    return EyePointingIdMap();

  map<int, EyePointingIdMap>::const_iterator eyeIt = fTelPointingIds.find(iEye);
  if (eyeIt == fTelPointingIds.end())
    return EyePointingIdMap();

  return eyeIt->second;
}


/*****************************************************************/
/* VAODS (proxy to aerosols)                                     */
/*****************************************************************/
bool
Detector::HasVAOD(const int iEye )
  const
{
  return fVAODs.find(iEye) != fVAODs.end();
}


/*****************************************************************/
bool
Detector::HasVAODs()
  const
{
  return !fVAODs.empty();
}


/*****************************************************************/
double
Detector::GetVAODAtReferenceHeight(const int iEye)
  const
{
  const map<int, double>::const_iterator it = fVAODs.find(iEye);
  if (it != fVAODs.end())
    return it->second;
  else {
    const string errMsg = "** No VAODAtReferenceHeight data found for this eye!";
    throw runtime_error(errMsg);
  }
}


/*****************************************************************/
const map<int, double>&
Detector::GetVAODsAtReferenceHeight()
  const
{
  return fVAODs;
}


/*****************************************************************/
void
Detector::SetVAODAtReferenceHeight(const int iEye, const double vaod)
{
  fVAODs[iEye] = vaod;
}


/*****************************************************************/
void
Detector::SetCorrectorRingStatus(const int iEye, const TBits& statusBits)
{
  fCorrectorRingStatus[iEye] = statusBits;
}


/*****************************************************************/
bool
Detector::HasCorrectorRing(const int iEye, const int iTel)
  const
{
  if (iTel < 1)
    return false;

  const map<int, TBits>::const_iterator eyeIter = fCorrectorRingStatus.find(iEye);
  if (eyeIter != fCorrectorRingStatus.end())
    return eyeIter->second.TestBitNumber(iTel);
  else
    return false;
}


/*****************************************************************/
void
Detector::SetMirrorsInDAQ(const int iEye, const TBits& statusBits)
{
  fTelDAQBits[iEye] = statusBits;
}


/*****************************************************************/
bool
Detector::IsInDAQ(const int iEye, const int iTel)
  const
{
  if (iTel < 1)
    return false;

  const map<int, TBits>::const_iterator eyeIter = fTelDAQBits.find(iEye);
  if (eyeIter != fTelDAQBits.end())
    return eyeIter->second.TestBitNumber(iTel);
  else
    return false;
}


/*****************************************************************/
const TBits&
Detector::GetMirrorsInDAQ(const int eyeId)
  const
{
  const map<int, TBits>::const_iterator eyeIter = fTelDAQBits.find(eyeId);

  if (eyeIter == fTelDAQBits.end()) {
    ostringstream msg;
    msg << "Mirrors-in-DAQ list for non-existing eye with ID "
        << eyeId << " requested";
    throw runtime_error(msg.str());
  }

  return eyeIter->second;
}


/*****************************************************************/
void
Detector::AddMismatchedPixel(const int eyeId, const int telId, const int pixelId)
{
  const int index =
    TelescopeGeometry::fgNumberOfPixels*(eyeId*6 + telId) + pixelId;
  fMismatchedPixels.insert(index);
}


/*****************************************************************/
bool
Detector::IsMismatchedPixel(const int eyeId, const int telId, const int pixelId)
  const
{
  const int index =
    TelescopeGeometry::fgNumberOfPixels*(eyeId*6 + telId) + pixelId;
  return fMismatchedPixels.find(index) != fMismatchedPixels.end();
}


/*****************************************************************/
void
Detector::AddBadPixel(const int eyeId, const int telId, const int pixelId)
{
#warning FIXME: hardcoded number of telescopes
  const int index =
    TelescopeGeometry::fgNumberOfPixels*(eyeId*6 + telId) + pixelId;
  fBadPixels.insert(index);
}


/********************************************************************/
bool
Detector::IsBadPixel(const int eyeId, const int telId, const int pixelId)
  const
{
  const int index =
    TelescopeGeometry::fgNumberOfPixels*(eyeId*6 + telId) + pixelId;
  return fBadPixels.find(index) != fBadPixels.end();
}


/********************************************************************/
void
Detector::SetHasFdUpTime(const bool uptime)
{
  fHasFdUpTime = uptime;
}

bool
Detector::HasFdUpTime()
  const
{
  return fHasFdUpTime;
}


float
Detector::GetWeatherInformation(const MeteoSite site, const WeatherInfoType wtype)
  const
{
  return fMeteo[site].GetWeatherInformation(wtype);
}


