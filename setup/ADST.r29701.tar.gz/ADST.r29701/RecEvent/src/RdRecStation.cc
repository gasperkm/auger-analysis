
#ifdef AUGER_RADIO_ENABLED

#include <RdRecStation.h>

#include <iostream>
#include <vector>
#include <cmath>
#include <TMath.h>
#include <stdexcept>
#include <sstream>
using namespace std;

ClassImp(RdRecStation);


//=============================================================================
/*!
  \class   RdRecStation 
  \brief   Data of reconstructed Radio stations
  \brief   Based on the SD classes by (I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger)
  
  \version 2.5 
  \date    December 2013
  \author  Maximilien Melissas

*/
//=============================================================================


RdRecStation::RdRecStation() :
  fRTimeSecond(0),
  fRTimeNSecond(0),
  fTimePeakPosition_s(0),
  fTimePeakPosition_ns(0),
  fSignalWindowStart_s(0),
  fSignalWindowStop_s(0),
  fNoiseWindowStart_s(0),
  fNoiseWindowStop_s(0),
  fSignalWindowStart_ns(0),
  fSignalWindowStop_ns(0),
  fNoiseWindowStart_ns(0),
  fNoiseWindowStop_ns(0),
  fSNR(0.),
  fNoise(0.),
  fPulsefound(false)
{

}

RdRecStation::~RdRecStation(){
}

double RdRecStation::GetSignalArrivalAzimuth() const
{
  try {
    #warning FS: RdRecStation::GetSignalArrivalAzimuth() not yet implemented
    std::cerr << "Not yet implemented!" << endl;
    return 0;
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecStation::GetSignalArrivalZenith() const
{
  try {
    #warning FS: RdRecStation::GetSignalArrivalZenith() not yet implemented
    std::cerr << "Not yet implemented!" << endl;
    return 0;
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

void RdRecStation::SetRdTimeTrace(const vector<Float_t>& timeTrace, int polNb){ 
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) { 
    fTraces[polNb].SetTimeTrace(timeTrace);
    }
  return;
}

void RdRecStation::SetRdAbsSpectrum(const vector<Float_t>& freqTrace, int polNb){
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) {
    fTraces[polNb].SetAbsoluteFreqSpectrum(freqTrace);
    }
  }

void RdRecStation::SetRdTrace(const RdTrace& trac, int polNb) {
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) {

  fTraces[polNb]=trac;
        }                
}


const vector<Float_t>& RdRecStation::GetRdTimeTrace(int polNb) const throw(out_of_range) {
        map<int,RdTrace >::const_iterator miter= fTraces.find(polNb);
        if (miter!=fTraces.end()) {
//                vector<Float_t> vret=miter->second.GetTimeTrace();
//                return vret;
                return miter->second.GetTimeTrace();
                }
        // in case of error we return an vector of zero 
        // Need to find a better error management
        else {
          ostringstream errmsg; 
          errmsg.str("");
          errmsg << " RdRecStation::GetRdTimeTrace(" << polNb << ")\n";
          errmsg <<" Polarisation or Channel "<<polNb <<" not defined";
                throw (out_of_range(errmsg.str()));         
                }        
}

 
const vector<Float_t>& RdRecStation::GetRdAbsSpectrum(int polNb)  const 
        throw(out_of_range)
        {

        map<int,RdTrace >::const_iterator miter
                = fTraces.find(polNb);
        if (miter!=fTraces.end()) {
                return miter->second.GetAbsoluteFreqSpectrum();
                
                }
        // in case of error we return an vector of zero 
        // Need to find a better error management
        else {
          ostringstream errmsg;
          errmsg.str("");
          errmsg << " RdRecStation::GetRdAbsSpectrum( " << polNb<<" )\n";
          errmsg << " Polarisation or Channel ``" << polNb << "'' not defined" ;
                throw (out_of_range(errmsg.str()));         
                }        
}

const RdTrace& RdRecStation::GetRdTrace(int polNb) const
  throw (std::out_of_range)
 { 
  map<int,RdTrace>::const_iterator miter =fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    return miter->second;        
    }
  else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << "RdRecStation::GetRdTrace( "<< polNb << " )\n" ;
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    throw (out_of_range(errmsg.str()));         
    }        
  }

RdTrace& RdRecStation::GetRdTrace(int polNb) 
  throw (std::out_of_range)
 { 
  map<int,RdTrace>::iterator miter =fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    return miter->second;        
    }
  else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " RdRecStation::GetRdTrace( " << polNb << " ) \n";
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    throw (out_of_range(errmsg.str()));         
    }        
  }
void RdRecStation::SetEFieldTimeTrace(const vector<Float_t>& timeTrace, int polNb) {
  SetRdTimeTrace(timeTrace,polNb);
  }
void RdRecStation::SetEFieldnAbsSpectrum(const vector<Float_t>& freqTrace, int polNb) { 
  SetRdAbsSpectrum(freqTrace, polNb);
  }
void RdRecStation::SetRdChannelTrace(const vector<Float_t>& timeTrace,int chanNb) { 
  SetRdTimeTrace(timeTrace,chanNb+10);
  }
void RdRecStation::SetChannelAbsSpectrum(const vector<Float_t>& freqTrace,int chanNb) { 
  SetRdAbsSpectrum(freqTrace,chanNb+10);
  }

const vector<Float_t>& RdRecStation::GetEFieldTimeTrace(int polNb) const throw (out_of_range) { 
  return GetRdTimeTrace(polNb);
  } 
const vector <Float_t>& RdRecStation::GetEFieldnAbsSpectrum(int polNb) const throw (out_of_range) { 
  return GetRdAbsSpectrum(polNb);
  }
const vector<Float_t>& RdRecStation::GetRdChannelTrace(int chanNb) const throw (out_of_range) { 
  return GetRdTimeTrace(chanNb+10);
  }

const vector<Float_t>& RdRecStation::GetChannelAbsSpectrum(int chanNb) const throw(out_of_range) { 
  return GetRdAbsSpectrum( chanNb+10);
  }


  UInt_t RdRecStation::GetADCSignalThreshold(int polNb) const throw(out_of_range) { 
  map<int,UInt_t>::const_iterator miter =fADCSignalThreshold.find(polNb);
  if (miter!=fADCSignalThreshold.end()) {
    return miter->second;        
    }
  else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " RdRecStation::GetADCSignalThreshold( " << polNb << " ) \n";
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    if (polNb<10) 
      errmsg << "\n This variable is only available at the Channel Level ";
    throw (out_of_range(errmsg.str()));         
    }
  }

  UInt_t RdRecStation::GetADCNoiseThreshold(int polNb) const throw(out_of_range) { 
  map<int,UInt_t>::const_iterator miter =fADCNoiseThreshold.find(polNb);
  if (miter!=fADCNoiseThreshold.end()) {
    return miter->second;        
    }
  else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " RdRecStation::GetADCNoiseThreshold( " << polNb << " ) \n";
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    if (polNb<10) 
      errmsg << "\n This variable is only available at the Channel Level ";
    throw (out_of_range(errmsg.str()));         
    }
  }

  void RdRecStation::SetADCSignalThreshold(UInt_t thresh, int polNb) { 
    if (polNb<10 && polNb>14) { 
      cout << " Warning " << polNb << " does not correspond to a standard channel id !!";
      cout << " Low level information should be affected to a channel \n";
      cout << " I assume you know what you are doing, and I will affect the variable anyway"<< endl;
      }
    fADCSignalThreshold[polNb]=thresh;
    }


  void RdRecStation::SetADCNoiseThreshold(UInt_t thresh, int polNb) { 
    if (polNb<10 && polNb>14) { 
      cout << " Warning " << polNb << " does not correspond to a standard channel id !!";
      cout << " Low level information should be affected to a channel \n";
      cout << " I assume you know what you are doing, and I will affect the variable anyway"<< endl;
      }
    fADCSignalThreshold[polNb]=thresh;
    }

  void RdRecStation::SetChannelSaturated(int polNb, bool saturated) { 
    if (polNb<10 && polNb>14) { 
      cout << " Warning " << polNb << " does not correspond to a standard channel id !!";
      cout << " Low level information should be affected to a channel \n";
      cout << " I assume you know what you are doing, and I will affect the variable anyway"<< endl;
      }
    fIsChannelSaturated[polNb]=saturated;
    }
  bool RdRecStation::IsChannelSaturated(int polNb) const {
    map<int,bool>::const_iterator miter =fIsChannelSaturated.find(polNb);
    if (miter!=fIsChannelSaturated.end()) {
      return miter->second;        
      }
    else  
      return false;
    }
#endif
