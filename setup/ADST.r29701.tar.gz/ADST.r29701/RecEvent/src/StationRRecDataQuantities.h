// #ifdef AUGER_RADIO_ENABLED
/**
   \file
   StationRRecDataQuantities quantities to be stored in ParameterStorage objects of StationRecData
   \version $Id: StationRRecDataQuantities.h 22429 2012-12-12 20:59:43Z schroeder $
*/

#ifndef _revt_StationRRecDataQuantities_h_
#define _revt_StationRRecDataQuantities_h_

// static const char CvsId_revt_StationRRecDataQuantities[] = "$Id: StationRecData.h ";

/**
 * all quantities are in auger units
 * all times are with respect to the event time (REvent::GetHeader().GetTime(); )
 * if you add a quantity, please explain this quantity in a comment, and include in which module it is set
 */

namespace revt {
  
enum StationRRecDataQuantities {
  eSignal =  1,         // strength of the signal according to definition [RdStationSignalReconstructor]
  eSignalTime =  2,     // time at which the signal was found, relative to the event start time [RdStationSignalReconstructor]
  eNoise =  3,          // RMS of trace as determined in the noise window [RdStationSignalReconstructor]
  eSignalToNoise =  4,  // signal-to-noise ratio according to definition [RdStationSignalReconstructor]
  
  eNoiseWindowStart =  5,         // relative to trace start time! start and stop of the noise window. inside this window the rms is calculated, set by the RdEventInitializer
  eNoiseWindowStop =  6,          // relative to trace start time!
  eSignalWindowStart =  7,        // relative to trace start time! start and stop of the window in which the signal was determined, see configuration of RdStationSignalReconstructor
  eSignalWindowStop =  8,         // relative to trace start time!
  eSignalSearchWindowStart =  9,  // relative to trace start time! start and stop of the signal search window. inside this window the search for the signal (e.g. max. amplitude) is performed, set by the RdEventInitializer
  eSignalSearchWindowStop =  10,  // relative to trace start time!
  
  #warning TH: add comment for ePolarizationTheta and ePolarizationPhi
  ePolarizationTheta =  11,
  ePolarizationPhi =  12,
  
  ePeakAmplitudeNS =  13,     // maximum amplitude (inside signal window) of efield trace in NS-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeEW =  14,     // maximum amplitude (inside signal window) of efield trace in EW-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeV =  15,      // maximum amplitude (inside signal window) of efield trace in Vertical-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeMag =  16,    // maximum amplitude (inside signal window) of the quadratic sum of the three polarisations (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  
  ePeakTimeNS =  17,          // times at which the maximum amplitudes described above were found [RdStationSignalReconstructor]
  ePeakTimeEW =  18,          // All this 4 times are relative to the start of the event 
  ePeakTimeV =  19,
  ePeakTimeMag =  20,
  
  eNoiseRmsEW =  21,        // RMS (inside noise window) of EW-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsNS =  22,        // RMS (inside noise window) of NS-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsV =  23,         // RMS (inside noise window) of Vertical-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsMag =  24,       // RMS (inside noise window) of quadratic sum of all polarisations of Efield trace [RdStationSignalReconstructor]

  eNoiseMeanNS =  25,       // Mean (inside noise window) of NS-Polarisation of Efield trace [RdStationSignalReconstructor] 
  eNoiseMeanEW =  26,       // Mean (inside noise window) of EW-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseMeanV =  27,        // Mean (inside noise window) of Vertical-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseMeanMag =  28,      // Mean (inside noise window) of quadratic sum of all polarisations of Efield trace [RdStationSignalReconstructor]
  
  eMinSignal =  29,         // Minimum signal strength to set the pulsefound flag to true [RdStationSignalReconstructor.xml]
  eMinSignalToNoise =  30,  // Minimum signal to noise to set the pulsefound flag to true [RdStationSignalReconstructor.xml]
  
  #warning TH: add comments for FWHM quantities
  eSignalFWHMNS =  31,
  eSignalFWHMEW =  32,
  eSignalFWHMV =  33,
  eSignalFWHMMag =  34,
  
  #warning TH: add comments for integrated quantities
  eIntegratedSignalNS =  35,
  eIntegratedSignalEW =  36,
  eIntegratedSignalV =  37,
  eIntegratedSignalMag =  38,
  
  #warning TH: add comments for polarization quantities
  #warning DF: please document relative to what ePolarization*Time are defined
  ePolarizationThetaMaxTime =  39,
  ePolarizationPhiMaxTime =  40,
  ePolarizationThetaSameTime =  41,
  ePolarizationPhiSameTime =  42,
  
//obsolete = 43,              // this parameter slot is obsolete
  eTraceStartTime = 44,       // start time of the trace with respect to the event time, set by the RdEventInitializer
  eEFieldVectorNS = 45, // the weighted mean of all efield vectors within the FWHM interval (the weighting factor is the length of the vector). The length is set to "eSignal" [RdStationEfieldVectorCalculator]
  eEFieldVectorEW = 46, // [RdStationEfieldVectorCalculator]
  eEFieldVectorV = 47, // [RdStationEfieldVectorCalculator]
  eAngleToLorentzVector = 48, // angular difference between electric field vector and the Lorentz force vector resulting from the incoming direction of the shower and the magnetic field of the earth

  eTimeResidual = 49,  //Time residual of the station [RdWaveFit]

  // Stokes parameter of the pulse see [GAP-2011-088]
  // The reference coordinate for these parameters depends on the settings in the RdPolarizationReconstructor.
  eStokesI = 50, //Stokes parameter I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesQ = 51, //Stokes parameter Q [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesU = 52, //Stokes parameter U [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesV = 53, //Stokes parameter V [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioQdivI = 54, // Q/I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioUdivI = 55, // U/I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioVdivI = 56, // V/I [RdPolarizationReconstructor] [GAP-2011-088]
  ePolarizationAngle = 57, // Will contain the Polarization angle of the pulse (not filled yet)
  eObserverAngle = 58, // Contains the observer angle with respect to the shower core in the projected vxB frame
  eAlpha = 59, // Contains opening the angle of the shower's arrival direction with the earth magnetic field
  //Station rejection status
  eMaxAmplitudeOutsideSignalSearchWindow = 60, // Contains the maximum amplitude of the three electric field channels combined ( sqrt(x^2+y^2+z^2) ) outside the signal search window in order to be able to do a quality cut
  eStationRejected =61, /// Present if the station is rejected, [RdStationRejector]
  
  // The arrival direction of the signal in a station is stored as the direction of a (x,y,z) vector
  // in the local cooredinate system of the station
  // This vector is always perpendicular to the shower front at the position of the station.
  // There a two special cases:
  // for a plane wave approximation, this vector is parallel to the shower axis,
  // for a spherical wavefront approximation, it points towards the point source of the signal,
  eSignalArrivalDirectionX = 62, // x-component of vector for signal arrival direction (perpendicular to wavefront)
  eSignalArrivalDirectionY = 63, // y-component of vector for signal arrival direction (perpendicular to wavefront)
  eSignalArrivalDirectionZ = 64, // z-component of vector for signal arrival direction (perpendicular to wavefront)

};


}

#endif
// #endif

// Configure (x)emacs for this file ...
// Local Variables:
// mode: c++
// compile-command: "make -C .. -k"
// End:
