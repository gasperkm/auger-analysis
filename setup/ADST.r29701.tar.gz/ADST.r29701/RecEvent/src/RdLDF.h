#include <TObject.h>
#include <TF1.h>
#ifdef AUGER_RADIO_ENABLED
#ifndef RdLDF_H
#define RdLDF_H

enum ELDFrefCore { 
  eFit, 
  eSD,
  eFD,
  eMC
  };
class RdLDF : public TObject { 

  public: 
  RdLDF();
  ~RdLDF();
  TF1& GetFunction() {return fLDFfunc;}
  const TF1& GetFunction() const {return fLDFfunc;} 
  void  SetFunction(TF1& function) {fLDFfunc=function;}
  const ELDFrefCore& GetLDFRefCore() {return frefcore;}
  void SetLDFRefCore(ELDFrefCore coreref) {frefcore=coreref;}


  private:
  TF1 fLDFfunc;
  ELDFrefCore frefcore; 
  ClassDef(RdLDF,1);
  };
#endif 
#endif
