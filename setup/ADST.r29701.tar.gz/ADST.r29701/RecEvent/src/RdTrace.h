#ifndef __RdTrace_H
#define __RdTrace_H

#ifdef AUGER_RADIO_ENABLED

#include <TObject.h>
#include <vector>

class RdTrace : public TObject {

  public:
//Add Phase Spectrum. 
    RdTrace();
    ~RdTrace();
    const inline  std::vector<Float_t>& GetTimeTrace() const {return fTimeTrace;}
    inline void SetTimeTrace(const std::vector<Float_t>& tra ){fTimeTrace=tra;}
    const inline std::vector<Float_t>& GetAbsoluteFreqSpectrum() const {return fAbsoluteFreqSpectrum;}
    const inline std::vector<Float_t>& GetPhaseSpectrum() const {return fPhaseSpectrum;}
    inline void SetAbsoluteFreqSpectrum(const std::vector<Float_t>& sp) {fAbsoluteFreqSpectrum=sp;};
    inline void SetPhaseSpectrum(const std::vector<Float_t>& sp) {fPhaseSpectrum=sp;};
    inline void SetFreqRange(Float_t min=30,Float_t max=80) {fFreqMin=min; fFreqMax=max;}; // Here the Minimum and Maximum are the value of the Frequency of the First and Last bin, depending of the Nyquist zone min can be greater than max !!! 
    inline const Float_t& GetMinFreq() const  {return fFreqMin; }
    inline const Float_t& GetMaxFreq() const {return fFreqMax; }
    inline void SetSamplingRate(Float_t rate) {fSamplingRate=rate;}        
    inline const Float_t& GetSamplingRate() const {return fSamplingRate;}
    Float_t Bin2Freq(int bin) const; // Convert bin in MHz
    Float_t Bin2Time(int bin) const; // Convert bin in ns
    void operator=(RdTrace rtr2);

  private:
  
    Float_t fFreqMin,fFreqMax;
    Float_t fSamplingRate;
    std::vector<Float_t> fTimeTrace;
    std::vector<Float_t> fAbsoluteFreqSpectrum;
    std::vector<Float_t> fPhaseSpectrum;
  ClassDef (RdTrace,2);

};

#endif

#endif

