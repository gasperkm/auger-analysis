#ifndef _INCLUDE_GEN_SHOWER_H_
#define _INCLUDE_GEN_SHOWER_H_

#include <Shower.h>

#include <vector>
#include <map>


//  MC shower data definition

class GenShower : public Shower  {

public:
  GenShower();
  virtual ~GenShower() { }

  // getters

  Int_t GetPrimary() const { return fIDPrim; }  ///< 22=photon, 2212=proton, ... 1000026056=iron
  std::string GetPrimaryName() const;           ///< human readable name of primary
  std::string GetShortPrimaryName() const;      ///< human readable name of primary

  Double_t GetElecEnergy() const { return fE_em; }  ///< get electromagnetic energy [eV] (a.k.a. calorimetric energy)
  Double_t GetX1() const { return fX1; }            ///< get point of first interaction [g/cm^2]
  Double_t GetXmax() const { return fXmax; }        ///< get shower maximum [g/cm^2]
  Double_t GetdEdXmax() const { return fdEdXmax; }  ///< get energy depost at Xmax

  ///returns number of muons at ground level
  Double_t GetMuonNumber() const { return fNMuons; }

  ///returns muon weight scale
  Double_t GetMuonWeightScale() const { return fMuonWeightScale; }

  ///returns pointer to number of charged particles at shower track
  const std::vector<Double_t>& GetElectrons() const { return fElectrons; }

  ///returns pointer to energy deposit at shower track at shower track \f$[GeV]\f$
  const std::vector<Double_t>& GetEnergyDeposit() const { return fEnergyDeposit; }

  ///returns pointer to slant depth \f$[g/cm^2]\f$
  const std::vector<Double_t>& GetDepth() const { return fDepth; }

  ///returns vector of approximate shower ages \f$s = 3 / (1 + 2 X_{max}/X)\f$
  std::vector<Double_t> GetShowerAge() const;

  /// get the core GPS nanosecond (override of Shower method for backward compatibility with older productions)
  UInt_t GetCoreTimeNanoSecond() const;

  // setters

  /// set primary particle identifier
  void SetPrimary(const Int_t iPrim) { fIDPrim = iPrim; }

  /// set electromagnetic energy [eV] (a.k.a. calorimetric energy)
  void SetElecEnergy(const Double_t energy) { fE_em = energy; }
  void SetXmax(const Double_t xmax) { fXmax = xmax; }
  void SetX1(const Double_t x1) { fX1 = x1; }
  void SetdEdXmax(const Double_t xmax) { fdEdXmax = xmax; }

  /// Set slant depth \f$[g/cm^2]\f$
  void SetDepth(const std::vector<Double_t>& dep);

  /// Set number of charged particles  at shower track
  void SetElectrons(const std::vector<Double_t>& elec);

  /// Set number of charged particles  at shower track
  void SetEnergyDeposit(const std::vector<Double_t>& edep);

  /// Set number of muons at ground level
  void SetMuonNumber(const Double_t nmuons) { fNMuons = nmuons; }

  /// Set muon weight scale
  void SetMuonWeightScale(const Double_t scale) { fMuonWeightScale = scale; }

private:

  Int_t fIDPrim;        // 22: Photon, 2212: Proton, 1000026056: Iron

  Double_t fE_em;       // electromagnetic energy [eV]
  Double_t fX1;
  Double_t fXmax;
  Double_t fdEdXmax ;

  ///number of muons at ground level
  Double_t fNMuons;

  ///muon weight scale
  Double_t fMuonWeightScale;

  /// ------ the profile part ----------
  /// Number of entries in profile arrays (slant depth, photons at track, electrons at track)
  ///slant depth \f$[g/cm^2]\f$
  std::vector<Double_t> fDepth;

  ///number of charged particle at shower track
  std::vector<Double_t> fElectrons;

  ///energy deposit at shower track \f$[GeV]\f$
  std::vector<Double_t> fEnergyDeposit;

  // for backward compatibility... (ClassDef < 16)
  unsigned int fCoreTimeNSecond;

  ClassDef(GenShower, 20);
};

#endif
