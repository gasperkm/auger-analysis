// $Id: FdGenShower.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdGenShower.h>


ClassImp(FdGenShower);
