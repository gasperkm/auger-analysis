#ifndef __include_Selection_H
#define __include_Selection_H

#include <Cut.h>
#include <CutSpec.h>

#include <vector>
#include <string>
#include <map>

class RecEvent;
class DetectorGeometry;
class FDEvent;

class Selection {
public:
  Selection(const DetectorGeometry* const* geom,
            const RecEvent* const* event,
            int verbosity=1, bool nMinusOne = true,
            const std::string& cutFile="cuts.txt");

  Selection(const DetectorGeometry* const* geom,
            const RecEvent* const* event,
            int verbosity=1, bool nMinusOne = true,
            const std::vector<std::string>& cutFiles = std::vector<std::string>(1, "cuts.txt"));

  virtual ~Selection() { }

  // These are important for cut authors:
  static const RecEvent& CurrEvent() { return *fCurrEvent;}
  static const FDEvent& CurrFDEvent() { return *fCurrFD;}
  static const DetectorGeometry* GetDetectorGeometry() { return fCurrGeometry;}

  bool IsSelected(int eyeID=-1, double weight=1.);
  void AddCutFunction(CutSpec::CutFunctionPtr func) { fCutFunctions.push_back(func); }
  void WriteNMinusOne();
  void WriteCutStatistics(const std::string& histNamePrefix) const;
  const std::vector<Cut>& GetCuts() const { return fCuts;}
  void SetSelectionName(const std::string& name) {fSelectionName=name;}

  double GetNFDEvents() const {return fNFDEvents;}
  double GetNAugerEvents() const {return fNAugerEvents;}

  void PrintCutStatistics(bool latex=false) const;

  int GetCutWhichKilledEvent() const { return fCutWhichKilledEvent;}

  /// add an array of cuts to the cut registry
  static void AddToCutRegistry(const CutSpec* cuts);
  /// add a single cut to the cut registry
  static void AddToCutRegistry(const std::string& cutName, CutSpec::CutFunctionPtr cutFunctionPtr, int nParams);
  /// add a single cut to the cut registry without specifying the number of cut parameters
  static void AddToCutRegistry(const std::string& cutName, CutSpec::CutFunctionPtr cutFunctionPtr);
  /// get a ptr to the cutspec of given name. Returns NULL if that cut does not exist
  static CutSpec* GetCutFromRegistry(const std::string& cutName);

  /// Set the user config map
  static void SetUserConfiguration(const std::map<std::string, std::string>& config) {fgUserConfiguration = config;}
  /// Get the user config map
  static const std::map<std::string, std::string>& GetUserConfiguration() {return fgUserConfiguration;}

protected:
  void ReadCuts(const std::vector<std::string>& cutFiles);
  void ReadCuts(const std::string& cutFile);

  void InitializeCutFunctions();

private:
  Selection();

  double GetEfficiency(unsigned int iCut) const;
  virtual double GetNEvents() const = 0;

  const DetectorGeometry* const* fDetectorGeometry;
  const RecEvent* const* fEvent;
  int fVerbosity;
  bool fNMinusOne;

  // global map of cut names and function pointers (see CutSpec.h)
  static std::map<std::string, CutSpec> fgCutNameFunctionMap;

  static std::map<std::string, std::string> fgUserConfiguration;

  static const FDEvent* fCurrFD;
  static const RecEvent* fCurrEvent;
  static const DetectorGeometry* fCurrGeometry;
  std::vector<Cut> fCuts;
  //#ifndef __MAKECINT__
  std::vector<CutSpec::CutFunctionPtr> fCutFunctions;
  //#endif
  std::string fSelectionName;

  double fNAugerEvents;
  double fNFDEvents;

  int fCutWhichKilledEvent;

};
#endif
