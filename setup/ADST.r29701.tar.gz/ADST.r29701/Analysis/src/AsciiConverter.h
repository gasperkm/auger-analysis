#ifndef __AsciiConverter_h
#define __AsciiConverter_h

#include <iosfwd>
#include <string>
#include <vector>

class RecEvent;
class TBits;

namespace ADST {
  namespace AC {
    class ACColumn;
  }

  class AsciiConverter {
  public:
    AsciiConverter();
    AsciiConverter(const std::string& outfile);
    AsciiConverter(std::ostream& outstream);
    virtual ~AsciiConverter();

    virtual void WriteFileHeader() = 0;
    virtual void Convert(const RecEvent& event) = 0;

    void WriteColumnTextDescription(std::ostream& target); //< Writes the textual description of the columns
    void WriteColumnLaTeXDescription(std::ostream& target); //< Writes the LaTeX description of the columns

    static std::vector<ADST::AC::ACColumn*>& GetColumnTemplates() { return fgColumnTypes; }
    static unsigned int TBitsToInt(const TBits& bits); //< Convert a ROOT TBits to an int with each decimal being 0/1

    void SetOwnershipOfStream(bool doOwn) { fDoOwnOutStream = doOwn; }
  protected:
    void WriteColumnHeader();

    std::ostream& GetOutputStream();
    std::vector<ADST::AC::ACColumn*>& GetColumns() { return fColumns; }
    const std::vector<ADST::AC::ACColumn*>& GetColumns() const { return fColumns; }
    const std::string& GetColumnSeparator() const { return fColumnSeparator; }

    virtual std::string GetOutputDescription() = 0;

  private:
    unsigned int GetMaxColumnDescriptionWidth();
    unsigned int GetMaxColumnNameWidth();
    unsigned int GetMaxColumnUnitWidth();
    unsigned int GetMaxColumnNumberWidth();

    bool fDoOwnOutStream; //< set if we have to clean up the ptr to the output stream
    std::ostream* fOut; //< a pointer to an output stream for the ASCII
    std::vector<ADST::AC::ACColumn*> fColumns; //< vector of columns for the conversion. Pointers to global objects
    std::string fColumnSeparator;

    static std::vector<ADST::AC::ACColumn*> fgColumnTypes;
  };
} // end namespace ADST

#endif
