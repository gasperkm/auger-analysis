#ifndef __ACGlobalColumn_h
#define __ACGlobalColumn_h

#include <string>
#include <iosfwd>
#include <ACColumn.h>

namespace ADST {
  namespace AC {
    class ACGlobalColumn : public ACColumn {
    public:
      ACGlobalColumn();
      ACGlobalColumn(const std::string& name, const std::string& unit,
                     const std::string& descr, const unsigned int width);
      virtual ~ACGlobalColumn();

      virtual void Convert(std::ostream& outs, const RecEvent& event) const = 0;

    private:
    };
  } // end namespace ADST::AC
} // end namespace ADST

#endif
