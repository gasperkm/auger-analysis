#include <RecEvent.h>
#include <RecEventFile.h>
#include <DetectorGeometry.h>
#include <FileInfo.h>
#include <EventInfo.h>
#include <Analysis.h>
#include <SDSelection.h>
#include <FDSelection.h>
#include <AnalysisConsts.h>
#include <UtilityFunctions.h>

#include <TFile.h>
#include <TH1F.h>
#include <TProfile.h>
#include <TTimeStamp.h>


#include <cmath>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>

using namespace std;

bool gSelectBothDataSets     = true;
bool gSaveMissingEvents      = false;
bool gSaveIntersectingEvents = false;
bool gMicroADST              = false;
string gAnalysisConfig       = "analysis.config";

struct sdOutlier{
  int  nStations;
  double s1000;
  double energy;
  double coreDist;
  double theta;
  bool trigger;
  double curvature;
} gSDOutliers;

bool gSaveOutliers           = false;



/*========================================================

   print some usage hints

==========================================================*/
void usage(const char* exe) {

  cout <<  "\n  Usage:   " << exe << " reco1.root reco2.root\n"
       <<  "           " << exe << " \"reco1*.root\" \"reco2*.root\" \n "
       << endl;
  cout <<  "  Options: -m: read files in microADST mode \n"
       <<  "           -s: save missing events as ADST \n"
       <<  "           -b: apply selection to both files \n"
       <<  "           -i: save intersection of events as ADST \n"
       <<  "           -o: save outliers as ADST \n"
       <<  "           -c: config file for event selection (default: analysis.config) \n"
       << endl;
}

/*========================================================

   reads command line options

==========================================================*/
int getOptions(int argc, char** argv){

  int c;
  while ((c = getopt (argc, argv, "c:bshmio::")) != -1) {
    switch (c) {
    case 'c':
      gAnalysisConfig = string(optarg);
      break;
    case 'b':
      gSelectBothDataSets=true;
      break;
    case 's':
      gSaveMissingEvents=true;
      break;
    case 'i':
      gSaveIntersectingEvents=true;
      break;
    case 'm':
      gMicroADST=true;
      break;
    case 'o':
      gSaveOutliers=true;
      break;
    case 'h':
      return -1;
    default:
      return -1;
    }
  }
  if ( gMicroADST && gSaveMissingEvents )
    cout << " option -s set --> "
         << " ignoring microADST for first file! " << endl;
  if ( gMicroADST && gSaveIntersectingEvents )
    cout << " option -i set --> "
         << " ignoring microADST for first file! " << endl;

  if ( gMicroADST && gSaveOutliers )
    cout << " option -o set --> "
         << " ignoring microADST for both files! " << endl;

  //init outliers values
  gSDOutliers.nStations= 10000;
  gSDOutliers.s1000= 1e6;
  gSDOutliers.energy= 1e6;
  gSDOutliers.coreDist= 1e6;
  gSDOutliers.theta= 1e9;
  gSDOutliers.trigger= false;
  gSDOutliers.curvature= 1e6;

  return optind;
}





void ReadOutliersFile(){

  ifstream in;
  in.open(gAnalysisConfig.c_str());
  if ( ! in.good() ) {
    string errMsg = " Analysis::Analysis() - Error reading config file "
      + gAnalysisConfig;
    cout << errMsg << endl;
    throw std::runtime_error(errMsg);
  }
                        // if path use for config file
  const string path = ((gAnalysisConfig.rfind('/')==string::npos) ?
		       // use local path (pwd)
		       "./" :
		       // else use global path
		       gAnalysisConfig.substr(0, gAnalysisConfig.rfind('/')+1));

  string buffer;
  string fileName;
  while (!in.eof()) {
    getline(in, buffer);
    if ( !buffer.empty() && buffer[0] != '#' ) {
      stringstream line(buffer);
      string descriptor;
      line >> descriptor;
      if ( descriptor != "\n" && descriptor != "" ) {
	if ( descriptor == "SDOutliersFile" )
	  line >> fileName;
	if (!in.good())
          break;
      }
    }
  }
  in.close();

  ifstream in2;
  in2.open( (path+fileName).c_str() );

  while (!in2.eof()) {
    getline(in2, buffer);
    if ( !buffer.empty() && buffer[0] != '#' ) {
      stringstream line(buffer);
      string descriptor;
      line >> descriptor;
      double value;
      if ( descriptor == "stations" ) {
	line >> value;
	gSDOutliers.nStations= int( value );
      }
      else
	if ( descriptor == "s1000" ) {
	  line >> value;
	  gSDOutliers.s1000= value;
	}else
	  if ( descriptor == "energy" ) {
	    line >> value;
	    gSDOutliers.energy= value;
	  }else
	    if ( descriptor == "core" ) {
	      line >> value;
	      gSDOutliers.coreDist= value;
	    }
	    else
	      if ( descriptor == "zenith" ) {
		line >> value;
		gSDOutliers.theta= value;
	      }
	      else
		if ( descriptor == "trigger" ) {
		  gSDOutliers.trigger = true;
		}
		else
		  if ( descriptor == "curvature" ) {
		    line >> value;
		    gSDOutliers.curvature = value;
		  }

      if (!in2.good()) break;
    }
  }

}


/*========================================================

  creates and fills SD histos

==========================================================*/
bool FillSDHistos(const SDEvent& event1,const SDEvent& event2, TFile* tFile) {

  static bool first = true;
  bool outlier=false;
  if ( first ) {
    first = false;
    tFile->cd();
    new TH1F("dESD","2*(E1-E2)/(E1+E2)",101,-2.,2.);
    new TProfile("dESDvsE","2*(E1-E2)/(E1+E2) vs lg((E1+E2)/2)",30,17.,20.);
    new TH1F("dS1000","2*(S1-S2)/(S1+S2)",101,-2.,2.);
    new TH1F("dS1000Pull","(S1-S2)/sqrt(s1Err^2+s2Err^2)",101,-20.,20.);
    new TProfile("dS1000_S1000","2*(S1-S2)/(S1+S2)",15,log10(3.), log10(160.));
    new TH1F("dTheta_SD","(#theta1-#theta2)",101,-10.,10.);
    new TH1F("dEta","angular resolution",101,-0.01, 20.);
    new TH1F("dStations","(st1-st2)",21,-10.5,10.5);
    new TH1F("dCore","(r1-r2)", 1000, 0, 1000);
    new TH1F("dCurvature","(curvature1- curvature1)", 101, -10, 10);
    new TH1F("dLDFStatus","(ldfstatus1- ldfstatus2)", 11, -2, 2);
    new TH1F("curvaturePull","(curvature1- curvature1)/ Errors", 101, -10, 10);
    new TH1F("dAngularChi2", "Chi21- Chi22 (angular)", 101, -10, 10);
    new TH1F("dLDFChi2", "Chi21- Chi22  (ldf)", 101, -10, 10);

    new TProfile("dS1000vsCos2Theta","2*(S1-S2)/(S1+S2) vs cos2((#theta1+#theta2)/2) ",30,2.5,1.);
    new TProfile("dS1000vsBeta","2*(S1-S2)/(S1+S2) vs (#beta1+#beta2)/2 ",30,-4,0.);
  }
  const SdRecShower& theSDEvent1= event1.GetSdRecShower();
  const SdRecShower& theSDEvent2= event2.GetSdRecShower();

  const double E1=theSDEvent1.GetEnergy();
  const double E2=theSDEvent2.GetEnergy();
  const double Emean=0.5*(E1+E2);

  const double S1=theSDEvent1.GetS1000();
  const double S2=theSDEvent2.GetS1000();

  const double theta1=theSDEvent1.GetZenith()*180./TMath::Pi();
  const double theta2=theSDEvent2.GetZenith()*180./TMath::Pi();
  const double thetamean=0.5*(theta1+theta2);

  const double coreDiff= (theSDEvent1.GetCoreSiteCS()-
			  theSDEvent2.GetCoreSiteCS()).Mag();

  const double beta1=theSDEvent1.GetBeta();
  const double beta2=theSDEvent2.GetBeta();
  const double betamean=0.5*(beta1+beta2);

  const int st1=event1.GetNumberOfCandidates();
  const int st2=event2.GetNumberOfCandidates();

  const TVector3& axis1= theSDEvent1.GetAxisSiteCS();
  const TVector3& axis2= theSDEvent2.GetAxisSiteCS();
  const double angle= axis1.Angle(axis2)*180./TMath::Pi();

  const double Rc1= theSDEvent1.GetRadiusOfCurvature()/ 1000.;
  const double Rc2= theSDEvent2.GetRadiusOfCurvature()/ 1000.;
  if ( Rc1- Rc2 )
    if ( 2.*(Rc1- Rc2)/ (Rc1+ Rc2) > gSDOutliers.curvature){
      outlier= true;
    }

  if ( Rc1 && Rc1 ){
    ((TH1F*) tFile->Get("dCurvature"))->Fill((Rc1-Rc2));
    if ( theSDEvent1.GetCurvatureError() &&
	 theSDEvent1.GetCurvatureError()){
      const double Rc1Err= theSDEvent1.GetRadiusOfCurvatureError()/ 1000.;
      const double Rc2Err= theSDEvent2.GetRadiusOfCurvatureError()/ 1000.;
      const double rcPull= (Rc1-Rc2)/ sqrt( Rc1Err*Rc1Err+  Rc2Err*Rc2Err);
      ((TH1F*) tFile->Get("curvaturePull"))->Fill(rcPull);
    }

  }

  ((TH1F*) tFile->Get("dLDFStatus"))->Fill(theSDEvent1.GetLDFStatus() - theSDEvent2.GetLDFStatus() );
  ((TH1F*) tFile->Get("dAngularChi2"))->Fill(theSDEvent1.GetAngleChi2() - theSDEvent2.GetAngleChi2() );
  ((TH1F*) tFile->Get("dLDFChi2"))->Fill(theSDEvent1.GetLDFChi2() - theSDEvent2.GetLDFChi2() );


  if (abs(st1-st2) > gSDOutliers.nStations )
    outlier= true;


  if (S1+S2>0) {
    const double relDiffS1000= 2.*(S1-S2)/(S1+S2);
    if(abs(relDiffS1000) > gSDOutliers.s1000)
      outlier= true;

    ((TH1F*) tFile->Get("dS1000"))->Fill(relDiffS1000);
    const double uncertainty= sqrt(theSDEvent1.GetS1000Error()
				   *theSDEvent1.GetS1000Error()+
				   theSDEvent2.GetS1000Error()
				   *theSDEvent2.GetS1000Error());
    if (uncertainty)
      ((TH1F*) tFile->Get("dS1000Pull"))->Fill(relDiffS1000/uncertainty);
    ((TProfile*) tFile->Get("dS1000vsCos2Theta"))->Fill(pow(cos(thetamean*TMath::Pi()/180.), 2),
						    relDiffS1000);
    ((TProfile*) tFile->Get("dS1000vsBeta"))->Fill(betamean,
						   relDiffS1000);
    ((TProfile*) tFile->Get("dS1000_S1000"))->Fill(log10((S1+S2)/2.),
						   relDiffS1000);

  }
  if (theta1+theta2>0) {
    const double thetaDiff= (theta1-theta2);
    if(abs(thetaDiff)>gSDOutliers.theta)
      outlier = true;
    ((TH1F*) tFile->Get("dTheta_SD"))->Fill(thetaDiff);
    ((TH1F*) tFile->Get("dEta"))->Fill(angle);

  }
  if (coreDiff>0) {
    if(coreDiff>gSDOutliers.coreDist)
      outlier= true;
    ((TH1F*) tFile->Get("dCore"))->Fill(coreDiff);
  }


  if (Emean>0) {
    const double relDiffEnergy= (E1-E2)/Emean;

    if(abs(relDiffEnergy) > gSDOutliers.energy)
      outlier= true;

    ((TH1F*) tFile->Get("dESD"))->Fill(relDiffEnergy);
    ((TProfile*) tFile->Get("dESDvsE"))->Fill(log10(Emean), relDiffEnergy);
  }
  ((TH1F*) tFile->Get("dStations"))->Fill(st1-st2);
  if(gSDOutliers.trigger && (event1.GetT5Trigger() !=event2.GetT5Trigger()))
     outlier= true;

  return outlier;
}

/*========================================================

  creates and fills Detector related histos

==========================================================*/
bool FillDetector(const unsigned int nEyes,
                  const Detector& detector1,
		  const Detector& detector2,
		  const double moonCycle,
		  TFile* tFile) {

  static bool first = true;
  if ( first ) {
    first = false;
    tFile->cd();
    const int nMoon = 100;
    const double firstMoon = 0.;
    const double lastMoon = 100.;
    for ( unsigned int i=0; i< nEyes; i++ ) {
      ostringstream title;
      title << "dVAODvsT_" << i+1;
      new TProfile(title.str().c_str(),title.str().c_str(),nMoon,firstMoon,lastMoon);
    }
  }


  for ( unsigned int i=0; i< nEyes; i++ ) {

    const unsigned int thisEye = i+1;

    if ( detector1.HasVAOD(thisEye) && detector2.HasVAOD(thisEye) ) {
      const double vaod1 = detector1.GetVAODAtReferenceHeight(thisEye);
      const double vaod2 = detector2.GetVAODAtReferenceHeight(thisEye);

      ostringstream title;
      title << "dVAODvsT_" << thisEye;
      ((TProfile*) tFile->Get(title.str().c_str()))->Fill(moonCycle,vaod1-vaod2);
    }
  }
  return true;
}



/*========================================================

  creates and fills FD histos

==========================================================*/
bool FillFDHistos(const FDEvent& event1,const FDEvent& event2,
		  TFile* tFile) {

  const int nMoon = 100;
  const double firstMoon = 0.;
  const double lastMoon = 100.;

  static bool first = true;

  if ( first ) {

    first = false;

    const int nEnergyBins=14;
    const double energyBins[nEnergyBins+1]={16.5,16.75,17.,17.25,17.5,17.7,
                                            17.9,18.1,18.3,18.5,18.75,19.,
                                            19.3,19.5,20.};

    tFile->cd();
    new TH1F(    "dNdE","dNdE",nEnergyBins,energyBins);
    new TH1F(    "dEFD","2*(E1-E2)/(E1+E2)",101,-2.,2.);
    new TProfile("dEFDvsRcore","2*(E1-E2)/(E1+E2) vs r_core",25,0.,50.);
    new TProfile("dEFDvsT","2*(E1-E2)/(E1+E2) vs moon cycle",nMoon,firstMoon,lastMoon);
    new TProfile("dEFDvsMonth","2*(E1-E2)/(E1+E2) vs month",12,0.49,12.49);
    new TProfile("dEFDvsE","2*(E1-E2)/(E1+E2) vs lg((E1+E2)/2)",nEnergyBins,energyBins);
    new TProfile("dEFDvsXmaxVert","2*(E1-E2)/(E1+E2) vs xMaxVert",25,300.,900.);
    new TProfile("dEFDvsCfrac","2*(E1-E2)/(E1+E2) vs C-frac",15,0.,100.);
    new TProfile("dEFDvsScattCfrac","2*(E1-E2)/(E1+E2) vs scatt C-frac",50,0.,100.);
    new TProfile("dEFDvsCosTheta","2*(E1-E2)/(E1+E2) vs cos(theta)",20,0.,1.);
    new TProfile("dEFDvsZeta","2*(E1-E2)/(E1+E2) vs #zeta",20,0.,4.);
    new TH1F("dZeta","(#zeta1-#zeta2)/deg",101,-3.,3.);
    new TProfile("dZetavsE","(#zeta1-#zeta2) vs lg((E1+E2)/2)",nEnergyBins,energyBins);
    new TH1F(    "dXmax","Xmax1-Xmax2",101,-100.,100.);
    new TH1F(    "dXmaxErr","XmaxErr1-XmaxErr2",101,-20.,20.);
    new TProfile("dXmaxvsRcore","(Xmax1-Xmax2) vs r_core",25,0.,50.);
    new TProfile("dXmaxvsT","(Xmax1-Xmax2) vs moon cycle",nMoon,firstMoon,lastMoon);
    new TProfile("dXmaxvsMonth","(Xmax1-Xmax2) vs month",12,0.49,12.49);
    new TProfile("dXmaxvsE","(Xmax1-Xmax2) vs lg((E1+E2)/2)",nEnergyBins,energyBins);
    new TProfile("dXmaxvsCfrac","(Xmax1-Xmax2) vs C-frac",15,0.,100.);
    new TProfile("dXmaxvsScattCfrac","(Xmax1-Xmax2) vs scatt C-frac",50,0.,100.);
    new TProfile("dXmaxvsCosTheta","(Xmax1-Xmax2) vs cos(theta)",15,0.,1.);
    new TProfile("dXmaxvsPixRMS","(Xmax1-Xmax2) vs RMS(pix)",25,0.,50.);
    new TProfile("averageProf1","average prof1",80,-1000.,1000.);
    new TProfile("averageProf2","average prof2",80,-1000.,1000.);
    new TProfile("dcosZvsE","(cosZ1/cosZ2) vs lg((E1+E2)/2)",nEnergyBins,energyBins);
    new TH1F(    "dGHChi2","GHChi21-GHChi22",101,-100.,100.);
    new TProfile("dGHChi2vsT","(GHChi21-GHChi22) vs moon cycle",nMoon,firstMoon,lastMoon);
    new TProfile("dGHChi2vsE","(GHChi21-GHChi22) vs lg((E1+E2)/2)",nEnergyBins,energyBins);
    new TH1F(    "dAngle","space angle",50,0.,10.);
    new TH1F(    "dChi0","chi0_1-chi0_2",101,-10.,10.);
    new TH1F(    "dT0","t0_1-t0_2",101,-1000.,1000.);
    new TProfile("dAngleVsE","space angle vs energy",nEnergyBins,energyBins);
    new TProfile("dChi0VsE","chi0_1-chi0_2 vs energy",nEnergyBins,energyBins);
    new TProfile("dT0VsE","t0_1-t0_2 vs energy",nEnergyBins,energyBins);
    new TH1F(    "dFOVMin","",501,-1000.,1000.);
    new TH1F(    "dFOVMax","",501,-1000.,1000.);
    new TH1F(    "mieAttRatio","(mieAttAtXmax1/mieAttAtXmax2)",101,0.,10.);
    new TProfile("mieAttRatiovsT","(mieAttAtXmax1/mieAttAtXmax2) vs time",nMoon,firstMoon,lastMoon);
    new TH1F(    "dMieAtt","(mieAttAtXmax1-mieAttAtXmax2)",201,-1.,1.);
    new TProfile("dMieAttvsT","(mieAttAtXmax1-mieAttAtXmax2) vs time",nMoon,firstMoon,lastMoon);
  }

  const FdRecApertureLight& apLight1 = event1.GetFdRecApertureLight();
  const FdRecApertureLight& apLight2 = event2.GetFdRecApertureLight();

  const double moonCycle  = event1.GetMoonCycle();
  const int    kGPS_UTC_Offset =  315957587;
  const TTimeStamp fdTime(event1.GetGPSSecond(),
			  event1.GetGPSNanoSecond());
  const int yymmdd= fdTime.GetDate(kTRUE,kGPS_UTC_Offset);
  const int month =(yymmdd%10000)/100;
  const double E1         = event1.GetFdRecShower().GetEnergy();
  const double E2         = event2.GetFdRecShower().GetEnergy();
  const double Emean      = 0.5*(E1+E2);
  const double lgEmean    = log10(Emean);
  const double dEdXmax1   = event1.GetFdRecShower().GetdEdXmax();
  const double dEdXmax2   = event2.GetFdRecShower().GetdEdXmax();
  const double Xmax1      = event1.GetFdRecShower().GetXmax();
  const double Xmax2      = event2.GetFdRecShower().GetXmax();
  const double XmaxErr1   = event1.GetFdRecShower().GetXmaxError();
  const double XmaxErr2   = event2.GetFdRecShower().GetXmaxError();
  const double chi21      = event1.GetFdRecShower().GetGHChi2();
  const double chi22      = event2.GetFdRecShower().GetGHChi2();
  const double cFrac      = event1.GetFdRecShower().GetCherenkovFraction();
  const double coreDist   = event1.GetFdRecGeometry().GetCoreEyeDistance()/1000.;
  const double scattCFrac = 100.*(apLight1.GetLightFraction(FdApertureLight::eMie) +
				  apLight1.GetLightFraction(FdApertureLight::eRayleigh));
  const double zeta1      = apLight1.GetZeta();
  const double zeta2      = apLight2.GetZeta();

  const TVector3& axis1  = event1.GetFdRecShower().GetAxisCoreCS();
  const TVector3& axis2  = event2.GetFdRecShower().GetAxisCoreCS();
  const double cosZ1      = axis1.Z();
  const double cosZ2      = axis2.Z();
  const double chi0_1     = event1.GetFdRecGeometry().GetChi0();
  const double chi0_2     = event2.GetFdRecGeometry().GetChi0();
  const double t0_1       = event1.GetFdRecGeometry().GetT0();
  const double t0_2       = event2.GetFdRecGeometry().GetT0();
  const double fovMin1    = event1.GetFdRecShower().GetXFOVMin();
  const double fovMin2    = event2.GetFdRecShower().GetXFOVMin();
  const double fovMax1    = event1.GetFdRecShower().GetXFOVMax();
  const double fovMax2    = event2.GetFdRecShower().GetXFOVMax();
  const double pixRMS     = event1.GetFdRecPixel().GetMeanPixelRMS();
  const double mieAtt1    = event1.GetFdRecShower().GetMieAttXmax();
  const double mieAtt2    = event2.GetFdRecShower().GetMieAttXmax();

  const bool printEventIDs = false;

  if ( printEventIDs ) {
    if ( fabs(E1-E2)/Emean > 0.5 || fabs(Xmax1-Xmax2) > 100 ) {
      if ( fabs(E1-E2)/Emean > 0.5 )
        cout << "large energy difference! dE/E=" << (E1-E2)/Emean;
      if ( fabs(Xmax1-Xmax2) > 50 )
        cout << "large Xmax difference! dXmax=" << Xmax1-Xmax2;

      cout << " eye/run/event " << event1.GetEyeId() << "/"
           << event1.GetRunId() << "/" << event1.GetEventId() << " E1="
           << E1 << " E2=" << E2 << " Xmax1="
           << Xmax1 << " " << " Xmax2=" << Xmax2  << endl;
    }
  }

  ((TH1F*) tFile->Get("dNdE"))->Fill(log10(Emean));
  ((TH1F*) tFile->Get("dEFD"))->Fill((E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsXmaxVert"))->Fill(Xmax1*cosZ1,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsRcore"))->Fill(coreDist,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsT"))->Fill(moonCycle,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsMonth"))->Fill(month,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsE"))->Fill(lgEmean,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsCfrac"))->Fill(cFrac,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsScattCfrac"))->Fill(scattCFrac,(E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsCosTheta"))->Fill((cosZ1+cosZ2)/2.,
						   (E1-E2)/Emean);
  ((TProfile*) tFile->Get("dEFDvsZeta"))->Fill(zeta1/degree,(E1-E2)/Emean);
  if (zeta1 != 0 && zeta2 != 0) {
    ((TProfile*) tFile->Get("dZetavsE"))->Fill(lgEmean, (zeta1-zeta2)/degree);
    ((TH1D*) tFile->Get("dZeta"))->Fill((zeta1-zeta2)/degree);
  }

  ((TH1F*) tFile->Get("dXmax"))->Fill(Xmax1-Xmax2);
  ((TH1F*) tFile->Get("dXmaxErr"))->Fill(XmaxErr1-XmaxErr2);
  ((TH1F*) tFile->Get("dFOVMin"))->Fill(fovMin1-fovMin2);
  ((TH1F*) tFile->Get("dFOVMax"))->Fill(fovMax1-fovMax2);
  ((TProfile*) tFile->Get("dXmaxvsRcore"))->Fill(coreDist,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsT"))->Fill(moonCycle,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsMonth"))->Fill(month,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsE"))->Fill(lgEmean,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsCfrac"))->Fill(cFrac,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsScattCfrac"))->Fill(scattCFrac,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsCosTheta"))->Fill((cosZ1+cosZ2)/2.,Xmax1-Xmax2);
  ((TProfile*) tFile->Get("dXmaxvsPixRMS"))->Fill(pixRMS,Xmax1-Xmax2);

  ((TH1F*) tFile->Get("dGHChi2"))->Fill(chi21-chi22);
  ((TProfile*) tFile->Get("dGHChi2vsT"))->Fill(moonCycle,chi21-chi22);
  ((TProfile*) tFile->Get("dGHChi2vsE"))->Fill(lgEmean,chi21-chi22);

  ((TProfile*) tFile->Get("dcosZvsE"))->Fill(lgEmean,cosZ1/cosZ2);
  ((TH1F*) tFile->Get("dAngle"))->Fill(axis1.Angle(axis2)*kradDeg);
  ((TH1F*) tFile->Get("dT0"))->Fill(t0_1-t0_2);
  ((TH1F*) tFile->Get("dChi0"))->Fill((chi0_1-chi0_2)*kradDeg);
  ((TProfile*) tFile->Get("dAngleVsE"))->Fill(lgEmean,axis1.Angle(axis2)*kradDeg);
  ((TProfile*) tFile->Get("dT0VsE"))->Fill(lgEmean,t0_1-t0_2);
  ((TProfile*) tFile->Get("dChi0VsE"))->Fill(lgEmean,(chi0_1-chi0_2)*kradDeg);

  ((TH1F*) tFile->Get("mieAttRatio"))->Fill(mieAtt1/mieAtt2);
  ((TProfile*) tFile->Get("mieAttRatiovsT"))->Fill(moonCycle,mieAtt1/mieAtt2);
  ((TH1F*) tFile->Get("dMieAtt"))->Fill(mieAtt1-mieAtt2);
  ((TProfile*) tFile->Get("dMieAttvsT"))->Fill(moonCycle,mieAtt1-mieAtt2);


  const unsigned int thisEye = event1.GetEyeId();
  ostringstream title;
  title << "dEFDvsT_eye" << thisEye;
  TProfile * eyeEnergyDiff = (TProfile*) tFile->Get(title.str().c_str());
  if ( eyeEnergyDiff == NULL ) {
    tFile->cd();
    eyeEnergyDiff = new TProfile(title.str().c_str(),title.str().c_str(),nMoon,firstMoon,lastMoon);
  }
  eyeEnergyDiff->Fill(moonCycle,(E1-E2)/Emean);


  if ( !gMicroADST ) {
    const std::vector<Double_t>& depth1 = event1.GetFdRecShower().GetDepth();
    const std::vector<Double_t>& depth2 = event2.GetFdRecShower().GetDepth();
    const std::vector<Double_t>& dEdX1 = event1.GetFdRecShower().GetEnergyDeposit();
    const std::vector<Double_t>& dEdX2 = event2.GetFdRecShower().GetEnergyDeposit();
    const std::vector<Double_t>& dEdX1err = event1.GetFdRecShower().GetEnergyDepositError();
    const std::vector<Double_t>& dEdX2err = event2.GetFdRecShower().GetEnergyDepositError();

    TProfile* prof1 = ((TProfile*) tFile->Get("averageProf1"));
    TProfile* prof2 = ((TProfile*) tFile->Get("averageProf2"));

    for ( unsigned int i=0;i<depth1.size();i++) {
      const double x   = depth1[i]-Xmax1;
      const double y   = dEdX1[i]/dEdXmax1;
      const double err = dEdX1err[i]/dEdXmax1;
      prof1->Fill(x,y,1./err/err);
    }


    for ( unsigned int i=0;i<depth2.size();i++) {
      const double x   = depth2[i]-Xmax2;
      const double y   = dEdX2[i]/dEdXmax2;
      const double err = dEdX2err[i]/dEdXmax2;
      prof2->Fill(x,y,1./err/err);
    }
  }

  return false;

}

/*========================================================

   analysis function
   called for each matching event

==========================================================*/
vector<bool> AnalyzeEvent(Analysis* analysis[2],
			  RecEvent* recEvents[2],
			  TFile* tFile) {

  bool analyzed = false;
  bool outlier = false;
  if ( analysis[0]->HasSDSelection() ) {
    if ( analysis[0]->IsGoodSD() &&
	 ( analysis[1]==NULL ||
	   analysis[1]->IsGoodSD()) ) {
      outlier= FillSDHistos(recEvents[0]->GetSDEvent(),
			    recEvents[1]->GetSDEvent(), tFile);
      analyzed = true;
    }
  }

  if ( analysis[0]->HasFDSelection() ) {

    const std::vector<FDEvent>& fdEvents1 = recEvents[0]->GetFDEvents();
    double moonCycle = -1;

    for ( vector<FDEvent>::const_iterator iEye1 = fdEvents1.begin();
	  iEye1 != fdEvents1.end();
	  ++iEye1) {

      moonCycle = iEye1->GetMoonCycle();

      if ( analysis[0]->IsGoodEye(iEye1->GetEyeId())) {
	if ( recEvents[1]->HasEye(iEye1->GetEyeId())  &&
	     (analysis[1]==NULL ||
	      analysis[1]->IsGoodEye(iEye1->GetEyeId())) ) {
	  const FDEvent& eye1=(*iEye1);
	  const FDEvent& eye2=recEvents[1]->GetEye(iEye1->GetEyeId());
	  outlier = FillFDHistos(eye1,eye2,tFile);
	  analyzed = true;
	}
      }
    }

    if ( moonCycle >= 0. )
      FillDetector( (*(analysis[0]->GetDetectorGeometry()))->GetNEyes(),
                   recEvents[0]->GetDetector(),
		   recEvents[1]->GetDetector(),
		   moonCycle, tFile);

  }


  vector<bool> mypair;
  mypair.push_back(analyzed);
  mypair.push_back(outlier);
  return mypair;

}



/*========================================================

   compareADSTs main()

==========================================================*/
int main(int argc, char** argv) {


  int nOptions = getOptions(argc,argv);

  if ( nOptions < 0 || argc-nOptions != 2 ) {
    usage(argv[0]);
    return 1;
  }

  TFile* outFile = new TFile("compareEvents.root","RECREATE");

  EventInfo eventInfo;
  RecEventFile* dataFile[2];
  RecEvent* recEvent[2];
  DetectorGeometry* theGeometry[2];
  Analysis* analysis[2]={NULL,NULL};

  for ( unsigned int i=0;i<2;i++) {
    dataFile[i]    = new RecEventFile(argv[nOptions+i]);
    cout << " opening file " << argv[nOptions+i];
    if ( gMicroADST && !(gSaveMissingEvents&&i==0) )
      cout << " in MicroADST mode";
    cout << " (Nev=" << dataFile[i]->GetNEvents()
	 << ")" << endl;

    recEvent[i]    = new RecEvent();
    if ( gSelectBothDataSets || i == 0 ) {
      theGeometry[i] = new DetectorGeometry();
      ostringstream anaName;
      anaName << "file" << i;
      analysis[i]    = new Analysis(&theGeometry[i],&recEvent[i], gAnalysisConfig, false, anaName.str());
      analysis[i]->InitSDCuts();
      analysis[i]->InitFDCuts();
      dataFile[i]->ReadDetectorGeometry(*(theGeometry[i]));
    }
    bool setmicro=  gMicroADST && !(gSaveMissingEvents && i==0);
    if (setmicro && !gSaveOutliers)
      dataFile[i]->SetMicroADST();
    dataFile[i]->SetBuffers(&(recEvent[i]));
  }

  RecEventFile* missingEventFile = NULL;
  if ( gSaveMissingEvents )  {
   missingEventFile = new RecEventFile("missingEvents.root",
				       RecEventFile::eWrite);
   missingEventFile->SetBuffers(&recEvent[0]);
  }
  RecEventFile* intersectionFile = NULL;
  if ( gSaveIntersectingEvents ) {
    intersectionFile = new RecEventFile("intersectingEvents.root",
				        RecEventFile::eWrite);
    intersectionFile->SetBuffers(&recEvent[0]);
  }

  RecEvent* outlierEvent=NULL;
  RecEventFile* outliersFile = NULL;
  if(gSaveOutliers){
    ReadOutliersFile();
    outlierEvent = new RecEvent();
    outliersFile = new RecEventFile("outliers.root",
				    RecEventFile::eWrite);
    outliersFile->SetBuffers(&outlierEvent);
  }

  cout << " building search map... " << flush;
  dataFile[1]->SearchForSDEvent(0);
  cout << " done " << endl;

  int nMatch=0;
  int nAna=0;

  unsigned int nEv0=dataFile[0]->GetNEvents();

  cout << " reading events... " << endl;
  for ( unsigned int i=0;i<nEv0;i++) {
    dataFile[0]->GetEventInfo(i,&eventInfo);
    UInt_t sdEventId = eventInfo.GetSDId();
    if ( dataFile[1]->SearchForSDEvent(sdEventId)==RecEventFile::eSuccess  ) {

      nMatch++;

      dataFile[0]->ReadEvent(i);
      vector<bool> analysisResult = AnalyzeEvent(analysis,recEvent,outFile);
      if( analysisResult[0]) {
	if (gSaveIntersectingEvents)
	  intersectionFile->WriteEvent();
      	nAna++;
      }

      if(gSaveOutliers && analysisResult[1]){
	outlierEvent= recEvent[0];
	outliersFile->WriteEvent();
	outlierEvent= recEvent[1];
	outliersFile->WriteEvent();
      }
    }
    else if ( gSaveMissingEvents ) {
      dataFile[0]->ReadEvent(i);
      missingEventFile->WriteEvent();
    }


    if ( i%100 == 0 )
      UtilityFunctions::ShowProgress(i,nEv0);
  }

  UtilityFunctions::ShowProgress(nEv0,nEv0);

  cout << "\n\n " << nMatch << " matching event"
       << (nMatch>1?"s":"")
       << " out of " << dataFile[0]->GetNEvents()
       << endl;
  cout << " " << nAna << " Auger event"
       << (nAna>1?"s":"") << " analyzed" << endl;


  outFile->cd();

  for ( unsigned int i=0; i<2; i++ )
    if ( analysis[i] )
      analysis[i]->WriteCutStatistics();

  if ( analysis[0] && analysis[1] ) {
    if ( analysis[0]->HasSDSelection() && analysis[1]->HasSDSelection() )
      cout << " SD selected events: N(file1)= " << analysis[0]->GetSDSelection().GetCuts().back().GetNEvents()
           << " N(file2)=" << analysis[1]->GetSDSelection().GetCuts().back().GetNEvents() << endl;
    if ( analysis[0]->HasFDSelection() && analysis[1]->HasFDSelection() )
      cout << " FD selected eyes: N(file1)= " << analysis[0]->GetFDSelection().GetCuts().back().GetNEvents()
           << " N(file2)=" << analysis[1]->GetFDSelection().GetCuts().back().GetNEvents() << endl;

  }

  outFile->Write();
  outFile->Close();

  if ( gSaveMissingEvents ) {
    FileInfo theInfo;
    dataFile[0]->ReadFileInfo(theInfo);
    missingEventFile->WriteDetectorGeometry (*theGeometry[0]);
    missingEventFile->WriteFileInfo(theInfo);
    cout << " " << missingEventFile->GetNEvents()
	 << " missing events written to missingEvents.root" << endl;
    missingEventFile->Close();
  }

  if ( gSaveIntersectingEvents ) {
    FileInfo theInfo;
    dataFile[0]->ReadFileInfo(theInfo);
    intersectionFile->WriteDetectorGeometry (*theGeometry[0]);
    intersectionFile->WriteFileInfo(theInfo);
    cout << " " << intersectionFile->GetNEvents()
	 << " intersecting events written to intersectingEvents.root" << endl;
    intersectionFile->Close();
  }


  if ( gSaveOutliers ) {
    FileInfo theInfo;
    dataFile[0]->ReadFileInfo(theInfo);
    outliersFile->WriteDetectorGeometry (*theGeometry[0]);
    outliersFile->WriteFileInfo(theInfo);
    cout << " " << outliersFile->GetNEvents()/2
	 << " outliers written to outliers.root defined as: \n"
	 << "     --__--__ stations         : " << gSDOutliers.nStations  <<" \n"
	 << "     --__--__ rel. S1000 diff. : "<<  gSDOutliers.s1000      <<" \n"
	 << "     --__--__ rel. energy diff.: "<<  gSDOutliers.energy     <<" \n"
	 << "     --__--__ core distance    : "<<  gSDOutliers.coreDist   << endl;

    outliersFile->Close();
  }

}
