#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"

#include "Analysis.h"
#include "Selection.h"
#include "FDSelection.h"
#include "Cut.h"

#include <TTree.h>

using namespace std;

// This is the definition of my user cut...
bool myFunnyCut(Cut& cut) {
  // this is to check that we can call Selection static methods from here!
  FDSelection::CurrFDEvent(); 
 
  // Do something...
  double result = 5.;
  cut.SetCurrValue(result);

  double cutParam = cut.GetCutParameters()[0];

  if ( cut.IsAntiCut() )
    return(result > cutParam);
  else
    return(result <= cutParam);
}

int main(int argc, char **argv) {
  TTree::SetMaxTreeSize(200000000000ll);

  // THIS MUST HAPPEN BEFORE THE ANALYSIS OBJECT IS CREATED
  // OTHERWISE, THE CUT WON'T BE RECOGNIZED AT THAT TIME.
  // Here, we register our custom cut with the Analysis:
  Selection::AddToCutRegistry("myFunnyCut", myFunnyCut);

  if ( argc < 2 ) {
    cout << " usage: selectWithExtraCuts <fileNames> " << endl;
    return 1;
  }

  RecEvent *         theRecEvent = new RecEvent();
  DetectorGeometry * theGeometry = new DetectorGeometry();

  RecEventFile dataFile(argv+1); 
  dataFile.SetBuffers(&theRecEvent);
  dataFile.ReadDetectorGeometry(*theGeometry);

  RecEventFile * selectedFile = new RecEventFile("selected.root",RecEventFile::eWrite); 
  selectedFile->SetBuffers(&theRecEvent);


  Analysis analysis(&theGeometry,&theRecEvent,"analysis.config");

  while (dataFile.ReadNextEvent()==RecEventFile::eSuccess ) {

    const int currentEventNumber =  dataFile.GetCurrentEvent();
    if ( currentEventNumber && currentEventNumber % 5000 == 0 ) 
      cout << dataFile.GetCurrentEventString() << endl;

    if (! analysis.IsGoodSD() || ! analysis.IsGoodSim() ) 
      continue;
    
    if (analysis.HasFDSelection()){
      for ( RecEvent::EyeIterator iEye = theRecEvent->EyesBegin();
	    iEye != theRecEvent->EyesEnd(); )
	if ( ! analysis.IsGoodEye(iEye->GetEyeId()) ) 
	  theRecEvent->GetFDEvents().erase(iEye);
	else 
	  ++iEye;
      if (theRecEvent->GetFDEvents().empty()) 
	continue; 
    }
    
    selectedFile->WriteEvent();
  
  }


  cout << "\n total events   : " << dataFile.GetNEvents() << endl;
  cout << " selected events  : " << selectedFile->GetNEvents() << endl;

  analysis.PrintCutStatistics(false);

  FileInfo theInfo;
  dataFile.ReadFileInfo(theInfo);
  selectedFile->WriteDetectorGeometry (*theGeometry);
  selectedFile->WriteFileInfo(theInfo);
  selectedFile->cd();
  analysis.WriteNMinusOne();
  analysis.WriteCutStatistics();
  selectedFile->Close();
}
