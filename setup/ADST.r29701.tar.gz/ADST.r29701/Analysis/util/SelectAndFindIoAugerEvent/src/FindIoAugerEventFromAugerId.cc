#include <iostream>
#include <fstream>
#include <string>
#include <set>

using namespace std;
#include "RecEventFile.h"
#include "RecEvent.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"
#include "Analysis.h"
#include "UtilityFunctions.h"

#include "IoAuger.h"
#include "AugerEvent.h"

#include "TDatime.h"

#include <TTree.h>

// forward delarations

using namespace std;

// global variables
AugerFile* fgAugerFile;
unsigned int fgAugerFileNumber;
unsigned int fgNoEventsPerFile;

/************************************************************/
void usage(){
  cout << "\n  FindIoAugerEventFromAugerId: utility program to \n"
       << "    find&extract IoAuger events given their Auger ID.\n\n"

       << "Usage: FindIoAugerEventFromAugerId <textFileWithRawDataFileNames> <noEventsPerOutputFile> <AugerID1> <AugerID2> ...\n"
       << endl;
}

/******************************************************************/
void nextOutputFile() {

  if (fgAugerFile != NULL)
    fgAugerFile->Close();

  if (fgAugerFileNumber == 0) {
    fgAugerFile = new AugerFile("SelectedEvents_IoAuger.root", AugerFile::eWrite);
  }
  else {
    char buffer[1024];
    sprintf(buffer, "SelectedEvents_IoAuger_%u.root", fgAugerFileNumber);
    fgAugerFile = new AugerFile(buffer, AugerFile::eWrite);
  }
  fgAugerFileNumber++;
}


/*********************************************************/
string parseAugerIdFromKeyName(string keyname) {
  string id;
  int indexhash = -1;
  for (unsigned int i = 0; i < keyname.size()-1; i++) {
    if (keyname[i] == '#') {
      indexhash = i;
      break;
    }
  }
  if (indexhash < 0) {
    cerr << "This should never happen! There is no hash '#' in the key name! The key is:\n" << keyname << endl;
    return id;
  }

  id = keyname.substr(0, indexhash);
  return id;
}

/*********************************************************/
int findRawEvents(string filelistfile, set<string>& selectSet) {
  ifstream fileList;
  fileList.open(filelistfile.c_str());
  if ( !fileList.is_open() ) {
    cerr << " RecFindIoAugerEventFromAugerId: - Error could not read IoAuger file list from file " 
         << filelistfile << "\n"
         << "             exit ..." << endl;
    exit(1);
  }

  cout << " Searching IoAuger events in the raw data files."
       << "\n This may take a while..." << endl;
  int nRaw = 0;
  UtilityFunctions::ShowProgress(0,selectSet.size());
  while (1) {
    if (fileList.good() ) {
      string thisFile;
      fileList >> thisFile;
      if (thisFile == "")
        break;

      TFile* rootfile = new TFile(thisFile.c_str(), "READ");
      if (rootfile == NULL) {
        cout << "Could not open root file " << thisFile << ". Skipping it." << endl;
        continue;
      }
      rootfile->cd();
      TIter nextkey(rootfile->GetListOfKeys());
      TKey *key;
      while ( (key = (TKey*)nextkey()) ) {
        string name(key->GetName());
        string augerId = parseAugerIdFromKeyName(name);
        bool exists = (selectSet.count(augerId) > 0);

        if (exists) {
          if (nRaw != 0 && nRaw % fgNoEventsPerFile == 0)
            nextOutputFile();

          nRaw++;

          AugerEvent *event = (AugerEvent*)key->ReadObj();
          event->EventId = strtoll(augerId.c_str(), NULL, 0);

          fgAugerFile->Write(*event, false); // bool is verbosity
          delete event;
	  if ( nRaw%100 == 0 )
	    UtilityFunctions::ShowProgress(nRaw,selectSet.size());
        }
      }
      if (key != NULL) delete key;
      rootfile->Close();
      if (rootfile != NULL) delete rootfile;

      if ( fileList.eof() )
        break;
    }
    else
      break;
  }

  UtilityFunctions::ShowProgress(nRaw,selectSet.size());
  cout << "\nWrote " << nRaw << " IoAuger events to output file." << endl;

  return nRaw;
}


/******************************************************************/
int main(int argc, char **argv) {
  TTree::SetMaxTreeSize(200000000000ll);
  fgAugerFileNumber = 0;

  if ( argc < 4 ) {
    usage();
    exit(1);
  }

  set<string> selectSet;

  string filelistFile(argv[1]);

  fgNoEventsPerFile= (unsigned int) atoi(argv[2]);

  int j=3;
  vector<string> augerIds;
  while ( argv[j] != NULL ) {
    selectSet.insert(string(argv[j]));
    j++;
  }

  if ( selectSet.empty() ) {
    usage();
    return 1;
  }

  cout << "\n\nSearching for " << selectSet.size() << " IoAuger events."<<endl;

  // open the first output file
  nextOutputFile();

  //int nRaw = findRawEvents(filelistFile, selectSet);
  findRawEvents(filelistFile, selectSet);
  
  fgAugerFile->Close();
}

  
