#ifndef _LongitudinalProfile_h_
#define _LongitudinalProfile_h_

#include <vector>

class FDEvent;
class GenShower;
class TGraphErrors;
class TF1;

class ProfilePoint {

public:
  ProfilePoint(const double x, const double y, const double yErr,
               const double depth) :
    fX(x), fY(y), fYErr(yErr), fDepth(depth) {}

  double fX;
  double fY;
  double fYErr;
  double fDepth;

};

inline bool operator<(const ProfilePoint& lhs,
                      const ProfilePoint& rhs)
{
  if ( lhs.fDepth  < rhs.fDepth )
    return true;
  else
    return false;
}


class LongitudinalProfile {

  //
  // utility class for longitudinal profiles
  //

public:

  enum EProfYaxis {
    edEdX,
    eNe,
    eLight
  };

  enum EProfXaxis {
    eDepth,
    eAge,
    eTime
  };

  enum EProfResidual {
    eNone,
    eFit,
    eMC
  };

public:
  LongitudinalProfile() {};

  void SetProfile(const FDEvent& fdEvent,
                  const GenShower& genShower,
                  const EProfXaxis xAxis,
                  const EProfYaxis yAxis,
                  const EProfResidual residual,
                  const TF1* fitFunction);

  // get profile graph (needs to be deleted by user!)
  TGraphErrors* GetGraph(const double deltaDepth) const;

private:

  std::vector<ProfilePoint> fProfile;

};

#endif
