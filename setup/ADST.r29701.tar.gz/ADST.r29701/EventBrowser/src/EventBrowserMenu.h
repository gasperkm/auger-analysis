#ifndef __INCLUDE_EventBrowserMenu_H__
#define __INCLUDE_EventBrowserMenu_H__

class TGWindow;
class TGCompositeFrame;
class TGMenuBar;
class TGLayoutHints;
class TGPopupMenu;


class  EventBrowserMenu {

public:
  EventBrowserMenu  (TGCompositeFrame *main);
  ~EventBrowserMenu();

  bool ToggleAnimation();
  bool ToggleSpeedAnimation();
  bool ToggleShowerPlaneArray();
  bool ToggleShowMC();
  bool ToggleShowMCTraces();
  bool ToggleShowBadStations();
  bool ToggleShowPMTSignals();
  bool ToggleShowLDFOnArray();
  bool ToggleAperture();
  bool ToggleShowAerosols();
  bool ToggleShowViewableFOV();
  bool ToggleShowTelsInDAQ();
  bool ToggleUseLCEfficiency();
  bool ToggleFDinSD();
  bool ToggleZeta();
  bool ToggleSDinFD();
  bool ToggleFDT3SDP();
  bool ToggleFDXmaxSDP();
  bool ToggleAllTracesinSD();

  void SetShowTelApertureLight();
  void SetShowEyeApertureLight();
  void SetShowEyeAndTelApertureLight();

  void EnableMC();


private:

  bool ToggleFDEntry(const int entryId);

  TGMenuBar *fMenuBar;

  TGLayoutHints *fMenuBarLayout;
  TGLayoutHints *fMenuBarItemLayout;
  TGLayoutHints *fMenuBarHelpLayout;

  TGPopupMenu *fMenuFile;
  TGPopupMenu *fMenuFDOptions;
  TGPopupMenu *fMenuApertureLightOptions;
  TGPopupMenu *fMenuSDOptions;
  TGPopupMenu *fMenuMCOptions;
#ifdef AUGER_RADIO_ENABLED
  TGPopupMenu *fMenuROptions;
#endif
  TGPopupMenu *fMenuHelp;
};



#endif
