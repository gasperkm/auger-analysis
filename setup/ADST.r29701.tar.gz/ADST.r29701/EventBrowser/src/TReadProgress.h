//
// File   : TReadProgress.h
//
// Purpose: Display a progress bar window when reading events
//
// Author : P.Facal, INFN Rome
//
// $Id: TReadProgress.h 18212 2010-12-21 14:16:51Z darko $
//

#ifndef _TReadProgress_h_
#define _TReadProgress_h_

#ifndef ROOT_TGFrame
#include "TGFrame.h"
#endif

#include "TGProgressBar.h"

class TGTextButton;
class TGVerticalFrame;
class TGLayoutHints;

class TReadProgress : public TGMainFrame {
 private:
  TGTextButton      *fStop;
  TGHProgressBar    *fBar;
  TGVerticalFrame   *fFrame;
  TGLayoutHints     *fLayF, *fLayB, *fLayS;
  int                fNEvents;
  Bool_t             fS;
 public:  
  TReadProgress(const TGWindow *p, UInt_t w, UInt_t h, 
		const char * windowName = NULL);
  virtual ~TReadProgress();

  virtual Bool_t ProcessMessage(Long_t msg, Long_t parm1, Long_t parm2);
  virtual void CloseWindow();
  
  void SetNEvents(int evs) { fBar->SetRange(0,evs);}
  Bool_t Event(int i) {  fBar->SetPosition(i); fBar->Layout(); return fS;}
};

#endif // _TReadProgress_h_




