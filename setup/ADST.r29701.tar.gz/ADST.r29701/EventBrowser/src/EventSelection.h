#ifndef _include_EventSelection_h__
#define _include_EventSelection_h__

#include <TQObject.h>
#include <vector>
#include "FdRecLevel.h"
#include "SdRecLevel.h"

#include <vector>
#include <set>

class TGCompositeFrame;
class TGNumberEntry;
class TGRadioButton;
class EventInfo;
class TGCompositeFrame;
class TGHButtonGroup;
class TGCheckButton;
class TGComboBox;
class TGTextButton;
class TCanvas;
class TObjArray;
class TH1F;

class EventSelection : public TQObject {

public:
  EventSelection (TGCompositeFrame *main);
  ~EventSelection();

  void HandleButtonSignals();
  void SelectEvents(const std::vector<EventInfo>& eventInfo,
		    TGComboBox* mainEventList);
  void FindEvent(UInt_t id, const std::vector<EventInfo>& eventInfo);
  void ResetSelection();
  void SetHQFDSelection();
  void SetHQSDSelection();
  void DoFileSelection();
  int GetEventNumber(Long_t what);
  bool ToggleSelectionEnable();
  void SetCurrentEvent(int iEvent);
  void SetEventInfoClassVersion(int iVersion)
  { fEventInfoClassVersion=iVersion; }
  const std::vector <int> & GetSelectedEventList() const
  { return fSelectedEvents; }

private:

  void FillFDHistos(const EventInfo &,const std::vector<int> &);

  void FillSDHistos(const EventInfo &);
  void FillMCHistos(const EventInfo &);
  void DrawHistos();
  void InitHistograms();
  void GetRangeFromHistograms();
  void ResetHistograms();
  int fEventInfoClassVersion;
#ifdef AUGER_RADIO_ENABLED
  void FillRDHistos(const EventInfo&);
#endif

  std::vector<int> fSelectedEvents;
  std::vector<int>::const_iterator fEventIterator;
  std::set<int> fFileSelectedEvents;

  TObjArray* fSelectionObjects;

  TGCompositeFrame* fMain;

  TCanvas* fCanvasEnergy;
  TCanvas* fCanvasZenith;
  TCanvas* fCanvasStations;
  TCanvas* fCanvasPixels;
  TCanvas* fCanvasEyes;
  TCanvas* fCanvasInfo;

  TGTextButton* fUpdateButton;
  TGTextButton* fResetButton;
  TGTextButton* fHQFDButton;
  TGTextButton* fHQSDButton;
  TGTextButton* fFileSelectionButton;
  TGTextButton* fFindGPSButton;
  TGTextButton* fFindSDButton;
  TGTextButton* fFindFDButton;
#ifdef AUGER_RADIO_ENABLED
  TGTextButton* fFindRDButton;
#endif

  TGCheckButton* fSelectionButton;
  TGCheckButton* fSelectionFromHistButton;
  TGNumberEntry* fEminTextField;
  TGNumberEntry* fEmaxTextField;
  TGNumberEntry* fZminTextField;
  TGNumberEntry* fZmaxTextField;

  TGNumberEntry* fXminTextField;
  TGNumberEntry* fXmaxTextField;
  TGCheckButton* fSDEnergySelectionButton;
  TGCheckButton* fFDEnergySelectionButton;
  TGCheckButton* fMCEnergySelectionButton;
#ifdef AUGER_RADIO_ENABLED
  TGCheckButton* fRDEnergySelectionButton;
#endif

  TGNumberEntry* fTankTextField;
  TGRadioButton* fSDTrigger3;
  TGRadioButton* fSDTrigger4;
  TGRadioButton* fSDTrigger5;
  TGCheckButton* fSDSaturation;
  TGNumberEntry* fSDAngChi2;
  TGNumberEntry* fSDLDFChi2;
#ifdef AUGER_RADIO_ENABLED
  TGNumberEntry* fRdStationTextField;
  TGNumberEntry* fRdRecLevelTextField;
  TGNumberEntry* fRdminAzimuthTextField;
  TGNumberEntry* fRdmaxAzimuthTextField;
#endif

  TGNumberEntry* fEyeTextField;
  TGNumberEntry* fPixelTextField;
  TGCheckButton* fHybridButton;
  TGCheckButton* fFOVButton;
  TGComboBox* fFDRecLevel;

  TGComboBox* fSDRecLevel;

  TGNumberEntry* fFindGPSTime;
  TGNumberEntry* fFindSDID;
  TGNumberEntry* fFindFDEye;
  TGNumberEntry* fFindFDRun;
  TGNumberEntry* fFindFDEvent;
#ifdef AUGER_RADIO_ENABLED
  TGNumberEntry* fFindRDRun;
  TGNumberEntry* fFindRDEvent;
#endif


  TH1F* fSDenergyHist;
  TH1F* fFDenergyHist;
  TH1F* fMCenergyHist;
  TH1F* fSDzenithHist;
  TH1F* fFDzenithHist;
  TH1F* fMCzenithHist;
  TH1F* fSDTankHist;
  TH1F* fFDPixelHist;
  TH1F* fFDEyeXmaxHist;
#ifdef AUGER_RADIO_ENABLED
  TH1F* fRDzenithHist;
#endif
  ClassDef (EventSelection, 2);
};



#endif
