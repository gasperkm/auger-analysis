#ifndef _include_VPlots_h__
#define _include_VPlots_h__

#include <string>

class VPlots {


public:

  VPlots():fPlotsUpTodate(false) {}
  virtual ~VPlots() {}
  virtual void Update() = 0;
  virtual void Clear() = 0;
  virtual void SetShowMC(bool) {}
  virtual std::string PrintPostScript() = 0;

  virtual bool IsFD() { return false; }
  virtual bool IsUpToDate() { return fPlotsUpTodate; }
  virtual void SetUpToDate(bool b) { fPlotsUpTodate = b; }

private:
  bool fPlotsUpTodate;
};

#endif
