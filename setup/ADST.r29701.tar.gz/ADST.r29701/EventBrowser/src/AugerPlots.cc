#include "AugerPlots.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserConfig.h"
#include "StyleManager.h"
#include "DetectorGeometry.h"
#include "RecEvent.h"
#include "ArrayPlot.h"
#include "Display3D.h"
#include "LongitudinalProfile.h"

#include <TGFrame.h>
#include <TGSlider.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGTab.h>
#include <TGraphErrors.h>
#include <TLegend.h>
#include <TLatex.h>
#include <TGaxis.h>
#include <TSpline.h>
#include <TH2F.h>
#include <TSystem.h>

#include <cmath>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <algorithm>
#include <iomanip>

using namespace std;
using namespace view::Consts;


ClassImp (AugerPlots);


AugerPlots::AugerPlots(TGCompositeFrame* main,
		       const StyleManager* const * styleManager,
		       const DetectorGeometry* const * geom,
		       const RecEvent* const * event,
		       const bool& isMC) :
  fStyleManager(styleManager),
  fEvent(event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fArrayPlot(0)
{
  const double width  = main->GetWidth();
  const double height = main->GetHeight();

  fEventInfoObjects = new TObjArray();
  fEventInfoObjects->SetOwner(kTRUE);
  fAnglePlotObjects = new TObjArray();
  fAnglePlotObjects->SetOwner(kTRUE);
  f2DPlotObjects = new TObjArray();
  f2DPlotObjects->SetOwner(kTRUE);
  fProfilePlotObjects = new TObjArray();
  fProfilePlotObjects->SetOwner(kTRUE);
  fShowerParameterObjects= new TObjArray();
  fShowerParameterObjects->SetOwner(kTRUE);

  TGLayoutHints* mainLayout =
    new TGLayoutHints (kLHintsTop|kLHintsLeft, 3, 3, 3, 3);
  TGLayoutHints* centeredLayout =
    new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3);
  TGLayoutHints* centeredLayoutExpandX =
    new TGLayoutHints(kLHintsCenterX|kLHintsCenterY|kLHintsExpandX,3,3,3,3);
  TGLayoutHints* bottomLayout =
    new TGLayoutHints(kLHintsBottom|kLHintsCenterY,3,3,3,3);
  TGLayoutHints* canvasLayout = centeredLayout;
  //    new TGLayoutHints(kLHintsExpandX|kLHintsExpandY,3,3,3,3);
  TGHorizontalFrame* mainHorizontalFrame =
    new TGHorizontalFrame(main, UInt_t(width), UInt_t(height));

  main->AddFrame(mainHorizontalFrame, mainLayout);

  TGVerticalFrame* mainVerticalFrame1 =
    new TGVerticalFrame(mainHorizontalFrame,
                        UInt_t(0.5*width), UInt_t(height));
  TGVerticalFrame* mainVerticalFrame2 =
    new TGVerticalFrame(mainHorizontalFrame, UInt_t(0.5*width), UInt_t(height));

  mainHorizontalFrame->AddFrame (mainVerticalFrame1, mainLayout);
  mainHorizontalFrame->AddFrame (mainVerticalFrame2, centeredLayout);



  // 2D/3D/Profile plots

  fArrayTab = new TGTab(mainVerticalFrame1,mainVerticalFrame1->GetWidth(),
                        mainVerticalFrame1->GetHeight());
  fArrayTab->Associate(this);

  fDisplay3DFrame = fArrayTab->AddTab("3D");
  TGCompositeFrame* twoDPlot = fArrayTab->AddTab("2D");
  TGCompositeFrame* profileTab = fArrayTab->AddTab("Profiles");


  // ----------------- 3D display ---------
  fDisplay3D = new Display3D(fDisplay3DFrame, styleManager, geom, event, fIsMC);



  // ------------------- profile plots

  TRootEmbeddedCanvas* emCanProf =
    new TRootEmbeddedCanvas("AugerProfile", profileTab,
                            UInt_t(0.6*width), UInt_t(0.6*width));
  profileTab->AddFrame(emCanProf, canvasLayout);
  fProfilePlot = emCanProf->GetCanvas();

  TGHButtonGroup* profileButtons= new TGHButtonGroup(profileTab,"rebin depth");
  fProfileRebinButton = new TGHSlider(profileButtons,
                                      100, kSlider2 | kScaleBoth,eSDZoomToCore);
  fProfileRebinButton->SetRange(0,100);

  profileTab->AddFrame(profileButtons,bottomLayout);
  profileButtons->AddFrame(fProfileRebinButton, bottomLayout);

  fProfileRebinButton->SetPosition(0); // start without zoom
  fProfileRebinButton->Connect("Released()",
                               "AugerPlots",
                               this, "DrawProfilePlot()");



  // ------------------- 2D array view

  TRootEmbeddedCanvas* emCan2D = new TRootEmbeddedCanvas("2DPlot", twoDPlot,
                                                         UInt_t(0.6*width), UInt_t(0.6*width));
  twoDPlot->AddFrame(emCan2D, canvasLayout);
  f2DPlot = emCan2D->GetCanvas();

  TGHButtonGroup* arrayButtons= new TGHButtonGroup(twoDPlot,"Core zoom");
  fArrayZoomButton=new TGHSlider(arrayButtons,
                                 100, kSlider2 | kScaleBoth,eSDZoomToCore);
  fArrayZoomButton->SetRange(0,1000);

  twoDPlot->AddFrame(arrayButtons, bottomLayout);
  arrayButtons->AddFrame(fArrayZoomButton, bottomLayout);

  fArrayPlot = new ArrayPlot(fEvent,
                             fDetectorGeometry,
                             fStyleManager,
                             fArrayZoomButton,
                             f2DPlot);
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  int startUpPosition = (int) ( (*fStyleManager)->GetStartUpZoom()*
                                ( fArrayZoomButton->GetMaxPosition() -
                                  fArrayZoomButton->GetMinPosition()));
  fArrayZoomButton->SetPosition(startUpPosition);  // start zoomed

  fArrayZoomButton->Connect("PositionChanged(Int_t)",
                            "ArrayPlot", fArrayPlot, "DoSdZoom(Int_t)");
  fArrayZoomButton->Connect("Released()", "ArrayPlot",
                            fArrayPlot, "Draw(bool,bool,bool)");

  f2DPlot->Modified();
  f2DPlot->Update();

  fArrayTab->SetTab(1);

  mainVerticalFrame1->AddFrame(fArrayTab,centeredLayout);

  // energy and angle plots
  TRootEmbeddedCanvas* embeddedCanvasInfo =
    new TRootEmbeddedCanvas("CanvasInfo", mainVerticalFrame2,
                            UInt_t(0.35*width), UInt_t(0.05*height));
  mainVerticalFrame2->AddFrame(embeddedCanvasInfo, centeredLayoutExpandX);
  fCanvasInfo = embeddedCanvasInfo->GetCanvas();
  fCanvasInfo->Modified();
  fCanvasInfo->Update();
  TRootEmbeddedCanvas* embeddedEnergyPlot =
    new TRootEmbeddedCanvas("EnergyPlot", mainVerticalFrame2,
                            UInt_t(0.35*width), UInt_t(0.4*height));
  mainVerticalFrame2->AddFrame(embeddedEnergyPlot, centeredLayoutExpandX);
  fEnergyPlot = embeddedEnergyPlot->GetCanvas();
  fEnergyPlot->Modified();
  fEnergyPlot->Update();

  //########### energy/Xmax buttons #######################
  TGHButtonGroup* energyOrXmaxButtons =
    new TGHButtonGroup (mainVerticalFrame2,"shower parameters");
  fEnergyOverviewButton =
    new TGRadioButton(energyOrXmaxButtons, new TGHotString("Energy  "));
  fXmaxOverviewButton   =
    new TGRadioButton(energyOrXmaxButtons, new TGHotString("Xmax  "));
  fEnergyOverviewButton->SetToolTipText("Energy");
  fXmaxOverviewButton->SetToolTipText("Xmax");
  fEnergyOverviewButton->Connect("Released()", "AugerPlots",
                                 this, "HandleShowerParameterButton()");
  fXmaxOverviewButton->Connect("Released()", "AugerPlots",
                               this, "HandleShowerParameterButton()");
  mainVerticalFrame2->AddFrame(energyOrXmaxButtons,
                               new TGLayoutHints(kLHintsTop|kLHintsLeft,
                                                 1, 1, 2, 2));
  fEnergyOverviewButton->SetState(kButtonDown);

  TRootEmbeddedCanvas* embeddedAnglePlot =
    new TRootEmbeddedCanvas("AnglePlot", mainVerticalFrame2,
                            UInt_t(0.35*width), UInt_t(0.45*height));
  mainVerticalFrame2->AddFrame(embeddedAnglePlot, centeredLayoutExpandX);
  fAnglePlot = embeddedAnglePlot->GetCanvas();
  fAnglePlot->Modified();
  fAnglePlot->Update();
  fAnglePlot->SetEditable(false);

  //########### arrival direction buttons #######################
  TGHButtonGroup* GalacticButtons =
    new TGHButtonGroup (mainVerticalFrame2,"galactic coordinates");
  fHammerAitoffButton =
    new TGRadioButton(GalacticButtons,
                      new TGHotString("Hammer-Aitoff "),
                      eHammerAitoff);
  fSansonFlamsteedButton =
    new TGRadioButton(GalacticButtons,
                      new TGHotString("Sanson-Flamsteed "),
                      eSansonFlamsteed);
  fParabolicButton=
    new TGRadioButton(GalacticButtons,
                      new TGHotString("Parabolic"),
                      eParabolic);
  fHammerAitoffButton->SetToolTipText("Hammer-Aitoff projection");
  fSansonFlamsteedButton->SetToolTipText("Sanson-Flamsteed projection");
  fParabolicButton->SetToolTipText("Parabolic projection");
  fHammerAitoffButton->Connect("Released()", "AugerPlots",
                               this, "HandleGalacticButton()");
  fSansonFlamsteedButton->Connect("Released()", "AugerPlots",
                                  this, "HandleGalacticButton()");
  fParabolicButton->Connect("Released()", "AugerPlots",
                            this, "HandleGalacticButton()");
  mainVerticalFrame2->AddFrame(GalacticButtons,
                               new TGLayoutHints(kLHintsTop|kLHintsLeft,1, 1, 2, 2));
  fHammerAitoffButton->SetState(kButtonDown);
  fProjectionType=3;
}

AugerPlots::~AugerPlots() {

}

void
AugerPlots::DrawEventInfo()
{
  if (!*fEvent)
    return;

  fEventInfoObjects->Delete();

  fCanvasInfo->cd();
  double avEnergy;
  double avEnergyError;
  double avEnergyChi2;
  int avEnergyNdf;
  (*fEvent)->CalculateAverage(RecEvent::eFDsAndSD, RecEvent::eEnergy,
			     avEnergy, avEnergyError,
			     avEnergyChi2, avEnergyNdf);
  ostringstream id;
  id << setiosflags(ios::fixed) << setprecision(1)
     << (*fEvent)->GetEventId();
// << " <E>= " ;
//   if (avEnergyNdf>0) {
//     double fac=1.;
//     if ( avEnergyNdf>0 && avEnergyChi2/avEnergyNdf > 1. )
//       fac = sqrt(avEnergyChi2/avEnergyNdf);
//     id << avEnergy/1.e18 <<  " #pm "<< avEnergyError/1.e18*fac << "EeV";
//   }
//   else if (avEnergyNdf>-1) {
//     id << avEnergy/1.e18 <<  " #pm "<< avEnergyError/1.e18 << "EeV";
//   }
//   else
//     id << "---";


  TLatex* legend=new TLatex();
  legend->SetNDC();
  legend->SetTextAlign(12);
  legend->SetTextSize(0.5);
  legend->DrawLatex(0.02,0.5,id.str().c_str());
  legend->Draw("");
  fEventInfoObjects->Add(legend);

  fCanvasInfo->Modified();
  fCanvasInfo->Update();

}

void
AugerPlots::DrawAnglePlot()
{
  //     x = glongitude; // units: radian
  //     y = glatitude;
  // - - Sanson-Flamsteed projection:
  //        xpoint = x * cos(y);
  //        ypoint = y;
  // - - Parabolic projection:
  //        xpoint = x * (2.*cos(y*2./3.)-1.);
  //        ypoint = cpi * sin(y/3.);
  // - - Hammer-Aitoff projection:
  //        gamma  = sqrt(2./(1.+cos(y)*cos(x*0.5)));
  //        xpoint = gamma * cos(y) * 2. * sin(x*0.5);
  //        ypoint = gamma * sin(y);

  Double_t cxmin=-3.6, cxmax=3.6, cymin=-1.8, cymax=1.8, xp, yp, cmksize=1.0;

  fAnglePlot->SetEditable(true);

  fAnglePlot->Range(cxmin,cymin,cxmax,cymax);
  fAnglePlot->Resize();

  fAnglePlot->SetFillColor(10);
  fAnglePlot->SetBorderMode(0);
  fAnglePlot->SetBorderSize(1);
  fAnglePlot->SetHighLightColor(1);
  fAnglePlot->SetFrameBorderMode(0);
  fAnglePlot->Draw();

  fAnglePlot->Modified();
  fAnglePlot->Update();
  fAnglePlot->cd();

  PlotGalacticAxis();

  fAnglePlot->Modified();


  vector <double> latitudes;
  vector <double> longitudes;
  vector <double> e_latitudes;
  vector <double> e_longitudes;
  vector <double> rho_longlat;
  vector <int> colors;
  vector <int> styles;
  vector <string> graphNames;

  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {
    double glat = (*fEvent)->GetGenShower().GetGalacticLatitude();
    double glong = (*fEvent)->GetGenShower().GetGalacticLongitude()/degree;
    if ( glong >  180. )
      glong -= 360.;
    if ( glong < -180. )
      glong += 360.;

    glong*=degree;
    GalactProject(fProjectionType, glong, glat, xp, yp);

    latitudes.push_back(xp);
    longitudes.push_back(yp);
    e_latitudes.push_back(0.);
    e_longitudes.push_back(0.);
    rho_longlat.push_back(0.);
    colors.push_back((*fStyleManager)->GetMCColor());
    graphNames.push_back(string("MC"));
    styles.push_back(24);
  }

  const SDEvent &sdEvent= (*fEvent)->GetSDEvent();
  if(sdEvent.GetRecLevel()>=eHasSdAxis) {
    double glat=sdEvent.GetSdRecShower().GetGalacticLatitude();
    double glong=sdEvent.GetSdRecShower().GetGalacticLongitude()/degree;
    if ( glong >  180. )
      glong -= 360.;
    if ( glong < -180. )
      glong += 360.;

    glong*=degree;
    GalactProject(fProjectionType, glong, glat, xp, yp);

    latitudes.push_back(xp);
    longitudes.push_back(yp);
    e_latitudes.push_back(sdEvent.GetSdRecShower().GetGalacticLatitudeError());
    e_longitudes.push_back(sdEvent.GetSdRecShower().GetGalacticLongitudeError());
    rho_longlat.push_back(sdEvent.GetSdRecShower().GetLongLatCorrelation());
    colors.push_back((*fStyleManager)->GetSDColor());
    styles.push_back(20);
    graphNames.push_back(string("SD"));
  }

  for (unsigned int k=0;k<fSourceCatalogue.size();k++) {

    double glong=fSourceCatalogue[k].first;
    double glat=fSourceCatalogue[k].second;

    if ( glong >  180. )
      glong -= 360.;
    if ( glong < -180. )
      glong += 360.;

    glong*=degree;
    glat*=degree;

    GalactProject(fProjectionType, glong, glat, xp, yp);


    latitudes.push_back(xp);
    longitudes.push_back(yp);
    e_latitudes.push_back(0.);
    e_longitudes.push_back(0.);
    rho_longlat.push_back(0.);
    colors.push_back((*fStyleManager)->GetSourceColor());
    graphNames.push_back(fSourceNames[k]);
    styles.push_back(2);
  }

  for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
        eyeIter < (*fEvent)->EyesEnd();
        ++eyeIter ) {
    if(eyeIter->GetRecLevel()>=eHasAxis) {
      colors.push_back((*fStyleManager)->GetFDEyeColor(eyeIter->GetEyeId()));
      styles.push_back(20);
      double glat=eyeIter->GetFdRecShower().GetGalacticLatitude();
      double glong=eyeIter->GetFdRecShower().GetGalacticLongitude()/degree;

      if ( glong >  180. )
        glong -= 360.;
      if ( glong < -180. )
        glong += 360.;

      glong*=degree;
      GalactProject(fProjectionType, glong, glat, xp, yp);

      latitudes.push_back(xp);
      longitudes.push_back(yp);
      e_latitudes.push_back(eyeIter->GetFdRecShower().GetGalacticLatitudeError());
      e_longitudes.push_back(eyeIter->GetFdRecShower().GetGalacticLongitudeError());
      rho_longlat.push_back(eyeIter->GetFdRecShower().GetLongLatCorrelation());
      graphNames.push_back(string("FD"));
    }
  }


  if ( longitudes.empty() ) {
    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no angles reconstructed");
    legend->Draw("");
    fAnglePlotObjects->Add(legend);
  }
  else {

    for ( unsigned int j=0;j<longitudes.size();j++) {
      TGraph* eventpos = new TGraph(1,&latitudes[j],&longitudes[j]);
      eventpos->SetName(graphNames[j].c_str());
      fAnglePlotObjects->Add(eventpos);
      eventpos->SetMarkerSize(cmksize);
      eventpos->SetMarkerColor(colors[j]);
      eventpos->SetMarkerStyle(styles[j]);
      eventpos->Draw("p");
    }

  }

  fAnglePlot->Modified();
  fAnglePlot->Update();
  fAnglePlot->SetEditable(false);

}


void
AugerPlots::GalactProject(Int_t fProjectionType,
                          Double_t xgphi, Double_t ygthe,
                          Double_t& xp, Double_t& yp)
{
  Double_t gamma=0., xpos=0., ypos=0.;

  if ( fProjectionType <= 1 ) { // Sanson-Flamsteed projection.
    xpos = -xgphi * cos(ygthe);
    ypos = ygthe;
  }
  else if ( fProjectionType == 2 ) { // Parabolic projection.
    xpos = -xgphi * (2.*cos(ygthe*2./3.)-1.);
    ypos = TMath::Pi() * sin(ygthe/3.);
  }
  else if ( fProjectionType >= 3 ) { // Hammer-Aitoff projection.
    gamma = sqrt(2./(1.+cos(ygthe)*cos(xgphi*0.5)));
    xpos = -gamma * cos(ygthe) * 2. * sin(xgphi*0.5);
    ypos = gamma * sin(ygthe);
  }

  xp = xpos;
  yp = ypos;
}



// =======================================================================
// plot all axes lines and numbers of the galactic projection.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void
AugerPlots::PlotGalacticAxis()
{
  fAnglePlot->SetEditable(true);
  fAnglePlot->cd();

  double xp, yp, cmksize=0.2;

  ostringstream cangle;
  //  Char_t cangle[24];
  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  if ( fProjectionType <= 1 ) { // Sanson-Flamsteed projection.

    // - - - - - - - plot longitude axes lines:
    for(int ilon=-180; ilon<=180; ilon=ilon+90) {
      double xgphi = degree * ilon;
      for(int ilat=-90; ilat<=90; ilat=ilat+2 ) {
        double ygthe = degree * ilat;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
        if ( ilat == 0 ) {
          xp = xp - 0.40 + 0.12 * (180+ilon) / 90.;
          cangle.str("");
          cangle << setiosflags(ios::fixed) << setprecision(0) << ilon;
          TText* taxisa = new TText(xp,yp,cangle.str().c_str());
          fAnglePlotObjects->Add(taxisa);
          taxisa->SetTextAlign(11);
          taxisa->SetTextColor(1);
          taxisa->SetTextSize(0.03);
          taxisa->Draw();
        }
      }
    }

    // - - - - - - - plot latitude axes lines:
    for(int ilat=-60; ilat<=60; ilat=ilat+120 ) {
      double ygthe = degree * ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+4 ) {
        double xgphi = degree * ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
      }
    }
    for(int ilat=-30; ilat<=30; ilat=ilat+30) {
      double ygthe = degree * ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+3 ) {
        double xgphi = degree * ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
      }
    }

    // - - - - - - - plot numbers of degrees at the axes:
    TText* taxis0 = new TText(-0.06,1.6,"90");
    taxis0->SetTextAlign(11);
    taxis0->SetTextColor(1);
    taxis0->SetTextSize(0.03);
    taxis0->Draw();
    TText* taxis1 = new TText(1.8,1.0,"60");
    taxis1->SetTextAlign(11);
    taxis1->SetTextColor(1);
    taxis1->SetTextSize(0.03);
    taxis1->Draw();
    TText* taxis2 = new TText(2.9,0.47,"30");
    taxis2->SetTextAlign(11);
    taxis2->SetTextColor(1);
    taxis2->SetTextSize(0.03);
    taxis2->Draw();
    TText* taxis3 = new TText(-2.0,1.0,"60");
    taxis3->SetTextAlign(11);
    taxis3->SetTextColor(1);
    taxis3->SetTextSize(0.03);
    taxis3->Draw();
    TText* taxis4 = new TText(-3.1,0.47,"30");
    taxis4->SetTextAlign(11);
    taxis4->SetTextColor(1);
    taxis4->SetTextSize(0.03);
    taxis4->Draw();
    TText* taxis5 = new TText(2.9,-0.57,"-30");
    taxis5->SetTextAlign(11);
    taxis5->SetTextColor(1);
    taxis5->SetTextSize(0.03);
    taxis5->Draw();
    TText* taxis6 = new TText(1.8,-1.1,"-60");
    taxis6->SetTextAlign(11);
    taxis6->SetTextColor(1);
    taxis6->SetTextSize(0.03);
    taxis6->Draw();
    TText* taxis7 = new TText(-3.1,-0.57,"-30");
    taxis7->SetTextAlign(11);
    taxis7->SetTextColor(1);
    taxis7->SetTextSize(0.03);
    taxis7->Draw();
    TText* taxis8 = new TText(-2.0,-1.1,"-60");
    taxis8->SetTextAlign(11);
    taxis8->SetTextColor(1);
    taxis8->SetTextSize(0.03);
    taxis8->Draw();
    TText* taxis9 = new TText(-0.1,-1.7,"-90");
    taxis9->SetTextAlign(11);
    taxis9->SetTextColor(1);
    taxis9->SetTextSize(0.03);
    taxis9->Draw();

    fAnglePlotObjects->Add(taxis0);
    fAnglePlotObjects->Add(taxis1);
    fAnglePlotObjects->Add(taxis2);
    fAnglePlotObjects->Add(taxis3);
    fAnglePlotObjects->Add(taxis4);
    fAnglePlotObjects->Add(taxis5);
    fAnglePlotObjects->Add(taxis6);
    fAnglePlotObjects->Add(taxis7);
    fAnglePlotObjects->Add(taxis8);
    fAnglePlotObjects->Add(taxis9);
  }

  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  else if (fProjectionType == 2) { // Parabolic projection.

    // - - - - - - - plot longitude axes lines:
    for(int ilon=-180; ilon<=180; ilon=ilon+90) {
      double xgphi = degree * ilon;
      for(int ilat=-90; ilat<=90; ilat=ilat+2 ) {
        double ygthe = degree * ilat;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker *axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
        if ( ilat == 0 ) {
          xp = xp - 0.40 + 0.12 * (180+ilon) / 90.;
          cangle.str("");
          cangle << setiosflags(ios::fixed) << setprecision(0) << ilon;
          TText* taxisa = new TText(xp,yp,cangle.str().c_str());
          fAnglePlotObjects->Add(taxisa);
          taxisa->SetTextAlign(11);
          taxisa->SetTextColor(1);
          taxisa->SetTextSize(0.03);
          taxisa->Draw();
        }
      }
    }

    // - - - - - - - plot latitude axes lines:
    for(int ilat=-60; ilat<=60; ilat=ilat+120 ) {
      double ygthe = degree * ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+5 ) {
        double xgphi = degree * ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
      }
    }
    for(int ilat=-30; ilat<=30; ilat=ilat+30) {
      double ygthe = degree * ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+3 ) {
        double xgphi = degree * ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* axespos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(axespos);
        axespos->SetMarkerSize(cmksize);
        axespos->SetMarkerColor(15);
        axespos->Draw();
      }
    }

    // - - - - - - - plot numbers of degrees at the axes:
    TText* taxis0 = new TText(-0.07,1.60,"90");
    taxis0->SetTextAlign(11);
    taxis0->SetTextColor(1);
    taxis0->SetTextSize(0.03);
    taxis0->Draw();
    TText* taxis1 = new TText(-0.10,-1.70,"-90");
    taxis1->SetTextAlign(11);
    taxis1->SetTextColor(1);
    taxis1->SetTextSize(0.03);
    taxis1->Draw();
    TText* taxis2 = new TText(1.70,1.11,"60");
    taxis2->SetTextAlign(11);
    taxis2->SetTextColor(1);
    taxis2->SetTextSize(0.03);
    taxis2->Draw();
    TText* taxis3 = new TText(1.69,-1.16,"-60");
    taxis3->SetTextAlign(11);
    taxis3->SetTextColor(1);
    taxis3->SetTextSize(0.03);
    taxis3->Draw();
    TText* taxis4 = new TText(2.80,0.54,"30");
    taxis4->SetTextAlign(11);
    taxis4->SetTextColor(1);
    taxis4->SetTextSize(0.03);
    taxis4->Draw();
    TText* taxis5 = new TText(2.80,-0.65,"-30");
    taxis5->SetTextAlign(11);
    taxis5->SetTextColor(1);
    taxis5->SetTextSize(0.03);
    taxis5->Draw();
    TText* taxis6 = new TText(-2.94,0.57,"30");
    taxis6->SetTextAlign(11);
    taxis6->SetTextColor(1);
    taxis6->SetTextSize(0.03);
    taxis6->Draw();
    TText* taxis7 = new TText(-3.00,-0.64,"-30");
    taxis7->SetTextAlign(11);
    taxis7->SetTextColor(1);
    taxis7->SetTextSize(0.03);
    taxis7->Draw();
    TText* taxis8 = new TText(-1.85,1.11,"60");
    taxis8->SetTextAlign(11);
    taxis8->SetTextColor(1);
    taxis8->SetTextSize(0.03);
    taxis8->Draw();
    TText* taxis9 = new TText(-1.91,-1.17,"-60");
    taxis9->SetTextAlign(11);
    taxis9->SetTextColor(1);
    taxis9->SetTextSize(0.03);
    taxis9->Draw();

    fAnglePlotObjects->Add(taxis0);
    fAnglePlotObjects->Add(taxis1);
    fAnglePlotObjects->Add(taxis2);
    fAnglePlotObjects->Add(taxis3);
    fAnglePlotObjects->Add(taxis4);
    fAnglePlotObjects->Add(taxis5);
    fAnglePlotObjects->Add(taxis6);
    fAnglePlotObjects->Add(taxis7);
    fAnglePlotObjects->Add(taxis8);
    fAnglePlotObjects->Add(taxis9);

  }

  // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  else if ( fProjectionType >= 3 ) { // Hammer-Aitoff projection.

    // - - - - - - - plot longitude axes lines:
    for(int ilon=-180; ilon<=180; ilon=ilon+90 ) {
      double xgphi = degree*ilon;
      for(int ilat=-90; ilat<=90; ilat=ilat+3 ) {
        double ygthe = degree*ilat;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* eventpos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(eventpos);
        eventpos->SetMarkerSize(0.2);
        eventpos->SetMarkerColor(15);
        eventpos->Draw();
      }
    }

    // - - - - - - - plot latitude axes lines:
    for(int ilat=-60; ilat<=60; ilat=ilat+120 ) {
      double ygthe = degree * ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+9 ) {
        double xgphi = degree*ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* eventpos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(eventpos);
        eventpos->SetMarkerSize(cmksize);
        eventpos->SetMarkerColor(15);
        eventpos->Draw();
      }
    }
    for(int ilat=-30; ilat<=30; ilat=ilat+30 ) {
      double ygthe= degree*ilat;
      for(int ilon=-180; ilon<=180; ilon=ilon+5 ) {
        double xgphi = degree*ilon;
        GalactProject(fProjectionType, xgphi, ygthe, xp, yp);
        TMarker* eventpos = new TMarker(xp,yp,8);
        fAnglePlotObjects->Add(eventpos);
        eventpos->SetMarkerSize(cmksize);
        eventpos->SetMarkerColor(15);
        eventpos->Draw();
      }
    }

    // - - - - - - - plot numbers of degrees at the axes:
    TText* taxis0 = new TText(3.0,-0.05,"-180");
    taxis0->SetTextSize(0.03);
    taxis0->SetTextColor(1);
    taxis0->SetTextAlign(11);
    taxis0->Draw();
    TText* taxis1 = new TText(-3.2,-0.05,"+180");
    taxis1->SetTextSize(0.03);
    taxis1->SetTextColor(1);
    taxis1->SetTextAlign(11);
    taxis1->Draw();
    TText* taxis2 = new TText(-0.1,1.45,"+90");
    taxis2->SetTextSize(0.03);
    taxis2->SetTextColor(1);
    taxis2->SetTextAlign(11);
    taxis2->Draw();
    TText* taxis3 = new TText(-0.1,-1.55,"-90");
    taxis3->SetTextSize(0.03);
    taxis3->SetTextColor(1);
    taxis3->SetTextAlign(11);
    taxis3->Draw();
    TText* taxis4 = new TText(2.5,0.75,"+30");
    taxis4->SetTextSize(0.03);
    taxis4->SetTextColor(1);
    taxis4->SetTextAlign(11);
    taxis4->Draw();
    TText* taxis5 = new TText(1.5,1.3,"+60");
    taxis5->SetTextSize(0.03);
    taxis5->SetTextColor(1);
    taxis5->SetTextAlign(11);
    taxis5->Draw();
    TText* taxis6 = new TText(-2.7,-0.75,"-30");
    taxis6->SetTextSize(0.03);
    taxis6->SetTextColor(1);
    taxis6->SetTextAlign(11);
    taxis6->Draw();
    TText* taxis7 = new TText(-1.65,-1.333,"-60");
    taxis7->SetTextSize(0.03);
    taxis7->SetTextColor(1);
    taxis7->SetTextAlign(11);
    taxis7->Draw();
    TText* taxis8 = new TText(-2.7,0.75,"+30");
    taxis8->SetTextSize(0.03);
    taxis8->SetTextColor(1);
    taxis8->SetTextAlign(11);
    taxis8->Draw();
    TText* taxis9 = new TText(-1.65,1.25,"+60");
    taxis9->SetTextSize(0.03);
    taxis9->SetTextColor(1);
    taxis9->SetTextAlign(11);
    taxis9->Draw();
    TText* taxis10 = new TText(2.55,-0.8,"-30");
    taxis10->SetTextSize(0.03);
    taxis10->SetTextColor(1);
    taxis10->SetTextAlign(11);
    taxis10->Draw();
    TText* taxis11 = new TText(1.5,-1.3,"-60");
    taxis11->SetTextSize(0.03);
    taxis11->SetTextColor(1);
    taxis11->SetTextAlign(11);
    taxis11->Draw();
    TText* taxis12 = new TText(0.05,0.02,"0");
    taxis12->SetTextSize(0.03);
    taxis12->SetTextColor(1);
    taxis12->SetTextAlign(11);
    taxis12->Draw();
    TText* taxis13 = new TText(1.6,0.02,"-90");
    taxis13->SetTextSize(0.03);
    taxis13->SetTextColor(1);
    taxis13->SetTextAlign(11);
    taxis13->Draw();
    TText* taxis14 = new TText(-1.5,0.02,"+90");
    taxis14->SetTextSize(0.03);
    taxis14->SetTextColor(1);
    taxis14->SetTextAlign(11);
    taxis14->Draw();

    fAnglePlotObjects->Add(taxis0);
    fAnglePlotObjects->Add(taxis1);
    fAnglePlotObjects->Add(taxis2);
    fAnglePlotObjects->Add(taxis3);
    fAnglePlotObjects->Add(taxis4);
    fAnglePlotObjects->Add(taxis5);
    fAnglePlotObjects->Add(taxis6);
    fAnglePlotObjects->Add(taxis7);
    fAnglePlotObjects->Add(taxis8);
    fAnglePlotObjects->Add(taxis9);
    fAnglePlotObjects->Add(taxis10);
    fAnglePlotObjects->Add(taxis11);
    fAnglePlotObjects->Add(taxis12);
    fAnglePlotObjects->Add(taxis13);
    fAnglePlotObjects->Add(taxis14);
  }
}

void
AugerPlots::DrawShowerParameterPlot()
{
  fEnergyPlot->cd();
  fShowerParameterObjects->Delete();
  fEnergyPlot->Clear();

  if ( fEnergyOverviewButton->IsOn() )
    DrawEnergyPlot();
  else
    DrawXmaxPlot();

  fEnergyPlot->Modified();
  fEnergyPlot->Update();

}

void
AugerPlots::DrawXmaxPlot()
{
  vector <double> xmax;
  vector <double> e_xmax;
  vector <double> yAxis;
  vector <string> labels;
  vector <int>    colors;
  int counter = 0;

  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {
    counter ++;
    xmax.push_back((*fEvent)->GetGenShower().GetXmax());
    e_xmax.push_back(0.);
    yAxis.push_back(counter);
    colors.push_back((*fStyleManager)->GetMCColor());
    labels.push_back("MC");
  }

  // loop on detector eyes to get correct LL,LM,LA,CO sequence
  vector<UShort_t> detEyeNumbers = (*fDetectorGeometry)->GetEyeNumbers();
  for ( unsigned int iE=0; iE<detEyeNumbers.size(); iE++ ) {
    int detEyeID = detEyeNumbers[iE];

    for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
          eyeIter < (*fEvent)->EyesEnd();
          ++eyeIter ) {

      if ( eyeIter->GetEyeId() == detEyeID ) {
        if(eyeIter->GetRecLevel()>=eHasEnergy) {

          UInt_t eyeId = eyeIter->GetEyeId();
          const EyeGeometry &eye = (*fDetectorGeometry)->GetEye(eyeId);

          counter ++;
          xmax.push_back(eyeIter->GetFdRecShower().GetXmax());
          e_xmax.push_back(eyeIter->GetFdRecShower().GetXmaxError());
          yAxis.push_back(counter);
          colors.push_back((*fStyleManager)->GetFDEyeColor(eyeIter->GetEyeId()));
          string eyeName = (string) eye.GetEyeNameAbbr();
          labels.push_back(eyeName);
        }
      }
    }
  }


  if ( xmax.empty() ) {
    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no Xmax reconstructed");
    legend->Draw("");
    fShowerParameterObjects->Add(legend);
  }
  else {

    // draw a nice X-Axis ...

    double minX=0.;
    double maxX=0.;
    for ( unsigned int i=0;i<xmax.size();i++) {
      double x=xmax[i];
      double ex=e_xmax[i];
      double fac = 2.;
      if ( i == 0 || x-fac*ex < minX )
        minX = x-fac*ex;
      if ( i == 0 || x+fac*ex > maxX )
        maxX = x+fac*ex;
    }
    if ( minX == maxX ) {// for MC if error =0 ...
      minX-=0.2;
      maxX+=0.2;
    }

    double x1 = minX - 0.15*(maxX - minX);
    double x2 = maxX + 0.15*(maxX - minX);
    double ax1 = minX - 0.05*(maxX - minX);
    double ax2 = maxX + 0.05*(maxX - minX);
    double labelX = minX - 0.11*(maxX - minX);
    fEnergyPlot->Range(x1, -0.25, x2, yAxis.back()+0.5);
    TGaxis* axis = new TGaxis(ax1, 0.5, ax2, 0.5, ax1, ax2, 510, "");
    axis->SetTitle("X_{max} [g/cm^{2}]");
    axis->SetTitleSize(0.06);

    // ... the average ...
    if ( xmax.size() > 1 ) {
      double avXmax;
      double avXmaxError;
      double avXmaxChi2;
      int avXmaxNdf;
      (*fEvent)->CalculateAverage(RecEvent::eFDs, RecEvent::eXmax,
			      avXmax, avXmaxError,
			      avXmaxChi2, avXmaxNdf);

      TBox* box = new TBox(avXmax-avXmaxError,0.5,avXmax+avXmaxError,yAxis.back()+0.25);
      box->SetFillColor(kYellow);
      box->SetLineWidth(0);
      box->Draw();
      fShowerParameterObjects->Add(box);

      const double fac = avXmaxChi2/avXmaxNdf > 1 ?
        sqrt(avXmaxChi2/avXmaxNdf) : 1;

      TLine* line1 = new TLine(avXmax-avXmaxError*fac,0.5,
                                avXmax-avXmaxError*fac,yAxis.back()+0.25);
      TLine* line2 = new TLine(avXmax+avXmaxError*fac,0.5,
                                avXmax+avXmaxError*fac,yAxis.back()+0.25);

      line1->Draw();
      line1->SetLineStyle(2);
      line2->Draw();
      line2->SetLineStyle(2);

      fShowerParameterObjects->Add(line1);
      fShowerParameterObjects->Add(line2);


      TLatex* legend = new TLatex();

      ostringstream chi2;
      chi2 <<  setiosflags(ios::fixed) << setprecision(1)
           << "#chi^{2}/Ndf = " << float(avXmaxChi2) << " / "
           << int(avXmaxNdf);

      legend->SetNDC();
      legend->SetTextAlign(12);
      legend->SetTextSize(0.05);
      legend->DrawLatex(0.73,0.95,chi2.str().c_str());

      fShowerParameterObjects->Add(legend);

    }

    axis->Draw();
    fShowerParameterObjects->Add(axis);


    // ... and the data itself

    for ( unsigned int i=0;i<labels.size();i++) {
      TGraphErrors* xmaxGraph = new TGraphErrors(1,
                                                 &xmax[i],
                                                 &yAxis[i],
                                                 &e_xmax[i],NULL);
      xmaxGraph->SetTitle("");
      xmaxGraph->SetMarkerStyle(20);
      xmaxGraph->SetMarkerColor(colors[i]);
      xmaxGraph->SetLineColor(colors[i]);
      xmaxGraph->Draw("P");
      fShowerParameterObjects->Add(xmaxGraph);

      TText* tmp = new TText(labelX,yAxis[i],labels[i].c_str());
      tmp->SetTextAlign(12);
      tmp->SetTextColor(colors[i]);
      tmp->Draw();
      fShowerParameterObjects->Add(tmp);
    }
  }

}

void
AugerPlots::DrawEnergyPlot()
{
  vector <double> energies;
  vector <double> e_energies;
  vector <double> yAxis;
  vector <string> labels;
  vector <int>    colors;
  int counter = 0;

  if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {
    counter ++;
    energies.push_back((*fEvent)->GetGenShower().GetEnergy()/1.e18);
    e_energies.push_back(0.);
    yAxis.push_back(counter);
    colors.push_back((*fStyleManager)->GetMCColor());
    labels.push_back("MC");
  }

  const SDEvent &sdEvent= (*fEvent)->GetSDEvent();
  if(sdEvent.GetRecLevel()>=eHasLDF) {
    counter ++;
    energies.push_back(sdEvent.GetSdRecShower().GetEnergy()/1.e18);
    e_energies.push_back(sdEvent.GetSdRecShower().GetEnergyError()/1.e18);
    yAxis.push_back(counter);
    colors.push_back((*fStyleManager)->GetSDColor());
    labels.push_back("SD");
  }


  // loop on detector eyes to get correct LL,LM,LA,CO sequence
  vector<UShort_t> detEyeNumbers = (*fDetectorGeometry)->GetEyeNumbers();
  for ( unsigned int iE=0; iE<detEyeNumbers.size(); iE++ ) {
    int detEyeID = detEyeNumbers[iE];

    for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
          eyeIter < (*fEvent)->EyesEnd();
          ++eyeIter ) {

      if ( eyeIter->GetEyeId() == detEyeID ) {
        if(eyeIter->GetRecLevel()>=eHasEnergy) {

          UInt_t eyeId = eyeIter->GetEyeId();
          const EyeGeometry &eye = (*fDetectorGeometry)->GetEye(eyeId);

          counter ++;
          energies.push_back(eyeIter->GetFdRecShower().GetEnergy()/1.e18);
          e_energies.push_back(eyeIter->GetFdRecShower().GetEnergyError()/1.e18);
          yAxis.push_back(counter);
          colors.push_back((*fStyleManager)->GetFDEyeColor(eyeIter->GetEyeId()));
          string eyeName = (string) eye.GetEyeNameAbbr();
          labels.push_back(eyeName);
        }
      }
    }
  }


  if ( energies.empty() ) {
    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no energies reconstructed");
    legend->Draw("");
    fShowerParameterObjects->Add(legend);
  }
  else {

    // draw a nice X-Axis ...

    double minE=0.;
    double maxE=0.;
    for ( unsigned int i=0;i<energies.size();i++) {
      double e=energies[i];
      double ee=e_energies[i];
      double fac = 2.;
      if ( i == 0 || e-fac*ee < minE )
        minE = e-fac*ee;
      if ( i == 0 || e+fac*ee > maxE )
        maxE = e+fac*ee;
    }
    if ( minE == maxE ) {// for MC if error =0 ...
      minE-=0.2;
      maxE+=0.2;
    }

    double e1=minE-0.15*(maxE-minE);
    double e2=maxE+0.15*(maxE-minE);
    double ax1=minE-0.05*(maxE-minE);
    double ax2=maxE+0.05*(maxE-minE);
    double labelX=minE-0.11*(maxE-minE);
    fEnergyPlot->Range(e1,-0.25,e2,yAxis.back()+0.5);
    TGaxis*axis = new TGaxis(ax1,0.5,ax2,0.5,ax1,ax2,510,"");
    axis->SetTitle("E [EeV]");
    axis->SetTitleSize(0.06);

    // ... the average ...
    if ( energies.size() > 1 ) {
      double avEnergy;
      double avEnergyError;
      double avEnergyChi2;
      int avEnergyNdf;
      (*fEvent)->CalculateAverage(RecEvent::eFDsAndSD, RecEvent::eEnergy,
                                  avEnergy, avEnergyError,
                                  avEnergyChi2, avEnergyNdf);
      avEnergy/=1.e18;
      avEnergyError/=1.e18;

      TBox* box = new TBox(avEnergy-avEnergyError,0.5,avEnergy+avEnergyError,yAxis.back()+0.25);
      box->SetFillColor(kYellow);
      box->SetLineWidth(0);
      box->Draw();
      fShowerParameterObjects->Add(box);

      double fac=1.;
      if ( avEnergyChi2/avEnergyNdf > 1. )
        fac = sqrt(avEnergyChi2/avEnergyNdf);
      TLine* line1 = new TLine(avEnergy-avEnergyError*fac,0.5,
                               avEnergy-avEnergyError*fac,yAxis.back()+0.25);
      TLine* line2 = new TLine(avEnergy+avEnergyError*fac,0.5,
                               avEnergy+avEnergyError*fac,yAxis.back()+0.25);

      line1->Draw();
      line1->SetLineStyle(2);
      line2->Draw();
      line2->SetLineStyle(2);

      fShowerParameterObjects->Add(line1);
      fShowerParameterObjects->Add(line2);


      TLatex* legend = new TLatex();
      ostringstream chi2;
      chi2 << setiosflags(ios::fixed) << setprecision(1)
           << "#chi^{2}/Ndf = " << float(avEnergyChi2)
           << " / " << int(avEnergyNdf);

      legend->SetNDC();
      legend->SetTextAlign(12);
      legend->SetTextSize(0.05);
      legend->DrawLatex(0.73,0.95,chi2.str().c_str());

      fShowerParameterObjects->Add(legend);

    }

    axis->Draw();
    fShowerParameterObjects->Add(axis);


    // ... and the data itself

    for ( unsigned int i=0;i<labels.size();i++) {
      TGraphErrors* energyGraph = new TGraphErrors(1,
                                                   &energies[i],
                                                   &yAxis[i],
                                                   &e_energies[i],NULL);
      energyGraph->SetTitle("");
      energyGraph->SetMarkerStyle(20);
      energyGraph->SetMarkerColor(colors[i]);
      energyGraph->SetLineColor(colors[i]);
      energyGraph->Draw("P");
      fShowerParameterObjects->Add(energyGraph);

      TText* tmp = new TText(labelX,yAxis[i],labels[i].c_str());
      tmp->SetTextAlign(12);
      tmp->SetTextColor(colors[i]);
      tmp->Draw();
      fShowerParameterObjects->Add(tmp);
    }
  }

}

void
AugerPlots::Draw2DPlot()
{
  f2DPlotObjects->Delete();
  fArrayPlot->Clear();

  // draw array ...
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  fArrayPlot->GetMaxAndMinTime();
  fArrayPlot->Draw(true, true, (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)));


  f2DPlot->Modified();
  f2DPlot->Update();
}

void
AugerPlots::UpdatePalette()
{
  fDisplay3D->UpdatePalette();
}

void
AugerPlots::DrawProfilePlot()
{
  fProfilePlotObjects->Delete();
  fProfilePlot->cd();

  if (!*fEvent)
    return;

  vector<TGraphErrors*> dEdXGraphs;
  vector<TF1*> ghFunctions;

  double minX=0, maxX=0, minY=0, maxY=0;
  bool first=true;
  for ( RecEvent::ConstEyeIterator eyeIter = (*fEvent)->EyesBegin();
        eyeIter < (*fEvent)->EyesEnd();
        ++eyeIter ) {

    if ( eyeIter -> GetRecLevel() >= eHasdEdXProfile ) {
      const FdRecShower &fdRecShower = eyeIter->GetFdRecShower();
      if ( fdRecShower.GetEnergyDeposit().size() > 0 ) {
        double dX = fProfileRebinButton->GetPosition();
        LongitudinalProfile profile;
        profile.SetProfile(*eyeIter, (*fEvent)->GetGenShower(),
                           LongitudinalProfile::eDepth,
                           LongitudinalProfile::edEdX,
                           LongitudinalProfile::eNone, NULL);
        TGraphErrors* dedx = profile.GetGraph(dX);

        const vector<Double_t> & depth    = fdRecShower.GetDepth();
        const vector<Double_t> & eDep     = fdRecShower.GetEnergyDeposit();
        const vector<Double_t> & eDepErr  = fdRecShower.GetEnergyDepositError();

        vector<Double_t> minDep(eDep.size());
        vector<Double_t> maxDep(eDep.size());

        transform(eDep.begin(),eDep.end(),eDepErr.begin(),minDep.begin(),minus<Double_t>());
        transform(eDep.begin(),eDep.end(),eDepErr.begin(),maxDep.begin(),plus<Double_t>());

        double thisYmax =  *max_element(maxDep.begin(),maxDep.end());
        double thisYmin =  *min_element(minDep.begin(),minDep.end());

        if ( first || minX > depth.front() )
          minX = depth.front();
        if ( first || maxX < depth.back() )
          maxX = depth.back();

        if ( first || minY > thisYmin )
          minY = thisYmin;
        if ( first || maxY < thisYmax )
          maxY = thisYmax;

        int color = (*fStyleManager)->GetFDEyeColor(eyeIter->GetEyeId());
        dedx->SetLineColor(color);
        dedx->SetMarkerColor(color);
        dedx->SetMarkerStyle((*fStyleManager)->GetProfileDataType());
        dedx->SetMarkerSize((*fStyleManager)->GetProfileDataSize());
        first = false;
        dEdXGraphs.push_back(dedx);
        fProfilePlotObjects->Add(dedx);

        TF1* ghFunction = new TF1("GHfunction",
                                  "[0]*pow((x-[1])/([2]-[1]),([2]-[1])/[3])*exp(([2]-x)/[3])",
                                  fmax(0.,fdRecShower.GetX0()+1.),5000.);

        ghFunction->SetNpx(1000);
        ghFunction->SetParameters(fdRecShower.GetdEdXmax(),
                                  fdRecShower.GetX0(),
                                  fdRecShower.GetXmax(),
                                  fdRecShower.GetLambda());
        ghFunction->SetLineColor(color);
        ghFunction->SetLineWidth(2);
        ghFunctions.push_back(ghFunction);
        fProfilePlotObjects->Add(ghFunction);

      }
    }
  }

  if ( ! dEdXGraphs.empty() ) {
    // draw the axis
    double xBorder=50.;
    double border=0.05;
    TH1F* tmpHist = new TH1F("tmpProfiles","",100,minX-xBorder,maxX+xBorder);
    for ( int i=0;i<100;i++)
      tmpHist->SetBinContent(i+1,fmin(0.,minY-border*fabs(maxY))); // put zero-line where no one can see
    fProfilePlotObjects->Add(tmpHist);

    tmpHist->GetYaxis()->SetRangeUser(fmin(0.,minY-border*fabs(maxY)),maxY+border*fabs(maxY));
    tmpHist->GetYaxis()->SetTitle("dE/dX [PeV/(g/cm^{2})]");
    tmpHist->GetYaxis()->SetTitleOffset(1.4);
    tmpHist->GetXaxis()->SetNdivisions(505);
    tmpHist->GetXaxis()->SetTitle("slant depth [g/cm^{2}]");
    tmpHist->Draw();

    // Draw the MC dedx profile if available and asked for
    if (fIsMC && EventBrowserConfig::Get(cfg::eShowMC)) {
      const GenShower& genShower = (*fEvent)->GetGenShower();
      const vector<Double_t>& dedx  = genShower.GetEnergyDeposit();
      const vector<Double_t>& depth = genShower.GetDepth();
      TGraph* dedxGraph = new TGraph(dedx.size(), &depth.front(), &dedx.front());
      dedxGraph->SetLineColor((*fStyleManager)->GetMCColor());
      dedxGraph->SetLineWidth(2);
      dedxGraph->SetLineStyle(9);
      fProfilePlotObjects->Add(dedxGraph);
      dedxGraph->Draw("l");
    }

    // Draw the GH-fits and reconstructed dedx profiles
    for ( vector<TF1*>::iterator iter = ghFunctions.begin();
          iter != ghFunctions.end();
          ++iter )
      (*iter)->Draw("SAME");

    for ( vector<TGraphErrors*>::iterator iter = dEdXGraphs.begin();
          iter != dEdXGraphs.end();
          ++iter )
      (*iter)->Draw("p");
  }

  fProfilePlot->Modified();
  fProfilePlot->Update();
}

void
AugerPlots::UpdateArrayPlot()
{
  Draw2DPlot();
  DrawProfilePlot();
}

void
AugerPlots::Update3DPlot()
{
  fDisplay3D->Update();
}

void
AugerPlots::Set3DFDButtons(EButtonSignals e)
{
  fDisplay3D->SetFDButtons(e);
}

void
AugerPlots::Update()
{
  fShowerParameterObjects->Delete();
  fAnglePlotObjects->Delete();
  f2DPlotObjects->Delete();
  fProfilePlotObjects->Delete();
  fEventInfoObjects->Delete();

  if (!*fEvent) {
    return;
  }

  if ( fArrayTab->GetCurrent() == 0 )
    fDisplay3D->Update();

  UpdateArrayPlot();
  DrawEventInfo();
  DrawAnglePlot();
  DrawShowerParameterPlot();
}

void
AugerPlots::Clear()
{

  fDisplay3D->Clear();

  fProfilePlot->Clear();
  f2DPlot->Clear();
  fCanvasInfo->Clear();
  fEnergyPlot->Clear();
  fAnglePlot->SetEditable(true);
  fAnglePlot->Clear();
  fAnglePlot->Update();
  fAnglePlot->SetEditable(false);
  fProfilePlot->Update();
  f2DPlot->Update();
  fCanvasInfo->Update();
  fEnergyPlot->Update();
  fAnglePlotObjects->Delete();
  fShowerParameterObjects->Delete();
  f2DPlotObjects->Delete();
  fProfilePlotObjects->Delete();
  fEventInfoObjects->Delete();
  fArrayPlot->Clear();

}


/*****************************************************************/
std::string
AugerPlots::PrintPostScript()
{

  const unsigned int kAugerIDLength = 12;

  const char* AugerID;//[100];
  string AugerIDstring = (*fEvent)->GetEventId();
  string AugerString="123456789";
  string auger="uger";
  string event="event"; //MC ID

  if((int)AugerIDstring.find(auger) > 0) {
    string tempAugerID(AugerIDstring.begin() + AugerIDstring.find(auger) + 5,
                       AugerIDstring.begin() + AugerIDstring.find(auger) + 5 + kAugerIDLength);
    AugerString=tempAugerID;
  }
  else {
    if((int)AugerIDstring.find(event) > 0) {
      AugerIDstring.erase(0, (int)AugerIDstring.find(event)+5 );
      AugerString=AugerIDstring;
    }
  }

  AugerID=AugerString.c_str();

  int tabID=0;
  if(fArrayTab!=NULL) tabID=fArrayTab->GetCurrent();
  const int k3D=0, k2D=1;

  ostringstream ArrayFileStream;

  ArrayFileStream << "/tmp/tmp_array_" << AugerID << ".eps";
  const char* ArrayFile = ArrayFileStream.str().c_str();
  switch(tabID) {
    case k3D: {
      fDisplay3D->SaveCanvas(ArrayFile);
      break;
    }
    case k2D: {
      f2DPlot->cd();
      f2DPlot->Print(ArrayFile);
      break;
    }
    default: {
      fProfilePlot->cd();
      fProfilePlot->Print(ArrayFile);
      break;
    }
  }

  ostringstream EnergyFileStream;
  EnergyFileStream << "/tmp/tmp_energy_" << AugerID << ".eps";
  const char* EnergyFile = EnergyFileStream.str().c_str();
  fEnergyPlot->cd();
  fEnergyPlot->Print(EnergyFile);

  ostringstream AngleFileStream;
  AngleFileStream << "/tmp/tmp_angle_" << AugerID << ".eps";
  const char* AngleFile = AngleFileStream.str().c_str();
  fAnglePlot->cd();
  fAnglePlot->Print(AngleFile);

  ostringstream filenameStream;
  filenameStream << "Overview_" << AugerID;

  ostringstream command;

  command << ADST_BIN_DIR << "/Auger2ps.csh "
          << AugerID << " " << filenameStream.str();

  if (system(command.str().c_str())) { /* just to prevent compiler warning ... */ }

  ostringstream psfileStream;
  psfileStream << filenameStream.str() << ".ps";
  return psfileStream.str();
}


void
AugerPlots::Save3D(const std::string &str)
  const
{
  fDisplay3D->SaveCanvas(str);
}


Bool_t
AugerPlots::ProcessMessage (Long_t msg, Long_t parm1, Long_t /*parm2*/)
{

  switch (GET_MSG (msg)) {

  case kC_COMMAND:
    switch (GET_SUBMSG (msg)) {
    case kCM_TAB: {
      if ( parm1 == 0 )
        fDisplay3D->Update();
    }
    default:
      break;
    }
  default:
    break;
  }
  return kTRUE;
}

void
AugerPlots::HandleShowerParameterButton()
{
  if (!*fEvent)
    return;
  DrawShowerParameterPlot();
}

void
AugerPlots::HandleGalacticButton()
{
  if (!*fEvent)
    return;
  if(fHammerAitoffButton->IsOn())
    fProjectionType=3;
  else if ( fSansonFlamsteedButton->IsOn() )
    fProjectionType=1;
  else
    fProjectionType=2;
  fAnglePlotObjects->Delete();
  DrawAnglePlot();
}


void
AugerPlots::LoadSources(char* fileName)
{
  fSourceCatalogue.clear();

  ifstream sourceFile;
  sourceFile.open(fileName);
  if ( !sourceFile.is_open() ) {
    cerr << " AugerPlots::LoadSources() - Error, could not open file "
         << fileName << endl;
    return;
  }

  while (!sourceFile.eof()) {
    char buffer[1000];
    sourceFile.getline(buffer,1000);
    if ( buffer[0] != '#' ) {

      pair<double,double> galCoords;
      double longi,lati;
      double redshift, radioPower;
      string name;
      string linebreak;

      stringstream testline(buffer);
      stringstream line(buffer);

      testline >> linebreak;
      if(linebreak!= "\n" && linebreak != "" ) {
        line >> name >> longi >> lati >> redshift >> radioPower;
        fSourceCatalogue.push_back(pair<double,double>(longi,lati));
        fSourceNames.push_back(name);
      }
    }

    if (!sourceFile.good() )
      break;
  }


  fAnglePlotObjects->Delete();
  DrawAnglePlot();

}
