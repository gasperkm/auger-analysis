#ifndef _GaisserHillas_h_
#define _GaisserHillas_h_

#include <vector>
#include <cstddef>

class FdRecShower;

class GaisserHillas {

  //
  // utility class for Gaisser-Hillas function
  //

public:
  GaisserHillas();
  ~GaisserHillas();

  double operator() (double *x, double* p = NULL) const;

  void SetShowerParameters(const FdRecShower& shower);

  void SetNSigma(double nSigma)
  { fNSigma = nSigma; }

  void SetXisAge(bool tmp)
  { fXisAge = tmp; }

  void SetResiduals(bool resid)
  { fResiduals = resid; }

  void SetScaleFactor(double fac)
  { fScaleFactor = fac; }

private:

  enum EGHParameters {
    eNmax=0,
    eXmax,
    eX0,
    eLambda,
    eNParameters
  };

  double fCovMat[eNParameters][eNParameters];
  double fGHParameters[eNParameters];

  bool fResiduals;
  bool fXisAge;
  double fNSigma;
  double fScaleFactor;
};

#endif
