#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class EventBrowser+;
#pragma link C++ class EventSelection+;
#pragma link C++ class VPlots+;
#pragma link C++ class SdPlots+;
#ifdef AUGER_RADIO_ENABLED
#pragma link C++ class RdPlots+;
#endif
#pragma link C++ class FdPlots+;
#pragma link C++ class AugerPlots+;
#pragma link C++ class ArrayPlot+;
#pragma link C++ class Display3D+;
#pragma link C++ class StatusBar+;
#pragma link C++ class OfflineConfigurationPopup+;
#pragma link C++ class RiseTimePlots+;
#pragma link C++ class SdSimulationPlots+;

#endif
