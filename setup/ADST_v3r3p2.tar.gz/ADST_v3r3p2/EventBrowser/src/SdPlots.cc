#include "SdPlots.h"
#include "ArrayPlot.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "EventBrowserConfig.h"

#include "RecEvent.h"
#include "Detector.h"
#include "DetectorGeometry.h"

#include "Detector.h"
#include "SDEvent.h"

#include "StyleManager.h"

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TH1F.h>
#include <TH2F.h>

#include <TClass.h>
#include <TProfile.h>
#include <TLegend.h>
#include <TLegendEntry.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TLatex.h>
#include <TGSlider.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TMarker.h>
#include <TTimeStamp.h>
#include <TText.h>
#include <TColor.h>
#include <TGDoubleSlider.h>

#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>

#include <iomanip>

using namespace std;
using namespace view::Consts;


ClassImp(SdPlots);
#define round(x) (x<0? ceil( (x)-0.5 ) : floor( (x)+0.5 ))



// Only kept for backward compatibility: signal error needs to be set in the energy reconstruction module
inline
double StationSignalError(double signal) { return 1.06*sqrt(signal); }

inline
void EnlargeMinMax(const vector<double>& x, const vector<double>& xerr,
                   double& tempMin, double& tempMax){
  // compute the min,max range according to the values in x
  if (x.empty() || x.size() != xerr.size())
    return;
  for (size_t i=0; i<x.size(); ++i){
    const double currentMax = x[i]+xerr[i];
    const double currentMin = x[i]-xerr[i];
    tempMax = max(currentMax, tempMax);
    tempMin = min(currentMin, tempMin);
  }
}



SdPlots::SdPlots(TGCompositeFrame* main,
                 const StyleManager* const * styleManager,
                 const DetectorGeometry* const * geom,
                 const RecEvent* const * event,
                 const bool& isMC) :
  fStyleManager(styleManager),
  fEvent(event),
  fIsMC(isMC),
  fDetectorGeometry(geom),
  fArrayPlot(0),
  fSdColorStatus(eSDGroundTimeColors)
{

  fSdTimeRes= true;
  fSdFallTime = false;
  fSdRiseTime = false;
  fSdT50 = false;
  fSdLDFOnStatus = true;
  fPMTObjects= new TObjArray();
  fPMTObjects->SetOwner(kTRUE);
  fEventObjects= new TObjArray();
  fEventObjects->SetOwner(kTRUE);

  fTracesObjects= new TObjArray();
  fTracesObjects->SetOwner(kTRUE);

  fMain= main;
  fMain->SetCleanup(kDeepCleanup);

  fHasFADCTraces=false;
  fHasVEMTraces=false;

  const UInt_t width = UInt_t(main->GetWidth());
  const UInt_t height = UInt_t(main->GetHeight());

  const UInt_t upperHeight = UInt_t(0.58*height);
  const UInt_t lowerHeight = UInt_t(0.46*height);
  const UInt_t arrayWidth = UInt_t(0.4*width);
  const UInt_t statWidth = UInt_t(0.27*width);
  const UInt_t statHeight = UInt_t(0.7*upperHeight);
  const UInt_t infoHeight = UInt_t(0.5*upperHeight);
  const UInt_t infoWidth = UInt_t(0.3*width);


  TGLayoutHints* mainHorLayout = new TGLayoutHints(kLHintsExpandX
                                                   |kLHintsExpandY,
                                                   1, 1, 1, 1);
  TGLayoutHints* centered= new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,
                                             1,1,1,1);

  TGLayoutHints* centeredX= new TGLayoutHints(kLHintsCenterX,
                                              1,1,1,1);

  TGLayoutHints* centeredExpandXY = new TGLayoutHints(kLHintsExpandX|
                                                      kLHintsExpandY|
                                                      kLHintsCenterX|
                                                      kLHintsCenterY,
                                                      1,1,1,1);


  TGLayoutHints* expandXY = new TGLayoutHints(kLHintsExpandX|
                                              kLHintsExpandY,
                                              1,1,1,1);

  TGLayoutHints* expandY = new TGLayoutHints(kLHintsExpandY,
                                             1,1,1,1);

  TGHorizontalFrame* mainHor1 = new TGHorizontalFrame(main,
                                                      UInt_t(width),
                                                      upperHeight);
  TGHorizontalFrame* mainHor2 = new TGHorizontalFrame(main,
                                                      UInt_t(width),
                                                      lowerHeight);

  main->AddFrame(mainHor1, mainHorLayout);
  main->AddFrame(mainHor2, mainHorLayout);

  TGVerticalFrame* vertical1 = new TGVerticalFrame(mainHor1,
                                                   infoWidth,
                                                   upperHeight);

  mainHor1->AddFrame(vertical1, expandY);
  //================> event info frame <=======================
  fSDEventInfoTab = new TGTab(vertical1, infoWidth, infoHeight);
  TGCompositeFrame *eventInfoFrame = fSDEventInfoTab->AddTab("Event Info");
  TRootEmbeddedCanvas *canvInfoEmb = new TRootEmbeddedCanvas("canvInfoEmb",
                                                             eventInfoFrame,
                                                             infoWidth,
                                                             infoHeight);
  eventInfoFrame->AddFrame(canvInfoEmb, expandY);
  fCanvasInfo= canvInfoEmb->GetCanvas();

  //MC info tab
  TGCompositeFrame *eventMCFrame = fSDEventInfoTab->AddTab("MC info");
  TRootEmbeddedCanvas *canvMCEmb = new TRootEmbeddedCanvas("canvMCEmb",
                                                           eventMCFrame,
                                                           infoWidth,
                                                           infoHeight);
  eventMCFrame->AddFrame(canvMCEmb, expandY);
  fCanvasMCInfo= canvMCEmb->GetCanvas();


  //Shower universality tab
  TGCompositeFrame *eventUnivFrame = fSDEventInfoTab->AddTab("Universality");
  TRootEmbeddedCanvas *canvUnivEmb = new TRootEmbeddedCanvas("canvUnivEmb",
                                                             eventUnivFrame,
                                                             infoWidth,
                                                             infoHeight);
  eventUnivFrame->AddFrame(canvUnivEmb, expandY);
  fCanvasUnivInfo= canvUnivEmb->GetCanvas();

  vertical1->AddFrame(fSDEventInfoTab, expandY);

  fArrayZoomButton=new TGHSlider(vertical1, 200,
                                 kSlider2 | kScaleBoth, eSDZoomToCore);
  fArrayZoomButton->Connect("Pressed()", "SdPlots", this, "DoSdPressed()");
  fArrayZoomButton->Connect("Released()", "SdPlots", this, "DoSdReleased()");
  fArrayZoomButton->SetRange(0,1000);
  fArrayZoomButton->SetPosition(700);
  vertical1->AddFrame(fArrayZoomButton, centeredX);



  // fTracesSlider = new TGDoubleHSlider(horizFrameLDF, 100,
  //                                  kDoubleScaleBoth, 2000,
  //                                  kHorizontalFrame,TColor::Number2Pixel(16),
  //                                  kFALSE, kFALSE);
  // fTracesSlider->Connect("PositionChanged()", "SdPlots", this,
  // "DoTracesSlider()");
  // horizFrameLDF->AddFrame(fTracesSlider,   new TGLayoutHints(
  // kLHintsCenterY |kLHintsRight,3,3,3,3));
  // fTracesSlider->SetRange(-1000,1000);
  // fTracesSlider->SetPosition(-900, 900);
  // fTracesSlider->SetEnabled(false);


  //================> arrray frame <===========================
  TGVerticalFrame* vertical3 = new TGVerticalFrame(mainHor1,
                                                   arrayWidth,
                                                   upperHeight);
  mainHor1->AddFrame(vertical3, centered);
  TRootEmbeddedCanvas* canvArrayEmb = new TRootEmbeddedCanvas("canvArrayEmb",
                                                              vertical3,
                                                              arrayWidth,
                                                              upperHeight);
  vertical3->AddFrame(canvArrayEmb, centered);
  fCanvasArray= canvArrayEmb->GetCanvas();
  fCanvasArray->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)",
                        "SdPlots", this,
                        "HandleArrayClicked(Int_t,Int_t,Int_t,TObject*)");
  fCanvasArray->SetBottomMargin(0.14);
  fCanvasArray->SetTopMargin(0.06);
  fCanvasArray->GetCanvas()->SetEditable(false);

  fArrayPlot = new ArrayPlot(fEvent,
                             fDetectorGeometry,
                             fStyleManager,
                             fArrayZoomButton, fCanvasArray);
  fArrayPlot->SetSDColorStatus(fSdColorStatus);
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  fArrayZoomButton->Connect("PositionChanged(Int_t)", "ArrayPlot",
                            fArrayPlot, "DoSdZoom(Int_t)");



  TGVerticalFrame* vertical2 = new TGVerticalFrame(mainHor1,
                                                   statWidth,
                                                   upperHeight);
  mainHor1->AddFrame(vertical2, expandY);

  TGTab* fSDStatInfoTab = new TGTab(vertical2, infoWidth, infoHeight);
  vertical2->AddFrame(fSDStatInfoTab, expandY);

  //================> stations frame <=========================
  TGCompositeFrame *statInfoFrame = fSDStatInfoTab->AddTab("Stations");

  fStationsListBox = new TGListBox(statInfoFrame, 89);
  fStationsListBox->Connect("Selected(Int_t)", "SdPlots",
                            this, "SelectStation()");
  //  fStationsListBox->Resize(statWidth, statHeight);
  statInfoFrame->AddFrame(fStationsListBox, expandXY);

  //================> options frame <==========================
  TGCompositeFrame *optFrame = fSDStatInfoTab->AddTab("Options");
  TGHorizontalFrame *statHFrame = new TGHorizontalFrame(optFrame,
                                                        statWidth,
                                                        statHeight);

  optFrame->AddFrame(statHFrame, expandY);


  TGVButtonGroup *colorButtons = new TGVButtonGroup(statHFrame,"Colors");
  statHFrame->AddFrame(colorButtons, centeredX);
  fColButton1 = new TGRadioButton(colorButtons, "None", eSDNoColors);
  fColButton1->SetToolTipText("no colors");
  fColButton2 = new TGRadioButton(colorButtons, "Ground time",
                                  eSDGroundTimeColors);
  fColButton2->SetToolTipText("station colors from time:"
                              " cold(early) to hot(late) ");
  fColButton3 = new TGRadioButton(colorButtons, "Time residual",
                                  eSDGroundResidualColors);
  fColButton3->SetToolTipText("station colors from time residuals"
                              "to a plane fit: hot(shower centrum)-"
                              " cold(shower margin) ");
  fColButton4 = new TGRadioButton(colorButtons,"Azimuth",
                                  eSDShowerPlaneAzimuthColors);
  fColButton4->SetToolTipText("station colors from shower plane azimuth:"
                              " hot(early)- cold(late) ");

  //  fColButton5=new TGRadioButton(colorButtons,"Geomagnetic
  //  azimuth", eSDGeoMagneticAngleColors);
  //  fColButton5->SetToolTipText("station colors from  geomagnetic
  //  angle: hot(orthogonal)- cold(parallel) ");

  fColButton1->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fColButton2->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fColButton3->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fColButton4->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  //  fColButton5->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  colorButtons ->SetRadioButtonExclusive();
  fColButton2->SetState(kButtonDown);


  TGVButtonGroup *tracesButtons= new TGVButtonGroup(statHFrame,"");
  statHFrame->AddFrame(tracesButtons, centeredX);

  fArrayButton = new TGRadioButton(tracesButtons, "Array", eSDArray);
  fArrayButton->SetToolTipText("Draw the array");
  fTracesButton = new TGRadioButton(tracesButtons, "Traces", eSDTraces);
  fTracesButton->SetToolTipText("Traces: only candidate stations");
  fArrayButton->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fTracesButton->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  tracesButtons->SetRadioButtonExclusive();
  fArrayButton->SetState(kButtonDown);

  fSdArrayOnStatus = true;

  TGHButtonGroup *eventTimeButtons = new TGHButtonGroup(optFrame,
                                                        "Time Residuals");

  optFrame->AddFrame(eventTimeButtons, centeredX);

  fEventTimeRes  = new TGRadioButton(eventTimeButtons,
                                     new TGHotString("plane"), eSDTimeRes);
  fEventCurvTimeRes  = new TGRadioButton(eventTimeButtons,
                                         new TGHotString("curvature"),
                                         eSDCurvTimeRes);
  fEventNoTimeRes  = new TGRadioButton(eventTimeButtons,
                                       new TGHotString("none "), eSDNoTimeRes);


  TGHButtonGroup *eventButtons = new TGHButtonGroup(optFrame,
                                                    "Trace variables");
  optFrame->AddFrame(eventButtons, centeredX);
  fEventRiseTime = new TGCheckButton(eventButtons,
                                     new TGHotString("rise time"),
                                     eSDRiseTime);
  fEventFallTime = new TGCheckButton(eventButtons,
                                     new TGHotString("fall time"),
                                     eSDFallTime);
  fEventT50 = new TGCheckButton(eventButtons,
                                new TGHotString("T50"),
                                eSDT50);


  fEventTimeRes->SetState(kButtonDown);
  fEventTimeRes ->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventTimeRes ->SetToolTipText("Time residual to plane fit"
                                 " vs distance to shower core in SPC ");
  fEventCurvTimeRes ->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventCurvTimeRes ->SetToolTipText("Time residual to curvature"
                                     " vs distance to shower core in SPC ");
  fEventNoTimeRes->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventNoTimeRes->SetToolTipText("No time residuals, "
                                  "maybe you want some fall times only? ");
  fEventFallTime->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventFallTime->SetToolTipText("Fall time vs distance to "
                                 "shower core in SPC ");
  fEventRiseTime->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventRiseTime->SetToolTipText("Rise time vs distance to shower core "
                                 "in SPC ");
  fEventT50->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fEventT50->SetToolTipText("T50");

  TGHorizontalFrame* horizFrameLDF = new TGHorizontalFrame(optFrame,
                                                           UInt_t(width),
                                                           upperHeight);
  optFrame->AddFrame(horizFrameLDF);

  TGHButtonGroup* ldfButtons= new TGHButtonGroup(horizFrameLDF,"");
  horizFrameLDF->AddFrame(ldfButtons, new TGLayoutHints(kLHintsTop|kLHintsLeft,
                                                        3,3,3,3));
  fLDFButton = new TGRadioButton(ldfButtons, "LDF", eSDLDF);
  fLDFButton->SetToolTipText(" lateral distribution function");
  fLDFResButton = new TGRadioButton(ldfButtons, "LDF Residuals",
                                    eSDLDFResiduals);
  fLDFResButton->SetToolTipText("LDF residuals versus"
                                " distance to core in SPC");
  fLDFButton->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  fLDFResButton->Connect("Clicked()", "SdPlots", this, "DoSdButton()");
  ldfButtons ->SetRadioButtonExclusive();

  //================> LDF and time residuals frame <===========
  fSDEventTab = new TGTab(mainHor2, UInt_t(width), lowerHeight);
  mainHor2->AddFrame(fSDEventTab, expandXY );

  TGCompositeFrame* ldfandTResFrame = fSDEventTab->AddTab("LDF and Time");
  TGHorizontalFrame* horizFrameldf = new TGHorizontalFrame(ldfandTResFrame,
                                                           UInt_t(width),
                                                           lowerHeight);
  ldfandTResFrame->AddFrame(horizFrameldf, centeredExpandXY);


  const UInt_t ldfWidth = UInt_t(0.48*width);
  TRootEmbeddedCanvas *canvasLDFEmb = new TRootEmbeddedCanvas("canvasLDFEmb",
                                                              horizFrameldf,
                                                              ldfWidth,
                                                              lowerHeight);
  horizFrameldf->AddFrame(canvasLDFEmb, centeredExpandXY);
  fCanvasLDF= canvasLDFEmb->GetCanvas();
  fCanvasLDF->SetBottomMargin(0.14);
  fCanvasLDF->SetTopMargin(0.04);


  TRootEmbeddedCanvas *canvasTResEmb = new TRootEmbeddedCanvas("canvasTResEmb",
                                                               horizFrameldf,
                                                               ldfWidth,
                                                               lowerHeight);

  horizFrameldf->AddFrame(canvasTResEmb, centeredExpandXY);
  fCanvasTRes= canvasTResEmb->GetCanvas();
  fCanvasTRes->SetBottomMargin(0.14);
  fCanvasTRes->SetTopMargin(0.04);


  //================> VEM traces frame <=======================


  TGCompositeFrame *vemFrame = fSDEventTab->AddTab("VEM Traces");
  TRootEmbeddedCanvas *canvPMTVEMEmb = new TRootEmbeddedCanvas("canvPMTVEMEmb",
                                                               vemFrame,
                                                               width,
                                                               lowerHeight);

  vemFrame->AddFrame(canvPMTVEMEmb, centeredExpandXY);
  fCanvasPMTVEM = canvPMTVEMEmb->GetCanvas();
  fCanvasPMTVEM->SetBottomMargin(0.14);
  fCanvasPMTVEM->SetTopMargin(0.14);

  //================> HG traces frame <========================
  TGCompositeFrame *hgFrame = fSDEventTab->AddTab("Dynode (HG)");
  TRootEmbeddedCanvas *canvPMTHGEmb = new TRootEmbeddedCanvas("canvPMTHGEmb",
                                                              hgFrame,
                                                              width ,
                                                              lowerHeight);
  hgFrame->AddFrame(canvPMTHGEmb, centeredExpandXY);
  fCanvasPMTHG = canvPMTHGEmb->GetCanvas();
  fCanvasPMTHG->SetBottomMargin(0.14);
  fCanvasPMTHG ->SetTopMargin(0.14);

  //================> LG traces frame <========================
  TGCompositeFrame *lgFrame = fSDEventTab->AddTab("Anode (LG)");
  TRootEmbeddedCanvas *canvPMTLGEmb = new TRootEmbeddedCanvas("canvPMTLGEmb",
                                                              lgFrame,
                                                              width ,
                                                              lowerHeight);
  lgFrame->AddFrame(canvPMTLGEmb, centeredExpandXY);
  fCanvasPMTLG = canvPMTLGEmb->GetCanvas();
  fCanvasPMTLG->SetBottomMargin(0.14);
  fCanvasPMTLG->SetTopMargin(0.14);

  fSDEventTab->SetEnabled(1, fHasVEMTraces);
  fSDEventTab->SetEnabled(2, fHasFADCTraces);
  fSDEventTab->SetEnabled(3, fHasFADCTraces);
  TGCompositeFrame *mpdFrame = fSDEventTab->AddTab("MPDs");

  TRootEmbeddedCanvas *canvMPD = new TRootEmbeddedCanvas("canvMPD",
                                                         mpdFrame,
                                                         width,
                                                         lowerHeight);
  // canvMPD->Divide(2,1);
  mpdFrame->AddFrame(canvMPD, centeredExpandXY);
  fCanvasMPD = canvMPD->GetCanvas();
  fCanvasMPD->Divide(2,1);
  fCanvasMPD->SetBottomMargin(0.14);
  fCanvasMPD->SetTopMargin(0.14);
  fSDEventTab->SetEnabled(4, false);

  TGCompositeFrame *calibFrame = fSDEventTab->AddTab("Calibration");

  TRootEmbeddedCanvas *canvCalib = new TRootEmbeddedCanvas("canvCalib",
                                                           calibFrame,
                                                           width,
                                                           lowerHeight);
  // canvMPD->Divide(2,1);
  calibFrame->AddFrame(canvCalib, centeredExpandXY);
  fCanvasCalib = canvCalib->GetCanvas();
  fCanvasCalib->Divide(6,1);
  fCanvasCalib->SetBottomMargin(0.14);
  fCanvasCalib->SetTopMargin(0.14);
  fSDEventTab->SetEnabled(5, true);

  fLDFButton->SetState(kButtonDown);

}

SdPlots::~SdPlots()
{
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();
  if (fEventObjects->GetEntriesFast())
    fPMTObjects->Delete();
  delete fEventObjects;
  delete fPMTObjects;

  fMain->Cleanup();

}


void
SdPlots::Clear()
{
  if (fPMTObjects->GetEntriesFast())
    fPMTObjects->Delete();
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();
  if (fTracesObjects->GetEntriesFast())
    fTracesObjects->Delete();

  fCanvasLDF->Clear();
  fCanvasTRes->Clear();
  fCanvasInfo->Clear();
  fCanvasMCInfo->Clear();

  fCanvasUnivInfo->Clear();

  fCanvasArray->Update();
  fCanvasLDF->Update();
  fCanvasTRes->Update();
  fCanvasInfo->Update();
  fCanvasMCInfo->Update();

  fCanvasUnivInfo->Update();

  fArrayPlot->Clear();
}

void
SdPlots::Update()
{
  if (fEventObjects->GetEntriesFast())
    fEventObjects->Delete();

  if (!*fEvent)
    return;

  fHasFADCTraces = (*fEvent)->GetSDEvent().HasFADCTraces();
  fHasVEMTraces = (*fEvent)->GetSDEvent().HasVEMTraces();

  const bool showMCTraces = EventBrowserConfig::Get(cfg::eShowMCTraces) && fIsMC;

  fSDEventTab->SetEnabled(1, true);
  fSDEventTab->SetEnabled(2, fHasFADCTraces && !showMCTraces);
  fSDEventTab->SetEnabled(3, fHasFADCTraces && !showMCTraces);

  fEventCurvTimeRes->SetEnabled((*fEvent)->GetSDEvent().HasCurvature()) ;

  fTracesButton->SetEnabled(fHasVEMTraces);
  fSDEventInfoTab->SetEnabled(1, fIsMC);

  SdEventInfo(fCanvasInfo);
  if (fIsMC) SdMCInfo();

  SdUnivInfo();

  fArrayPlot->GetMaxAndMinTime();
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  if (fSdArrayOnStatus){
    fArrayButton->SetState(kButtonDown);
    if (fTracesButton->IsEnabled())
      fTracesButton->SetState(kButtonUp);
    fSdArrayOnStatus=true;
    UpdateArrayPlot();
  }
  else{
    if (fTracesButton->IsEnabled())
      fTracesButton->SetState(kButtonDown);
    DrawAllTraces(fCanvasArray);
  }
  //fSDEventTab->SetTab(0);
  DrawLDF();
  DrawTimeResiduals();
  UpdateStationsList();
  SelectStation();
}


void
SdPlots::DoTracesSlider()
{
  //   TGFrame *frm = (TGFrame *) gTQSender;
  //   int id=-1;
  //   if (frm->IsA()->InheritsFrom(TGDoubleSlider::Class())) {
  //     TGDoubleSlider *sl = (TGDoubleSlider*) frm;
  //     id = sl->WidgetId();
  //   }else  return;
}



void
SdPlots::DoSdReleased()
{
  TGButton* button = (TGButton*)gTQSender;
  UInt_t id = button->WidgetId();
  switch (id)
    {
    case eSDZoomToCore:
      if (fTracesButton->IsEnabled())
        fTracesButton->SetState(kButtonUp);
      fSdArrayOnStatus=true;
      if (fArrayButton->IsEnabled())
        fArrayButton->SetState(kButtonDown);
      UpdateArrayPlot();
      break;
    case eSDNoColors:
    case eSDGroundTimeColors:
    case eSDGroundResidualColors:
    default:
      break;
    }
}

void SdPlots::DoSdPressed()
{
  TGButton* button = (TGButton*)gTQSender;
  UInt_t id = button->WidgetId();
  switch (id){
  case eSDZoomToCore:
    fSdArrayOnStatus=true;
    if (fTracesButton->IsEnabled())
      fTracesButton->SetState(kButtonUp);
    if (fArrayButton->IsEnabled())
      fArrayButton->SetState(kButtonDown);
    break;

  case eSDLDF:
  case eSDLDFResiduals:
    fSDEventTab->SetTab(0);
    break;

  default: break;
  }
}



void
SdPlots::HandleArrayClicked(Int_t event, Int_t px, Int_t py, TObject* /*sel*/)
{
  TCanvas *c = (TCanvas *) gTQSender;
  TPad *pad = (TPad *) c->GetSelectedPad();
  if ((event == kButton1Down) ||  (event == kButton1Double)) {
    if (fSdArrayOnStatus){
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      const int stid = (*fDetectorGeometry)->GetClosestStationId(ClickX*1000., ClickY*1000.);
      if (stid!=0){
        const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();

        fStationsListBox->Select(stid);
        for ( unsigned int iS=0;iS<stations.size(); ++iS){
          if ( (int) stations[iS].GetId() == stid ){
            UpdateTracesPlots(iS);

            UpdateArrayPlot();
            fArrayPlot->DrawSelectedStationMarker(iS);
            break;
          }
        }
      }
    } // if array on
    else {
      fCanvasArray->GetCanvas()->SetEditable(true);
      //clean all the colors
      for (int i=1; i<=(*fEvent)->GetSDEvent().GetNumberOfCandidates();++i){
        fCanvasArray->GetCanvas()->GetPad(i)->SetFillColor(0);
        fCanvasArray->GetCanvas()->GetPad(i)->Modified();
      }
      fCanvasArray->GetCanvas()->Update();
      int padnumber= pad->GetNumber();
      if ( padnumber > 0 ) {
        fCanvasArray->GetCanvas()->Update();
        const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();
        int accstnumber=0;
        bool foundStation=false;
        for ( unsigned int iS=0;iS<stations.size();iS++) {
          if ( stations[iS].IsAccidental())
            ++accstnumber;
          if ((int)(iS-accstnumber)>=padnumber-1) {
            foundStation=true;
            break;
          }
        }
        padnumber+= accstnumber-1;
        if ( foundStation ) {
          // fSDEventTab->SetTab(1);
          pad->SetFillColor(16);
          pad->Modified();
          UpdateTracesPlots(padnumber);
        }
        fStationsListBox->Select(padnumber-accstnumber);
        fCanvasArray->GetCanvas()->Modified();
        fCanvasArray->GetCanvas()->Update();
      }
      fCanvasArray->GetCanvas()->SetEditable(false);
    }
  }
  else if ((event == kButton2Down) ||  (event == kButton2Double)) {
    if (fSdArrayOnStatus){
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      fArrayPlot->SetZoomCenter(ClickX,ClickY);
      UpdateArrayPlot();
    }
  }

}

void SdPlots::UpdateStationsList(){

#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0,maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
  fStationsListBox->Layout();
#endif

  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();
  unsigned int firstId=0;
  unsigned int lastId= 0;
  int n=0;

  for ( unsigned int iS=0;iS<stations.size();iS++) {
    ostringstream name;
    int stationId= stations[iS].GetId();
    if ( stations[iS].IsCandidate()) {
      name << stationId << " ";
      name << stations[iS].GetStationTriggerName(fRecStationClassVersion)<< " ";
      name << setiosflags(ios::fixed) << setprecision(1)
           <<  round(stations[iS].GetTotalSignal()*10.)/10.;
      if (stations[iS].GetRecoveredSignal()!=0) {
        name << "( " <<  round(stations[iS].GetRecoveredSignal()*10.)/10.
             <<  ")";
      }
      name << " VEM " ;
      if (stations[iS].GetPLDTimeOffset())
        name << " " << stations[iS].GetPLDTimeOffset() << " "
             << stations[iS].GetPLDVersion();
      if (firstId == 0){
        firstId = stations[iS].GetId();
        lastId = 0;
      }
      fStationsListBox->InsertEntry( name.str().c_str(), stationId, lastId);
      lastId = stationId;
      ++n;
    } else {
      if (stations[iS].IsAccidental()) {
        if (stations[iS].IsDense() && !EventBrowserConfig::Get(cfg::eShowMC))
          continue;

        name.str("");
        name << stations[iS].GetId() << " ";
        name << stations[iS].GetStationTriggerName(fRecStationClassVersion) << " ";
        name << round(stations[iS].GetTotalSignal()*10.)/10.;
        if (stations[iS].GetRecoveredSignal()!=0){
          name <<  "("  <<  round(stations[iS].GetRecoveredSignal()*10.)/10
               << ")";
        }
        name << " VEM " << stations[iS].GetRemovalReason();
        int stationId= stations[iS].GetId();
        fStationsListBox->InsertEntry(name.str().c_str(), stationId, lastId);
        fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(18));
        ++n;
      }
    }
  }
  fStationsListBox->MapSubwindows();
  fStationsListBox->Layout();
  fStationsListBox->Select(firstId);

  UpdateTracesPlots(0);
}



void SdPlots::SelectStation(){

  int stationNumber= fStationsListBox->GetSelected();
  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();
  for ( unsigned int iS=0;iS<stations.size();++iS)
    if ((stations[iS].GetId()) == (unsigned int)fStationsListBox->GetSelected())
      stationNumber=iS;


  if (stationNumber >= 0){
    // fSDEventTab->SetTab(1);
    if (fSdArrayOnStatus) {
      UpdateArrayPlot();
      fArrayPlot->DrawSelectedStationMarker(stationNumber);
    }

    UpdateTracesPlots(stationNumber);
  }
}

void
SdPlots::DoSdButton()
{
  if (!*fEvent)
    return;

  TGButton* button = (TGButton*)gTQSender;
  UInt_t id = button->WidgetId();
  switch (id) {
  case eSDArray:
    if (fArrayButton->IsDown()&& !fSdArrayOnStatus){
      fSdArrayOnStatus= true;
      UpdateArrayPlot();
    }
    break;
  case eSDTraces:
    if (fTracesButton->IsDown() && fSdArrayOnStatus){
      fSdArrayOnStatus= false;
      DrawAllTraces(fCanvasArray);
    }
    break;
  case eSDNoColors:
    if (fColButton1->IsDown() && fSdColorStatus != eSDNoColors ) {
      fSdColorStatus = eSDNoColors;
      fArrayPlot->SetSDColorStatus(fSdColorStatus);
      Update();
    }
    break;
  case eSDGroundTimeColors:
    if (fColButton2->IsDown() && fSdColorStatus != eSDGroundTimeColors) {
      fSdColorStatus = eSDGroundTimeColors;
      fArrayPlot->SetSDColorStatus(fSdColorStatus);
      Update();
    }
    break;
  case eSDGroundResidualColors:
    if (fColButton3->IsDown() && fSdColorStatus != eSDGroundResidualColors) {
      fSdColorStatus = eSDGroundResidualColors;
      fArrayPlot->SetSDColorStatus(fSdColorStatus);
      Update();
    }
    break;
  case eSDShowerPlaneAzimuthColors:
    if ( fColButton4->IsDown() && fSdColorStatus != eSDShowerPlaneAzimuthColors ){
      fSdColorStatus = eSDShowerPlaneAzimuthColors;
      fArrayPlot->SetSDColorStatus(fSdColorStatus);
      Update();
    }
    break;
    /*
       case eSDGeoMagneticAngleColors:
       if ( fColButton5->IsDown() &&
       fSdColorStatus!=eSDGeoMagneticAngleColors ){
       fSdColorStatus=eSDGeoMagneticAngleColors;
       fArrayPlot->SetSDColorStatus(fSdColorStatus);
       fSdArrayOnStatus? UpdateArrayPlot() : DrawAllTraces(fCanvasArray);
       DrawLDF();
       SelectStation();
       }
       break;
    */
  case eSDTimeRes:
    if (fEventTimeRes->IsDown())
      fSdTimeRes=1;
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDCurvTimeRes:
    if (fEventCurvTimeRes->IsDown())
      fSdTimeRes=2;
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDNoTimeRes:
    if (fEventNoTimeRes->IsDown())
      fSdTimeRes=0;
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDFallTime:
    fSdFallTime=fEventFallTime->IsDown();
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDRiseTime:
    fSdRiseTime=fEventRiseTime->IsDown();
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDT50:
    fSdT50=fEventT50->IsDown();
    DrawTimeResiduals();
    fSDEventTab->SetTab(0);
    break;
  case eSDLDF:
    fSdLDFOnStatus=true;
    DrawLDF();
    break;
  case eSDLDFResiduals:
    fSdLDFOnStatus= false;
    DrawLDF();
    break;
  default: break;
  }

}


void SdPlots::DrawAllTraces(TCanvas *myCanvas){

  fTracesObjects->Delete();

  const std::vector<SdRecStation>& stations= (*fEvent)->GetSDEvent().GetStationVector();
  myCanvas->GetCanvas()->SetEditable(true);
  myCanvas->Clear();
  int nr= (*fEvent)->GetSDEvent().GetNumberOfCandidates();
  int extra=nr%3>0?1:0;
  myCanvas->Divide(3, (int)(nr/3.)+extra);
  int i=0;
  int startGen=800;
  int endGen=0;
  for ( unsigned int iS=0; iS<stations.size(); ++iS){
    if (!stations[iS].IsCandidate())
      continue;
    const int start= stations[iS].GetSignalStartSlot();
    const int end= stations[iS].GetSignalEndSlot();

    startGen= min(start, startGen);
    endGen= max(end, endGen);
  }

  for ( unsigned int iS=0; iS<stations.size(); ++iS){
    if (!stations[iS].IsCandidate())
      continue;
    ++i;

    TString name;
    const double timeSec       = stations[iS].GetTimeSecond();
    const double timeNSec      = stations[iS].GetTimeNSecond();
    const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9) + Long64_t(timeNSec);
    const int color=fArrayPlot->GetColor(stationTime,
                                         stations[iS].GetPlaneTimeResidual(),
                                         stations[iS].GetAzimuthSP());
    vector<float> vem;
    if ( stations[iS].GetVEMTrace(1).size()!=0)
      vem=stations[iS].GetVEMTrace(1);
    else {
      if ( stations[iS].GetVEMTrace(2).size()!=0)
        vem=stations[iS].GetVEMTrace(2);
      else
        if ( stations[iS].GetVEMTrace(3).size()!=0)
          vem=stations[iS].GetVEMTrace(3);
    }

    char title[] = "tracexxxx";
    sprintf(title,"%d",iS);
    TH1F *trace = new TH1F (title,"",endGen-startGen, startGen, endGen);
    fTracesObjects->Add(trace);
    if (vem.size()!=0)
      for (int j=startGen;j<endGen; ++j)
        trace->Fill(j, vem[j]);

    myCanvas->cd(i);
    trace->SetLineColor(color);
    trace->SetFillColor(color);
    trace->GetYaxis()->SetTitle("S [VEM peak]");
    trace->GetXaxis()->SetTitle("t [25 ns]");
    trace->Draw();
  }

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
  myCanvas->GetCanvas()->SetEditable(false);
}

void SdPlots::CreateTracesPads(TCanvas& canvas, string padname){

  TPad* thisPad = NULL;
  const double yaxis = 0.08;
  const double rightPart = 0.008;
  const double padWidth = (1.-yaxis-rightPart)/3.;

  for (unsigned int i= 0; i<3; ++i){
    const double xpos= i*padWidth + (i>0?yaxis:0);
    double xpos2= (i+1)*padWidth + yaxis+ (i==2?rightPart:0);
    if (xpos2>1.0)
      xpos2= 1;
    ostringstream padName;
    padName << padname << i;
    thisPad = new TPad(padName.str().c_str(), padName.str().c_str(),
                       xpos, 1, xpos2, 0 );
    fPMTObjects->Add(thisPad);
    canvas.cd();
    thisPad->Draw();
    thisPad->cd();
    thisPad->SetRightMargin(i==2?0.03:0.0);
    thisPad->SetLeftMargin((i>0?0.01:0.15));
    thisPad->SetFrameBorderSize(0);
    thisPad->SetTopMargin(0.07);
    thisPad->SetBottomMargin(0.15);
    thisPad->Modified();
    thisPad->SetCanvas(fCanvasPMTVEM);
    thisPad->SetNumber(i+1);
    canvas.cd();
  }


}

void SdPlots::UpdateTracesPlots(int stNumber){

  fPMTObjects->Delete();
  if (!(*fEvent)->GetSDEvent().HasTriggeredStations())
    return;

  fCanvasPMTVEM->Clear();
  fCanvasPMTHG->Clear();
  fCanvasPMTLG->Clear();

  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();

  if (!stations.size())
    return;

  const SdRecStation& recStation= stations[stNumber];
  const int stId= recStation.GetId();

  if (EventBrowserConfig::Get(cfg::eSdShowAllTraces)) {
    DrawTracesAllPMTs(recStation);
    return;
  }

  CreateTracesPads(*fCanvasPMTVEM, "padvem");
  CreateTracesPads(*fCanvasPMTLG, "padLG");
  CreateTracesPads(*fCanvasPMTHG, "padHG");

  const bool showMCTraces = EventBrowserConfig::Get(cfg::eShowMCTraces) && fIsMC;
  for (unsigned int pmtId=1; pmtId<4; pmtId++) {
    if (showMCTraces) {
      if (!(*fEvent)->GetSDEvent().HasSimStation(stId))
        continue;
      DrawMCTraces(pmtId, (*fEvent)->GetSDEvent().GetSimStationVector()[stNumber], recStation);
    }  else
      DrawTraces(pmtId, recStation);
  }

  double maximum= -1;
  double minimum= 1.e6;
  double maximumLG= -1;
  double minimumLG= 1.e6;
  double maximumHG= -1;
  double minimumHG= 1.e6;

  for ( int i=0; i<fPMTObjects->GetEntries(); ++i)
    if (fPMTObjects->At(i)->IsA()->InheritsFrom(TH1::Class())){
      TH1D& histo=*(TH1D *) fPMTObjects->At(i);
      TString name= histo.GetName();
      if (name.BeginsWith("vem")){
        maximum= max(maximum, histo.GetMaximum());
        minimum= min(minimum, histo.GetMinimum());
      }
      if (name.BeginsWith("lg")){
        maximumLG= max(maximumLG, histo.GetMaximum());
        minimumLG= min(minimumLG, histo.GetMinimum());
      }
      if (name.BeginsWith("hg")){
        maximumHG= max(maximumHG, histo.GetMaximum());
        minimumHG= min(minimumHG, histo.GetMinimum());
      }

    }

  for ( int i=0; i<fPMTObjects->GetEntries(); ++i)
    if (fPMTObjects->At(i)->IsA()->InheritsFrom(TH1::Class())){
      TH1D& histo=*(TH1D *) fPMTObjects->At(i);
      TString name= histo.GetName();
      if (name.BeginsWith("vem")){
        histo.GetYaxis()->SetRangeUser(minimum*0.9, maximum*1.05);
      }
      if (name.BeginsWith("lg")){
        histo.GetYaxis()->SetRangeUser(minimumLG*0.9, maximumLG*1.05);
      }
      if (name.BeginsWith("hg")){
        histo.GetYaxis()->SetRangeUser(minimumHG*0.9, maximumHG*1.05);
      }
    }


  fCanvasPMTVEM->GetCanvas()->Modified();
  fCanvasPMTVEM->GetCanvas()->Update();

  fCanvasPMTHG->GetCanvas()->Modified();
  fCanvasPMTHG->GetCanvas()->Update();

  fCanvasPMTLG->GetCanvas()->Modified();
  fCanvasPMTLG->GetCanvas()->Update();
  UpdateCalib(recStation.GetPMTTraces());
}




void SdPlots::DrawMCTraces(int iTrace, const  GenStation& simStation, const  SdRecStation& recStation){
  unsigned int stationId = (unsigned int) simStation.GetId();
  if (stationId==0) return;

  // ------------- muon trace --------------
  fCanvasPMTVEM->cd(iTrace);

  vector<float> muon=  simStation.GetMuonTrace(iTrace);

  const int start=1;
  const int end=muon.size();

  ostringstream histName;
  histName << "muon" << stationId << "_" << iTrace;
  ostringstream histTitle;
  histTitle << "";
  int startSlot=start;
  int endSlot=end;


  TH1F *muontrace = new TH1F (histName.str().c_str(),histTitle.str().c_str(),
                              end-start, start, end);
  fPMTObjects->Add(muontrace);


  const  bool hasmutrace=  (muon.size()!=0);
  if (hasmutrace)
    for (int j=start;j<end; ++j){
      muontrace->Fill(j, muon[j]);
    }
  histName.str("");
  histName << "electron" << stationId << "_" << iTrace;
  vector<float> electron= simStation.GetElectronTrace(iTrace);
  TH1F *electrontrace = new TH1F(histName.str().c_str(),histTitle.str().c_str(),
                                 end-start, start, end);
  fPMTObjects->Add(electrontrace);
  const  bool haseltrace=  (electron.size()!=0);

  if (haseltrace)
    for (int j=start;j<end; ++j){
      electrontrace->Fill(j, electron[j]);
    }

  histName.str("");
  histName << "photon" << stationId << "_" << iTrace;


  vector<float> photon= simStation.GetPhotonTrace(iTrace);
  TH1F *photontrace = new TH1F(histName.str().c_str(),histTitle.str().c_str(),
                               end-start, start, end);
  fPMTObjects->Add(photontrace);

  const  bool hasphotrace=  (photon.size()!=0);
  if (hasphotrace)
    for (int j=start;j<end; ++j){
      photontrace->Fill(j, photon[j]);
    }
  histName.str("");
  histName << "total" << stationId << "_" << iTrace;
  TH1F *totaltrace = new TH1F(histName.str().c_str(),histTitle.str().c_str(),
                              end-start, start, end);
  fPMTObjects->Add(totaltrace);

  for (int j=start;j<end; ++j){
    double signal= 0.;
    if(haseltrace)
      signal+=electron[j];
    if (hasphotrace)
      signal+= photon[j];
    if (hasmutrace)
      signal+=muon[j];
    totaltrace->Fill(j, signal);
  }
  for (int k=1; k<=totaltrace->GetNbinsX(); ++k)
    if (totaltrace->GetBinContent(k) >0) {
      startSlot= k;
      break;
    }

  for (int k=totaltrace->GetNbinsX(); k>0; k=k-1)
    if (totaltrace->GetBinContent(k) >0) {
      endSlot= k;
      break;
    }


  totaltrace->Draw("");

  vector<float> vem= recStation.GetVEMTrace(iTrace);
  histName << "total1" << stationId << "_" << iTrace;
  TH1F *trace_vem = new TH1F(histName.str().c_str(),histTitle.str().c_str(),
                             end-start, start, end);
  fPMTObjects->Add(trace_vem);

  double sum=0;
  double sum0=0;

  if (vem.size()!=0)
    for (int j=start;j<end; ++j){
      trace_vem->Fill(j, vem[j]);
      sum+= vem[j]-totaltrace->GetBinContent(j);
      sum0+= vem[j];
    }

  trace_vem->SetLineColor(6);
  trace_vem->Draw("same");

  if (iTrace==1) 
    totaltrace->GetYaxis()->SetTitle("Signal [VEM peak]");
  if (iTrace==3) 
    totaltrace->GetXaxis()->SetTitle("t [25 ns]");
  totaltrace->GetXaxis()->SetRangeUser(startSlot-10, endSlot+20 );

  photontrace->SetLineColor((*fStyleManager)->GetPhotonColor());
  photontrace->SetFillColor((*fStyleManager)->GetPhotonColor());
  photontrace->SetFillStyle((*fStyleManager)->GetPhotonStyle());
  photontrace->Draw("same");


  muontrace->SetLineColor((*fStyleManager)->GetMuonColor());
  muontrace->SetFillColor((*fStyleManager)->GetMuonColor());
  muontrace->SetFillStyle((*fStyleManager)->GetMuonStyle());
  muontrace->Draw("same");

  electrontrace->SetLineColor((*fStyleManager)->GetElectronColor());
  electrontrace->SetFillColor((*fStyleManager)->GetElectronColor());
  electrontrace->SetFillStyle((*fStyleManager)->GetElectronStyle());
  electrontrace->Draw("same");


  TLegend* legend = new TLegend(0.667086,0.694277,0.933811,0.941209,NULL,"brNDC");
  legend->SetTextSize(0.04);

  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  legend->AddEntry(totaltrace,"total","lf");
  legend->AddEntry(electrontrace,"electrons","lf");
  legend->AddEntry(muontrace,"muons","lf");
  legend->AddEntry(photontrace,"photons","lf");
  legend->AddEntry(trace_vem,"calib. trace","lf");
  legend->Draw("same");
}





void SdPlots::DrawTraces(int iTrace, const SdRecStation& recStation){

  const unsigned int stationID = (unsigned int) recStation.GetId();

  if (stationID==0)
    return;

  const TString & stationName= recStation.IsDense()?
    "dense":(*fDetectorGeometry)->GetStationName(stationID);

  const double timeSec = recStation.GetTimeSecond();
  const double timeNSec = recStation.GetTimeNSecond();
  const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9)
    + Long64_t(timeNSec);

  int color = (*fStyleManager)->GetTankNoiseColor();

  if (recStation.IsCandidate())
    color = fArrayPlot->GetColor(stationTime,
                                 recStation.GetPlaneTimeResidual(),
                                 recStation.GetAzimuthSP());

  const int startSlot = recStation.GetSignalStartSlot();
  const int endSlot = recStation.GetSignalEndSlot();

  const Traces& traces = recStation.GetPMTTraces(eTotalTrace, iTrace);

  // ------------- VEM trace --------------
  const vector<float>& vem = traces.GetVEMComponent();
  int end = vem.size();
  int start = 0;
  const bool hasTrace = (end != 0);

  if (!hasTrace) {
    start = startSlot-50;
    end = endSlot+50;
  }

  ostringstream histName;
  histName << "vem" << iTrace;
  ostringstream histTitle;
  histTitle << stationName << " (" << stationID
            << "), PMT " << iTrace << " at "
            <<  (int) recStation.GetSPDistance()
            << "m";

  TH1F* trace_vem = new TH1F(histName.str().c_str(),histTitle.str().c_str(),
                             end-start, start, end);
  fPMTObjects->Add(trace_vem);

  double signal = 0;
  if (hasTrace) {
    for (int j = start; j < end; ++j) {
      trace_vem->Fill(j, vem[j]);
      if (j >= startSlot && j < endSlot)
        signal += vem[j];
    }
    signal*=traces.GetPeak()/traces.GetCharge();
  }
  else {
    // use only if trace is empty; beware: GetVEMSignal was broken in the past (HD)
    signal = traces.GetVEMSignal();
  }

  TLegend* legend = new TLegend(0.4937,0.667,0.930,0.893);
  fPMTObjects->Add(legend);

  legend->SetTextSize(0.04);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);
  ostringstream name;
  name << setiosflags(ios::fixed) << setprecision(1);
  if (signal)
    name << "S = " <<  round(signal*10.)/10.  << " VEM";
  else
    name << "No signal data";
  legend->AddEntry("",name.str().c_str(),"");
  name.str("");
  name << "D/A = " <<  round(traces.GetDynodeAnodeRatio()*10.)/10.;
  legend->AddEntry("",name.str().c_str(),"");
  name.str("");
  name << "VEM Charge =  " <<  round(traces.GetCharge()*10.)/10.;
  legend->AddEntry("",name.str().c_str(),"");
  name.str("");
  name << "VEM Peak = " <<  round(traces.GetPeak()*10.)/10.;
  legend->AddEntry("",name.str().c_str(),"");

  trace_vem->SetLineColor(color);
  trace_vem->SetFillColor(color);

  if (iTrace==1)
    trace_vem->GetYaxis()->SetTitle("Signal [VEM peak]");
  if (iTrace==3)
    trace_vem->GetXaxis()->SetTitle("t [25 ns]");

  trace_vem->GetXaxis()->SetRangeUser(startSlot-15, endSlot+20 );

  fCanvasPMTVEM->cd(iTrace);

  TLine *startLine= new TLine(startSlot,0,startSlot, trace_vem->GetMaximum()/2.);
  fPMTObjects->Add(startLine);
  startLine->SetLineColor(kBlue);
  startLine->SetLineWidth(1);
  startLine->SetLineStyle(2);

  TLine *endLine= new TLine(endSlot,0,endSlot, trace_vem->GetMaximum()/2.);
  fPMTObjects->Add(endLine);

  endLine->SetLineColor(kBlue);
  endLine->SetLineWidth(1);
  endLine->SetLineStyle(2);
  TLatex* erlegend=new TLatex();
  erlegend->SetNDC();
  erlegend->SetTextAlign(12);
  erlegend->SetTextSize(0.055);
  erlegend->SetTextColor(4);
  fPMTObjects->Add(erlegend);

  trace_vem->Draw();
  startLine->Draw();
  endLine->Draw();

  if ( recStation.GetTime50()!=0 ) {
    if ( recStation.GetRiseTime()!=0 ){
      const double t0 = startSlot+(recStation.GetTime50()-recStation.GetRiseTime())/25.;
      const double t1 = startSlot+recStation.GetTime50()/25.;
      TLine* l = new TLine(t0, 0, t1, 0);
      fPMTObjects->Add(l);
      l->SetLineColor((*fStyleManager)->GetRiseTimeColor());
      l->SetLineWidth(3);
      l->Draw();
    }
    if (recStation.GetFallTime()!=0){
      const double t0 = startSlot+recStation.GetTime50()/25.;
      const double t1 = startSlot+(recStation.GetTime50()+recStation.GetFallTime())/25.;
      TLine* l = new TLine(t0, 0, t1, 0);
      fPMTObjects->Add(l);
      l->SetLineColor((*fStyleManager)->GetFallTimeColor());
      l->SetLineWidth(3);
      l->Draw();
    }
  }

  const double timeShift = recStation.GetCurvatureTimeResidual()!=0 ?
    recStation.GetCurvatureTimeResidual() : recStation.GetPlaneTimeResidual();
  const double frontInTrace = startSlot+timeShift/25.;
  TMarker* frontInTraceMarker = new TMarker(frontInTrace,0,22);
  fPMTObjects->Add(frontInTraceMarker);
  frontInTraceMarker->SetMarkerSize(1.2*frontInTraceMarker->GetMarkerSize());
  frontInTraceMarker->SetMarkerColor(kGreen);
  frontInTraceMarker->Draw();

  if (!hasTrace)
    erlegend->DrawLatex(0.4,0.5,"no trace data");

  if (!(EventBrowserConfig::Get(cfg::eShowMCTraces) && fIsMC))
    legend->Draw();

  if (!fHasFADCTraces)
    return;

  fCanvasPMTLG->cd(iTrace);
  const vector<unsigned short int>& lg= traces.GetLowGainComponent();
  start = 0;
  end = lg.size();

  ostringstream histNameLG;
  histNameLG << "lg" << iTrace;
  if (!traces.IsLowGainOk())
    histNameLG << " Tube NOT ok";

  TH1F *trace_lg = new TH1F(histNameLG.str().c_str(),histTitle.str().c_str(),
                            end-start, start, end);
  fPMTObjects->Add(trace_lg);

  if (!lg.empty())
    for (int j=start;j<end; ++j)
      trace_lg->Fill(j, lg[j]);
  trace_lg->SetLineColor(color);
  if (iTrace==1)
    trace_lg->GetYaxis()->SetTitle("adc counts");
  if (iTrace==3)
    trace_lg->GetXaxis()->SetTitle("t [25 ns]");

  const  double baselinelg= traces.GetBaselineLG();
  TLine *baseLinelg= new TLine(start,baselinelg,end,baselinelg);
  fPMTObjects->Add(baseLinelg);
  baseLinelg->SetLineColor(1);
  baseLinelg->SetLineWidth(2);
  baseLinelg->SetLineStyle(2);

  if (!lg.empty()){
    trace_lg->Draw();
    baseLinelg->Draw();
  }
  else
    erlegend->DrawLatex(0.4,0.5,"no trace data");

  fCanvasPMTHG->cd(iTrace);
  const vector<short unsigned int>& hg= traces.GetHighGainComponent();

  const  double baseline= traces.GetBaseline();
  TLine *baseLine= new TLine(start,baseline,end,baseline);

  fPMTObjects->Add(baseLine);
  baseLine->SetLineColor(1);
  baseLine->SetLineWidth(2);
  baseLine->SetLineStyle(2);

  ostringstream histNameHG;
  histNameHG << "hg" << iTrace;
  if (!traces.IsTubeOk())
    histNameHG << "Tube NOT ok";
  TH1F *trace_hg = new TH1F(histNameHG.str().c_str(),histTitle.str().c_str(),
                            end-start, start, end);
  fPMTObjects->Add(trace_hg);

  if (!hg.empty())
    for (int j=start;j<end; ++j)
      trace_hg->Fill(j, hg[j]);

  if (iTrace==1)
    trace_hg->GetYaxis()->SetTitle("adc counts");
  if (iTrace==3)
    trace_hg->GetXaxis()->SetTitle("t [25 ns]");
  trace_hg->SetLineColor(color);

  if (!hg.empty()){
    trace_hg->Draw();
    baseLine->Draw();
  } else
    erlegend->DrawLatex(0.4,0.5,"no trace data");

}

void SdPlots::DrawTracesAllPMTs(const SdRecStation& recStation){

  unsigned int stationID = (unsigned int) recStation.GetId();
  if (stationID==0)
    return;

  ostringstream stationName;
  stationName <<  ( recStation.IsDense()?
                    "dense":(*fDetectorGeometry)->GetStationName(stationID))
              << "( " << stationID << " )";

  fCanvasPMTVEM->SetRightMargin(0.26);
  fCanvasPMTLG->SetRightMargin(0.26);
  fCanvasPMTHG->SetRightMargin(0.26);
  fCanvasPMTVEM->SetLeftMargin(0.08);
  fCanvasPMTLG->SetLeftMargin(0.08);
  fCanvasPMTHG->SetLeftMargin(0.08);

  const int startSlot= recStation.GetSignalStartSlot();
  const int endSlot= recStation.GetSignalEndSlot();

  // ------------- VEM trace --------------
  fCanvasPMTVEM->cd();
  TLegend* legend = new TLegend(0.768763,0.156584,0.941176,0.882562);
  fPMTObjects->Add(legend);
  legend->SetTextSize(0.07);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  double maxVEM = 0;
  double maxLG = 0;
  double maxHG = 0;
  double minVEM = 1e30;
  double minLG = 1e30;
  double minHG = 1e30;
  TH1F *first_vem = NULL;
  TH1F *first_lg = NULL;
  TH1F *first_hg = NULL;

  for (int pmt=1; pmt<4; ++pmt){
    const vector<float>& vem= recStation.GetVEMTrace(pmt);
    const int start=0;
    int end = vem.size();
    const bool goodvem= !vem.empty();
    ostringstream histName;
    histName << "vem" << pmt;
    TH1F *trace_vem = new TH1F(histName.str().c_str(),
                               stationName.str().c_str(),
                               end-start, start, end);
    fPMTObjects->Add(trace_vem);

    double signal= 0;
    if (goodvem)
      for (int j=start;j<end; ++j){
        trace_vem->Fill(j, vem[j]);
        if (j>startSlot && j<endSlot)
          signal+= vem[j];
      }

    const vector<short unsigned int>& lg= recStation.GetLowGainTrace(pmt);
    histName.str("");
    histName << "lg" << pmt;
    end = lg.size();
    TH1F *trace_lg = new TH1F(histName.str().c_str(),
                              stationName.str().c_str(),
                              end, 0, end);
    fPMTObjects->Add(trace_lg);
    if (!lg.empty()){
      for (int j=0;j<end; ++j){
        trace_lg->Fill(j, lg[j]);
      }
    }

    const vector<short unsigned int>& hg= recStation.GetHighGainTrace(pmt);
    histName.str("");
    histName << "hg" << pmt;
    end = hg.size();
    TH1F *trace_hg = new TH1F(histName.str().c_str(),
                              stationName.str().c_str(),
                              end, 0, end);
    fPMTObjects->Add(trace_hg);
    if (!hg.empty()){
      for (int j=0;j<end; ++j){
        trace_hg->Fill(j, hg[j]);
      }
    }


    signal*=recStation.GetPeak(pmt)/recStation.GetCharge(pmt);
    trace_vem->SetLineColor(pmt);
    trace_lg->SetLineColor(pmt);
    trace_hg->SetLineColor(pmt);
    if (pmt==3){
      trace_vem->SetLineColor(4);
      trace_lg->SetLineColor(4);
      trace_hg->SetLineColor(4);
    }

    trace_vem->GetXaxis()->SetRangeUser(startSlot-10, endSlot+20 );

    if (!vem.empty() && first_vem == NULL){
      fCanvasPMTVEM->cd();
      trace_vem->Draw();
      first_vem = trace_vem;
    }
    else{
      fCanvasPMTVEM->cd();
      trace_vem->Draw("same");
    }

    if (!lg.empty() && first_lg == NULL){
      fCanvasPMTLG->cd();
      trace_lg->Draw();
      first_lg = trace_lg;
    }
    else{
      fCanvasPMTLG->cd();
      trace_lg->Draw("same");
    }

    if (!hg.empty() && first_hg == NULL){
      fCanvasPMTHG->cd();
      trace_hg->Draw();
      first_hg = trace_hg;
    }
    else{
      fCanvasPMTHG->cd();
      trace_hg->Draw("same");
    }

    double thisVEM = trace_vem->GetMaximum();
    maxVEM = max(thisVEM, maxVEM);
    maxLG = max(maxLG, trace_lg->GetMaximum());
    maxHG = max(maxHG, trace_hg->GetMaximum());
    minVEM = min(trace_vem->GetMinimum(), minVEM);
    minLG = min(trace_lg->GetMinimum(), minLG);
    minHG = min(minHG, trace_hg->GetMinimum());

    trace_vem->GetYaxis()->SetTitle("Signal [VEM peak]");
    trace_vem->GetYaxis()->SetTitleOffset(0.6);
    trace_vem->GetXaxis()->SetTitle("t [25 ns]");
    trace_lg->GetYaxis()->SetTitle("adc counts");
    trace_lg->GetYaxis()->SetTitleOffset(0.6);
    trace_lg->GetXaxis()->SetTitle("t [25 ns]");
    trace_hg->GetYaxis()->SetTitle("adc counts");
    trace_hg->GetYaxis()->SetTitleOffset(0.6);
    trace_hg->GetXaxis()->SetTitle("t [25 ns]");


  }

  if ( first_vem != NULL )
    first_vem->GetYaxis()->SetRangeUser(0.95*minVEM, maxVEM*1.1);
  if ( first_lg != NULL )
    first_lg->GetYaxis()->SetRangeUser(0.95*minLG, maxLG*1.1);
  if ( first_hg != NULL )
    first_hg->GetYaxis()->SetRangeUser(0.95*minHG, maxHG*1.1);

  ostringstream name;
  name << "D/A: ";
  TLegendEntry *entry= legend->AddEntry("",name.str().c_str(),"");

  for (int pmt=1; pmt<4; ++pmt){
    name.str("");
    name << " " << recStation.GetDynodeAnodeRatio(pmt);
    entry=legend->AddEntry("",name.str().c_str(),"");
    entry->SetTextColor(pmt);
    if (pmt==3)
      entry->SetTextColor(4);
  }
  name.str("");
  name << "VEM Charge:  ";
  entry=legend->AddEntry("",name.str().c_str(),"");

  for (int pmt=1; pmt<4; ++pmt){
    name.str("");
    name << " " << recStation.GetCharge(pmt);
    entry=legend->AddEntry("",name.str().c_str(),"");
    entry->SetTextColor(pmt);
    if (pmt==3)
      entry->SetTextColor(4);
  }
  name.str("");
  name << "VEM Peak: ";
  legend->AddEntry("",name.str().c_str(),"");
  for (int pmt=1; pmt<4; ++pmt){
    name.str("");
    name << " " << recStation.GetPeak(pmt);
    entry=legend->AddEntry("",name.str().c_str(),"");
    entry->SetTextColor(pmt);
    if (pmt==3)
      entry->SetTextColor(4);
  }

  TLine *startLine= new TLine(startSlot, minVEM, startSlot, maxVEM/2.);
  fPMTObjects->Add(startLine);
  startLine->SetLineColor(kBlue);
  startLine->SetLineWidth(1);
  startLine->SetLineStyle(2);

  TLine *endLine= new TLine(endSlot, minVEM, endSlot, maxVEM/2.);
  fPMTObjects->Add(endLine);
  endLine->SetLineColor(kBlue);
  endLine->SetLineWidth(1);
  endLine->SetLineStyle(2);
  fCanvasPMTVEM->cd();
  legend->Draw();
  startLine->Draw();
  endLine->Draw();


  fCanvasPMTLG->cd();
  legend->Draw();
  TLine *startLine2= new TLine(startSlot,minLG, startSlot, maxLG);
  fPMTObjects->Add(startLine2);
  startLine2->SetLineColor(kBlue);
  startLine2->SetLineWidth(2);
  startLine2->SetLineStyle(2);
  TLine *endLine2= new TLine(endSlot, minLG, endSlot, maxLG);
  fPMTObjects->Add(endLine2);
  endLine2->SetLineColor(kBlue);
  endLine2->SetLineWidth(2);
  endLine2->SetLineStyle(2);
  startLine2->Draw();
  endLine2->Draw();


  fCanvasPMTHG->cd();
  legend->Draw();
  TLine *startLine3= new TLine(startSlot,minHG, startSlot, maxHG);
  fPMTObjects->Add(startLine3);
  startLine3->SetLineColor(kBlue);
  startLine3->SetLineWidth(3);
  startLine3->SetLineStyle(3);
  TLine *endLine3= new TLine(endSlot, minHG, endSlot, maxHG);
  fPMTObjects->Add(endLine3);
  endLine3->SetLineColor(kBlue);
  endLine3->SetLineWidth(3);
  endLine3->SetLineStyle(3);
  startLine3->Draw();
  endLine3->Draw();

  fCanvasPMTVEM->GetCanvas()->Modified();
  fCanvasPMTVEM->GetCanvas()->Update();
  fCanvasPMTHG->GetCanvas()->Modified();
  fCanvasPMTHG->GetCanvas()->Update();
  fCanvasPMTLG->GetCanvas()->Modified();
  fCanvasPMTLG->GetCanvas()->Update();


}

void SdPlots::SdMCInfo(){

  fCanvasMCInfo->cd();
  fCanvasMCInfo->Clear();

  const SDEvent &sdevent= (*fEvent)->GetSDEvent();
  const GenShower & genShower = (*fEvent)->GetGenShower();

  float x1=0.03;
  float x2 = 0.11;
  float y=0.95;
  float dy=0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);
  y-=0.5*dy;

  double energysd= sdevent.GetSdRecShower().GetEnergy();
  double energymc= genShower.GetEnergy();
  double power=(int) log10(energysd)>(int) log10(energymc)?(int) log10(energysd):(int) log10(energymc);

  double energy_err = sdevent.GetSdRecShower().GetEnergyError();
  energysd/=pow(10.,power);
  energy_err/=pow(10.,power);
  energymc/=pow(10.,power);

  ostringstream info;

  info << "Event: " << sdevent.GetEventId() << " " << genShower.GetPrimaryName();
  slegend->DrawLatex(x2,y,info.str().c_str()); y-=dy;
  info.str("");

  info << "============================= ";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");
  if (energysd>0.)
    info  <<  showpoint  <<  setiosflags(ios::fixed) << setprecision(2)
          << "    E_{SD} = (" << energysd << " #pm "
          << energy_err << ") #times 10^{" << setprecision(0)  << noshowpoint
          << power << "} eV";
  else
    info <<"     ";

  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");

  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "    E_{MC} = " << energymc <<" #times 10^{" << setprecision(0)  << noshowpoint
       << power << "} eV";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");

  const double mean= 100.*(energysd-energymc)/(energymc);
  if (energysd>0.)
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "(E_{SD}-E_{MC})/E_{MC} = " << mean <<" %";
  else
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "          ";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=1.3*dy;
  info.str("");

  if ( sdevent.GetSdRecShower().GetZenith()!=0.)
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "(#theta, #phi)_{SD}= (" << sdevent.GetSdRecShower().GetZenith()/degree<< " ,  "
         << sdevent.GetSdRecShower().GetAzimuth()/degree<< ") #pm ("
         << sdevent.GetSdRecShower().GetZenithError()/degree
         << ", " << sdevent.GetSdRecShower().GetAzimuthError()/degree <<") #circ";
  else
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "          ";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");

  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "(#theta, #phi)_{MC}= (" << genShower.GetZenith()/degree<< " ,  "
       << genShower.GetAzimuth()/degree<< ") #circ";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=1.3*dy;
  info.str("");

  const TVector3 & showerCore=sdevent.GetSdRecShower().GetCoreSiteCS();
  double xC = showerCore.X()/1000.;
  double yC = showerCore.Y()/1000.;
  const double zC = showerCore.Z();
  const double xC_err =sdevent.GetSdRecShower().GetCoreEastingError()/1000.;
  const double yC_err = sdevent.GetSdRecShower().GetCoreNorthingError()/1000.;
  if (xC!=0.)
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "(x,y)_{SD} = (" <<xC
         <<", " << yC<< ") #pm (" << xC_err << ", " << yC_err << ") km";
  else
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "          ";

  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");



  const TVector3 & showerCoreMC=genShower.GetCoreAtAltitudeSiteCS(zC);
  xC = showerCoreMC.X()/1000.;
  yC = showerCoreMC.Y()/1000.;

  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "(x,y)_{MC} = (" <<xC <<", " << yC << ") km";
  slegend->DrawLatex(x1,y,info.str().c_str()); y-=dy;
  info.str("");

  slegend->Draw("");
  fCanvasMCInfo->GetCanvas()->Modified();
  fCanvasMCInfo->GetCanvas()->Update();
}

void SdPlots::SdEventInfo(TCanvas* myCanvas){

  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const float x1 = 0.03;
  const float x2 = 0.05;
  // const float x3 = 0.7;
  const float dy = 0.055;
  float y = 0.95;

  const SDEvent &sdevent= (*fEvent)->GetSDEvent();

  TLatex latex;
  latex.SetTextSize(0.045);

  ostringstream info;
  info << "Event " << sdevent.GetEventId();
  info << (sdevent.GetBadPeriodId()?" :-(":" :-)");
  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  latex.DrawLatex (x1, y, info.str().c_str()); y-=dy;
  info.str("");
  const unsigned int yymmdd= sdevent.GetYYMMDD();
  const unsigned int hhmmss= sdevent.GetHHMMSS();
  const unsigned int year=yymmdd/10000+2000;
  const unsigned int month=(yymmdd%10000)/100;
  const unsigned int day=(yymmdd%100);
  const unsigned int hour=(int)(hhmmss/10000.);
  const unsigned int minute=(hhmmss%10000)/100;
  const unsigned int second=(hhmmss%100);
  info << "Time (UTC): " << year << '/' << month << '/'
       << day << ' '
       << setw(2) << setfill('0') << hour << ':'
       << setw(2) << setfill('0') << minute << ':'
       << setw(2) << setfill('0') << second << ' ';
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");
  const int lGPSsec = sdevent.GetGPSSecond();
  const int lGPSnsec = sdevent.GetGPSNanoSecond();
  info << "Time (GPS): " << lGPSsec << " s " << lGPSnsec << " ns";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");
  if (sdevent.IsLightning()){
    info << " ====> LIGHTNINIG! <====";
    latex.DrawLatex(x1, y,info.str().c_str()); y-=dy;
    info.str("");
  }

  if (sdevent.GetT4Trigger() != 0) {
    info << "Trigger: " << sdevent.ReturnT4Name() << "; "
         << (sdevent.GetT5Trigger() ? sdevent.ReturnT5Name() : "no T5");
    latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
    info.str("");
  } else {
    info << "no T4 trigger" << endl;
    latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
    info.str("");
  }

  const int accidentals = sdevent.GetNoOfAccidentalStations();
  info << "Stations: "<< sdevent.GetNumberOfCandidates()
       << " (Acc: " << accidentals
       << ", Bad: " << sdevent.GetNoOfRemovedStations() - accidentals
       << ")";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");
  const SdRecShower& sdRecShower= sdevent.GetSdRecShower();
  if (sdevent.HasLDF()) {
    const LDF& ldf = sdRecShower.GetLDF();
    info << ldf.ReturnReconstructionStatus() << " (" << ldf.GetLDFStatus()
         << ")" ;
    latex.SetTextFont((*fStyleManager)->GetBoldFontType());
    y-=dy/2.;
    latex.DrawLatex(x1, y, info.str().c_str()); y-=dy;
    info.str("");
    double energy = sdRecShower.GetEnergy();
    double energy_err = sdRecShower.GetEnergyError();
    double energy_sys =  sdRecShower.GetEnergyLDFSys();
    const double power = energy>0.?(int) log10(energy):0.;
    const double norm =pow(10, power);
    energy /= norm;
    energy_err /= norm;
    energy_sys /= norm;
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "E = ( " << energy << " #pm "
         << energy_err;
    if (energy_sys)
      info << " #pm "<<  energy_sys
           << "";
    info << " ) #times 10^{" << setprecision(0)  << noshowpoint
         << power << "} eV";
    latex.SetTextFont((*fStyleManager)->GetNormalFontType());
    if (energy > 0){
      latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
    } else {
      latex.DrawLatex(x2, y, "No energy estimate"); y-=dy;
    }
    info.str("");
    if (sdevent.HasAxis()) {
      info << showpoint << setiosflags(ios::fixed) << setprecision(1)
           << "(#theta, #phi) = ( " << sdRecShower.GetZenith()/degree<< " #pm "
           << sdRecShower.GetZenithError()/degree<< ", "
           << sdRecShower.GetAzimuth()/degree<< " #pm "
           << sdRecShower.GetAzimuthError()/degree<< " ) deg";
      latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
      info.str("");

    }
    const TVector3& showerCore=sdRecShower.GetCoreSiteCS();
    const double xC = showerCore.X()/1000.;
    const double yC = showerCore.Y()/1000.;
    const double xC_err =sdRecShower.GetCoreEastingError()/1000.;
    const double yC_err = sdRecShower.GetCoreNorthingError()/1000.;
    info << showpoint << setiosflags(ios::fixed) << setprecision(2)
         << "(x,y) = ("
         << xC << " #pm " << xC_err
         <<", " << yC << " #pm "
         << yC_err << ") km";
    y -= dy/2.;
    latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
    info.str("");

    const string sizeLabel = sdRecShower.GetShowerSizeLabel();
    const bool isHorizontalReconstruction = ((sizeLabel == "N19") ||
                                             sdRecShower.GetLDF().GetLDFStatus() >= 10);

    const int precision = 1-int(std::log10(sdRecShower.GetShowerSizeError()));
    info << setiosflags(ios::fixed) << setprecision(precision)
         << sizeLabel << " = "
         << sdRecShower.GetShowerSize()<< " #pm "
         << sdRecShower.GetShowerSizeError();
    if (sdRecShower.GetShowerSizeSys() > 0)
      info << " ( #pm " << sdRecShower.GetShowerSizeSys() << ")";
    if (!isHorizontalReconstruction)
      info << " VEM";
    latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
    info.str("");

    if (!isHorizontalReconstruction) {
      info << showpoint << setiosflags(ios::fixed) << setprecision(2)
           <<"#beta ";
      if (sdRecShower.GetBetaError()>0.)
        info <<"= " << sdRecShower.GetBeta()
             <<" #pm " << sdRecShower.GetBetaError()
             <<" ( #pm " << sdRecShower.GetLDF().GetBetaSys()
             << " )";
      else
        info << " = " << sdRecShower.GetBeta()
             << " ( #pm " << sdRecShower.GetLDF().GetBetaSys()
             << " )";

      if (sdRecShower.GetGamma() != 0.) {
        info << showpoint << setiosflags(ios::fixed) << setprecision(2)
             <<", #gamma ";
        if (sdRecShower.GetGammaError()>0.)
          info <<"= " << sdRecShower.GetGamma()
               <<" #pm " << sdRecShower.GetGammaError() << endl;
        else
          info << " = " << sdRecShower.GetGamma() << endl;
      }

      if (sdRecShower.GetROpt()>0.) {
        info << setprecision(0)
             <<", r_{opt} = "<< sdRecShower.GetROpt()
          //<<" #pm" <<  sdRecShower.GetROptError()
             << " m";
      }
      latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
      info.str("");
    }


    if (sdevent.HasCurvature()) {
      const double rC= sdRecShower.GetRadiusOfCurvature()/ 1000.;
      const double rCErr= sdRecShower.GetRadiusOfCurvatureError()/ 1000.;

      info << showpoint << setiosflags(ios::fixed) << setprecision(2)
           << "radius = " << rC;
      if (rCErr > 0)
        info << " #pm " << rCErr;
      info << " km";
      if (sdRecShower.GetAngleNDoF() <= 0 || rCErr == 0)
        info << " (estimated)";

      latex.DrawLatex(x2,y,info.str().c_str()); 
      y-=dy;
      info.str("");
    }

    latex.SetTextFont((*fStyleManager)->GetBoldFontType());
    y-=dy/2.;
    latex.DrawLatex(x1, y, "Monitoring"); y-=dy;
    info.str("");


    const float age = sdevent.GetAverageStationAge()/(365.*24.*3600.);
    if (age != 0){
      info << "average stations age: " << setprecision(1)
           << fixed << age << " yr";
      latex.SetTextFont((*fStyleManager)->GetNormalFontType());
      latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
      info.str("");
      const Detector& det = (*fEvent)->GetDetector();
      if (det.HasWeatherInformation()){
        const double temp = det.GetWeatherInformation(eTemperature);
        const double dayTemp = det.GetWeatherInformation(eDayTemperature);
        if (temp)
          info << "T = " << setprecision(1)  << temp << "#circC; ";
        if (dayTemp)
          info << "T (day) = " << setprecision(1)  << dayTemp << "#circC";;

        latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
      info.str("");
      }
    }
  }
  else {
    y-= 2.*dy;
    info<< " no SD reconstruction ";
    latex.DrawLatex(x1,y,info.str().c_str()); y-=dy;
  }


  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}

void SdPlots::SdUnivInfo(){
  fCanvasUnivInfo->cd();
  fCanvasUnivInfo->Clear();

  const float x1 = 0.03;
  const float x2 = 0.05;
  const float dy = 0.055;
  float y = 0.95;

  const SDEvent &sdevent= (*fEvent)->GetSDEvent();
  const UnivRecShower& univRecShower = sdevent.GetUnivRecShower();

  TLatex latex;
  latex.SetTextSize(0.045);
  ostringstream info;

  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  y-=dy/2.;
  latex.DrawLatex(x1, y, "Universality Reconstruction"); y-=dy;
  info.str("");

  double energy = univRecShower.GetEnergy();
  double energy_err = univRecShower.GetEnergyError();
  const double power = energy>0.?(int) log10(energy):0.;
  const double norm =pow(10, power);
  energy /= norm;
  energy_err /= norm;
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "E = ( " << energy << " #pm "
       << energy_err;
  info << " ) #times 10^{" << setprecision(0)  << noshowpoint
       << power << "} eV";
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  const double Nmu = univRecShower.GetNmu();
  const double NmuError = univRecShower.GetNmuError();
  info.str("");
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "Nmu = " << Nmu << " #pm "
       << NmuError;
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double Xmax = univRecShower.GetXmax();
  const double XmaxErr = univRecShower.GetXmaxError();
  info.str("");
  info << "X#scale[0.7]{max} = " << setiosflags(ios::fixed) << setprecision(0)
       << Xmax << " #pm " << XmaxErr << " g/cm^{2}";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double XmaxMu = univRecShower.GetXmaxMu();
  const double XmaxMuErr = univRecShower.GetXmaxMuError();
  info.str("");
  info << "X#scale[0.7]{max}(mu) = " << setiosflags(ios::fixed) << setprecision(0)
       << XmaxMu << " #pm " << XmaxMuErr << " g/cm^{2}";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  info << showpoint << setiosflags(ios::fixed) << setprecision(1)
       << "(#theta, #phi) = ( " << univRecShower.GetZenith()/degree<< " #pm "
       << univRecShower.GetZenithError()/degree<< ", "
       << univRecShower.GetAzimuth()/degree<< " #pm "
       << univRecShower.GetAzimuthError()/degree<< " ) deg";
  latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
  info.str("");

  const TVector3& showerCore=univRecShower.GetCoreSiteCS();
  const double xC = showerCore.X()/1000.;
  const double yC = showerCore.Y()/1000.;
  const double xC_err =univRecShower.GetCoreEastingError()/1000.;
  const double yC_err = univRecShower.GetCoreNorthingError()/1000.;
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "(x,y) = ("
       << xC << " #pm " << xC_err
       <<", " << yC << " #pm "
       << yC_err << ") km";
  y -= dy/2.;
  latex.DrawLatex(x2,y,info.str().c_str()); y-=dy;
  info.str("");


  latex.SetTextFont((*fStyleManager)->GetBoldFontType());
  y-=dy/2.;
  latex.DrawLatex(x1, y, "True values"); y-=dy;
  info.str("");
  const GenShower & genShower = (*fEvent)->GetGenShower();

  const double NmuMC = genShower.GetNmu();
  info.str("");
  info << showpoint << setiosflags(ios::fixed) << setprecision(2)
       << "Nmu = " << NmuMC;
  latex.SetTextFont((*fStyleManager)->GetNormalFontType());
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double XmaxMC = genShower.GetXmax();
  info.str("");
  info << "X#scale[0.7]{max} = " << setiosflags(ios::fixed) << setprecision(0)
       << XmaxMC << " g/cm^{2}";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;

  const double XmaxMuMC = genShower.GetXmaxMu();
  info.str("");
  info << "X#scale[0.7]{max}(mu) = " << setiosflags(ios::fixed) << setprecision(0)
       << XmaxMuMC << " g/cm^{2}";
  latex.DrawLatex(x2, y, info.str().c_str()); y-=dy;
  info.str("");

  fCanvasUnivInfo->GetCanvas()->Modified();
  fCanvasUnivInfo->GetCanvas()->Update();
}


void SdPlots::DrawLDF()
{
  fCanvasLDF->cd();
  fCanvasLDF->Clear();
  if (fSdLDFOnStatus)
    fCanvasLDF->SetLogy();
  else
    fCanvasLDF->SetLogy(false);

  const SDEvent& sdEvent = (*fEvent)->GetSDEvent();
  const SdRecShower& sdRecShower = sdEvent.GetSdRecShower();
  const ESdRecLevel reclevel = sdEvent.GetRecLevel();
  const LDF& ldf = sdRecShower.GetLDF();

  const string sizeLabel = sdRecShower.GetShowerSizeLabel();
  const bool isHorizontalReconstruction = sizeLabel == "N19" || ldf.GetLDFStatus() >= 10;

  if (reclevel < eHasLDF){
    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no LDF available");
    legend->Draw("");
    fCanvasLDF->GetCanvas()->Modified();
    fCanvasLDF->GetCanvas()->Update();
    fEventObjects->Add(legend);
    return;
  }

  TLegend* ldfLegend = new TLegend(0.6,0.6,0.93,0.96, NULL,"brNDC");
  fEventObjects->Add(ldfLegend);
  ldfLegend->SetTextSize(0.045);
  ldfLegend->SetFillColor(0);
  ldfLegend->SetLineColor(0);
  ldfLegend->SetFillStyle(0);
  ldfLegend->SetBorderSize(0);

  unsigned int notDrawn = 0;

  vector<int> stcolor;
  vector<double> signalErr;
  vector<double> signal;
  vector<double> sPDistance;
  vector<double> sPDistanceErr;
  vector<double> satSignalErr;
  vector<double> satSignal;
  vector<double> satSPDistance;
  vector<double> satSPDistanceErr;

  vector<double> recSignalErr;
  vector<double> recSignal;
  vector<double> recSPDistance;
  vector<double> recSPDistanceErr;

  vector<double> accSignalErr;
  vector<double> accSignal;
  vector<double> accSPDistance;

  vector<double> silentSPDistance;
  vector<double> silentSignal;

  vector<double> ldfResidual;
  vector<double> ldfResidualError;

  vector<double> recldfResidual;
  vector<double> recldfResidualError;

  vector<double> accldfResidual;
  vector<double> accldfResidualError;
  vector<double> badSilentSPDistance;
  vector<double> badSilentSignal;


  const std::vector<SdRecStation>& stations=
    sdEvent.GetStationVector();

  ostringstream name;
  name << "Stage: " << sdRecShower.GetLDF().GetLDFStatus();
  ldfLegend->AddEntry("",name.str().c_str(), "");
  name.str("");

  if (sdRecShower.GetLDFChi2()<0.001)
    name << showpoint << setiosflags(ios::fixed) << setprecision(3)
         << "#chi^{2}/Ndf:  " << "(< 0.1)/ "
         << (int) (sdRecShower.GetLDFNdof()) << endl;
  else
    name << showpoint << setiosflags(ios::fixed) << setprecision(1)
         << "#chi^{2}/Ndf: "
         << sdRecShower.GetLDFChi2() << "/ "
         << (int)(sdRecShower.GetLDFNdof()) << endl;

  ldfLegend->AddEntry("",name.str().c_str(), "");

  const TVector3& showerCore = sdRecShower.GetCoreSiteCS();
  const TVector3& showerAxis = sdRecShower.GetAxisSiteCS();

  for (unsigned int iS=0; iS<stations.size(); iS++) {
    const double distance = stations[iS].GetSPDistance();
    const double distanceErr = stations[iS].GetSPDistanceError();

    if (stations[iS].IsCandidate()) {

      if (stations[iS].IsLowGainSaturated()) {
        satSignal.push_back(stations[iS].GetTotalSignal());
        satSignalErr.push_back( /* backward compatibility */
                               stations[iS].GetTotalSignalError() ?
                               stations[iS].GetTotalSignalError() :
                               StationSignalError(stations[iS].GetTotalSignal()));
        satSPDistance.push_back(distance);
        satSPDistanceErr.push_back(distanceErr);

        if (stations[iS].GetRecoveredSignal()!=0) {
          recSignal.push_back(stations[iS].GetRecoveredSignal());
          recSignalErr.push_back(stations[iS].GetRecoveredSignalError());
          const double satRes= (stations[iS].GetRecoveredSignal()-
                                ldf.Evaluate(distance, EventBrowserConfig::GetLDFType()))
            /stations[iS].GetRecoveredSignalError();

          recldfResidual.push_back(satRes);
          recldfResidualError.push_back(1.);
          recSPDistance.push_back(distance);
          recSPDistanceErr.push_back(distanceErr);
        }
      }
      else { // not low gain saturated
        if (stations[iS].GetLDFResidual()!=0){
          sPDistance.push_back(distance);
          sPDistanceErr.push_back(distanceErr);

          signal.push_back(stations[iS].GetTotalSignal());
          signalErr.push_back( /* backward compatibility */
                              stations[iS].GetTotalSignalError() ?
                              stations[iS].GetTotalSignalError() : StationSignalError(stations[iS].GetTotalSignal()));

          ldfResidual.push_back(stations[iS].GetLDFResidual());
          ldfResidualError.push_back(1.);
        }
      }

      const double timeSec       = stations[iS].GetTimeSecond();
      const double timeNSec      = stations[iS].GetTimeNSecond();
      const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9)
        + Long64_t(timeNSec);

      const int color= fArrayPlot->GetColor(stationTime,
                                            stations[iS].GetPlaneTimeResidual(),
                                            stations[iS].GetAzimuthSP());
      stcolor.push_back(color);
    }

    if (stations[iS].IsAccidental() && 0 < distance && distance < 5e3) {
      if (stations[iS].IsDense() && !EventBrowserConfig::Get(cfg::eShowMC))
        continue;

      accSPDistance.push_back(distance);
      accSignal.push_back(stations[iS].GetTotalSignal());
      accSignalErr.push_back( /* backward compatibility */
                             stations[iS].GetTotalSignalError() ?
                             stations[iS].GetTotalSignalError() : StationSignalError(stations[iS].GetTotalSignal()));
      accldfResidual.push_back(stations[iS].GetLDFResidual());
      accldfResidualError.push_back(1.);
    }
  }

  const Detector& det = (*fEvent)->GetDetector();
  const vector<SdBadStation>& badStations =
    (*fEvent)->GetSDEvent().GetBadStationVector();
  TBits array = det.GetActiveStations();
  for (size_t i=0;i<badStations.size();++i){
    if (badStations[i].GetReason() != eBadSilent)
      array[badStations[i].GetId()] = false;

  }

  for (DetectorGeometry::StationPosMapConstIterator iStation =
         (*fDetectorGeometry)->GetStationsBegin();
       iStation != (*fDetectorGeometry)->GetStationsEnd();
       ++iStation) {
    if (array.TestBitNumber(iStation->first)) {
      const int id= iStation->first;
      const double distance=
        (*fDetectorGeometry)->GetStationAxisDistance(id, showerAxis, showerCore);
      if ( distance<10000. && !sdEvent.HasStation(id)){
        if (sdEvent.HasBadStation(id)
            && (sdEvent.GetBadStationById(id)->GetReason() == eBadSilent ||
                sdEvent.GetBadStationById(id)->GetReason() == eNotAliveT2 ||
                sdEvent.GetBadStationById(id)->GetReason() == eNotAliveT120)){
            badSilentSPDistance.push_back(distance);
            badSilentSignal.push_back(3.);

        } else {
          silentSPDistance.push_back(distance);
          silentSignal.push_back(3.);
        }
      }
    }
  }

  if (signal.size() == 0) {
    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no LDF available");
    legend->Draw("");
    fCanvasLDF->GetCanvas()->Modified();
    fCanvasLDF->GetCanvas()->Update();
    fEventObjects->Add(legend);
    return;
  }

  TGraphErrors* ldfGraph= new TGraphErrors(signal.size(),
                                           &sPDistance[0],
                                           &signal[0],
                                           &sPDistanceErr[0],
                                           &signalErr[0] );
  ldfGraph->SetName("candidates");
  fEventObjects->Add(ldfGraph);
  ldfGraph->SetMarkerStyle(20);
  ldfGraph->SetLineColor((*fStyleManager)->GetLDFCandColor());
  ldfGraph->SetMarkerColor((*fStyleManager)->GetLDFCandColor());

  // xrange same for normal and residual plot
  double xmin(100), xmax(2000);
  EnlargeMinMax(sPDistance, sPDistanceErr, xmin, xmax);
  EnlargeMinMax(satSPDistance, satSPDistanceErr, xmin, xmax);
  EnlargeMinMax(recSPDistance, recSPDistanceErr, xmin, xmax);
  xmin -= 0.1*(xmax-xmin);
  xmax += 0.3*(xmax-xmin);

  if (xmin < 0.0) 
    xmin = 1.0;

  //  coloredMark;
  if (fSdLDFOnStatus) {
    double ymin(1e10), ymax(0);
    EnlargeMinMax(signal, signalErr, ymin, ymax);
    EnlargeMinMax(satSignal, satSignalErr, ymin, ymax);
    EnlargeMinMax(recSignal, recSignalErr, ymin, ymax);
    ymax *= 1.5;
    ymin = 0.5;
    TH2F* ldfFrame = new TH2F("ldfFrame", ";r [m];Signal [VEM]",
                              100, xmin, xmax, 100, ymin, ymax);
    fEventObjects->Add(ldfFrame);
    ldfFrame->Draw("");

    TGraphErrors *lGraph= new TGraphErrors();
    lGraph->SetName("reconstructedLDF");
    fEventObjects->Add(lGraph);
    int nrOfPoints = 0;
    for (int i = int(xmin); i<xmax; i+=10) {
      const double funcval= ldf.Evaluate(i, EventBrowserConfig::GetLDFType());
      if (funcval==0)
        continue;
      lGraph->SetPoint(nrOfPoints, i, funcval);
      lGraph->SetPointError(nrOfPoints, 0., sdRecShower.SignalUncertainty()*sqrt(funcval));
      ++nrOfPoints;
    }
    lGraph->SetLineColor((*fStyleManager)->GetLDFFuncColor());
    lGraph->SetFillColor(33);
    lGraph->SetLineWidth(1);
    lGraph->Draw("e3");
    lGraph->Draw("lxsame");

    if (!isHorizontalReconstruction) {
      TGraphErrors* s1000Mark[2] = { new TGraphErrors(1) , new TGraphErrors(1) };

      s1000Mark[0]->SetName("s1000_1");
      s1000Mark[1]->SetName("s1000_2");
      fEventObjects->Add(s1000Mark[0]);
      fEventObjects->Add(s1000Mark[1]);

      const double rRef = ldf.GetReferenceDistance();
      s1000Mark[0]->SetPoint(0, rRef, ldf.GetS1000());
      s1000Mark[0]->SetPointError(0, 0.0 , ldf.GetS1000Error());
      s1000Mark[0]->SetMarkerStyle(21);
      s1000Mark[0]->SetMarkerSize(1);
      s1000Mark[0]->SetMarkerColor(2);
      s1000Mark[0]->SetLineColor(2);
      s1000Mark[0]->SetLineWidth(3);

      const double error1= ldf.GetS1000Error();
      const double error2= ldf.GetS1000BetaSys();
      s1000Mark[1]->SetPoint(0, rRef, ldf.GetS1000());
      s1000Mark[1]->SetPointError(0, 0.0 , sqrt(error2*error2+error1*error1));
      s1000Mark[1]->SetLineColor(6);
      s1000Mark[1]->SetLineWidth(3);

      s1000Mark[1]->Draw("zsame");
      s1000Mark[0]->Draw("pzsame");
    }

    ldfLegend->AddEntry(ldfGraph, "candidates", "lp");

    if (silentSignal.size()>0) {
      TGraphErrors* ldfGraphSil= new TGraphErrors(silentSignal.size(),
                                                  &silentSPDistance[0],
                                                  &silentSignal[0] , 0, 0 );
      ldfGraphSil->SetName("silents");
      fEventObjects->Add(ldfGraphSil);
      ldfGraphSil->SetMarkerStyle(23);
      ldfGraphSil->SetLineColor((*fStyleManager)->GetLDFSilColor());
      ldfGraphSil->SetMarkerColor((*fStyleManager)->GetLDFSilColor());
      ldfGraphSil->Draw("ps");
      ldfLegend->AddEntry(ldfGraphSil, "not-triggered", "lp");
    } else {
      ++notDrawn;
    }

    if (badSilentSignal.size()>0) {
      TGraphErrors* ldfGraphBadSil= new TGraphErrors(badSilentSignal.size(),
                                                     &badSilentSPDistance[0],
                                                     &badSilentSignal[0] , 0, 0 );
      ldfGraphBadSil->SetName("silentsBad");
      fEventObjects->Add(ldfGraphBadSil);
      ldfGraphBadSil->SetMarkerStyle(23);
      ldfGraphBadSil->SetLineColor(kRed+2);
      ldfGraphBadSil->SetMarkerColor(kRed+2);
      ldfGraphBadSil->Draw("ps");
      ldfLegend->AddEntry(ldfGraphBadSil, "sillent", "lp");
    } else {
      ++notDrawn;
    }


    if (satSignal.size()>0) {

      TGraphErrors* ldfGraphSat= new TGraphErrors(satSignal.size(),
                                                  &satSPDistance[0],
                                                  &satSignal[0],
                                                  &satSPDistanceErr[0] ,
                                                  &satSignalErr[0] );
      ldfGraphSat->SetName("saturated");
      fEventObjects->Add(ldfGraphSat);

      ldfGraphSat->SetMarkerStyle(20);
      ldfGraphSat->SetLineColor((*fStyleManager)->GetLDFSatColor());
      ldfGraphSat->SetMarkerColor((*fStyleManager)->GetLDFSatColor());
      ldfGraphSat->Draw("ps");
      ldfLegend->AddEntry( ldfGraphSat, "saturated", "lp");

      if (recSignal.size()>0) {
        TGraphErrors* ldfGraphRec= new TGraphErrors(recSignal.size(),
                                                    &recSPDistance[0],
                                                    &recSignal[0],
                                                    &recSPDistanceErr[0] ,
                                                    &recSignalErr[0] );

        ldfGraphRec->SetName("satratedRecovered");
        fEventObjects->Add(ldfGraphRec);
        ldfGraph->SetMaximum(ldfGraphRec->GetYaxis()->GetXmax()*10.);
        ldfGraphRec->SetMarkerStyle(20);
        ldfGraphRec->SetLineColor((*fStyleManager)->GetLDFSatRecColor());
        ldfGraphRec->SetMarkerColor((*fStyleManager)->GetLDFSatRecColor());
        ldfGraphRec->Draw("ps");
        ldfLegend->AddEntry( ldfGraphRec, "sat. recovered", "lp");
      }
    } else {
      ++notDrawn;
    }

    ldfGraph->Draw("ps");

    for (unsigned int i=0; i<signal.size(); ++i){
      TMarker*  coloredMark= new TMarker(sPDistance[i],signal[i],
                                         ldfGraph->GetMarkerStyle());
      coloredMark->SetMarkerColor(stcolor[i]);
      coloredMark->SetMarkerSize(0.65*ldfGraph->GetMarkerSize());
      coloredMark->Draw("same");
      fEventObjects->Add(coloredMark);
    }

    if (accSignal.size()>0) {
      TGraphErrors* ldfGraphAcc= new TGraphErrors(accSignal.size(),
                                                  &accSPDistance[0],
                                                  &accSignal[0], 0 ,
                                                  &accSignalErr[0] );
      ldfGraphAcc->SetName("accidental");
      fEventObjects->Add(ldfGraphAcc);
      ldfGraphAcc->SetMarkerStyle(24);
      ldfGraphAcc->SetMarkerSize(0.75);
      ldfGraphAcc->SetLineColor((*fStyleManager)->GetLDFAccColor());
      ldfGraphAcc->SetMarkerColor((*fStyleManager)->GetLDFAccColor());
      ldfGraphAcc->Draw("ps");
      ldfLegend->AddEntry(ldfGraphAcc, "removed", "lp");
    } else {
      ++notDrawn;
    }

  }
  else {
    // residual plots
    double ymin(0.0), ymax(0.0);
    EnlargeMinMax(ldfResidual, ldfResidualError, ymin, ymax);
    EnlargeMinMax(recldfResidual, recldfResidualError, ymin, ymax);
    ymin-=0.1*(ymax-ymin); 
    ymax+=0.1*(ymax-ymin);

    TH2F* ldfResFrame = new TH2F("residualFrame",
                                 ";r [m];(signal-LDF)/#sigma", 100, xmin, xmax,
                                 100, ymin, ymax);

    fEventObjects->Add(ldfResFrame);
    ldfResFrame->Draw("axis");

    TGraphErrors* ldfResGraph= new TGraphErrors(ldfResidual.size(),
                                                 &sPDistance[0],
                                                 &ldfResidual[0],
                                                 &sPDistanceErr[0],
                                                 &ldfResidualError[0] );
    ldfResGraph->SetName("residualGraph");
    fEventObjects->Add(ldfResGraph);
    ldfResGraph->SetMarkerStyle(20);
    ldfResGraph->SetLineColor((*fStyleManager)->GetLDFCandColor());
    ldfResGraph->SetMarkerColor((*fStyleManager)->GetLDFCandColor());
    ldfResGraph->Draw("ps");
    ldfLegend->AddEntry(ldfResGraph, "candidates", "lp");

    for (unsigned int i=0; i<signal.size(); ++i){
      TMarker*  coloredMark= new TMarker( sPDistance[i],ldfResidual[i],
                                          ldfResGraph->GetMarkerStyle());
      coloredMark->SetMarkerColor(stcolor[i]);
      coloredMark->SetMarkerSize(0.65*ldfResGraph->GetMarkerSize());
      coloredMark->Draw("same");
      fEventObjects->Add(coloredMark);
    }

    if (recldfResidual.size()>0) {
      TGraphErrors* ldfResGraphRec= new TGraphErrors(recldfResidual.size(),
                                                     &recSPDistance[0],
                                                     &recldfResidual[0],
                                                     &recSPDistanceErr[0] ,
                                                     &recldfResidualError[0]);
      ldfResGraphRec->SetName("resSatRec");
      fEventObjects->Add(ldfResGraphRec);
      ldfResGraphRec->SetMarkerStyle(20);
      ldfResGraphRec->SetLineColor((*fStyleManager)->GetLDFSatRecColor());
      ldfResGraphRec->SetMarkerColor((*fStyleManager)->GetLDFSatRecColor());
      ldfResGraphRec->Draw("ps");
      ldfLegend->AddEntry( ldfResGraphRec, "sat. recovered", "lp");
    } else {
      ++notDrawn;
    }

    if (accldfResidual.size()>0) {
      TGraphErrors* ldfResGraphAcc= new TGraphErrors(accldfResidual.size(),
                                                     &accSPDistance[0],
                                                     &accldfResidual[0], 0 ,
                                                     &accldfResidualError[0]);
      ldfResGraphAcc->SetName("ldfResGraphAcc");
      fEventObjects->Add(ldfResGraphAcc);
      ldfResGraphAcc->SetMarkerStyle(24);
      ldfResGraphAcc->SetMarkerSize(0.75);
      ldfResGraphAcc->SetLineColor((*fStyleManager)->GetLDFAccColor());
      ldfResGraphAcc->SetMarkerColor((*fStyleManager)->GetLDFAccColor());
      ldfResGraphAcc->Draw("ps");
      ldfLegend->AddEntry( ldfResGraphAcc, "removed", "lp");
    } else {
      ++notDrawn;
    }

    ++notDrawn; // silents are never drawn in residual view

    TLine* horizontalLine = new TLine(xmin,0,xmax,0);
    fEventObjects->Add(horizontalLine);
    horizontalLine->SetLineColor(kBlue);
    horizontalLine->SetLineWidth(1);
    horizontalLine->SetLineStyle(2);
    horizontalLine->Draw("same");
  }
  for (unsigned int i=0; i<notDrawn; ++i)
    ldfLegend->AddEntry("", " ", "");

  ldfLegend->Draw("same");

  fCanvasLDF->GetCanvas()->Modified();
  fCanvasLDF->GetCanvas()->Update();

}


void
SdPlots::DrawTimeResiduals()
{
  fCanvasTRes->cd();
  fCanvasTRes->Clear();
  // fSDEventTab->SetTab(0);

  ESdRecLevel reclevel= (*fEvent)->GetSDEvent().GetRecLevel();
  if (reclevel< eHasSdAxis){

    TLatex* legend=new TLatex();
    legend->SetNDC();
    legend->SetTextAlign(12);
    legend->SetTextSize(0.035);
    legend->DrawLatex(0.4,0.5,"no axis available");
    legend->Draw("");
    fCanvasTRes->GetCanvas()->Modified();
    fCanvasTRes->GetCanvas()->Update();
    fEventObjects->Add(legend);
    return;
  }


  vector<double> sPDistance;
  vector<double> sPDistanceErr;
  vector<double> timeRes;
  vector<double> timeResErr;
  vector<double> timeStart;
  vector<double> timeEnd;
  vector<double> t50;
  vector<double> t50RMS;
  vector<double> fallTime;
  vector<double> fallTimeRMS;
  vector<double> riseTime;
  vector<double> riseTimeRMS;
  vector<double> t10;
  vector<int> stcolor;
  TGraphErrors* accTimeResGraph  = new TGraphErrors();
  fEventObjects->Add(accTimeResGraph);


  const std::vector<SdRecStation> & stations= (*fEvent)->GetSDEvent().GetStationVector();

  const SdRecShower& sdRecShower= (*fEvent)->GetSDEvent().GetSdRecShower();

  const TVector3 & showerCore=sdRecShower.GetCoreSiteCS();
  const TVector3 & showerAxis=sdRecShower.GetAxisSiteCS();

  int n=0;
  for (unsigned int iS=0; iS<stations.size(); ++iS) {
    if (stations[iS].IsCandidate()) {
      if (stations[iS].GetSPDistance()!=0) {
        sPDistance.push_back(stations[iS].GetSPDistance());
        sPDistanceErr.push_back(stations[iS].GetSPDistanceError());
      }
      else {
        sPDistance.push_back((*fDetectorGeometry)->GetStationAxisDistance(stations[iS].GetId(),
                                                                          showerAxis, showerCore));
        sPDistanceErr.push_back(0.);
      }

      double timeres = 0;
      switch (fSdTimeRes) {
      case 1:
        timeres= -stations[iS].GetPlaneTimeResidual();
        break;
      case 2:
        timeres= -stations[iS].GetCurvatureTimeResidual();
        break;
      default: timeres=0; break;
      }

      timeRes.push_back(timeres);
      timeResErr.push_back(sqrt(stations[iS].GetSignalTimeSigma2Intrinsic(sdRecShower.GetZenith())));
      timeStart.push_back(stations[iS].GetSignalStartSlot());
      timeEnd.push_back(stations[iS].GetSignalEndSlot());
      t50.push_back(stations[iS].GetTime50()+timeres);
      t50RMS.push_back(stations[iS].GetTime50RMS());
      t10.push_back(stations[iS].GetTime50()-stations[iS].GetRiseTime());

      if (fSdTimeRes)
        fallTime.push_back(stations[iS].GetFallTime()+timeres);
      else
        fallTime.push_back(stations[iS].GetFallTime());
      fallTimeRMS.push_back(stations[iS].GetFallTimeRMS());

      if (fSdTimeRes)
        riseTime.push_back(stations[iS].GetRiseTime()+timeres);
      else
        riseTime.push_back(stations[iS].GetRiseTime());
      riseTimeRMS.push_back(stations[iS].GetRiseTimeRMS());

      const double timeSec       = stations[iS].GetTimeSecond();
      const double timeNSec      = stations[iS].GetTimeNSecond();
      const Long64_t stationTime = Long64_t(timeSec)*Long64_t(1e9)
        + Long64_t(timeNSec);

      stcolor.push_back(fArrayPlot->GetColor(stationTime,
                                             stations[iS].GetPlaneTimeResidual(),
                                             stations[iS].GetAzimuthSP()));
      ++n;
    }

    if (stations[iS].IsAccidental()) {
      if (stations[iS].IsDense() && !EventBrowserConfig::Get(cfg::eShowMC))
        continue;

      const double r    = stations[iS].GetSPDistance();
      const double rErr = stations[iS].GetSPDistanceError();

      if (r == 0.0 || r > 5e3)
        continue;

      double timeres=0.;
      switch(fSdTimeRes) {
      case 1:
        timeres= -stations[iS].GetPlaneTimeResidual();
        break;
      case 2:
        timeres= -stations[iS].GetCurvatureTimeResidual();
        break;
      default: timeres=0; break;
      }

      const int i = accTimeResGraph->GetN();
      accTimeResGraph->SetPoint(i,r,timeres);
      accTimeResGraph->SetPointError(i,rErr,sqrt(stations[iS].GetSignalTimeSigma2Intrinsic(sdRecShower.GetZenith())));
    }

  }

  // zoom in

  double kresMax = 0.;
  double kresMin = 0.;
  double dMax = 0.;
  for (unsigned int i=0; i<timeRes.size(); ++i) {
    double mamamia_mic = 0;
    double mamamia_mare = 0;
    if (fSdTimeRes) {
      mamamia_mare+= timeRes[i]+timeResErr[i];
      mamamia_mic+= timeRes[i]-timeResErr[i];
    }
    if (fSdFallTime) {
      mamamia_mare+= fallTime[i]+ fallTimeRMS[i];
      mamamia_mic+= fallTime[i]- fallTimeRMS[i];
    }
    else
      if (fSdRiseTime) {
        mamamia_mare+= riseTime[i]+ riseTimeRMS[i];
        mamamia_mic+= riseTime[i]- riseTimeRMS[i];
      }
    kresMin= min(mamamia_mic, kresMin);
    kresMax= max(mamamia_mare, kresMax);
    dMax= max(sPDistance[i], dMax);
  }

  dMax+=1000.;
  kresMin-=50.;
  kresMax+=50.;


  TLegend* legend = new TLegend(0.2,0.51, 0.47, 0.96,NULL,"brNDC");
  legend->SetTextSize(0.045);
  legend->SetEntrySeparation(0.01);
  legend->SetFillColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);
  fEventObjects->Add(legend);

  if (n <= 1) {
    TLatex* Legend=new TLatex();
    Legend->SetNDC();
    Legend->SetTextAlign(12);
    Legend->SetTextSize(0.035);
    Legend->DrawLatex(0.4,0.5,"no times available");
    fCanvasTRes->GetCanvas()->Modified();
    fCanvasTRes->GetCanvas()->Update();
    fEventObjects->Add(Legend);
    return;
  }

  unsigned int notDrawn = 0;
  bool drawnaxis = false;
  if (fSdTimeRes) {
    ostringstream name;
    name << showpoint << setiosflags(ios::fixed) << setprecision(1);
    name << "#chi^{2}/NdF:  ";
    if (sdRecShower.GetAngleChi2()<0.1)
      name << "(< 0.1)/ ";
    else
      name << sdRecShower.GetAngleChi2() << "/ ";

    name << (sdRecShower.GetAngleNDoF()>0 ? int(sdRecShower.GetAngleNDoF()):0);

    legend->AddEntry("",name.str().c_str(), "");

    TGraphErrors* timeResGraph= new TGraphErrors(n,&sPDistance[0],&timeRes[0],
                                                 &sPDistanceErr[0],&timeResErr[0]);
    fEventObjects->Add(timeResGraph);
    timeResGraph->GetXaxis()->SetTitle("r[m]");
    timeResGraph->GetYaxis()->SetTitle("Time [ns]");
    timeResGraph->SetTitle("");
    timeResGraph->SetMarkerStyle(20);
    timeResGraph->SetMarkerColor((*fStyleManager)->GetTimeResColor());
    timeResGraph->SetLineColor((*fStyleManager)->GetTimeResColor());
    timeResGraph->GetXaxis()->SetRangeUser(0.,dMax);
    timeResGraph->GetYaxis()->SetRangeUser(kresMin,kresMax);
    legend->AddEntry(timeResGraph, "time residual", "lp");
    if (!drawnaxis){
      timeResGraph->Draw("AP");
      drawnaxis= true;
    }
    else
      timeResGraph->Draw("P");

    if (fSdTimeRes == 1) {

      if (sdRecShower.GetCurvature()) {
        const double rc = sdRecShower.GetRadiusOfCurvature();
        const double rcError = sdRecShower.GetRadiusOfCurvatureError();

        vector<double> timingR;
        vector<double> timingCurve;
        vector<double> timingCurveErrUp;
        vector<double> timingCurveErrLow;
        const int nPoints = 500;
        const double dr = dMax/(nPoints - 1);
        for (int i = nPoints - 1; i >= 0; --i) {
          const double r = i*dr;
          timingR.push_back(r);
          const double rcUp = rc+rcError;
          const double rcLow = rc-rcError;
          const double value = (sqrt(r*r+rc*rc) - (rc))/2.99*10.;
          const double valueUp = (sqrt(r*r+rcUp*rcUp) - (rcUp))/2.99*10.;
          const double valueLow = (sqrt(r*r+rcLow*rcLow) - (rcLow))/2.99*10.;
          timingCurve.push_back(value);
          timingCurveErrUp.push_back(fabs(valueUp-value));
          timingCurveErrLow.push_back(fabs(valueLow-value));

        }
        TGraphAsymmErrors* grCurvature = new TGraphAsymmErrors(timingR.size(),
                                                               &timingR[0], &timingCurve[0],
                                                               0, 0, &timingCurveErrUp[0], &timingCurveErrLow[0]);
        fEventObjects->Add(grCurvature);

        grCurvature->SetLineColor(kYellow+10);
        grCurvature->SetFillColor(kYellow+10);
        grCurvature->SetFillStyle(3001);
        grCurvature->SetLineWidth(1);
        grCurvature->Draw("e3");
        grCurvature->Draw("lxsame");

        timeResGraph->Draw("P");
      }
    }




    for (unsigned int i=0; i<timeRes.size(); ++i){
      TMarker* coloredMark = new TMarker( sPDistance[i],timeRes[i],
                                          timeResGraph->GetMarkerStyle());
      coloredMark->SetMarkerColor(stcolor[i]);
      coloredMark->SetMarkerSize(0.65*timeResGraph->GetMarkerSize());
      coloredMark->Draw("same");
      fEventObjects->Add(coloredMark);
    }


  } else {
    ++notDrawn;
  }


  if (fSdTimeRes && accTimeResGraph->GetN()>0) {
    accTimeResGraph->SetMarkerStyle(24);
    accTimeResGraph->SetMarkerSize(0.75);
    accTimeResGraph->SetLineColor((*fStyleManager)->GetLDFAccColor());
    accTimeResGraph->SetMarkerColor((*fStyleManager)->GetLDFAccColor());
    accTimeResGraph->Draw("ps");
    legend->AddEntry(accTimeResGraph, "removed", "lp");
  }
  else {
    ++notDrawn;
  }


  if (fSdRiseTime){

    TGraphErrors* riseTimeGraph= new TGraphErrors(n,&sPDistance.front(),
                                                  &riseTime.front(),
                                                  0, //&sPDistanceErr[0],
                                                  &riseTimeRMS.front());
    fEventObjects->Add(riseTimeGraph);
    riseTimeGraph->GetXaxis()->SetTitle("r[m]");
    riseTimeGraph->GetYaxis()->SetTitle("Time [ns]");
    riseTimeGraph->SetMarkerStyle(21);
    riseTimeGraph->SetMarkerSize(0.75);
    riseTimeGraph->SetMarkerColor((*fStyleManager)->GetRiseTimeColor());
    riseTimeGraph->SetTitle("");
    riseTimeGraph->SetLineColor((*fStyleManager)->GetRiseTimeColor());
    riseTimeGraph->GetXaxis()->SetRangeUser(0.,dMax);
    riseTimeGraph->GetYaxis()->SetRangeUser(kresMin,kresMax);
    legend->AddEntry(riseTimeGraph, "rise time", "lp");

    if (!drawnaxis){

      riseTimeGraph->Draw("AP");
      drawnaxis= true;
    }
    else
      riseTimeGraph->Draw("P");
  } else {
    ++notDrawn;
  }


  if (fSdFallTime){

    TGraphErrors* fallTimeGraph= new TGraphErrors(n,&sPDistance[0],&fallTime[0],
                                                  0,//&sPDistanceErr[0],
                                                  &fallTimeRMS[0]);
    fEventObjects->Add(fallTimeGraph);
    fallTimeGraph->GetXaxis()->SetTitle("r[m]");
    fallTimeGraph->GetYaxis()->SetTitle("Time [ns]");
    fallTimeGraph->SetMarkerStyle(21);
    fallTimeGraph->SetMarkerSize(0.75);
    fallTimeGraph->SetMarkerColor((*fStyleManager)->GetFallTimeColor());
    fallTimeGraph->SetTitle("");
    fallTimeGraph->SetLineColor((*fStyleManager)->GetFallTimeColor());
    fallTimeGraph->GetXaxis()->SetRangeUser(0.,dMax);
    fallTimeGraph->GetYaxis()->SetRangeUser(kresMin,kresMax);

    legend->AddEntry(fallTimeGraph, "fall time", "lp");
    if (!drawnaxis){
      fallTimeGraph->Draw("AP");
      drawnaxis= true;
    }
    else
      fallTimeGraph->Draw("P");
  } else {
    ++notDrawn;
  }


  if (fSdT50){

    TGraphAsymmErrors *time50Graph = new TGraphAsymmErrors(n,
                                                           &sPDistance[0],&t50[0],
                                                           0, 0,
                                                           &t10[0], &fallTime[0]);
    fEventObjects->Add(time50Graph);
    time50Graph->SetMarkerSize(0.75);
    time50Graph->SetMarkerStyle(27);
    time50Graph->SetLineColor((*fStyleManager)->GetRiseTimeColor()+2);
    time50Graph->SetMarkerColor((*fStyleManager)->GetRiseTimeColor()+2);
    time50Graph->SetTitle("");

    legend->AddEntry(time50Graph, "T50 (-T10 + T90)", "lp");
    if (!drawnaxis){

      time50Graph->Draw("AP");
      drawnaxis= true;
    }
    else
      time50Graph->Draw("P");
  } else {
    ++notDrawn;
  }



  if (drawnaxis) {
    TF1* f= new TF1("f","0", 0, dMax);
    fEventObjects->Add(f);
    f->SetLineColor(kBlue);
    f->SetLineWidth(1);
    f->SetLineStyle(2);
    f->Draw("same");
  }
  else {
    TLatex* Legend=new TLatex();
    Legend->SetNDC();
    Legend->SetTextAlign(12);
    Legend->SetTextSize(0.055);
    Legend->DrawLatex(0.2,0.5,"Please select something to be drawn");
    fCanvasTRes->GetCanvas()->Modified();
    fCanvasTRes->GetCanvas()->Update();
    fEventObjects->Add(Legend);
    return;
  }
  for (unsigned int i=0; i<notDrawn; ++i)
    legend->AddEntry("", " ", "");

  legend->Draw();
  fCanvasTRes->GetCanvas()->Modified();
  fCanvasTRes->GetCanvas()->Update();

}

std::string
SdPlots::PrintPostScript()
{
  cout << "\nPrinting Sd event" << endl;

  const int evId= (*fEvent)->GetSDEvent().GetEventId();

  ostringstream arrayFileStream;
  arrayFileStream << "/tmp/tmp" << evId << "_array.eps";
  const char* arrayFile = arrayFileStream.str().c_str();
  fCanvasArray->cd();
  fCanvasArray->Print(arrayFile);

  ostringstream ldfFileStream;
  ldfFileStream << "/tmp/tmp" << evId << "_ldf.eps";
  const char* ldfFile = ldfFileStream.str().c_str();
  fCanvasLDF->cd();
  fCanvasLDF->Print(ldfFile);

  ostringstream timeFileStream;
  timeFileStream << "/tmp/tmp" << evId << "_time.eps";
  const char* timeFile = timeFileStream.str().c_str();
  fCanvasTRes->cd();
  fCanvasTRes->Print(timeFile);

  ostringstream infoFileStream;
  infoFileStream << "/tmp/tmp" << evId << "_info.eps";
  const char* infoFile = infoFileStream.str().c_str();
  fCanvasInfo->cd();
  fCanvasInfo->Print(infoFile);


  ostringstream filenameStream;
  filenameStream << "SdEvent_" << evId << ".ps";
  const string filename = filenameStream.str();
  ostringstream commandStream;

  commandStream << ADST_BIN_DIR << "/SdEvent2ps.csh "
                << evId << " " << filename;

  const char* command = commandStream.str().c_str();

  int res = system(command);


  return (res == 0 ? filename : string(""));
}


void SdPlots::UpdateArrayPlot() {
  if (EventBrowserConfig::Get(cfg::eSdShowShowerPlaneArray))
    fArrayPlot->DrawShowerPlaneArray(true, EventBrowserConfig::Get(cfg::eSdShowFd), fIsMC && EventBrowserConfig::Get(cfg::eShowMC));
  else
    fArrayPlot->Draw(true, EventBrowserConfig::Get(cfg::eSdShowFd), fIsMC && EventBrowserConfig::Get(cfg::eShowMC));
}


void SdPlots::UpdateMPD(const SdRecStation& station){

  if (!station.HasMPD())
    return;
  const vector<double>& depth = station.GetMPDDepth();
  const vector<double>& depthEr = station.GetMPDDepthError();
  const vector<double>& signal = station.GetMPDSignal();
  const double minAxis = 100;//fmin(100.1, depth.front()-50.);
  const double maxAxis = fmax(1299.1, depth.back()-50.);
  TProfile* mpdProfile = new TProfile("mpdProfile", ";X[g/cm^{2}];S [a.u.]",
                                      30, minAxis, maxAxis);

  fPMTObjects->Add(mpdProfile);

  TGraphErrors* mpdGraph = new TGraphErrors();
  fPMTObjects->Add(mpdGraph);

  for (unsigned int depthIter = 0; depthIter< depth.size(); ++depthIter){
    mpdProfile->Fill(depth[depthIter], signal[depthIter]);
    mpdGraph->SetPoint(depthIter, depth[depthIter], signal[depthIter]);
    mpdGraph->SetPointError(depthIter, depthEr[depthIter],0);
  }

  fCanvasMPD->cd(1);
  mpdProfile->SetMarkerStyle(20);
  mpdProfile->Draw("lp");
  mpdProfile->SetMarkerColor(kRed);
  mpdGraph->Draw("p*same");
  mpdProfile->Draw("psame");

  TH1F* meanVEMHisto = new TH1F("meanVEMHisto",
                                ";t[25 ns];S[VEM peak]", 765, 0, 765);
  fPMTObjects->Add(meanVEMHisto);

  int nrPMTs = 0;
  for (unsigned int pmtId = 1; pmtId<4; ++pmtId){
    const vector<float>& vem = station.GetVEMTrace(pmtId);
    if (!vem.empty()){
      for (unsigned int i  = 0; i< vem.size(); ++i){
        meanVEMHisto->Fill(i, vem[i]);
      }
      ++nrPMTs;
    }
    if (nrPMTs){
      meanVEMHisto->Scale(nrPMTs);
      fCanvasMPD->cd(2);
      meanVEMHisto->GetXaxis()->SetRangeUser(200, 400);
      meanVEMHisto->Draw();
    }
  }



  fCanvasMPD->Update();
}



void SdPlots::UpdateCalib(const vector<Traces>& traces){

  for (vector<Traces>::const_iterator trIter = traces.begin();
       trIter != traces.end(); ++trIter) {
    const Traces& tr = *trIter;
    if (tr.GetType() != eTotalTrace)
      continue;

    const unsigned int pmtId = tr.GetPMTId();
    const CalibHistogram& calibHisto = tr.GetChargeHistogram();
    const vector<double>& bins = calibHisto.GetBinning();
    const vector<Int_t>& values = calibHisto.GetValues();

    vector<double> valEr;
    vector<double> val;
    for (unsigned int k = 0; k<values.size(); ++k){
      valEr.push_back(sqrt((double)values[k]));
      val.push_back((double)values[k]);
    }
    fCanvasCalib->cd(pmtId);

    TGraphErrors* chargeGraph = new TGraphErrors(bins.size(), &bins.front(),
                                                 &val.front(),
                                                 0, &valEr.front());
    ostringstream name;
    name << "charge_" << pmtId;
    chargeGraph->SetName(name.str().c_str());
    name.str("");
    name << "PMT " << pmtId << "; Charge [FADC]";
    chargeGraph->SetTitle(name.str().c_str());
    fPMTObjects->Add(chargeGraph);
    chargeGraph->Draw("al");
    chargeGraph->GetXaxis()->SetRangeUser(0, 400);

    const double charge = tr.GetCharge();
    //    const double chargeEr = tr.GetChargeError();

    TLine* chargeLine= new TLine(charge, 0, charge,
                                 chargeGraph->GetYaxis()->GetXmax());
    fPMTObjects->Add(chargeLine);
    chargeLine->SetLineColor(kRed);
    chargeLine->SetLineStyle(2);
    chargeLine->Draw("same");


    const CalibHistogram& peakHisto = tr.GetPeakHistogram();
    const vector<double>& binsPeak = peakHisto.GetBinning();
    const vector<Int_t>& valuesPeak = peakHisto.GetValues();

    valEr.clear();
    val.clear();
    for (unsigned int k = 0; k<values.size(); ++k){
      valEr.push_back(sqrt((double)valuesPeak[k]));
      val.push_back((double)valuesPeak[k]);
    }
    fCanvasCalib->cd(pmtId+3);

    TGraphErrors* peakGraph = new TGraphErrors(binsPeak.size(),
                                               &binsPeak.front(),
                                               &val.front(),
                                               0, &valEr.front());
    name.str("");
    name << "peak_" << pmtId;
    peakGraph->SetName(name.str().c_str());
    name.str("");
    name << "PMT " << pmtId << "; Peak [FADC]";
    peakGraph->SetTitle(name.str().c_str());



    fPMTObjects->Add(peakGraph);
    peakGraph->Draw("al");
    peakGraph->GetXaxis()->SetRangeUser(0, 100);
    //    peakGraph->SetMarkerStyle(20);

    const double peak = tr.GetPeak();
    // double peakEr = tr.GetPeakError();

    TLine* peakLine= new TLine(peak, 0, peak,
                               peakGraph->GetYaxis()->GetXmax());
    fPMTObjects->Add(peakLine);
    peakLine->SetLineColor(kRed);
    peakLine->SetLineStyle(2);
    peakLine->Draw("same");

  }

  fCanvasCalib->GetCanvas()->Modified();
  fCanvasCalib->GetCanvas()->Update();
}
