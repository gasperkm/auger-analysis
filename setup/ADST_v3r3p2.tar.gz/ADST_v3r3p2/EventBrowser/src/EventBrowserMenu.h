#ifndef __INCLUDE_EventBrowserMenu_H__
#define __INCLUDE_EventBrowserMenu_H__

class TGWindow;
class TGCompositeFrame;
class TGMenuBar;
class TGLayoutHints;
class TGPopupMenu;


class  EventBrowserMenu {

public:
  EventBrowserMenu  (TGCompositeFrame* main);
  ~EventBrowserMenu();

  bool ToggleAnimation();
  bool ToggleSpeedAnimation();
  bool ToggleShowerPlaneArray();
  bool ToggleShowMC();
  bool ToggleShowMCTraces();
  bool ToggleShowBadStations();
  bool ToggleShowPMTSignals();
  bool ToggleShowLDFOnArray();
  bool ToggleAperture();
  bool ToggleShowViewableFOV();
  bool ToggleShowTelsInDAQ();
  bool ToggleUseLCEfficiency();
  bool ToggleFDinSD();
  bool ToggleZeta();
  bool ToggleSDinFD();
  bool ToggleFDT3SDP();
  bool ToggleFDXmaxSDP();
  bool ToggleAllTracesinSD();
  bool ToggleSDinRD();
  bool ToggleFDinRD();
  bool ToggleSDinMD();
  bool ToggleFDinMD();
  void SetShowTelApertureLight();
  void SetShowEyeApertureLight();
  void SetShowEyeAndTelApertureLight();

  bool ToggleShowAerosols();
  bool ToggleShowCloudsOnArray();

  void EnableMC();


private:

  bool ToggleFDEntry(const int entryId);
  bool ToggleAtmoEntry(const int entryId);

  TGMenuBar* fMenuBar;

  TGLayoutHints* fMenuBarLayout;
  TGLayoutHints* fMenuBarItemLayout;
  TGLayoutHints* fMenuBarHelpLayout;

  TGPopupMenu* fMenuFile;
  TGPopupMenu* fMenuFDOptions;
  TGPopupMenu* fMenuApertureLightOptions;
  TGPopupMenu* fMenuSDOptions;
  TGPopupMenu* fMenuAtmoOptions;
  TGPopupMenu* fMenuMCOptions;
  TGPopupMenu* fMenuRDOptions;
  TGPopupMenu* fMenuMDOptions;
  TGPopupMenu* fMenuHelp;
};



#endif
