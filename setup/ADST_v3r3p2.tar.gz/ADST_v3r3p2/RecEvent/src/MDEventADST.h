// #include <RConfigure.h>
/*

   Martin Maur
   14 Apr 2012

*/

#ifndef __MDEventADST_h_
#define __MDEventADST_h_

#include <TObject.h>
#include <vector>
#include "MdRecCounter.h"
#include "MdSimCounter.h"
#include "MdRecShower.h"
#include "MdRecLevel.h"

class MDEvent: public TObject {
public:

  typedef std::vector<MdRecCounter> CounterList;
  typedef CounterList::iterator CounterIterator;
  typedef std::vector<MdSimCounter> SimCounterList;
  typedef SimCounterList::iterator SimCounterIterator;

  MDEvent();
  virtual ~MDEvent(){}

  // Reconstructed shower methods
  int GetEventId() const { return fMdEventId; }
  void SetId(const int event) { fMdEventId = event; }
  void SetNumberOfCandidates(unsigned int c){fNumberOfCandidates = c;}
  unsigned int GetNumberOfCandidates()const {return fNumberOfCandidates;}
  MdRecShower& GetMdRecShower() { return fMdRecShower; }
  const MdRecShower& GetMdRecShower() const { return fMdRecShower; }
  EMdRecLevel GetRecLevel() const {return fRecLevel;}
  void SetRecLevel(const EMdRecLevel level){fRecLevel = level;}
  bool HasRecEvent() const {return bool(fRecLevel);}
  bool HasLDF() const {return bool(fRecLevel == eHasMdLDF);}

  // Reconstructed counter methods
  void AddCounter(const MdRecCounter& c) {fCounters.push_back(c);}
  unsigned int GetNumberOfCounters() const { return fCounters.size(); }
  bool HasCounters() const { return !fCounters.empty(); }
  bool HasCounter(unsigned int id) const;
  bool HasCounterBySdPartnerId(unsigned int id) const;
  CounterIterator CountersBegin() {return fCounters.begin();}
  CounterIterator CountersEnd() { return fCounters.end();}
  MdRecCounter* GetCounter(unsigned int id);
  MdRecCounter* GetCounterBySdPartnerId(unsigned int id);
  // counter with the highest muon density (not using number of muons due to size differences)
  MdRecCounter* GetHottestCounter();

  // Simulated counter methods
  void AddSimCounter(const MdSimCounter& c) {fSimCounters.push_back(c);};
  unsigned int GetNumberOfSimCounters() const { return fSimCounters.size(); }
  bool HasSimCounters() const { return !fSimCounters.empty(); }
  bool HasSimCounter(unsigned int id) const;
  bool HasSimCounterBySdPartnerId(unsigned int id) const;
  SimCounterIterator SimCountersBegin() {return fSimCounters.begin();}
  SimCounterIterator SimCountersEnd() { return fSimCounters.end();}
  MdSimCounter* GetSimCounter(unsigned int id);
  MdSimCounter* GetSimCounterBySdPartnerId(unsigned int id);

private:
  int fMdEventId;
  unsigned int fNumberOfCandidates;
  MdRecShower fMdRecShower;
  SimCounterList fSimCounters;
  CounterList fCounters;
  EMdRecLevel fRecLevel;

  ClassDef(MDEvent, 3);
};


#endif // __MDEvent_h_
