#ifdef __CINT__

#pragma link C++ class RdEvent+;
#pragma link C++ class RdRecShower+;
#pragma link C++ class RdRecStation+;
#pragma link C++ class RdRecChannel+;
#pragma link C++ class std::vector<RdRecStation>+;
#pragma link C++ class std::vector<RdRecChannel>+;
#pragma link C++ class RdTrace+;
#pragma link C++ class SimRdPulse+;
#pragma link C++ class RdBeamPeak+;
#pragma link C++ class RdBeamQuants+;
#pragma link C++ class RdLDF+;
#pragma link C++ class RdRecShowerParameterStorageMap+;
#pragma link C++ class RdRecStationParameterStorageMap+;
#pragma link C++ class RdRecChannelParameterStorageMap+;
#pragma link C++ class std::pair<revt::ShowerRRecDataQuantities,revt::ShowerRRecDataQuantities>+;
#pragma link C++ class std::pair<revt::StationRRecDataQuantities,revt::StationRRecDataQuantities>+;
#pragma link C++ class std::pair<revt::ChannelRRecDataQuantities,revt::ChannelRRecDataQuantities>+;

#endif
