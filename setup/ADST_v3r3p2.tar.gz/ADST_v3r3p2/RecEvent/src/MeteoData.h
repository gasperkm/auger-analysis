#ifndef _adst_MeteoData_h_
#define _adst_MeteoData_h_

#include <TObject.h>
#include <algorithm>


enum WeatherInfoType {
  ePressure,
  eTemperature,
  eHumidity,
  eDayPressure,
  eDayTemperature,
  eDayHumidity,
  eNInfoTypes
};


class MeteoData {
public:
  MeteoData() { std::fill(fWeatherInfo, fWeatherInfo + eNInfoTypes, 0); }

  ~MeteoData() { }

  float GetWeatherInformation(const WeatherInfoType wtype) const { return fWeatherInfo[wtype]; }

  void
  SetWeatherInformation(const WeatherInfoType wtype, const float val)
  {
    fWeatherInfo[wtype] = val;
  }

private:
  float fWeatherInfo[eNInfoTypes];

  ClassDefNV(MeteoData, 1);

};


#endif
