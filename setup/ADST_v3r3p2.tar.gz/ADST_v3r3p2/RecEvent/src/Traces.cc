// $Id: Traces.cc 26094 2014-07-16 11:39:36Z darko $
#include <Traces.h>



ClassImp(Traces);
ClassImp(CalibHistogram);


Traces::Traces() :
  fTraceType(eTotalTrace),
  fVEMPeak(0),
  fVEMCharge(0),
  fVEMPeakEr(0),
  fVEMChargeEr(0),
  fVEMSignal(0),
  fIsVEMPeakFromHistogram(false),
  fIsVEMChargeFromHistogram(false),
  fDynodeAnodeRatio(0),
  fMuonPulseDecayTime(0),
  fMuonPulseDecayTimeEr(0),
  fBaseline(0),
  fBaselineRMS(0),
  fBaselineLG(0),
  fBaselineLGRMS(0),
  fIsTubeOK(true),
  fIsLowGainOK(true),
  fPMTId(0)
{ }


void
Traces::Clear(Option_t * /*option*/)
{
  fVEMPeak = 0;
  fVEMCharge = 0;
  fVEMPeakEr = 0;
  fVEMChargeEr = 0;
  fVEMSignal = 0;
  fIsVEMPeakFromHistogram = false;
  fIsVEMChargeFromHistogram = false;
  fDynodeAnodeRatio = 0;
  fBaseline = 0;
  fBaselineRMS = 0;
  fBaselineLG = 0;
  fBaselineLGRMS = 0;
  fPMTId = 0;
  fLow.clear();
  fHigh.clear();
  fVEM.clear();
}
