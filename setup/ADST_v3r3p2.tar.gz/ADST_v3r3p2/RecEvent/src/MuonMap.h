#ifndef __MuonMap_H
#define __MuonMap_H

#include <TObject.h>

#include <vector>
#include <iostream>
#include <string>

//
//  class to hold the muon map 
//

class MuonMapPoint: public TObject {

public: 
  MuonMapPoint();
  MuonMapPoint(const double x, const double y, 
               const double electronSignal); 
  
  ~MuonMapPoint();

  const double& GetX() const { return fX; }
  const double& GetY() const { return fY; }
  const double& GetElectronSignal() const { return fElectronSignal; }
  
private:
  double fX;
  double fY;
  double fElectronSignal;
  
  ClassDef (MuonMapPoint, 1)
    
};
    


class MuonMapContour: public TObject {

public: 
  MuonMapContour();
  ~MuonMapContour();
  
  typedef std::vector<MuonMapPoint> PointsList;
  typedef PointsList::iterator PointsIterator;
  typedef PointsList::const_iterator ConstPointsIterator;
  
  void AddPoint(const MuonMapPoint& myPoint){ 
    fPointsList.push_back(myPoint); 
  }
  
  const PointsList& GetPoints() const {return fPointsList; }
  unsigned int GetNumberOfPoints() const {return fPointsList.size(); }
  
  void SetContourSignal(const double signal){fContourSignal= signal; }
  const double& GetContourSignal() const {return fContourSignal; }
  
  void  ClearMap(){ fPointsList.clear(); }
  
  
private:
  
  PointsList fPointsList;
  double fContourSignal; 
  
  ClassDef (MuonMapContour, 2)
  
};






class MuonMap: public TObject {

  //this is supposed to interpolate by itself, etc
   
public:
  
  MuonMap();
  ~MuonMap();
  
  typedef std::vector<MuonMapContour> ContourList;
  typedef ContourList::iterator ContourIterator;
  typedef ContourList::const_iterator ConstContourIterator;
  
  
  void AddContour(const MuonMapContour& myContour){ 
    fContours.push_back(myContour); 
  }
  
  const ContourList& GetContours() const{ return fContours; }
  unsigned int GetNumberOfContours() const; 
  
  void SetMagneticFieldAzimuth(const double azi){fMagneticFieldAzimuth= azi;}
  const double& GetMagneticFieldAzimuth() const {return fMagneticFieldAzimuth;}

  void SetMuonMapType(const std::string muonMapType) { fMuonMapType = muonMapType; }
  const std::string GetMuonMapType() const { return fMuonMapType; }

  void ClearMap(); 
  
private:
  ContourList fContours; 
  double fMagneticFieldAzimuth;
  std::string fMuonMapType;
  
  ClassDef (MuonMap, 3)
};


#endif
