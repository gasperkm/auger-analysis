/**
   \file
   StationRRecDataQuantities quantities to be stored in ParameterStorage objects of StationRecData
   \version $Id: StationRRecDataQuantities.h 28752 2016-04-11 10:30:41Z aherve $
*/

#ifndef _revt_StationRRecDataQuantities_h_
#define _revt_StationRRecDataQuantities_h_

// static const char CvsId_revt_StationRRecDataQuantities[] = "$Id: StationRecData.h ";

/**
 * all quantities are in auger units
 * all times are with respect to the event time (REvent::GetHeader().GetTime(); )
 * if you add a quantity, please explain this quantity in a comment, and include in which module it is set
 */

namespace revt {
  
enum StationRRecDataQuantities {
  eSignal =  1,         // strength of the signal according to definition [RdStationSignalReconstructor]
  eSignalTime =  2,     // time at which the signal was found, relative to the event start time [RdStationSignalReconstructor]
  eNoise =  3,          // RMS of trace as determined in the noise window [RdStationSignalReconstructor]
  eSignalToNoise =  4,  // signal-to-noise ratio according to definition [RdStationSignalReconstructor]
  
  eNoiseWindowStart =  5,         // relative to trace start time! start and stop of the noise window. inside this window the rms is calculated, set by the RdEventInitializer
  eNoiseWindowStop =  6,          // relative to trace start time!
  eSignalWindowStart =  7,        // relative to trace start time! start and stop of the window in which the signal was determined, see configuration of RdStationSignalReconstructor
  eSignalWindowStop =  8,         // relative to trace start time!
  eSignalSearchWindowStart =  9,  // relative to trace start time! start and stop of the signal search window. inside this window the search for the signal (e.g. max. amplitude) is performed, set by the RdEventInitializer and corrected by any module which changes trace start time
  eSignalSearchWindowStop =  10,  // relative to trace start time!
  
  ePolarizationTheta =  11,     // [RdStationSignalReconstructor] - definition unclear
  ePolarizationPhi =  12,       // [RdStationSignalReconstructor] - definition unclear
  
  ePeakAmplitudeNS =  13,       // maximum amplitude (inside signal window) of efield trace in NS-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeEW =  14,       // maximum amplitude (inside signal window) of efield trace in EW-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeV =  15,        // maximum amplitude (inside signal window) of efield trace in Vertical-Polarisation (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeMag =  16,      // maximum amplitude (inside signal window) of the quadratic sum of the three polarisations (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  ePeakAmplitudeNSEWPlane = 65, // maximum amplitude (inside signal window) of the projection of the efield on the XY plane (the amplitude may be calculated on hilbert envelope depending on RdStationSignalReconstructor's settings)
  
  ePeakTimeNS =  17,          // times at which the maximum amplitudes described above were found [RdStationSignalReconstructor]
  ePeakTimeEW =  18,          // these 4 times are relative to the event time 
  ePeakTimeV =  19,
  ePeakTimeMag =  20,
  ePeakTimeNSEWPlane = 66,
  
  eNoiseRmsEW =  21,        // RMS (inside noise window) of EW-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsNS =  22,        // RMS (inside noise window) of NS-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsV =  23,         // RMS (inside noise window) of Vertical-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsMag =  24,       // RMS (inside noise window) of quadratic sum of all polarisations of Efield trace [RdStationSignalReconstructor]
  eNoiseRmsNSEWPlane = 67,  // RMS (inside noise window) of projection on XY plane of Efield trace [RdStationSignalReconstructor]

  eNoiseMeanNS =  25,       // Mean (inside noise window) of NS-Polarisation of Efield trace [RdStationSignalReconstructor] 
  eNoiseMeanEW =  26,       // Mean (inside noise window) of EW-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseMeanV =  27,        // Mean (inside noise window) of Vertical-Polarisation of Efield trace [RdStationSignalReconstructor]
  eNoiseMeanMag =  28,      // Mean (inside noise window) of quadratic sum of all polarisations of Efield trace [RdStationSignalReconstructor]
  eNoiseMeanNSEWPlane = 68, // Mean (inside noise window) of projection on XY plane of Efield trace [RdStationSignalReconstructor]
  
  eMinSignal =  29,         // Minimum signal strength to set the pulsefound flag to true [RdStationSignalReconstructor.xml]
  eMinSignalToNoise =  30,  // Minimum signal to noise to set the pulsefound flag to true [RdStationSignalReconstructor.xml]
  
  eSignalFWHMNS =  31,       // integral of the NS signal over the time given by the FWHM of the found pulse [RdStationSignalReconstructor]
  eSignalFWHMEW =  32,       // integral of the EW signal over the time given by the FWHM of the found pulse [RdStationSignalReconstructor]
  eSignalFWHMV =  33,        // integral of the vertical signal over the time given by the FWHM of the found pulse [RdStationSignalReconstructor]
  eSignalFWHMMag =  34,      // integral of the total signal over the time given by the FWHM of the found pulse [RdStationSignalReconstructor]
  eSignalFWHMNSEWPLane = 69, // integral of the horizontal plane signal over the time given by the FWHM of the found pulse [RdStationSignalReconstructor]
  
  eIntegratedSignalNS =  35,       // integral of the NS signal over the configured time around the found pulse [RdStationSignalReconstructor]
  eIntegratedSignalEW =  36,       // integral of the EW signal over the configured time around the found pulse [RdStationSignalReconstructor]
  eIntegratedSignalV =  37,        // integral of the vertical signal over the configured time around the found pulse [RdStationSignalReconstructor]
  eIntegratedSignalMag =  38,      // integral of the total signal over the configured time around the found pulse [RdStationSignalReconstructor]
  eIntegratedSignalNSEWPlane = 70, // integral of the horizontal plane signal over the configured time around the found pulse [RdStationSignalReconstructor]
  
  ePolarizationThetaMaxTime =  39,  //  [RdStationSignalReconstructor] - definition unclear
  ePolarizationPhiMaxTime =  40,    //  [RdStationSignalReconstructor] - definition unclear
  ePolarizationThetaSameTime =  41, //  [RdStationSignalReconstructor] - definition unclear
  ePolarizationPhiSameTime =  42,   //  [RdStationSignalReconstructor] - definition unclear
  
//obsolete = 43,              // this parameter slot is obsolete, do not re-use!

  eTraceStartTime = 44,  // start time of the trace with respect to the event time, set by the RdEventInitializer

  eEFieldVectorNS = 45,       // the weighted mean of the NS component of all efield vectors within the FWHM interval (the weighting factor is the length of the vector). The length is set to "eSignal" [RdStationEfieldVectorCalculator]
  eEFieldVectorEW = 46,       // dito EW [RdStationEfieldVectorCalculator]
  eEFieldVectorV = 47,        // dito V [RdStationEfieldVectorCalculator]
  eAngleToLorentzVector = 48, // angular difference between electric field vector and the Lorentz force vector resulting from the incoming direction of the shower and the magnetic field of the earth

  eTimeResidual = 49,  //Time residual of the station [RdPlaneFit][RdWaveFit]

  // Stokes parameter of the pulse, see [GAP-2011-088]
  // The reference coordinate system for these parameters depends on the settings in the RdPolarizationReconstructor.
  eStokesI = 50, //Stokes parameter I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesQ = 51, //Stokes parameter Q [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesU = 52, //Stokes parameter U [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesV = 53, //Stokes parameter V [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioQdivI = 54, // Q/I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioUdivI = 55, // U/I [RdPolarizationReconstructor] [GAP-2011-088]
  eStokesRatioVdivI = 56, // V/I [RdPolarizationReconstructor] [GAP-2011-088]
  ePolarizationAngle = 57, // [RdPolarizationReconstructor] Contains the Polarization angle of the pulse
  eObserverAngle = 58, // [RdPolarizationReconstructor] Contains the observer angle with respect to the shower core in the projected vxB frame
  eAlpha = 59, // [RdPolarizationReconstructor] Contains opening the angle of the shower's arrival direction with the earth magnetic field
  
  //Station rejection status
  eMaxAmplitudeOutsideSignalSearchWindow = 60, // Contains the maximum amplitude of the three electric field channels combined ( sqrt(x^2+y^2+z^2) ) outside the signal search window in order to be able to do a quality cut
  // eStationRejected =61,                        // this parameter is obsolete, do not re-use; originally set if the station was rejected, [RdStationRejector]
  
  // The arrival direction of the signal in a station is stored as the direction of a (x,y,z) vector
  // in the local cooredinate system of the station
  // This vector is always perpendicular to the shower front at the position of the station.
  // There a two special cases:
  // for a plane wave approximation, this vector is parallel to the shower axis,
  // for a spherical wavefront approximation, it points towards the point source of the signal,
  eSignalArrivalDirectionX = 62, // x-component of vector for signal arrival direction (perpendicular to wavefront)
  eSignalArrivalDirectionY = 63, // y-component of vector for signal arrival direction (perpendicular to wavefront)
  eSignalArrivalDirectionZ = 64, // z-component of vector for signal arrival direction (perpendicular to wavefront)

  // CAUTION: 65 to 70 are used for NSEWPlane parameters defined further up, start counting at 71 for new parameters
  eAngleToExpectedEFieldVector = 71, // angle between direction of measured efield vector and expected efield vector due to geo-magnetic and charge excess emission [RdStationEFieldVectorCalculator]
  
  //values stored for further analysis taken from one on the Scintillators according to setting of [RdScintSignalReconstructor]
  eAERAScintStationSignalHeight =  72,         // strength of the bigger scintillator signal according to definition [RdScintSignalReconstructor]
  eAERAScintStationSignalTime =  73,            // time at which the signal was found, relative to the event start time [RdScintSignalReconstructor]
  eAERAScintStationTimeResidual = 74,          // Time residual of the Scint station [RdScintPlaneFit]
  eAERAScintStationVEM =  75,                   // scintillator signal in Vertical Equivalent Muons according to definition (for now always TOP) [RdScintSignalReconstructor] 
  eAERAScintStationDepositedEnergy =  76,       // deposited Energy in the Scintillator according to definition (for now always TOP) [RdScintSignalReconstructor]

  eSignalEnergyDensityNS =  77,       // integral of the squared NS signal over the configured time around the found pulse (noise subtracted) and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]
  eSignalEnergyDensityEW =  78,       // integral of the squared EW signal over the configured time around the found pulse (noise subtracted) and converted to an energy density (unit eV/m^2)  [RdStationSignalReconstructor]
  eSignalEnergyDensityV =  79,        // integral of the squared vertical signal over the configured time around the found pulse (noise subtracted) and converted to an energy density (unit eV/m^2)  [RdStationSignalReconstructor]
  eSignalEnergyDensityMag =  80,      // integral of the squared total signal over the configured time around the found pulse  (noise subtracted) and converted to an energy density (unit eV/m^2)  [RdStationSignalReconstructor]
  eSignalEnergyDensityNSEWPlane = 81, // integral of the squared horizontal plane signal over the configured time around the found pulse (noise subtracted) and converted to an energy density (unit eV/m^2)  [RdStationSignalReconstructor]

  eNoiseEnergyDensityNS =  82,       // integral of the squared NS signal in the noise window normalized to the configured time and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]
  eNoiseEnergyDensityEW =  83,       // integral of the squared EW signal in the noise window normalized to the configured time and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]
  eNoiseEnergyDensityV =  84,        // integral of the squared vertical signal in the noise window normalized to the configured time and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]
  eNoiseEnergyDensityMag =  85,      // integral of the squared total signal in the noise window normalized to the configured time and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]
  eNoiseEnergyDensityNSEWPLane = 86, // integral of the squared horizontal signal in the noise window normalized to the configured time and converted to an energy density (unit eV/m^2) [RdStationSignalReconstructor]

  eStationRiseTime = 87,                        // risetime of the pulse found in  stationtrace with the highest SNR (calculated by RdStationSignalReconstructor) [RdStationRiseTimeCalculator]
  eTraceStartTimeCorrectionByGPSPosition = 88,   // timing correction that has been added to eTraceStartTime due to after-the-fact correction of GPS unit position [RdStationPositionCorrection]
  eTraceStartTimeCorrectionByBeacon = 89,        // timing correction that has been added to eTraceStartTime due to beacon timing correction [RdChannelBeaconTimingCalibrator]
  eTraceStartTimeCorrectionByTimeCalibration = 90,  // timing correction that has been added to eTraceStartTime due to timing calibration [RdStationTimingCalibrator]

  eLDFFitStationPositionVxB = 91,
  eLDFFitStationPositionVxVxB = 92,
  eLDFFitStationPositionV = 93,

  eCxxFraction = 94,  // charge excess fraction from measured polarization angle, see also eq. (5.4) in arxiv.org/abs/1406.1355 It can give rise to weird values if the observer angle is close to 0, 180, and 360 degrees  [RdPolarizationReconstructor] 

  eSignalSearchWindowTruncated = 95, // is set to true, if the signal search window was truncated [RdStationTimeWindowConsolidator]

  eAnalyticSignalVxBAmplitudeP0 = 96,
  eAnalyticSignalVxBAmplitudeP1 = 97,
  eAnalyticSignalVxBPhaseP0 = 98,
  eAnalyticSignalVxBPhaseP1 = 99,
  eAnalyticSignalVxVxBAmplitudeP0 = 100,
  eAnalyticSignalVxVxBAmplitudeP1 = 101,
  eAnalyticSignalVxVxBPhaseP0 = 102,
  eAnalyticSignalVxVxBPhaseP1 = 103,
  eSignalEnergyDensityVxBFit = 104,
  eSignalEnergyDensityVxVxBFit = 105,
  eSignalEnergyDensityShowerPlaneFit = 106,
  eSignalIntegrationTime = 107,     // [RdStationSignalReconstructor] width of the interval for pulse integration or signal shape fitting

  // quantities in shower plane
  ePeakAmplitudeVxB = 108,
  ePeakTimeVxB = 109,
  eNoiseRmsVxB = 110,
  eNoiseMeanVxB = 111,
  eSignalToNoiseVxB = 112,
  eSignalEnergyDensityVxB = 113,
  eNoiseEnergyDensityVxB = 114,

  ePeakAmplitudeVxVxB = 115,
  ePeakTimeVxVxB = 116,
  eNoiseRmsVxVxB = 117,
  eNoiseMeanVxVxB = 118,
  eSignalToNoiseVxVxB = 119,
  eSignalEnergyDensityVxVxB = 120,
  eNoiseEnergyDensityVxVxB = 121,


  // Christians private parameters for temporary use
  eBetaScan = 1001,
  eProbBetaScan = 1002,
  eBetaFit = 1003,
  eProbBetaFit = 1004,
  eBetaReferenceCore = 1005,
  eProbBetaReferenceCore = 1006,

  eOptimalChargeExcessStrength = 1007,  // charge excess strength that results in the smallest angle beta
  eBetaMin = 1008  // value of beta a optimal a


};


}

#endif

// Configure (x)emacs for this file ...
// Local Variables:
// mode: c++
// compile-command: "make -C .. -k"
// End:
