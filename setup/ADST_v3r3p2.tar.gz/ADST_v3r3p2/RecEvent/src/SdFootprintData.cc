/**
   \file

   \author Javier Gonzalez
   \version $Id: SdFootprintData.cc 22862 2013-03-01 23:18:55Z darko $
   \date 20 Apr 2012
*/

#include "SdFootprintData.h"


static const char CVSId[] = "$Id: SdFootprintData.cc 22862 2013-03-01 23:18:55Z darko $";


ClassImp(SdFootprintData);
