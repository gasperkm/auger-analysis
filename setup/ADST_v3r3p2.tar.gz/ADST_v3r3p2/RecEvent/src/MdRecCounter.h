/*

   Martin Maur
   14 Apr 2012
   Diego Ravignani
   24 Jun 2015 

*/

#ifndef __MdRecCounter_h_
#define __MdRecCounter_h_

#include <TObject.h>
#include <vector>
#include <MdRecModule.h>

class MdRecCounter: public TObject {
public:

  typedef std::vector<MdRecModule> ModuleList;
  typedef ModuleList::iterator ModuleIterator;

  MdRecCounter();
  virtual ~MdRecCounter(){}

  void SetId(const unsigned int id){fId=id;}
  unsigned int GetId() const {return fId;}

  void SetCandidate() {fRecStatus = eCandidate;}
  bool IsCandidate() const {return fRecStatus==eCandidate;}

  void SetSilent() {fRecStatus = eSilent;}
  bool IsSilent() const {return fRecStatus==eSilent;}

  void SetRejected() {fRecStatus = eRejected;}
  bool IsRejected() const {return fRecStatus==eRejected;}

  bool IsSaturated();

  void SetLDFResidual(const double c) {fLDFResidual = c;} ///< set the residual of LDF
  double GetLDFResidual() const {return fLDFResidual;}       ///< get the residual of LDF

  unsigned int GetNumberOfChannelsOn() const {return fNumberOfChannelsOn;}
  void SetNumberOfChannelsOn(const int nw) {fNumberOfChannelsOn = nw;}

  void SetNumberOfMuons(double noMuons) {fNumberOfMuons = noMuons;}
  double GetNumberOfMuons() const {return fNumberOfMuons;}

  void SetNumberOfMuonsErrorHigh(const double e) { fNumberOfMuonsErrorHigh=e; }
  double GetNumberOfMuonsErrorHigh() const { return fNumberOfMuonsErrorHigh; }    

  void SetNumberOfMuonsErrorLow(const double e) { fNumberOfMuonsErrorLow=e; }
  double GetNumberOfMuonsErrorLow() const { return fNumberOfMuonsErrorLow; }   

  void SetNumberOfMuonsLowLimit(const double e) { fNumberOfMuonsLowLimit=e; }
  double GetNumberOfMuonsLowLimit() const { return fNumberOfMuonsLowLimit; }

  void SetActiveArea(const double area) {fActiveArea = area;}
  double GetActiveArea() const {return fActiveArea;}

  void SetMuonDensity(double density) {fMuonDensity = density;}
  double GetMuonDensity() const {return fMuonDensity;} 

  void SetMuonDensityErrorHigh(double e) {fMuonDensityErrorHigh = e;}
  double GetMuonDensityErrorHigh() const {return fMuonDensityErrorHigh;} 

  void SetMuonDensityErrorLow(double e) {fMuonDensityErrorLow = e;}
  double GetMuonDensityErrorLow() const {return fMuonDensityErrorLow;} 

  TVector3 GetPosition() const { return fPosition; }
  void SetPosition(const TVector3 position) { fPosition=position; }

  // position in shower coordinate system
  // errors not filled, so the corresponding getters are commented out
  void SetSPDistance(const double c, const double e) {
    fSPDistance=c;fSPDistanceError=e;}
  double GetSPDistance() const {return fSPDistance;}
//  double GetSPDistanceError() const {return fSPDistanceError;}

  void SetSPAzimuth(const double c, const double e) {fSPAzimuth = c; fSPAzimuthError = e;}
  double GetSPAzimuth() const {return fSPAzimuth;}
//  double GetSPAzimuthError() const {return fSPAzimuthError;}

  void SetSPDelta(const double c, const double e) {fSPDelta=c;fSPDeltaError=e;}
  double GetSPDelta() const {return fSPDelta;}
//  double GetSPDeltaError() const {return fSPDeltaError;}

  void SetIsDense(const bool is = true) {fIsDense = is;}
  bool IsDense() const {return fIsDense;}

  unsigned int GetSdPartnerId() const {return fSdPartnerId;}
  void SetSdPartnerId(int partnerId){fSdPartnerId = partnerId;}

  void SetRecDataFlag(bool status) {fRecData = status;}
  bool HasRecData() const {return fRecData;} 

  // Module access methods
  void AddModule(const MdRecModule& m) {fModules.push_back(m);}
  unsigned int GetNumberOfModules() const {return fModules.size();}
  bool HasModules() const { return !fModules.empty(); }
  bool HasModule(unsigned int id) const;
  ModuleIterator ModulesBegin() {return fModules.begin();}
  ModuleIterator ModulesEnd() { return fModules.end();}
  MdRecModule* GetModule(unsigned int id);

private:

  /**
   * \brief Counter status
   *
   * The MD counter statuses defined here match the MD event data. Note however that the status 
   * enumeration in this class does not need to coincide with the list in the event data (and 
   * does not!). The getters/setters interface hide the integral values assigned to the status 
   * from any code using this class.
   */
  enum Status {
    eUndefined = 0,
    eCandidate,
    eSilent,
    eRejected
  };

  unsigned int fId;
  unsigned int fSdPartnerId;
  Status fRecStatus;

  double fLDFResidual;
  double fNumberOfMuons;
  double fNumberOfMuonsErrorHigh;
  double fNumberOfMuonsErrorLow;
  double fNumberOfMuonsLowLimit;
  double fActiveArea;
  double fMuonDensity;
  double fMuonDensityErrorHigh;
  double fMuonDensityErrorLow;  
  unsigned int fNumberOfChannelsOn;

  TVector3 fPosition;
  double fSPDistance;
  double fSPDistanceError;
  double fSPDelta;
  double fSPDeltaError;
  double fSPAzimuth;
  double fSPAzimuthError;

  bool fRecData;  // true if the counter has reconstructed data
  bool fIsDense;

  // Module data
  ModuleList fModules;

  ClassDef(MdRecCounter, 5);
};

#endif // __MdRecCounter_h_

