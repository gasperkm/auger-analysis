// $Id: DetectorGeometry.h 28752 2016-04-11 10:30:41Z aherve $
#ifndef __DetectorGeometry_H
#define __DetectorGeometry_H

#include <EyeGeometry.h>

#include <TObject.h>
#include <TVector3.h>
#include <TString.h>

#include <vector>
#include <map>
#include <string>


class TBits;

class TelescopeGeometry;
class EyeGeometry;


enum EGridFlag {
  eNoGrid = 0,
  eRegularArray = 1<<0, /// 1500 m spacing
  eInfill       = 1<<1, /// 750 m spacing
  eDoublet      = 1<<2, /// pair stations
  eTriplet      = 1<<3  /// triplets
};



//  class representing the detector geometry

class DetectorGeometry : public TObject {

public:

  typedef std::map<unsigned int, TVector3> StationPosMap;

  typedef std::map<unsigned int, TString> StationNameMap;
  typedef std::map<unsigned int, UInt_t> StationGridTypeMap;

  typedef std::map<unsigned int, double> StationCommissionTimeMap;

  typedef StationPosMap::iterator StationPosMapIterator;
  typedef StationPosMap::const_iterator StationPosMapConstIterator;

  typedef std::map<UInt_t, EyeGeometry> EyeMap_t;
  typedef EyeMap_t::iterator EyeIterator;
  typedef EyeMap_t::const_iterator ConstEyeIterator;

public:
  DetectorGeometry();

  // -------------- FD part ------------------

  /// get maximum and minimum angles of mirror
  void GetMinMaxPhi(const UInt_t eyeid,
                    const TBits & MiBits,
                    double &MinPhi,
                    double &MaxPhi) const;
  void GetMinMaxOmega(const UInt_t eyeid,
                      const TBits & MiBits,
                      double &MinOmega,
                      double &MaxOmega) const;

  bool HasEye(UInt_t eyeid) const {return fEyes.count(eyeid);}
  void AddEye(UInt_t eyeid, const EyeGeometry &eye);
  EyeGeometry& GetEye(UInt_t eyeid);
  const EyeGeometry& GetEye(UInt_t eyeid) const;
  unsigned int GetNEyes() const {return fEyes.size();}

  EyeIterator EyesBegin() {return fEyes.begin();}
  EyeIterator EyesEnd() {return fEyes.end();}
  ConstEyeIterator EyesBegin() const  {return fEyes.begin();}
  ConstEyeIterator EyesEnd() const  {return fEyes.end();}

  /// get map of eye ids
  std::vector<UShort_t> GetEyeNumbers() const;

  /// set eye x-coordinate in Site CS [m]
  void SetEye(const UInt_t iEye,
              const double X, const double Y, const double Z,
              const double phi, const double phiEye,
              const double thetaEye,
              const std::string &eyeName,
              const std::string &eyeNameAbbr);

  /// set telescope elevation and azimuth
  void SetTelescope(const UInt_t eyeId,
                    const UInt_t mirrorId,
                    const std::map<TString, Double_t>& telElevations,
                    const std::map<TString, Double_t>& telAzimuths,
                    UInt_t nFADC, Double_t bFADC,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas);

  // -------------- SD part ------------------

  /// set station x-coordinate in Site CS [m]
  void SetStation(const unsigned int iStation,
                  const double x, const double y, const double z,
                  const int gridType);

  /// set the station name
  void SetStationName(const unsigned int iStation, const TString& name);

  /// set station commission time in gps seconds
  void SetStationCommissionTime(const unsigned int iStation, const double gpsSecond);

  /// check if station is known
  bool isKnown(unsigned int i) const { return fStationName.find(i) != fStationName.end(); }

  /// get station coordinates in Site CS [m]
  const TVector3& GetStationPosition(const unsigned int id) const;

  /// get station name
  const TString& GetStationName(const unsigned int i) const;

  /// get station commission time as gps second
  double GetStationCommissionTime(const unsigned int i) const;

  /// get map of station positions
  const StationPosMap& GetStations() const { return fStationPos; }

  /// begining of stations
  StationPosMapIterator GetStationsBegin() { return fStationPos.begin(); }
  /// end of stations
  StationPosMapIterator GetStationsEnd() { return fStationPos.end(); }

  /// begining of const stations
  StationPosMapConstIterator GetStationsBegin() const { return fStationPos.begin(); }
  /// end of const stations
  StationPosMapConstIterator GetStationsEnd() const { return fStationPos.end(); }

  /// get a vector of station ids
  std::vector<int> GetStationIds() const;

  /// get a vector of station coordinates
  std::vector<double> GetStationXPositions() const;
  std::vector<double> GetStationYPositions() const;
  std::vector<double> GetStationZPositions() const;

  /// get number of stations
  Int_t GetNStations() const { return fStationPos.size(); }

  /// get min and max X coordinate
  double GetMinX() const;
  double GetMaxX() const;
  /// get min and max Y coordinate
  double GetMinY() const;
  double GetMaxY() const;
  /// get min and max Z coordinate
  double GetMinZ() const;
  double GetMaxZ() const;

  /// get id of station closest to (x,y)
  UInt_t GetClosestStationId(const double x, const double y) const ;
  /// get distance of station closest to (x,y) units: [m]
  double GetClosestStationDistance(const double x, const double y) const;

  /// test whether a point is in side the hexagon cell of a station
  bool IsInStationHexagon(const Int_t stId,
                          const double x,
                          const double y,
                          const double gridScale = 1500. /* meter */) const;

  /// get station axis distance in the shower plane given a tank, an axis and a core
  double GetStationAxisDistance(const TVector3& tank,
                                const TVector3& axis,
                                const TVector3& core) const;
  /// get station axis distance in the shower plane given a tank ID, an axis and a core
  double GetStationAxisDistance(const Int_t stId, const TVector3& axis,
                                const TVector3& core) const;

  /// get station coordinates in Shower plane [m]
  const TVector2 GetStationShowerPosition(const TVector3& tank,
                                          const TVector3& axis,
                                          const TVector3& core) const;

  /// get station coordinates in Shower plane [m]
  TVector2 GetStationShowerPosition(int id,
                                    const TVector3& axis,
                                    const TVector3& core) const;


  /// ids of stations of hexagon centered around station with id (includes id)
  const std::vector<unsigned int>& GetHexagon(const unsigned int stationID,
                                              const EGridFlag flag = eRegularArray) const;

  /// get Fd-Trigger-Readout-Section to which the stations belongs
  unsigned int GetFdTriggerReadoutSection(const unsigned int stationID) const;

  /** Merge the list of stations with that of another
   *  DetectorGeometry and store it in the object.
   *  Returns number of stations added to the object's list.
   */
  unsigned int MergeStationsFrom(const DetectorGeometry& source);

  /** Merge the eyes, telescopes, and telescope pointings with those
   *  of another DetectorGeometry and store them in the object.
   *  Returns ture if the object was modified.
   *  The object into which the information is merged takes precedence
   *  on conflicts.
   */
  bool MergeFDFrom(const DetectorGeometry& source);

  /// set cloud pixel definitions
  void SetCloudPixelDimensions(const double dx, const double dy)
  { fCloudPixelXWidth = dx; fCloudPixelYWidth = dy; }
  /// get cloud pixel center coordinates (site CS)
  std::vector<TVector3>& GetCloudPixelCenters()
  { return fCloudPixelCenters; }
  const std::vector<TVector3>& GetCloudPixelCenters() const
  { return fCloudPixelCenters; }
  double GetCloudPixelWidthX() const
  { return fCloudPixelXWidth; }
  double GetCloudPixelWidthY() const
  { return fCloudPixelYWidth; }

  // -------------- Radio part ------------------

  /// set station x-coordinate in Site CS [m]
  void SetRdStation(unsigned int iStation, double X, double Y, double Z);
  /// set the station name
  void SetRdStationName(unsigned int iStation, const TString& name);

  /// check if station is known
  bool isRdStationKnown(unsigned int i) const { return fRdStationsPos.count(i); }

  /// get station coordinates in Site CS [m]
  const TVector3& GetRdStationPosition(unsigned int i) const;
  TVector3& GetRdStationPosition(unsigned int i);

  /// get station name
  const TString& GetRdStationName(unsigned int i) const;
  TString& GetRdStationName(unsigned int i);

  /// get station coordinate iterators
  const StationPosMap& GetRdStations() const { return fRdStationsPos; }
  StationPosMapIterator GetRdStationsBegin() { return fRdStationsPos.begin(); }
  StationPosMapConstIterator GetRdStationsBegin() const  { return fRdStationsPos.begin(); }
  StationPosMapIterator GetRdStationsEnd() { return fRdStationsPos.end(); }
  StationPosMapConstIterator GetRdStationsEnd() const  { return fRdStationsPos.end(); }

  /// get a vector of station coordinates
  std::vector<double> GetRdStationXPositions() const;
  std::vector<double> GetRdStationYPositions() const;
  std::vector<double> GetRdStationZPositions() const;

  /// get number of stations
  Int_t GetNRdStations() const { return fRdStationsPos.size(); }

  /// get Id of station closest to (x,y)
  UInt_t GetClosestRdStationId(double x, double y) const;
  /// get distance of station closest to (x,y) units: [m]
  double GetClosestRdStationDistance(double x, double y) const;

  /// get station axis distance in the shower plane given a tank, an axis and a core
  double GetRdStationAxisDistance(const TVector3& station,
                                  const TVector3& axis,
                                  const TVector3& core) const;
  /// get station axis distance in the shower plane given a tank ID, an axis and a core
  double GetRdStationAxisDistance(const Int_t StationId,
                                  const TVector3& axis,
                                  const TVector3& core) const;

  /// get station coordinates in Shower plane [m]
  TVector3 GetRdStationShowerPosition(const int StationId,
                                      const TVector3& axis,
                                      const TVector3& core) const;

  /// get ids of stations of hexagon centered around stationID (includes stationID)
//  const std::vector<unsigned int> & GetHexagon(unsigned int stationID); // We are not Even sure that we will use hexagon

  /// get Fd-Trigger-Readout-Section to which the stations belongs

private:
  // cache implementation to compute some expensive look ups only once
  // all variables are declared mutable and not streamed to a file ("//!")
  mutable bool fNeedCacheRebuild; //!
  void RebuildCache() const;

  mutable std::map<unsigned int, unsigned int > fFdTriggerSections; //!
  typedef std::map<unsigned int, std::vector<unsigned int> > HexagonCache;
  mutable HexagonCache fHexagons[2]; //!
  mutable double fMaxX; //!
  mutable double fMaxY; //!
  mutable double fMaxZ; //!
  mutable double fMinX; //!
  mutable double fMinY; //!
  mutable double fMinZ; //!

private:
  // -------------- FD part ------------------
  EyeMap_t fEyes;

  // -------------- SD part ------------------
  StationPosMap fStationPos;
  StationNameMap fStationName;
  StationGridTypeMap fStationGridType;
  StationCommissionTimeMap fStationCommissionTime;

  // ------------- atmosphere -----------------
  std::vector<TVector3> fCloudPixelCenters;
  double fCloudPixelXWidth;
  double fCloudPixelYWidth;

  // ---------------------Radio Part-------------
  StationPosMap fRdStationsPos;
  StationNameMap fRdStationName;

  //---------------------------------
  ClassDef(DetectorGeometry, 22);

};


#endif
