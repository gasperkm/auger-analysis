#include <GenShower.h>
#include <ParticleType.h>
#include <iostream>
using namespace std;


ClassImp(GenShower);


//=============================================================================
/*!
  \class   GenShower
  \brief   Generated shower parameters

  \version 1.0
  \date    Sep 21 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
  \version $Id: GenShower.cc 28450 2016-02-02 15:42:51Z bridgeman $
*/
//=============================================================================

GenShower::GenShower() :
  fIDPrim(0),
  fE_em(0),
  fX1(0),
  fNmu(0),
  fXmaxMu(0),
  fXmax(0),
  fdEdXmax(0),
  fXmaxGH(0),
  fNmaxGH(0),
  fDistanceOfShowerMax(0),
  fMagneticFieldDeclination(0),
  fMagneticFieldInclination(0),
  fMagneticFieldStrength(0),
  fCoreTimeNSecond(0) // for backward compatibility ClassDef < 16
{
#ifdef DEBUGKG
  cout << " GenShower::GenShower() begin\n"
          " GenShower::GenShower() end" << endl;
#endif
}


//=============================================================================
void
GenShower::SetDepth(const std::vector<Double_t>& dep)
{
  fDepth = dep;
}


//=============================================================================
void
GenShower::SetElectrons(const std::vector<Double_t>& elec)
{
  fElectrons = elec;
}


//=============================================================================
void
GenShower::SetEnergyDeposit(const std::vector<Double_t>& elec)
{
  fEnergyDeposit = elec;
}


std::string
GenShower::GetPrimaryName()
  const
{
  switch (fIDPrim){
  case eUndefined: return "Undefined ";
  case ePhoton:    return "Photon ";
  case eProton:    return "Proton ";
  case eIron:      return "Iron ";
  case eCarbon:    return "Carbon ";
  case eHelium:    return "Helium ";
  case eSilicon:   return "Silicon ";
  case eNitrogen:  return "Nitrogen ";
  case eOxygen:    return "Oxygen ";
  default: return "check Offline";
  };
}


std::string
GenShower::GetShortPrimaryName()
  const
{
  switch (fIDPrim){
  case eUndefined:  return "?";
  case ePhoton:     return "#gamma";
  case eProton:     return "p";
  case eIron:       return "Fe";
  case eCarbon:     return "C";
  case eHelium:     return "He";
  case eSilicon:    return "Si";
  case eNitrogen:   return "N";
  case eOxygen:     return "O";
  default: return "?!!?";
  };
}


std::vector<Double_t>
GenShower::GetShowerAge()
  const
{
  const std::vector<Double_t>& depth = this->GetDepth();
  const Double_t xMax = this->GetXmax();

  std::vector<Double_t> age;
  age.resize(depth.size());
  for (unsigned int i = 0; i < depth.size(); ++i)
    age[i] = 3 * depth[i] / (depth[i] + 2*xMax);

  return age;
}

UInt_t
GenShower::GetCoreTimeNanoSecond() const {

  // for files produced with ClassDef < 16
  if ( fCoreTimeNSecond != 0 )
    return fCoreTimeNSecond;
  else
    return Shower::GetCoreTimeNanoSecond();
}


//--- deprecated functions
Double_t
GenShower::GetXmax()
  const
{
  cerr << "WARNING: GenShower::GetXmax() from ADST is "
       << "deprecated and will disappear soon \n"
       << "please use GetXmaxGH() or GetXmaxInterpolated()"
       << endl;
  return fXmax;
}

Double_t
GenShower::GetdEdXmax()
  const
{
  cerr << "WARNING: GenShower::GetdEdXmax() from ADST is "
       << "deprecated and will disappear soon \n"
       << "please use GetNmaxGH() or GetdEdXXmaxInterpolated()"
       << endl;
  return fdEdXmax;
}


