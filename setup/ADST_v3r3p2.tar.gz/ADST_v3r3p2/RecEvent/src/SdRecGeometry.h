#ifndef __SdRecGeometry_h__
#define __SdRecGeometry_h__

#include <FdGeometry.h>


class SdRecGeometry : public FdGeometry {

public:
  
private:

  ClassDef(SdRecGeometry, 1);
};


#endif
