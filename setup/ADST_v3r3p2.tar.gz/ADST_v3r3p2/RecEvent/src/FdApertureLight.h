// $Id: FdApertureLight.h 20049 2011-12-24 02:25:01Z darko $
#ifndef __FdApertureLight_H
#define __FdApertureLight_H

#include <TObject.h>
#include <vector>

class FdApertureLight : public TObject {

public:
  enum ELightComponent {
    eUnknown = -1,
    eTotalCherenkov = 0,
    eDirect,
    eMie,
    eRayleigh,
    eScattered,
    eFluorescence
  };

public:
  virtual ~FdApertureLight() { }

  // getters

  ///returns number of time points
  int GetNumberTimePoints() const;

  /// check if multiple scattered light is present
  bool HasMultipleScatteredLight() const;

  ///returns reference to time of arrival at camera \f$[ns]\f$
  const std::vector<Double_t>& GetTime() const { return fTime; }

  ///returns reference to total number of photons at aperture
  const std::vector<Double_t>& GetTotalLightAtAperture() const { return fDia_total; }

  ///returns reference to number of direct fluorescence photons on aperture
  const std::vector<Double_t>& GetFluorLightAtAperture() const { return fDia_fluor; }

  ///returns reference to number of direct Cherenkov photons at aperture
  const std::vector<Double_t>& GetCherLightAtAperture() const { return fDia_direct_cher; }

  ///returns reference number of Mie scattered Cherenkov photons at aperture
  const std::vector<Double_t>& GetMieCherLightAtAperture() const { return fDia_mie_cher; }

  ///returns reference to number of Rayleigh scattered Cherenkov photons at aperture
  const std::vector<Double_t>& GetRayCherLightAtAperture() const { return fDia_ray_cher; }

  ///returns reference to number of multiple scattered fluorescence photons at aperture
  const std::vector<Double_t>& GetMultScatFluorLightAtAperture() const { return fDia_multScat_fluor; }

  ///returns reference to number of multiple scattered Cherenkov photons at aperture
  const std::vector<Double_t>& GetMultScatCherLightAtAperture() const { return fDia_multScat_cher; }

  /// returns fraction of Cherenkov light at diaphragm (iLight: 0=total-Ckov, 1=direct, 2=Mie, 3=Rayleigh, 4=mult.scatt.)
  Double_t GetLightFraction(const ELightComponent iLight = eTotalCherenkov) const;

#ifdef PRIM_CHER
  ///returns reference to number of direct Cherenkov photons at aperture
  const std::vector<Double_t>& GetCherPrimaryLightAtAperture() const { return fDia_direct_cherPrimary; }

  ///returns reference number of Mie scattered Cherenkov photons at aperture
  const std::vector<Double_t>& GetMieCherPrimaryLightAtAperture() const { return fDia_mie_cherPrimary; }

  ///returns reference to number of Rayleigh scattered Cherenkov photons at aperture
  const std::vector<Double_t>& GetRayCherPrimaryLightAtAperture() const
  { return fDia_ray_cherPrimary; }
#endif

#ifdef PRIM_CHER
  /// returns light flux sum at time iTime
  Double_t GetLightFluxSum(const unsigned int iTime,
                           const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                           const bool fFluo, const bool cMult,
                           const bool cPrimDir, const bool cPrimMie, const bool cPrimRay) const;
  /// returns vector of light flux
  std::vector<Double_t> GetLightFluxSumVector(const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                              const bool fMult, const bool cMult,
                                              const bool cPrimDir, const bool cPrimMie, const bool cPrimRay) const;
#endif

  /// returns light flux sum at time iTime
  Double_t GetLightFluxSum(const unsigned int iTime,
                           const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                           const bool fMult, const bool cMult) const;
  /// returns vector of light flux
  std::vector<Double_t> GetLightFluxSumVector(const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                              const bool fMult, const bool cMult) const;

  /// Set time of arrival at camera
  void SetTime(const std::vector<Double_t>& tim);

  /// Set total number of photons arriving at the aperture
  void SetTotalLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of fluorescence photons arriving at the aperture
  void SetFluorLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of direct Cherenkov photons arriving at the aperture
  void SetCherLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of Mie scattered Cherenkov photons arriving at the aperture
  void SetMieCherLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of Rayleigh scattered Cherenkov photons arriving at the aperture
  void SetRayCherLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of multiple scattered fluorescence photons arriving at the aperture
  void SetMultScatFluorLightAtAperture(const std::vector<Double_t>& phot);

  /// Set number of multiple scattered Cherenkov photons arriving at the aperture
  void SetMultScatCherLightAtAperture(const std::vector<Double_t>& phot);

#ifdef PRIM_CHER
  /// Set number of direct Cherenkov photons arriving at the aperture
  void SetCherPrimaryLightAtAperture(const std::vector<Double_t>& phot)
  { fDia_direct_cherPrimary = phot; }

  /// Set number of Mie scattered Cherenkov photons arriving at the aperture
  void SetMieCherPrimaryLightAtAperture(const std::vector<Double_t>& phot)
  { fDia_mie_cherPrimary = phot; }

  /// Set number of Rayleigh scattered Cherenkov photons arriving at the aperture
  void SetRayCherPrimaryLightAtAperture(const std::vector<Double_t>& phot)
  { fDia_ray_cherPrimary = phot; }
#endif

private:
  ///time of arrival at camera \f$[ns]\f$
  std::vector<Double_t> fTime;

  ///total number of photons at aperture/diaphragm
  std::vector<Double_t> fDia_total;

  ///direct fluorescence photons at aperture/diaphragm
  std::vector<Double_t> fDia_fluor;

  ///direct Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_direct_cher;

  ///Mie scattered Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_mie_cher;

  ///Rayleigh scattered Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_ray_cher;

  ///multiple scattered fluorescence photons at aperture/diaphragm
  std::vector<Double_t> fDia_multScat_fluor;

  ///multiple scattered Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_multScat_cher;

#ifdef PRIM_CHER
  ///direct Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_direct_cherPrimary;

  ///Mie scattered Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_mie_cherPrimary;

  ///Rayleigh scattered Cherenkov photons at aperture/diaphragm
  std::vector<Double_t> fDia_ray_cherPrimary;
#endif

  ClassDef(FdApertureLight, 5);

};


#endif
