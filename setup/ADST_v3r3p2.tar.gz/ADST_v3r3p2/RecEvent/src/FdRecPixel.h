// $Id: FdRecPixel.h 23252 2013-04-04 10:16:11Z munger $
#ifndef __FdRecPixel_H
#define __FdRecPixel_H

#include <FdRecLevel.h>
#include <FdTrace.h>
#include <FdMultiTrace.h>
#include <FdApertureLight.h>
#include <TelescopeGeometry.h>

#include <TObject.h>

#include <vector>
#include <map>
#include <set>


//  Pixel data definition

class FdRecPixel : public TObject {

public:
  FdRecPixel();

  // getters
  int GetNumberOfPixels() const { return fnPixel; } ///< returns total number of pixels
  int GetNumberOfTriggeredPixels() const { return fnTrigPixel; } ///< returns number of triggered pixels
  int GetNumberOfPulsedPixels() const { return fnRecPixel; } ///< returns number of pixels after PulseFinder

  int GetNumberOfTracePixels() const { return fDataTrace.size(); } ///< returns number of pixels with stored adc-trace
  int GetNumberOfSpotTracePixels() const { return fSpotRecTrace.size(); } ///< returns number of pixels with stored adc-trace

  int GetNumberOfSDPFitPixels() const;  ///<returns number of pixels used in the SDP fit
  int GetNumberOfTimeFitPixels() const; ///<returns number of pixels used in the time fit

  /// get baseline RMS averaged over all pixels
  double GetMeanPixelRMS() const { return fmeanPixelRMS; }
  /// get baseline RMS averaged over all pixels
  double GetMeanADCRMS() const { return fmeanADCRMS; }

  /// get vector of pixel ids = (iTel-1)*maxPix+(idPix-1), where iTel is from 1-6
  const std::vector<UShort_t>& GetID() const { return fID; }
  /// get vector of pixel reconstruction status (see FdRecLevel)
  const std::vector<EPixelStatus>& GetStatus() const { return fStatus; }
  /// get vector of pulse centroid times [100 ns]
  const std::vector<double>& GetTime() const { return fTime; }
  /// get vector of pulse centroid time uncertainties [100 ns]
  const std::vector<double>& GetTimeErr() const { return fTimeErr; }
  /// get vector of $chi$ angles [rad]
  const std::vector<double>& GetChi() const { return fChi; }
  /// get vector of pixel charge [photons at aperture]
  const std::vector<double>& GetCharge() const { return fCharge; }
  /// get the i'th pixel id = (iTel-1)*maxPix + (idPix-1)
  int GetID(const int i) const { return fID[i]; }
  /// get the i'th pixel telescope id
  int GetTelescopeId(const int i) const
  { return fID[i]/TelescopeGeometry::GetMaxNumberOfPixelsPerCamera() + 1; }
  /// get the i'th pixel pixel id
  int GetPixelId(const int i) const
  { return fID[i]%TelescopeGeometry::GetMaxNumberOfPixelsPerCamera()+ 1; }
  /// get the i'th pixel reconstruction status (see FdRecLevel)
  EPixelStatus GetStatus(const int i) const { return fStatus[i]; }
  /// get the i'th pulse centroid time [100 ns]
  double GetTime(const int i) const { return fTime[i]; }
  /// get the i'th pulse centroid time uncertainty [100 ns]
  double GetTimeErr(const int i) const { return fTimeErr[i]; }
  /// get the i'th $chi$ angle [rad]
  double GetChi(const int i) const { return fChi[i]; }
  /// get the i'th pixel charge
  double GetCharge(const int i) const { return fCharge[i]; }
  /// get the FLT threshold of the i'th pixel
  int GetThreshold(const int i) const { return fThreshold[i]; }
   /// get the mean FLT threshold
  double GetMeanThreshold() const;

  /// get the i'th pixels adc trace
  const std::vector<double>& GetTrace(const int iPixel) const;
  /// get the i'th pixels (spot) reconstructed adc trace
  const std::vector<double>& GetSpotRecTrace(const int iPixel) const;
  /// get the i'th pixels simulated trace components
  const std::vector<double>& GetSimTrace(const int iPixel,
                                         const FdApertureLight::ELightComponent comp) const;
  /// get the adc traces
  const std::map<int, FdTrace>& GetTraces() const
  { return fDataTrace; }

  int GetSimTraceOffset(const int iPixel) const;

  /// get start time of pulse [100 ns]
  int GetPulseStart(const int i) const;
  /// get stop time of pulse [100 ns]
  int GetPulseStop(const int i) const;
  /// get baseline RMS
  double GetRMS(const int i) const;
  /// get trace ADC sum from bin j to k
  double GetTraceSum(const int i, const int j, const int k) const;
  /// get trace ADC sum from bin j to k
  double GetSpotRecTraceSum(const int i, const int j, const int k) const;
  /// get trace ADC maximum from bin j to k
  double GetTraceMax(const int i) const;
  /// get trace ADC maximum from bin j to k
  double GetSpotRecTraceMax(const int i) const;
  /// get the calibration constant [photons at aperture / ADC]
  double GetCalibrationConstant(const int i) const;

  /// ask for high gain saturation of the ith pixel
  bool IsHighGainSaturated(const int i) const
  { return fHighGainSaturatedPixels.find(i) != fHighGainSaturatedPixels.end(); }
  /// ask for high saturation of any pixels in this event
  bool HasHighGainSaturatedPixels() const
  { return !fHighGainSaturatedPixels.empty(); }

  /// ask for low gain saturation of the ith pixel
  bool IsLowGainSaturated(const int i) const
  { return fLowGainSaturatedPixels.find(i) != fLowGainSaturatedPixels.end(); }
  /// ask for low saturation of any pixels in this event
  bool HasLowGainSaturatedPixels() const
  { return !fLowGainSaturatedPixels.empty(); }

  /// ask for low gain saturation of the ith pixel
  bool IsSaturationRecovered(const int i) const
  { return fSaturationRecoveredPixels.find(i) != fSaturationRecoveredPixels.end(); }
  /// ask for low saturation of any pixels in this event
  bool HasSaturationRecoveredPixels() const
  { return !fSaturationRecoveredPixels.empty(); }

  /// return true if ADC-trace for i'th pixel is available
  bool HasADCTrace(const int i) const { return fDataTrace.find(i) != fDataTrace.end(); }
  bool HasSpotRecADCTrace(const int i) const { return fSpotRecTrace.find(i) != fSpotRecTrace.end(); }
  bool HasSimTrace(const int i, const FdApertureLight::ELightComponent source) const;

  /// return true if information about pixel status is available
  bool HasPixelStatus() const { return !fStatus.empty(); }

  // setters
  void SetNumberOfPixels(const int nPx);  ///< set total number of pixels and initialize vectors
  void SetNumberOfTriggeredPixels(const int nPix) { fnTrigPixel = nPix; } ///< set number of triggered pixels
  void SetNumberOfPulsedPixels(const int nPix) { fnRecPixel = nPix; } ///< set number of pixels with found pulse
  void SetNumberOfTracePixels(const int fnTracePx); ///< set number of pixels with stored adc-trace

  void SetID(const int i, const UShort_t id) { fID[i] = id; }
  void SetMeanPixelRMS(const float rms) { fmeanPixelRMS = rms; }
  void SetMeanADCRMS(const float rms) { fmeanADCRMS = rms; }

  void SetStatus(const int i, const EPixelStatus status) { fStatus[i] = status; }
  void SetTime(const int i, const double time) { fTime[i] = time; } ///< [timeslots]
  void SetTimeErr(const int i, const double error) { fTimeErr[i] = error; } ///< [timeslots]
  void SetCharge(const int i, const double charge) { fCharge[i] = charge; } ///< [adcCounts]
  void SetChi(const int i, const double chi) { fChi[i] = chi; }
  void SetThreshold(const int i, const int t) { fThreshold[i] = t; }
  void SetCalibrationConstant(const int i, const double cal) { fCalibConst[i] = cal; }
  void SetHighGainSaturated(const int i) { fHighGainSaturatedPixels.insert(i); }
  void SetLowGainSaturated(const int i) { fLowGainSaturatedPixels.insert(i); }
  void SetSaturationRecovered(const int i) { fSaturationRecoveredPixels.insert(i); }

  void SetDataTrace(const int i, const std::vector<double>& trace);
  void SetSpotRecTrace(const int i, const std::vector<double>& trace);
  void SetSimTrace(const std::vector<double>& trace, const int iPixel,
                   const FdApertureLight::ELightComponent source,
                   const int offset);

  void SetRMS(const int i, const double rms) { fRMS[i] = rms; }
  void SetPulseStart(const int i, const int start) { fPulseStart[i] = start; }
  void SetPulseStop(const int i, const int stop) { fPulseStop[i] = stop; }

private:
  int fnPixel;
  int fnTrigPixel;
  int fnRecPixel;
  int fnTracePixel;

  float fmeanPixelRMS;
  float fmeanADCRMS;

  std::vector<UShort_t> fID;
  std::vector<EPixelStatus> fStatus;
  std::vector<double> fTime;
  std::vector<double> fTimeErr;
  std::vector<double> fChi;
  std::vector<double> fCharge;
  std::vector<int> fThreshold;
  std::set<int> fHighGainSaturatedPixels;
  std::set<int> fLowGainSaturatedPixels;
  std::set<int> fSaturationRecoveredPixels;

  std::map<int, FdTrace> fDataTrace;
  std::map<int, FdTrace> fSpotRecTrace;
  std::map<int, FdMultiTrace> fSimTraceComponents;
  std::map<int, int> fSimTraceComponentsOffset;

  std::map<int, int> fPulseStart;
  std::map<int, int> fPulseStop;
  std::map<int, double> fRMS;
  std::map<int, double> fCalibConst;

  ClassDef(FdRecPixel, 10);

};


#endif
