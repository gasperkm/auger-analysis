// $Id: FdGeometry.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdGeometry.h>


ClassImp(FdGeometry);


//=============================================================================
/*!
  \class   FdGeometry
  \brief   Shower axis parameters (SDP, \f$\chi_0\f$ etc.)

  \version 1.0
  \date    Jan 20 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

FdGeometry::FdGeometry() :
  fSDPTheta(0),
  fSDPPhi(0),
  fT0(0),
  fRp(0),
  fChi0(0)
{ }


TVector3
FdGeometry::GetSDP()
  const
{
  TVector3 sdp(1,0,0);
  sdp.SetTheta(fSDPTheta);
  sdp.SetPhi(fSDPPhi);

  return sdp;
}
