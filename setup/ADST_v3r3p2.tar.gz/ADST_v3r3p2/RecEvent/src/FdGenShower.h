#ifndef __FdGenShower_H
#define __FdGenShower_H

#include <TObject.h>


//=============================================================================
//
//  reconstructed profile data definition
//
//=============================================================================

class FdGenShower : public TObject {

public:
  // class holding all variables dealing with the
  // shower properties as see from the eye

  void SetX1Chi(const double arg) { fX1Chi = arg; }
  void SetXmaxChi(const double arg) { fXmaxChi = arg; }

  double GetX1Chi() const { return fX1Chi; }
  double GetXmaxChi() const { return fXmaxChi; }

private:
  double fX1Chi;
  double fXmaxChi;

  ClassDef(FdGenShower, 1);

};


#endif
