#ifndef __RdRecLevel_H
#define __RdRecLevel_H

enum ERdRecLevel {

    /// no Rd event found
    eNoRd=0,
    eHasRdStationButNoShower=1,
    eHasRdShower=2,
    eHasRdShowerAndStation=3,
    eHasRdLDF=4
};

#endif
