// $Id: FdRecApertureLight.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdRecApertureLight.h>

#include <iostream>
#include <cmath>
using namespace std;


ClassImp(FdRecApertureLight);


//=============================================================================
/*!
      \class   FdRecApertureLight
       \brief   light at aperture

       \version 1.0
       \date    Sep 21 2004
       \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger

*/
//=============================================================================

FdRecApertureLight::FdRecApertureLight() :
  fZeta(0),
  fMaxCloudFractionInZeta(-1),
  fMaxCloudFractionWithLidarInZeta(-1)
{ }


//=============================================================================
void
FdRecApertureLight::SetTime(const std::vector<Double_t>& tim,
                            const std::vector<Double_t>& tim_err)
{
  FdApertureLight::SetTime(tim);
  fTime_err = tim_err;
}


//=============================================================================
void
FdRecApertureLight::SetTotalLightAtAperture(const std::vector<Double_t>& phot,
                                            const std::vector<Double_t>& phot_err)
{
  FdApertureLight::SetTotalLightAtAperture(phot);
  fDia_total_err = phot_err;
}


//=============================================================================
Double_t
FdRecApertureLight::GetTotalLightIntegral()
  const
{
  double sum = 0;
  const std::vector<Double_t>& diaLight = GetTotalLightAtAperture();

  // timeError is  1/2 * binsize (see FdApertureLightFinder)
  for (unsigned int i = 0; i < diaLight.size(); ++i)
    sum += diaLight[i] * 2*fTime_err[i];

  return sum;
}


//=============================================================================
Double_t
FdRecApertureLight::GetTotalLightIntegralError()
  const
{
  double sum = 0;
  const std::vector<Double_t>& diaLightErr = GetTotalLightAtApertureError();

  //timeError is  1/2 * binsize (see FdApertureLightFinder)
  for (unsigned int i = 0; i < diaLightErr.size(); ++i)
    sum += pow(diaLightErr[i] * 2*fTime_err[i], 2);

  return sqrt(sum);
}
