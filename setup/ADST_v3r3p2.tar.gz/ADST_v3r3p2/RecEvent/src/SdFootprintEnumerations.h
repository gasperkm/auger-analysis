/**
   \file


   \author Javier Gonzalez
   \version $Id: SdFootprintEnumerations.h 22862 2013-03-01 23:18:55Z darko $
   \date 20 Apr 2012
*/

#ifndef __SdFootprintEnumerations_h_
#define __SdFootprintEnumerations_h_

namespace SdFootprintEnumerations {
  enum Alignment {
    eNotAligned,
    eAligned,
    eIll
  };

  enum Parameter {
    eEarlyAoPProduct,
    eEarlyAoPSum,
    eUserDefined1=100000,
    eUserDefined2,
    eUserDefined3,
    eUserDefined4,
    eUserDefined5,
    eUserDefined6,
    eUserDefined7,
    eUserDefined8,
    eUserDefined9,
    eUserDefined10
  };
}

#endif // __SdFootprintEnumerations_h_

// Configure (x)emacs for this file ...
// Local Variables:
// mode:c++
// compile-command: "make -C .. -k"
// End:
