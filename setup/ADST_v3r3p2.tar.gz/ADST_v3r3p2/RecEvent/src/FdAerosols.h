#ifndef __FdAerosols_H
#define __FdAerosols_H

#include <TObject.h>
#include <vector>


class FdAerosols : public TObject {

public:
  /// returns Mie attenuation lengths
  const std::vector<Double_t>& GetMieAttenuationLength() const
  { return fMieAttenuationLength; }

  /// returns heights for the Mie attenuation length data points
  const std::vector<Double_t>& GetMieAttenuationHeight() const
  { return fMieAttenuationHeight; }

  /// sets Mie attenuation lengths
  void SetMieAttenuationLength(const std::vector<Double_t>& mieAtt)
  { fMieAttenuationLength = mieAtt; }

  /// sets heights for the Mie attenuation lengths
  void SetMieAttenuationHeight(const std::vector<Double_t>& mieAttH)
  { fMieAttenuationHeight = mieAttH; }

private:
  std::vector<Double_t> fMieAttenuationLength;
  std::vector<Double_t> fMieAttenuationHeight;

  ClassDef(FdAerosols, 1);

};


#endif
