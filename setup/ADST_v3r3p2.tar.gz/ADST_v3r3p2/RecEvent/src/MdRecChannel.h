// #include <config.h>
/*

   Martin Maur
   17 Apr 2012

*/

#ifndef __MdRecChannel_h_
#define __MdRecChannel_h_

#include <TObject.h>
#include <vector>

class MdRecChannel: public TObject {
public:
  MdRecChannel();
  virtual ~MdRecChannel(){}

  void SetId(const unsigned int id){fId=id;}
  unsigned int GetId()const {return fId;}

  void SetPixelId(const unsigned int id){fPixelId=id;}
  unsigned int GetPixelId()const {return fPixelId;}

  void SetScintillatorId(const unsigned int id){fScintillatorId=id;}
  unsigned int GetScintillatorId()const {return fScintillatorId;}

  /* Mask used to exclude broken channels from the analysis 
     Broken channels are conserved in the data with fMasked set to true.
     This can be useful, for example, to check that channels were masked correctly
  */
  void SetMask(bool mask) {fMasked=mask;}     
  bool IsMasked() {return fMasked;}

  // Trace methods
  void SetNumberOfBins(size_t n) { fNumberOfTraceBins=n; }
  size_t GetNumberOfBins() const { return fNumberOfTraceBins; }

  void SetBinning(const double b) {fTraceBinning = b;}
  double GetBinning() const {return fTraceBinning;}

  void SetTraceStartTime(unsigned long second, double nano) 
  {fTraceStartSecond = second; fTraceStartNano = nano; }
  unsigned long GetTraceStartSecond() const { return fTraceStartSecond; }
  double GetTraceStartNano() const { return fTraceStartNano; }
  bool HasTraceStartTime() {return (fTraceStartSecond!=0 && fTraceStartNano!=0);}   

  void SetTrace(const std::vector<char>& trace) {fTrace=trace;}
  bool HasTrace() const {return (!fTrace.empty());}
  const std::vector<char>& GetTrace() const {return fTrace;}

  // Pattern match methods
  const std::vector<double>& GetPatternMatchTimes() const {return fPatternMatchTimes;}
  std::vector<double>& GetPatternMatchTimes() {return fPatternMatchTimes;}
  bool HasPatternMatches() const {return fPatternMatchTimes.size()>0;}
 
  unsigned int GetNumberOfPatternMatchs() const {return fPatternMatchTimes.size();}
  //void SetNumberOfPatternMatchs(unsigned int n) {fNumberOfPatternMatchs = n;}

private:
  unsigned int fId;
  unsigned int fScintillatorId;
  unsigned int fPixelId;
  //unsigned int fNumberOfPatternMatchs;

  size_t fNumberOfTraceBins;
  double fTraceBinning;
  unsigned long fTraceStartSecond;
  double fTraceStartNano;
  std::vector<char> fTrace;

  std::vector<double> fPatternMatchTimes;  // 

  bool fMasked;

  ClassDef(MdRecChannel, 4);
};


#endif // __MdRecChannel_h_
