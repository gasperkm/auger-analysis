#ifndef __UnivRecShower_H
#define __UnivRecShower_H

#include <RecShower.h>

#include <TVector3.h>

#include <vector>
#include <iostream>


enum EUnivRecLevel {

// TODO add remaining rec types

  /// no universality reconstruction
  eNoReconstruction = 0,

  /// standard universality reconstruction success
  eGoodReconstruction = 1

};

//
//  Shower data definition
//


class UnivRecShower : public RecShower {

public:
  UnivRecShower();
  virtual ~UnivRecShower() { }

  EUnivRecLevel GetRecLevel() const { return fUnivRecLevel; }
  bool HasReconstruction() const { return fUnivRecLevel > eNoReconstruction; }

  /// get the reconstructed muon scale
  double GetNmu() const { return fNmu; }
  double GetNmuError() const { return fNmuError; }

  /// get the reconstructed electromagnetic shower maximum
  double GetXmax() const { return fXmax; }
  double GetXmaxError() const { return fXmaxError; }

  /// get the reconstructed muonic shower maximum
  double GetXmaxMu() const { return fXmaxMu; }
  double GetXmaxMuError() const { return fXmaxMuError; }

  double GetTimeModelOffset() const { return fTimeModelOffset; }
  double GetTimeModelOffsetError() const { return fTimeModelOffsetError; }

  int GetNumberOfShapeCandidates() const { return fNCandShape; }
  int GetNumberOfStartTimeCandidates() const { return fNCandStartTime; }
  int GetNumberOfLDFCandidates() const { return fNCandLDF; }

  // ----------- setters --------------------------------------

  void SetRecLevel(const EUnivRecLevel l) { fUnivRecLevel = l; }

  void SetNmu(const double Nmu) { fNmu = Nmu; }
  void SetNmuError(const double NmuError) { fNmuError = NmuError; }

  void SetXmax(const double Xmax) { fXmax = Xmax; }
  void SetXmaxError(const double XmaxError) { fXmaxError = XmaxError; }

  void SetXmaxMu(const double XmaxMu) { fXmaxMu = XmaxMu; }
  void SetXmaxMuError(const double XmaxMuError) { fXmaxMuError = XmaxMuError; }

  void SetTimeModelOffset(const double TimeModelOffset) { fTimeModelOffset = TimeModelOffset; }
  void SetTimeModelOffsetError(const double TimeModelOffsetError) { fTimeModelOffsetError = TimeModelOffsetError; }

  void SetNumberOfShapeCandidates(const int ncand) { fNCandShape = ncand; }
  void SetNumberOfStartTimeCandidates(const int ncand) { fNCandStartTime = ncand; }
  void SetNumberOfLDFCandidates(const int ncand) { fNCandLDF = ncand; }

  void DumpASCII(std::ostream& o = std::cout) const;

private:

  EUnivRecLevel fUnivRecLevel;

  Double_t fNmu;
  Double_t fNmuError;
  Double_t fXmax;
  Double_t fXmaxError;
  Double_t fXmaxMu;
  Double_t fXmaxMuError;
  Double_t fTimeModelOffset;
  Double_t fTimeModelOffsetError;

  int fNCandShape;
  int fNCandStartTime;
  int fNCandLDF;

  ClassDef(UnivRecShower, 3);

};


#endif
