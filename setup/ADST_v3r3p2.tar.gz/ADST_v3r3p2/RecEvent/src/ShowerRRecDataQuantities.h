/**
   \file
   ShowerRRecDataQuantities quantities to be stored in ParameterStorage objects of ShowerRecData
*/

#ifndef _revt_ShowerRRecDataQuantities_h_
#define _revt_ShowerRRecDataQuantities_h_

static const char CvsId_revt_ShowerRRecDataQuantities[] =
 "$Id: StationRecData.h ";

namespace revt {

/** ATTENTION: - Numerate enum
 *             - never change an index
 *  all values are in Auger base units
 *  a comment explaining a parameter and its origin is mandatory
 * 
 *  When you add new values take care that the range from 2000 to 2999
 *  is reserved for external users, and should NOT be used by Auger.
 */
enum ShowerRRecDataQuantities {

  eCoordinateOriginX = 1,   // X origin of the local coordinate system in reference Coordinate System (usually PampaAmarilla) [RdEventInitializer]
  eCoordinateOriginY = 2,   // Y origin of the local coordinate system in reference Coordinate System (usually PampaAmarilla) [RdEventInitializer]
  eCoordinateOriginZ = 3,   // Z origin of the local coordinate system in reference Coordinate System (usually PampaAmarilla) [RdEventInitializer]

  eShowerAxisX = 4, //Shower axis X [Rd*Fit] in the local coordinate system
  eShowerAxisY = 5, //Shower axis Y [Rd*Fit] in the local coordinate system
  eShowerAxisZ = 6, //Shower axis Z [Rd*Fit] in the local coordinate system

  eGamma = 7,               // variation of speed of light for horizontal showers [RdWaveFit]
  eWaveFitChi2 = 8,         // chi^2 of wave fit [RdWaveFit]
  eWaveFitNDF = 9,          // Number of degrees of freedom of wave fit [RdWaveFit]    

  eNumberOfStationsWithPulseFound = 10,   // Number of stations with pulse found [RdPreWaveFit, RdStationSignalReconstructor]

  eCoreX = 11,  // core position X [Rd*Fit] in the reference Coordinate System (usually PampaAmarilla)
  eCoreY = 12,  // core position Y [Rd*Fit] in the reference Coordinate System (usually PampaAmarilla)
  eCoreZ = 13,  // core position Z [Rd*Fit] in the reference Coordinate System (usually PampaAmarilla)

  eRecStage = 14, // the reconstruction stage of the shower (defined in ShowerRRecData.cc) [RdPreWaveFit, RdWaveFit, RdPlaneFit]
  eEnergy = 15,   // reconstructed by Rd2DLDFFitter

  ePreFitShowerAxisX = 16, // PreFit axis X [RdPreWaveFit] in the local coordinate system
  ePreFitShowerAxisY = 17, // PreFit axis Y [RdPreWaveFit] in the local coordinate system
  ePreFitShowerAxisZ = 18, // PreFit axis Z [RdPreWaveFit] in the local coordinate system

  ePreFitChi2 = 19,           // chi^2 of pre plane wave fit [RdPreWaveFit]
  ePreFitNDF = 20,            // Number of degrees of freedom of pre plane wave fit [RdPreWaveFit]

  eFitSuccess = 21,            // shows if iterative shower fit worked or failed
  eFitConvergence = 22,        // shows if iterative fit procedure converged [RdDirectionConvergenceChecker]
  eCoreTime = 23,              // time at which the shower axis hits the ground [RdPlaneFit]

  eRho = 24,                // angle between plane and cone front of the shower wavefront [RdWaveFit]

  eLDFParameter1 = 25,      // parameter 1 of an arbitrary LDF function (in case of an exponential function is is the amplitude)
  eLDFParameter2 = 26,      // parameter 2 of an arbitrary LDF function (in case of an exponential function is is the slope parameter R0)
  eLDFParameter3 = 27,      // parameter 3 of an arbitrary LDF function

  eNumberOfIterationsInDirectionFit = 28, // parameter keeping track of the number of iterations done in the direction fit [RdDirectionConvergenceChecker]
  
  eNumberOfAERAScintStationWithPulseFound = 29, // number of Stations found with scintillator pulse above Min (Top AND/OR Bottom) set in [RdScintSignalReconstructor]
  eNumberOfAERATopScintWithPulseFound = 30, // number of Top-Scint found with pulse above Min set in [RdScintSignalReconstructor]
  eNumberOfAERABottomScintWithPulseFound = 31, // number of Bottom-Scint found with pulse above Min set in [RdScintSignalReconstructor]

  eBaryCenterAERAScintX = 32,   // X weighted Barycenter TopScint in ePampaAmarilla Coordinate System [RdScintSignalReconstructor]
  eBaryCenterAERAScintY = 33,   // Y weighted Barycenter TopScint in ePampaAmarilla Coordinate System [RdScintSignalReconstructor]
  eBaryCenterAERAScintZ = 34,   // Z weighted Barycenter TopScint in ePampaAmarilla Coordinate System [RdScintSignalReconstructor]
  
  eBaryTimeAERAScint = 35,       // Barytime of the Scint [RdScintSignalReconstructor]
 
  eAERAScintShowerAxisX = 36, //Top Scint Shower axis X [RdScintPlaneFit] in the local coordinate system
  eAERAScintShowerAxisY = 37, //Top ScintShower axis Y [RdScintPlaneFit] in the local coordinate system
  eAERAScintShowerAxisZ = 38, //Top ScintShower axis Z [RdScintPlaneFit] in the local coordinate system
  
  eAERAScintCoreX = 39,              // X of core position reconstructed with Scintillators [RdScintLDFFit]
  eAERAScintCoreY = 40,              // Y of core position reconstructed with Scintillators [RdScintLDFFit]
  eAERAScintCoreZ = 41,              // Z of core position reconstructed with Scintillators [RdScintLDFFit]

  eAERAScintPlaneFitChi2 = 42,         // chi^2 of  Scint plane fit [RdScintPlaneFit]
  eAERAScintPlaneFitNDF = 43,          // Number of degrees of freedom of Scint plane fit [RdScintPlaneFit]
  
  eAERAScintLDFFitChi2 = 44,         // chi^2 of  Scint LDF fit [RdScintLDFFit]
  eAERAScintLDFFitNDF = 45,          // Number of degrees of freedom of Scint LDF fit [RdScintLDFFit]
  
  eChargeExcessStrength = 46,       // relative charge excess strength "a" as defined in the polarization paper

  eMagneticFieldVectorX = 47,       // X component of the magnetic field vector at the coordinate origin and event time [RdEventInitializer]
  eMagneticFieldVectorY = 48,       // Y component of the magnetic field vector at the coordinate origin and event time [RdEventInitializer]
  eMagneticFieldVectorZ = 49,       // Z component of the magnetic field vector at the coordinate origin and event time [RdEventInitializer]

  eRadioEnergy = 50,                // energy of radio emission [Rd2DLDFFitter]
  
  eGammaHyperbolicParam= 51,               // parameter of the hyperbolic [RdHyperbolicWavefrontFit]
  eHyperbolicWfFitChi2 = 52,         // chi^2 of hyperbolic wavefront fit [RdHyperbolicWavefrontFit]
  eHyperbolicWfFitNDF = 53,          // Number of degrees of freedom of hyperbolic wavefront fit [RdHyperbolicWavefrontFit]
  
  e2DLDFfitSignalChi2 = 54,         // chi^2 of the 2DLDF fit only calculated based on the signal stations [Rd2DLDFFitter]
  e2DLDFfitSignalNDF = 55,          // Number of degrees of freedom of the 2DLDF fit only calculated based on the signal stations [Rd2DLDFFitter]
  
  eReconstructedEnergy = 56,        // Primary evenrgy reconstructed with [RdAirShowerReconstruction] - an alternate reconstruction to the [Rd2DLDFFitter] coming from Tunka-Rex
  eReconstructedXmax = 57,          // Shower maximum reconstructed with [RdAirShowerReconstruction] - an alternate reconstruction to the [Rd2DLDFFitter] coming from Tunka-Rex
  
  // Christians personal parameters
  eProbSDCore = 101, // the probability extracted from the radio likelihood core estimator that the SD core position is the true core position
  eProbRdCorePol = 102,
  eProbSdCorePol = 103,
  eProbRdCoreScanPol = 104,
  eProbSdCoreImprovedPol = 105,

  eCoreScanX = 106,
  eCoreScanY = 107,
  eCoreScanZ = 108,
  
  eB = 1001  // offset b of the hyperbolic wavefront model used in the beam-forming [RdBeamFormer, RdWaveModel]

// 2DLDF temporary parameters
// eA_plus = 109,
// eX = 110,
// eY = 111,
// esigma = 112,
// eC_2 = 113,
// eC_1 = 114,
// eC_0 = 115,
// eChi2_2dLDF = 116,
// eLDFIntegral = 117
//
  
  // Attention: The range from 2000 to 2999 is reserved for external users and should not be used by Auger.


};

}

#endif

// Configure (x)emacs for this file ...
// Local Variables:
// mode: c++
// compile-command: "make -C .. -k"
// End:
