#include <RdRecStation.h>

#include <iostream>
#include <vector>
#include <cmath>
#include <TMath.h>
#include <stdexcept>
#include <sstream>

using namespace std;


ClassImp(RdRecStation);


//=============================================================================
/*!
  \class   RdRecStation
  \brief   Data of reconstructed Radio stations
  \brief   Based on the SD classes by (I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger)

  \version 2.6
  \date    December 2013
  \author  Maximilien Melissas, Tim Huege
*/
//=============================================================================

RdRecStation::RdRecStation() :
  fId(0),
  fPulsefound(false),
  fSaturated(false),
  fRejectionStatus(0)
{ }


RdRecStation::~RdRecStation()
{ }

void
RdRecStation::SetRdTimeTrace(const vector<Float_t>& timeTrace, const int polNb)
{
  // three-dimensional electric field
  if (polNb >= 0 && polNb < 3) {
    fTraces[polNb].SetTimeTrace(timeTrace);
  }
}


void
RdRecStation::SetRdAbsSpectrum(const vector<Float_t>& freqTrace, const int polNb)
{
  // three-dimensional electric field
  if (polNb >= 0 && polNb < 3) {
    fTraces[polNb].SetAbsoluteFreqSpectrum(freqTrace);
  }
}


void
RdRecStation::SetRdTrace(const RdTrace& trace, const int polNb)
{
  // three-dimensional electric field
  if (polNb >= 0 && polNb < 3) {
    fTraces[polNb] = trace;
  }
}

void
RdRecStation::SetRdTraceShowerPlane(const RdTrace& trace, const int polNb)
{
  // three-dimensional electric field
  if (polNb >= 0 && polNb < 3) {
    fTracesShowerPlane[polNb] = trace;
  }
}

void
RdRecStation::SetRdTraceAnalyticSignal(const RdTrace& trace, const int polNb)
{
  // three-dimensional electric field
  if (polNb >= 0 && polNb < 3) {
    fTracesAnalyticSignal[polNb] = trace;
  }
}


const vector<Float_t>&
RdRecStation::GetRdTimeTrace(int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTraces.find(polNb);
  if (miter != fTraces.end()) {
    return miter->second.GetTimeTrace();
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetRdTimeTrace(" << polNb << ")\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}

const vector<Float_t>&
RdRecStation::GetRdTimeTraceShowerPlane(int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTracesShowerPlane.find(polNb);
  if (miter != fTracesShowerPlane.end()) {
    return miter->second.GetTimeTrace();
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetTimeTrace(" << polNb << ")\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}

const vector<Float_t>&
RdRecStation::GetRdTimeTraceAnalyticSignal(int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTracesAnalyticSignal.find(polNb);
  if (miter != fTracesAnalyticSignal.end()) {
    return miter->second.GetTimeTrace();
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetTimeTrace(" << polNb << ")\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}



const vector<Float_t>&
RdRecStation::GetRdAbsSpectrum(const int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTraces.find(polNb);
  if (miter != fTraces.end()) {
    return miter->second.GetAbsoluteFreqSpectrum();
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetRdAbsSpectrum( " << polNb << " )\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}


const RdTrace&
RdRecStation::GetRdTrace(const int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTraces.find(polNb);
  if (miter != fTraces.end()) {
    return miter->second;
  } else {
    ostringstream errmsg;
    errmsg << "RdRecStation::GetRdTrace( " << polNb << " )\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}

const RdTrace&
RdRecStation::GetRdTraceShowerPlane(const int polNb)
  const
{
  const map<int, RdTrace>::const_iterator miter = fTracesShowerPlane.find(polNb);
  if (miter != fTracesShowerPlane.end()) {
    return miter->second;
  } else {
    ostringstream errmsg;
    errmsg << "RdRecStation::GetRdTrace( " << polNb << " )\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}


RdTrace&
RdRecStation::GetRdTrace(const int polNb)
{
  const map<int, RdTrace>::iterator miter = fTraces.find(polNb);
  if (miter != fTraces.end()) {
    return miter->second;
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetRdTrace( " << polNb << " )\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}

RdTrace&
RdRecStation::GetRdTraceShowerPlane(const int polNb)
{
  const map<int, RdTrace>::iterator miter = fTracesShowerPlane.find(polNb);
  if (miter != fTracesShowerPlane.end()) {
    return miter->second;
  } else {
    ostringstream errmsg;
    errmsg << " RdRecStation::GetRdTrace( " << polNb << " )\n"
              " Polarisation " << polNb << " not defined";
    throw out_of_range(errmsg.str());
  }
}

bool
RdRecStation::SignalStationsFirst(const RdRecStation& lhs, const RdRecStation& rhs)   // sort by signal stations, then non-signal stations
{
  if ((lhs.HasPulse() && rhs.HasPulse()) || (!lhs.HasPulse() && !rhs.HasPulse()))
  {
    // if both have a pulse or none has a pulse, sort by id
    return (lhs.GetId() < rhs.GetId());
  }
  else 
  {
    // if exactly one of them has a pulse, sort by pulse status
    return lhs.HasPulse();
  }
}

