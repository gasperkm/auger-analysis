#ifndef __Traces_H_
#define __Traces_H_

#include <TraceType.h>

#include <TObject.h>
#include <vector>


class CalibHistogram : public TObject {

  /// class to hold the information from the calibration 

public:
  CalibHistogram() { }
  CalibHistogram(const std::vector<Double_t>& bin, 
                 const std::vector<Int_t>& what)
  { fBinning = bin; fValues = what; }
  void SetBinning(const std::vector<Double_t>& what) { fBinning = what; }
  void SetValues(const std::vector<Int_t>& what) { fValues = what; }

  const std::vector<Double_t>& GetBinning() const { return fBinning; }
  const std::vector<Int_t>& GetValues() const { return fValues; }
  bool IsFilled() const { return !fValues.empty(); }
  
private:
  std::vector<Double_t> fBinning;
  std::vector<Int_t> fValues;
  
  ClassDef(CalibHistogram, 1);

};


class Traces : public TObject {

public:
  Traces();
  /// get the trace type (definitions in TraceType.h)
  ETraceType GetType() const { return fTraceType; }
  /// get the id of the PMT
  UShort_t GetPMTId() const { return fPMTId; }
  
  /// get calibrated signal
  Float_t GetVEMSignal() const { return fVEMSignal; }
  /// is the PMT functional?
  bool IsTubeOk() const { return fIsTubeOK; }
  /// is the low gain channel functional?
  bool IsLowGainOk() const { return fIsLowGainOK; }
  /// get the high gain (dynode) FADC trace
  const std::vector<UShort_t>& GetHighGainComponent() const { return fHigh; }
  /// get the low gain (anode) FADC trace
  const std::vector<UShort_t>& GetLowGainComponent() const { return fLow; }
  /// get the calibrated VEM trace
  const std::vector<Float_t>& GetVEMComponent() const { return fVEM; }
  
  /// get VEM charge in ADC counts from calibration histogram
  Float_t GetCharge() const { return fVEMCharge; } 
  /// get VEM charge error in ADC counts from calibration histogram
  Float_t GetChargeError() const { return fVEMChargeEr; }
  
  /// is the charge is from the online calibration or not
  bool IsVEMChargeFromHistogram() const { return fIsVEMChargeFromHistogram; }
  /// get the charge calibration histogram
  const CalibHistogram& GetChargeHistogram() const { return fChargeHistogram; }
  /// get VEM peak in ADC counts from calibration histogram
  Float_t GetPeak() const { return fVEMPeak; } 
  /// get VEM peak error in ADC counts from calibration histogram
  Float_t GetPeakError() const { return fVEMPeakEr; } 
  /// is the peak from the online calibration or not
  bool IsVEMPeakFromHistogram() const { return fIsVEMPeakFromHistogram; }
  /// get the peak calibration histogram
  const CalibHistogram& GetPeakHistogram() const { return fPeakHistogram; }
  /// get the muon pulse decay time
  Float_t GetMuonPulseDecayTime() const { return fMuonPulseDecayTime; }
  /// get the muon pulse decay time error
  Float_t GetMuonPulseDecayTimeError() const { return fMuonPulseDecayTimeEr; }
  Float_t GetDynodeAnodeRatio() const { return fDynodeAnodeRatio; }

  /// get the high gain (dynode) baseline
  Float_t GetBaseline() const { return fBaseline; } 
  /// get the RMS of the high gain (dynode) baseline
  Float_t GetBaselineRMS() const { return fBaselineRMS; }
  
  /// get the low gain (anode) baseline
  Float_t GetBaselineLG() const { return fBaselineLG; } 
  /// get the RMS of the low gain (anode) baseline
  Float_t GetBaselineLGRMS() const { return fBaselineLGRMS; }
  
  /// set PMT id
  void SetPMTId(const UShort_t what) { fPMTId = what; }
  /// sets the trace type (definitions in TraceType.h)
  void SetType(const ETraceType what) { fTraceType = what; }
  
  /// set calibrated signal
  void SetVEMSignal(const Float_t signal) { fVEMSignal = signal; }
  /// flag for the functionality of the PMT
  void SetIsTubeOk(const bool flag) { fIsTubeOK = flag; }
  /// flag for the functionality of the low gain channel
  void SetIsLowGainOk(const bool flag) { fIsLowGainOK = flag; }
  
  /// set the high gain (dynode) FADC trace
  void SetHighGainComponent(const std::vector<UShort_t>& what) { fHigh = what; }
  /// set the high gain (anode) FADC trace
  void SetLowGainComponent(const std::vector<UShort_t>& what) { fLow = what; }
  /// set the calibrated VEM trace
  void SetVEMComponent(const std::vector<Float_t>& what) { fVEM = what; }

  /// set VEM charge in ADC counts from calibration histogram
  void SetCharge(const Float_t charge, const Float_t chargeEr)
  { fVEMCharge = charge; fVEMChargeEr = chargeEr; }
  /// flag for knowing if the charge is from the online calibration or not
  void SetVEMChargeFromHistogram(const bool is)
  { fIsVEMChargeFromHistogram = is; }

  /// set the charge calibration histogram
  void SetChargeHistogram(const std::vector<Double_t>& binning, 
                          const std::vector<Int_t>& values) 
  {
    fChargeHistogram.SetBinning(binning);
    fChargeHistogram.SetValues(values);
  }
  
  /// set VEM peak in ADC counts from calibration histogram
  void SetPeak(const Float_t peak, const Float_t peakEr) 
  { fVEMPeak = peak; fVEMPeakEr = peakEr; }
  /// flag for knowing if the charge is from the online calibration or not
  void SetVEMPeakFromHistogram(const bool is) { fIsVEMPeakFromHistogram = is; }
  /// set the peak calibration histogram
  void SetPeakHistogram(const std::vector<Double_t>& binning, 
                        const std::vector<Int_t>& values) 
  {
    fPeakHistogram.SetBinning(binning);
    fPeakHistogram.SetValues(values);
  }
  /// set the muon pulse decay time
  void SetMuonPulseDecayTime(const Float_t tau,
                             const Float_t tauEr)
  { fMuonPulseDecayTime = tau; fMuonPulseDecayTimeEr = tauEr; }
  /// set the dynode/anode ratio
  void SetDynodeAnodeRatio(const Float_t dynAnR) { fDynodeAnodeRatio = dynAnR; }
  /// set the high gain (dynode) baseline
  void SetBaseline(const Float_t baseline, const Float_t baselineRMS)
  { fBaseline = baseline; fBaselineRMS = baselineRMS; }
  /// set the low gain baseline
  void SetBaselineLG(const Float_t baseline, const Float_t baselineRMS) 
  { fBaselineLG = baseline; fBaselineLGRMS = baselineRMS; }

  void Clear(Option_t * /*option*/ ="");
  
private:
  ETraceType fTraceType;

  Float_t fVEMPeak;
  Float_t fVEMCharge;
  Float_t fVEMPeakEr;
  Float_t fVEMChargeEr;
  Float_t fVEMSignal;
  bool fIsVEMPeakFromHistogram;
  bool fIsVEMChargeFromHistogram;
  Float_t fDynodeAnodeRatio;
  Float_t fMuonPulseDecayTime;
  Float_t fMuonPulseDecayTimeEr;

  Float_t fBaseline;
  Float_t fBaselineRMS;
  Float_t fBaselineLG;
  Float_t fBaselineLGRMS;

  std::vector<UShort_t> fLow;
  std::vector<UShort_t> fHigh;
  std::vector<Float_t> fVEM;

  bool fIsTubeOK;
  bool fIsLowGainOK;

  UShort_t fPMTId;
  CalibHistogram fChargeHistogram;
  CalibHistogram fPeakHistogram;
  
  ClassDef(Traces, 9);

};


#endif
