#ifndef __RecStation_H
#define __RecStation_H

#include <StationStatus.h> // for the enums

#include <TObject.h>
#include <TVector3.h>

#include <iostream>
#include <stdlib.h>

//
//  Station data definition
//

class RecStation : public TObject {

public:
  RecStation();
  virtual ~RecStation() { }
  void SetId(const UInt_t id) { fId = id; }               ///< set  id of station
  UInt_t GetId() const { return fId; }                    ///< get  id of station

  bool IsTrigger(EStationTrigger type) const;
  void SetTrigger(EStationTrigger type);

  /// set the trigger status of the station
  void SetToT() { SetTrigger(eTOT); }
  bool IsToT() const { return IsTrigger(eTOT); }

  void SetToTd() { SetTrigger(eTOTd); }
  bool IsToTd() const { return IsTrigger(eTOTd); }

  void SetMoPS() { SetTrigger(eMoPS); }
  bool IsMoPS() const { return IsTrigger(eMoPS); }

  void SetT1Threshold() { SetTrigger(eT1Threshold); }
  bool IsT1Threshold() const { return IsTrigger(eT1Threshold); }

  void SetT2Threshold() { SetTrigger(eT2Threshold); }
  bool IsT2Threshold() const { return IsTrigger(eT2Threshold); }

  void SetRandom() { SetTrigger(eRandom); }
  bool IsRandom() const { return IsTrigger(eRandom); }

  void SetSilent() { fStatus = eSilent; }                 ///< Set silent station flag
  bool IsSilent() const { return fStatus == eSilent; }     ///< ask for silent station

  void SetAccidental() { fStatus = eAccidental; }         ///< Set accidental station flag (offline rejected station)
  bool IsAccidental() const { return fStatus == eAccidental; }  ///< ask for accidental station (offline rejected station)

  void SetCandidate() { fStatus = eCandidate; }               ///< Set candidate station flag
  bool IsCandidate() const { return fStatus == eCandidate; }  ///< ask for candidate station

  void SetUnknown() { fStatus = eUnknown; }                   ///< Set not reconstructed station flag
  bool IsUnknown() const { return fStatus == eUnknown; }      ///< ask for knowledge

  EStationStatus GetStatus() const { return fStatus; }

  void SetHybrid() { fIsHybrid = true; }           ///< Set hybrid station flag
  bool IsHybrid() const { return fIsHybrid; }        ///< ask for used hybrid station

  std::string GetStationTriggerName(const int version = 20) const;

  void SetRejectStatus(const int stat); ///< set the rejection status from the calibration or reconstruction
  ERejectionStatus GetRejectionStatus() const { return fRejectionStatus; } ///< get the rejection flag

  bool IsDoublet() const; ///< Is the station one of the pair stations?
  bool IsTriplet() const; ///< Is the station one of the triad stations?

  void SetTotalSignal(const Double_t c, const Double_t e)
  { fTotalSignal = c; fTotalSignalError = e; }

  Double_t GetTotalSignal() const { return fTotalSignal; }           ///< get signal
  Double_t GetTotalSignalError() const { return fTotalSignalError; }

  std::string GetRemovalReason() const;

  void SetCalibrationVersion(const unsigned int version) { fCalibVersion = version; }
  UInt_t GetCalibrationVersion() const { return fCalibVersion; }

  void SetPLDVersion(const std::string& version) { fPLDVersion = version; }
  std::string GetPLDVersion() const { return fPLDVersion; }
  int GetPLDVersionAsInt() const {return atoi(fPLDVersion.c_str());}
  void SetPLDTimeOffset(const int offset) { fPLDTimeOffset = offset; }
  int  GetPLDTimeOffset() const { return fPLDTimeOffset; } 

  void SetT3ErrorCode(const unsigned int what) { fT3ErrorCode = what; }
  UInt_t GetT3ErrorCode() const { return fT3ErrorCode; }
  void SetT3Window(const unsigned int what) { fT3Window = what; }
  Double_t GetT3Window() const { return fT3Window; }

  // BEGIN: Deprecated interfaces
  bool IsThreshold() const { return IsTrigger(eT2Threshold); } // deprecated, kept for backward compatibility
  bool IsTOT() const { return IsTrigger(eTOT); } // deprecated, kept for backward compatibility
  bool IsTOTd() const { return IsTrigger(eTOTd); } // deprecated, kept for backward compatibility
  // END: Deprecated interfaces

private:
  EStationStatus fStatus;
  EStationTrigger fTrigger;
  ERejectionStatus fRejectionStatus;
  int fTriggerBits;
 
  UInt_t fId;
  Bool_t fIsHybrid;
  Double_t fTotalSignal;
  Double_t fTotalSignalError;

  UInt_t fCalibVersion;
  std::string fPLDVersion;
  Int_t fPLDTimeOffset;

  UInt_t fT3ErrorCode;
  Double_t fT3Window;

  ClassDef(RecStation, 11);

};


#endif
