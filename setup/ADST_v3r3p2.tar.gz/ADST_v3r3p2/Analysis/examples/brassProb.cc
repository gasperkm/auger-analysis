#include "Analysis.h"
#include "T2TriggerProb.h"

#include "DetectorGeometry.h"
#include "RecEvent.h"
#include "Shower.h"
#include "EyeGeometry.h"
#include "ParticleType.h"

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>

#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TProfile.h>
#include <TProfile2D.h>
#include <TGraph.h>
#include <TBits.h>
#include <TVector3.h>
#include <TMath.h>
#include <TRandom3.h>

using namespace std;

/*
 * routine for generating a graph of stations from a given
 * detector geometry and set of station status flags.
 */
TGraph* DrawArray (const TBits * stationArray, DetectorGeometry& geom) {
  vector<double> X;
  vector<double> Y;
  TGraph *stationPlot = NULL;

  for (DetectorGeometry::StationPosMapConstIterator iStation =
	 geom.GetStationsBegin();
       iStation != geom.GetStationsEnd();
       ++iStation) {

    if ((stationArray==NULL) || (stationArray->TestBitNumber(iStation->first))) {
      X.push_back (iStation->second.X()/1000.);
      Y.push_back (iStation->second.Y()/1000.);
    }
  }

  if ( ! X.empty() ) {

    stationPlot = new TGraph (X.size(), &X.front(), &Y.front());
    stationPlot->SetMarkerColor(0);
    stationPlot->SetMarkerSize(0.5);
    stationPlot->SetMarkerStyle(20);
//    stationPlot->Draw("P");
  }
  return stationPlot;
}



typedef struct {
   double x,y;
} Point;

struct Square {
  double minx;
  double maxx;
  double miny;
  double maxy;
  double height;
  double width;
};

Point MkPoint( const double& x, const double& y) {
  Point p; p.x = x; p.y = y; return p;
}

Point* RandomCore (const Square& s, TRandom* rnd) {
  Point* p = new Point;
  p->x = s.minx + rnd->Rndm()*s.width;
  p->y = s.miny + rnd->Rndm()*s.height;
  return p;
}


/*
 * Generate a new DetectorGeometry containing an evenly spaced array of given (X-) station spacing and size
 */
unsigned int MakeArray(DetectorGeometry* theGeometry, const double stationDist, const double arrayWidth, const double arrayHeight) {
  const double rowHeight = stationDist * sqrt(3.)/2.;
  const double colWidth  = stationDist;

  const unsigned int rows = (unsigned int) (arrayHeight / rowHeight);
  const unsigned int cols = (unsigned int) (arrayWidth / colWidth);
  const double z = 0.;
  unsigned int iStation = 0;

  for (unsigned int row = 0; row < rows; row++) {
    const double y = row*rowHeight;

    for (unsigned int col = 0; col < cols; col++) {
      const double x = col*colWidth + ((row%2)*colWidth/2.);

      iStation++;
      theGeometry->SetStation(iStation, x, y, z, 1);
      theGeometry->SetStationName(iStation, "someStation");
    }
  }
  return iStation;
}


/*******************************************************/
void usage() {
  cout << "Usage: brassTrigProbInfiniteArray <outFile> <lgE> <primary> <stationDist> [<nEvents>] [<fixedTheta>]\n\n"
       << "  Generates plots about the probability of obtaining a brass hybrid\n"
       << "  event given some array structure, energy an optionally a fixed zenith\n"
       << "  angle. (Default: sample 0-60deg)\n"
       << "  Creates a ROOT file $outFile which contains various graphs:\n"
       << "    stations: TGraph of the station positions\n"
       << "    genSquareGraph: TGraph of the square in which cores are cast\n"
       << "    trigProb2D: TProfile2D of the brass trigger probs over the core pos.\n"
       << "    trigProbOverTheta: trigger probability over zenith angle\n"
       << "    trigProbOverCosTheta: Take a guess!\n"
       << "    trigProbOverTankDistance: ... over shortest axis-tank distance\n"
       << endl;
}

/*******************************************************/
int main(int argc, char **argv) {

  if ( argc < 4 ) {
    usage();
    return 1;
  }

  const string outFileName        = string(argv[1]);
  const double logEnergy          = atof(argv[2]);
  const int primary               = atoi(argv[3]);
  const double stationDist        = atof(argv[4]);
  unsigned int n = 20000;
  if (argc >= 6)
    n = atoi(argv[5]);
  double fixedZenith = -1.;
  if (argc >= 7)
    fixedZenith = cos(atof(argv[6]) * M_PI / 180.);

  int iPrim;
  if (primary == 100) {
    iPrim = eProton;
    cout << "Primary:     Protons" << endl;
  }
  else if (primary == 5600) {
    iPrim = eIron;
    cout << "Primary:     Iron nuclei" << endl;
  }
  else {
    cout << "unimplemented primary (laziness failure)" << endl;
    abort();
  }

  cout << "Energy:      "<< logEnergy<<endl;
  cout << "stat. dist:  "<< stationDist << endl;
  cout << "fixedZenith: "<< (fixedZenith < 0. ? -1. : acos(fixedZenith)/3.14159*180.) <<endl;
  cout << "nevents:     "<< n<<endl;

  // Create new detector geometry of the given settings
  DetectorGeometry * theGeometry = new DetectorGeometry();
  const double arrayWidth        = 1500.*10.+2.*10000.; // large compared to generation area
  const double arrayHeight       = 1500.*10.+2.*10000.;
  const unsigned int nStations   = MakeArray(theGeometry, stationDist, arrayWidth, arrayHeight);

  // The area to generate events on
  Square* genSquare = new Square;
  genSquare->minx = -1500.*3. + arrayWidth/2. + 123.456; // shift to middle of array and add
  genSquare->maxx = +1500.*3. + arrayWidth/2. + 123.456; // arbitrary offset so that
  genSquare->miny = -1500.*3. + arrayHeight/2. + 96.111; // borders don't coincide with
  genSquare->maxy = +1500.*3. + arrayHeight/2. + 96.111; // a row of tanks. TODO: Better rotate!
  genSquare->width  = genSquare->maxx - genSquare->minx;
  genSquare->height = genSquare->maxy - genSquare->miny;

  // Since the T2TriggerProb wants a TBits array of station statuses, we generate
  // one that has them all enabled
  TBits* allOnStationStatus                  = new TBits(nStations+1000);
  for (unsigned int i = 0; i < allOnStationStatus->GetNbits(); i++)
    allOnStationStatus->SetBitNumber(i, kTRUE);

  // ARRAY PLOTS
  const unsigned int bins2D = 250;
  TProfile2D* trigProb = new TProfile2D(
    "trigProb2D", "trigProb2D",
    bins2D, genSquare->minx, genSquare->maxx, bins2D, genSquare->miny, genSquare->maxy
  );

  // prob over zenith
  const unsigned int thetaBins = 50;
  TProfile* trigProbTheta = new TProfile(
    "trigProbOverTheta", "trigProbOverTheta",
    thetaBins, 0., 61., 0., 1.
  );
  trigProbTheta->GetXaxis()->SetTitle("zenith [deg]");
  TProfile* trigProbCosTheta = new TProfile(
    "trigProbOverCosTheta", "trigProbOverCosTheta",
    thetaBins, 0., 1., 0., 1.
  );
  trigProbCosTheta->GetXaxis()->SetTitle("cos zenith");

  // trigProbDistance->GetXaxis()->SetTitle("distance to closest tank [m]");
  TH1D* trigProbHist = new TH1D("trigProb", "trigProb", 1000, 0., 1.);

  TFile* outFile = new TFile(outFileName.c_str(), "RECREATE");
  T2TriggerProb prob(&theGeometry);

  TRandom3* rnd = new TRandom3();

  // if no fixed zenith angle was configured,
  // we sample dN/dcosTheta ~ cosTheta up to 60deg
  const double maxCosTheta = cos(0.);
  const double minCosTheta = cos(60.*3.14159/180.);

  unsigned int nevents = 0;
  Shower shower;
  shower.SetEnergy(pow(10., logEnergy));

  // MAIN LOOP
  while (nevents < n) {
    if (!(nevents%1000))
      cout << "[brassTrigProb] Processing event " << nevents << endl;

    // Generate zenith
    double cosTheta = 0.;
    if (fixedZenith < 0.) {
      while (cosTheta < minCosTheta || cosTheta > maxCosTheta)
        cosTheta = sqrt(rnd->Rndm());
    }
    else
      cosTheta = fixedZenith;
    const double phi      = 2. * M_PI * rnd->Rndm();

    // Random core
    Point* corePoint = RandomCore(*genSquare, rnd);
    TVector3 coreVec(corePoint->x, corePoint->y, 0.);
    shower.SetCoreSiteCS(coreVec);

    TVector3 axis (1.,0.,0.);
    axis.SetTheta(acos(cosTheta));
    axis.SetPhi(phi);
    shower.SetAxisSiteCS(axis);
    shower.SetAxisCoreCS(axis);

    nevents++;

    const double PBrass = prob.GetBrassProb(shower, *allOnStationStatus, iPrim);

    trigProbHist->Fill(PBrass);
    trigProb->Fill(corePoint->x, corePoint->y, PBrass);
    trigProbCosTheta->Fill(cosTheta, PBrass);
    trigProbTheta->Fill(acos(cosTheta)/3.14159*180., PBrass);

    delete corePoint;
  } // end while need more events

  outFile->cd();
  trigProbHist->Write();
  trigProb->Write();
  trigProbCosTheta->Write();
  trigProbTheta->Write();
  //  trigProbDistance->Write();

  // generate a graph of the square we simulate on for the output
  double gSX[5], gSY[5];
  gSX[0] = genSquare->minx; gSY[0] = genSquare->miny;
  gSX[1] = genSquare->minx; gSY[1] = genSquare->maxy;
  gSX[2] = genSquare->maxx; gSY[2] = genSquare->maxy;
  gSX[3] = genSquare->maxx; gSY[3] = genSquare->miny;
  gSX[4] = genSquare->minx; gSY[4] = genSquare->miny;
  TGraph* genSquareGraph = new TGraph(5,gSX,gSY);
  genSquareGraph->SetNameTitle("genSquareGraph","genSquareGraph");
  outFile->cd();
  genSquareGraph->Write();

  // Generate graph of stations for the output
  vector<double> stationsX = theGeometry->GetStationXPositions();
  vector<double> stationsY = theGeometry->GetStationYPositions();
  TGraph* stationsGraph = new TGraph(stationsX.size(),&stationsX.front(),&stationsY.front());
  stationsGraph->SetNameTitle("stations", "stations");
  outFile->cd();
  stationsGraph->Write();

  outFile->Close();
}
