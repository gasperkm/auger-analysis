#ifndef __Timing_HH
#define __Timing_HH

#include <vector>

class Timing {

public:
  Timing();
  Timing(unsigned int binSize, unsigned int start, unsigned int stop);
  ~Timing();

  unsigned int GetTimeBinSeconds() const {return fTimeBinSeconds;}
  unsigned int GetFirstGPS() const {return fFirstGPS;}
  unsigned int GetLastGPS() const  {return fLastGPS;}
  unsigned int GetNTimeBins() const {return fNTimeBins;}

  unsigned int GetBinStart(unsigned int bin) const;
  unsigned int GetBinStop(unsigned int bin) const;

  bool HasTimeBin(unsigned int iGPS) const;
  unsigned int GetTimeBin(unsigned int iGPS) const;

  void SetTimeBins(unsigned int secs,
                   unsigned int firstGPS,
                   unsigned int lastGPS);

  //utility function: UTC date[yymmdd], time[hhmmss]; return zero if out of scope
  unsigned int GetGPSFromDate(unsigned int date, unsigned int time=0) const;

private:
  unsigned int fTimeBinSeconds;
  unsigned int fFirstGPS;
  unsigned int fLastGPS;
  unsigned int fNTimeBins;
};
#endif
