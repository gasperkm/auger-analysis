#ifndef __include_CutFileParserV1_H
#define __include_CutFileParserV1_H

#include <Cut.h>
#include <CutFileParser.h>

#include <TString.h>

#include <vector>
#include <string>
#include <sstream>


class TPRegexp;

class CutFileParserV1 {
public:
  CutFileParserV1();

  int GetVerbosity() { return fVerbosity; }
  void SetVerbosity(int v) { fVerbosity = v; }

  void Parse(const std::string& cutFile, std::vector<Cut>& cutList, bool makeNMinusOne);

  // global storage for regular expressions:
  static TPRegexp* const fgCutNameToken;
  static TPRegexp* const fgIsEmptyLine;
  static TPRegexp* const fgIsNewTypeRegexp;
  static TPRegexp* const fgIsRestOfLineEmpty;
  static TPRegexp* const fgOpeningBrace;
  static TPRegexp* const fgClosingBrace;
  static TPRegexp* const fgNumbers;
  static TString* const fgFloatRegexp;
  static TPRegexp* const fgOptionNameParams;
  static TPRegexp* const fgOptionNameNMinusOne;

private:
  enum V1ParserState {
    eStart = 0,
    eExpectCut,
    eNumbersOrBrace,
    eExpectOption,
    eBraceOrNewCut
  };

  // parser state properties
  V1ParserState fState;
  TString fLine;
  unsigned int fLineNo;
  unsigned int fLineOffset;
  std::ostringstream fErrMsg;
  std::vector<Cut>* fCuts;

  // currently parsed cut properties
  CutFileVersion fVersion;
  TString fCurrentCutName;
  bool fCurrentIsAntiCut;
  std::vector<double> fCurrentCutParameters;
  std::vector<double> fNMinusOneParameters;
  bool fMakeNMinusOne;


  // V1 format parsing routine(s)
  bool ParserStateStart();
  bool ParserStateExpectCut();
  bool ParserStateNumbersOrBrace();
  bool ParserStateExpectOption();
  bool ParserStateBraceOrNewCut();

  std::vector<double> SplitNumbers(TString str);
  std::vector<double> MatchNumbers();
  void ThrowError(const std::string& msg);
  void FinishCutParse();

  void StripComments(std::string& line);

  int fVerbosity;
};


#endif
