#ifndef __AsciiFDConverter_h
#define __AsciiFDConverter_h

#include <AsciiConverter.h>

class RecEvent;

namespace ADST {
  class AsciiFDConverter : protected AsciiConverter {
  public:

    AsciiFDConverter();
    AsciiFDConverter(const std::string& outfile);
    AsciiFDConverter(std::ostream& outstream);
    ~AsciiFDConverter();

    virtual void WriteFileHeader();
    virtual void Convert(const RecEvent& event);

    void SetMinFdRecLevel(int minRecLevel) { fMinFdRecLevel = minRecLevel; }
    int GetMinFdRecLevel() { return fMinFdRecLevel; }

  protected:
    virtual std::string GetOutputDescription();

  private:
    void Init();

    int fMinFdRecLevel;
  };
} // end namespace ADST

#endif
