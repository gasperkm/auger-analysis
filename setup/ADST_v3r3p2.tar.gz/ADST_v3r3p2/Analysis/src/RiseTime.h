#ifndef __RiseTime_H
#define __RiseTime_H

class SDEvent;

class RiseTime {
 public:
  RiseTime(const SDEvent* sdrec);
  ~RiseTime();
  double GetRiseTimeAt1000();
  static void RiseTimeFitFnc(int &nPar, double* const grad,
                             double &value, double* par, const int flag);
 private:

  const SDEvent * fSDEvent;

};
#endif
