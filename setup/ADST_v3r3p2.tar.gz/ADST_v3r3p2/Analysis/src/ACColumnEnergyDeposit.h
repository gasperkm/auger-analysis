#ifndef _ADST_AC_ACColumnEnergyDeposit_h_
#define _ADST_AC_ACColumnEnergyDeposit_h_

#include <ACColumn.h>
#include <ACFDColumn.h>
#include <RecEvent.h>

#include <iostream>
#include <vector>


namespace ADST {

  namespace AC {

    // Column of dE/dX vs X
    class ACColumnEnergyDeposit : public ACFDColumn {

    public:
      ACColumnEnergyDeposit() : ACFDColumn("dEdX", "-", "dEdX vs X", 9) { }

      virtual ~ACColumnEnergyDeposit() { }

      void
      Convert(std::ostream& outs, const RecEvent& /*event*/, const FDEvent& fdevent)
        const
      {
        using namespace std;
        using namespace ADST;
        const FdRecShower& fdrec = fdevent.GetFdRecShower();
        const vector<Double_t>& x = fdrec.GetDepth();
        const vector<Double_t>& dEdX = fdrec.GetEnergyDeposit();
        for (size_t i = 0, n = x.size(); i < n; ++i)
          outs << ' ' << x[i] << ' ' << dEdX[i];
      }

    };

  }

}


#endif
