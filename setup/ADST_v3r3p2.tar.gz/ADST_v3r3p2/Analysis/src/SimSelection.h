#ifndef __SimSelection_H
#define __SimSelection_H

#include <Selection.h>

class SimSelection : public Selection {
public:
  SimSelection(const DetectorGeometry* const* geom,
               const RecEvent* const* event,
               int verbosity = 1,
               bool nMinusOne = true,
               const std::string& cutFile = "simCuts.txt");

  SimSelection(const DetectorGeometry* const* geom,
               const RecEvent* const* event,
               int verbosity = 1,
               bool nMinusOne = true,
               const std::vector<std::string>& cutFiles = std::vector<std::string>(1, "simCuts.txt") );

private:
  const static CutSpec fgSimCutSpecs[];
  static bool fgCutSpecsInitialized;

  double GetNEvents() const { return 0.; }
  static bool primaryCut(Cut&);
};
#endif
