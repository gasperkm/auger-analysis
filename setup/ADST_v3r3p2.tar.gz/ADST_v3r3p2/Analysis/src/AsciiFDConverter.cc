#include <AsciiFDConverter.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

#include <RecEvent.h>

#include <ACColumn.h>
#include <ACGlobalColumn.h>
#include <ACFDColumn.h>
#include <ACColumnTypes.h>

using namespace std;

using namespace ADST;
using namespace ADST::AC;

/**********************************************************************/
AsciiFDConverter::AsciiFDConverter()
  : fMinFdRecLevel(0)
{
  Init();
}

/**********************************************************************/
AsciiFDConverter::AsciiFDConverter(const std::string& outfile)
 : AsciiConverter(outfile), fMinFdRecLevel(0)
{
  Init();
}

/**********************************************************************/
AsciiFDConverter::AsciiFDConverter(std::ostream& outstream)
 : AsciiConverter(outstream), fMinFdRecLevel(0)
{
  Init();
}

/**********************************************************************/
AsciiFDConverter::~AsciiFDConverter()
{
}

/**********************************************************************/
void
AsciiFDConverter::Convert(const RecEvent& event)
{
  std::ostream& os = GetOutputStream();
  const std::vector<ACColumn*>& columns = GetColumns();
  const std::string& colSep = GetColumnSeparator();

  for (RecEvent::ConstEyeIterator iEye = event.EyesBegin(); iEye != event.EyesEnd(); ++iEye)
  {
    if (iEye->GetRecLevel() < fMinFdRecLevel)
      continue;

    for (vector<ACColumn*>::const_iterator colIt = columns.begin(); colIt != columns.end(); ++colIt)
    {
      if (colIt != columns.begin())
        os << colSep;

      ostringstream fieldStr;
      fieldStr << setiosflags(std::ios::scientific) << setprecision(4);

      const ACColumn* col = *colIt;
      const ACGlobalColumn* globalCol = dynamic_cast<const ACGlobalColumn*>(col);
      if (globalCol != NULL) {
        globalCol->Convert(fieldStr, event);
        if (globalCol->GetWidth() != 0)
          os << setw(globalCol->GetWidth());
      }
      else {
        const ACFDColumn& fdCol = dynamic_cast<const ACFDColumn&>(*col);
        fdCol.Convert(fieldStr, event, *iEye);
        if (fdCol.GetWidth() != 0)
          os << setw(fdCol.GetWidth());
      }

      os << fieldStr.str();
    } // end foreach column
    os << "\n";
  } // end foreach eye
}

/**********************************************************************/
void
AsciiFDConverter::WriteFileHeader()
{
  std::ostream& outs = GetOutputStream();
  outs << "# " << GetOutputDescription() << "\n"
       << "# \n";
  WriteColumnHeader();
}

/**********************************************************************/
void
AsciiFDConverter::Init()
{
  vector<ACColumn*>& cols = GetColumns();
  if (cols.empty()) {
    //cols.push_back(new ACColumn());
  }
}

/**********************************************************************/
std::string
AsciiFDConverter::GetOutputDescription()
{
  return string("Reconstructed FD data list, created using the Offline Framework");
}

