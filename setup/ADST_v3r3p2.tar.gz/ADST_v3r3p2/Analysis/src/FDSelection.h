#ifndef __FDSelection_H
#define __FDSelection_H

#include <Selection.h>

#include <string>
#include <map>
#include <vector>

class FDSelection : public Selection {
public:
  FDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::string& cutFile = "fdCuts.txt" );

  FDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::vector<std::string>& cutFiles = std::vector<std::string>(1, "fdCuts.txt") );

private:
  const static CutSpec fgFDCutSpecs[];
  static bool fgCutSpecsInitialized;

  double GetNEvents() const { return GetNFDEvents(); }

  // cut functions
  static bool brassHybridProb(Cut&);
  static bool IsInFOV(Cut&);
  static bool xMaxErrorCut(Cut&);
  static bool xiMaxErrorCut(Cut&);
  static bool energyErrorCut(Cut&);
  static bool energyTotalErrorCut(Cut&);
  static bool profileFitChi2Cut(Cut&);
  static bool profileFitProbCut(Cut&);
  static bool profileFitChi2SigmaCut(Cut&);
  static bool timeFitChi2Cut(Cut&);
  static bool axisFitChi2Cut(Cut&);
  static bool axisPixelCut(Cut&);
  static bool sdpPixelCut(Cut&);
  static bool trigPixelCut(Cut&);
  static bool hybridDeltaTCut(Cut&);
  static bool hybridTankTriggerCut(Cut&);
  static bool maxZenithCut(Cut&);
  static bool minZenithCut(Cut&);
  static bool minCosZFDECut(Cut&);
  static bool maxLgEnergyCut(Cut&);
  static bool minLgEnergyCut(Cut&);
  static bool minLgECalCut(Cut&);
  static bool minViewAngleCut(Cut&);
  static bool eyeCut(Cut& cut);
  static bool cFracCut(Cut& cut);
  static bool dirCFracCut(Cut& cut);
  static bool primCFracCut(Cut& cut);
  static bool dirPrimCFracCut(Cut& cut);
  static bool minTotalLightCut(Cut& cut);
  static bool coreTankDistCut(Cut& cut);
  static bool coreTankDistECut(Cut& cut);
  static bool depthTrackLengthCut(Cut& cut);
  static bool angleTrackLengthCut(Cut& cut);
  static bool timeTrackLengthCut(Cut& cut);
  static bool maxDepthHoleCut(Cut& cut);
  static bool ICRC2005PhotonDistanceCut(Cut& cut);
  static bool minXFOVCut(Cut& cut);
  static bool maxXFOVCut(Cut& cut);
  static bool deltaProfileChi2Cut(Cut& cut);
  static bool deltaProfileChi2SpotCut(Cut& cut);
  static bool profileChi2RatioCut(Cut& cut);
  static bool badPixelCut(Cut& cut);
  static bool mismatchedPixelCut(Cut& cut);
  static bool depthVelocityCut(Cut& cut);
  static bool FiducialFOVICRC07(Cut& cut);
  static bool FiducialFOVPRL10(Cut& cut);
  static bool FiducialFOVICRC11(Cut& cut);
  static bool FiducialFOVICRC13(Cut& cut);
  static bool xMaxObsInExpectedFOV(Cut& cut);
  static bool GAP2007049FiducialFOV(Cut& cut);
  static bool GAP2007005FiducialFOV(Cut& cut);
  static bool GAP2007005FiducialDistance(Cut& cut);
  static bool GAP2007005FiducialZenith(Cut& cut);
  static bool minShowerAgeCut(Cut& cut);
  static bool maxShowerAgeCut(Cut& cut);
  static bool minRelativeDepthCut(Cut& cut);
  static bool maxRelativeDepthCut(Cut& cut);
  static bool minX0Cut(Cut& cut);
  static bool maxX0Cut(Cut& cut);
  static bool xRiseCut(Cut& cut);
  static bool maxCoreEyeDistanceCut(Cut& cut);
  static bool numberOfMirrorsCut(Cut& cut);
  static bool ICRC2007CalibPeriod(Cut& cut);
  static bool badFDPeriodRejection(Cut& cut);
  static bool mieDatabaseCut(Cut& cut);
  static bool GDASDatabaseCut(Cut& cut);
  static bool lidarDatabaseCut(Cut& cut);
  static bool LidarCloudRemovalCut(Cut& cut);
  static bool MinCloudDepthDistanceCut(Cut& cut);
  static bool MaxCloudThicknessCut(Cut& cut);
  static bool t3Cut(Cut& cut);
  static bool t3TimeAtGroundCut(Cut& cut);
  static bool CDASFDTriggerCut(Cut& cut);
  static bool saturationCut(Cut& cut);
  static bool allTelescopesHaveCorrectorRingCut(Cut& cut);
  static bool maxVAODCut(Cut& cut);
  static bool AAARGWG4(Cut& cut);
  static bool HDSpectrumDistanceCut(Cut& cut);
  static bool HDSpectrumDistance2012Cut(Cut& cut);
  static bool coreUncertaintyCut(Cut& cut);
  static bool heatOrientationUpCut(Cut& cut);
  static bool minimumAverageADCVarianceCut(Cut& cut);
  static bool potentialSDT5(Cut& cut);
  static bool MaxCloudFractionRelaxedCut(Cut& cut);
  static bool MaxCloudFractionWithLidarRelaxedCut(Cut& cut);
  static bool MaxCloudFractionStrictCut(Cut& cut);
  static bool MaxCloudFractionWithLidarStrictCut(Cut& cut);
  static bool RejectCDASVetoPeriods(Cut& cut);
  static bool RejectFDASVetoPeriods(Cut& cut);
  static bool RejectT3VetoPeriods(Cut& cut);
  static bool XmaxErrorLessThenXmaxCut(Cut& cut);
  static bool minPBrass(Cut& cut);
  static bool pbrassMaxProtonIronDifference(Cut& cut);
  static bool selectTelescopeCut(Cut& cut);
  static bool noBadPixelsInPulseCut(Cut& cut);
  static bool good10MHzCorrectionCut(Cut& cut);
  static bool HeCoHasUpTimeCut(Cut& cut);
  static bool minMeanPixelRMS(Cut& cut);
  static bool minMeanPixelRMSSimpleCut(Cut& cut);
  static bool minMeanPixelRMSMergedCut(Cut& cut);
  // helper functions
  static bool HasCorrectorRing(int iTel);
  static Double_t ApproxShowerAge (Double_t depth, Double_t xMax);
  static unsigned long long int GetT3Time(const unsigned long long int,
                                          const unsigned int);
  static bool CheckT3Time(const unsigned long long int,
                          const std::vector<unsigned long long int>&,
                          const std::vector<unsigned long long int>&,
                          const bool);
};


#endif
