
#include <FdRecStation.h>
#include <StationStatus.h> // for the enums

#include <iostream>
using namespace std;

ClassImp (FdRecStation);


FdRecStation::FdRecStation() :
    fChi_i (0),
    fTimeEye (0),
    fTime (0),
    fTimeError (0),
    fSignal (0),
    fSignalError (0),
    fTimeResidual (1.e20),            
    fDistanceToAxis (1.e20),
    fAge (0),
    fSlantDepth (0)
{

    //cout << " FdRecStation::FdRecStation " << (int)this << endl;
}


FdRecStation::~FdRecStation() {
    //cout << " FdRecStation::~FdRecStation " << (int)this << endl;
}

