#include <FdRecShower.h>

#include <TMath.h>

#include <iostream>
#include <cmath>
using namespace std;


ClassImp(FdRecShower);


//=============================================================================
/*!
  \class   FdRecShower
  \brief   Reconstructed shower parameters

  \version 1.0
  \date    Sep 20 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

FdRecShower::FdRecShower() :
  fTimTrackObs(0),
  fMinAngle(0),
  fMaxAngle(0),
  fMeanAngle(0),
  fXFOVMin(0),
  fXFOVMax(0),
  fZXmax(-999.),
  fAngTrackObs(0),
  fXTrackObs(0),
  fXTrackMin(0),
  fXTrackMax(0),
  fdEdXmax(0),
  fdEdXmaxError(0),
  fX1(0),
  fX1Error(0),
  fX1Chi(0),
  fX1ChiError(0),
  fXmax(0),
  fXmaxError(0),
  fXmaxChi(0),
  fXmaxChiError(0),
  fX0(0),
  fX0Error(0),
  fLambda(0),
  fLambdaError(0),
  fRhodEdXmaxXMax(0),
  fRhodEdXmaxLambda(0),
  fRhodEdXmaxX0(0),
  fRhoXMaxLambda(0),
  fRhoXMaxX0(0),
  fRhoLambdaX0(0),
  fGHChi2(-1.),
  fGHNdf(-1),
  fLineFitChi2(0),
  fDGHXmax1(-1.),
  fDGHXmax2(-1.),
  fDGHChi2Improvement(1e99),
  fCalEnergy(0),
  fCalEnergyError(0),
  fChkovFrac(0),
  fDistXmax(0),
  fHeightXmax(0),
  fCoreXmaxDist(0),
  fAttXmax(0),
  fMieAttXmax(0),
  fMieCorrection(0),
  fRayleighCorrection(0),
  fEnergyAtmError(0),
  fXmaxAtmError(0),
  fMaxCloudFracEyeShower(-1)
{
}


bool
FdRecShower::IsXmaxInFOV(double deltaX)
  const
{
  return fGHNdf > 0 &&
         fXTrackMax - deltaX > fXmax &&
         fXTrackMin + deltaX < fXmax;
}


void
FdRecShower::SetDepth(const std::vector<Double_t>& dep,
                      const std::vector<Double_t>& dep_err)
{
  fDepth = dep;
  fDepth_err = dep_err;
}


void
FdRecShower::SetElectrons(const std::vector<Double_t>& elec,
                          const std::vector<Double_t>& elec_err)
{
  fElectrons = elec;
  fElectrons_err = elec_err;
}


void
FdRecShower::SetEnergyDeposit(const std::vector<Double_t>& edep,
                              const std::vector<Double_t>& edep_err)
{
  fEnergyDeposit = edep;
  fEnergyDeposit_err = edep_err;
}


double
FdRecShower::EvaluateGaisserHillas(const double X)
  const
{

  if (X <= fX0)
    return 0;

  const double tmp = fXmax - fX0;

  return fdEdXmax * pow((X - fX0)/tmp, tmp/fLambda) *
    exp((fXmax - X)/fLambda);
}


std::vector<std::vector<Double_t> >
FdRecShower::GetCombineddEdXProfile(const double depthBin)
  const
{

  cerr << " FdRecShower::GetCombineddEdXProfile() is deprecated and will be "
       << "removed soon..." << endl;

  std::vector<std::vector<Double_t> > combinedProfile;

  if (!fEnergyDeposit.empty()) {

    std::vector<Double_t> c_depth;
    std::vector<Double_t> c_dEdX;
    std::vector<Double_t> c_dEdXErr;

    int n = 0;
    double xSum = 0;
    double wSum = 0;
    double ywSum = 0;
    double x0 = fDepth[0];

    for (unsigned int i = 0; i < fDepth.size(); ++i) {

      const double x = fDepth[i];
      const double y = fEnergyDeposit[i];
      const double w = 1 / (fEnergyDeposit_err[i]*fEnergyDeposit_err[i]);

      ++n;
      xSum += x;
      wSum += w;
      ywSum += (y*w);

      if (x0 + depthBin <= x) {

        c_depth.push_back(xSum /n);
        c_dEdX.push_back(ywSum / wSum);
        c_dEdXErr.push_back(sqrt(1 / wSum));

        n = 0;
        xSum = 0;
        wSum = 0;
        ywSum = 0;
        x0 = x;

      }
    }

    if (n > 0) {
      c_depth.push_back(xSum / n);
      c_dEdX.push_back(ywSum / wSum);
      c_dEdXErr.push_back(sqrt(1 / wSum));
    }

    combinedProfile.push_back(c_depth);
    combinedProfile.push_back(c_dEdX);
    combinedProfile.push_back(c_dEdXErr);

  }

  return combinedProfile;
}


std::vector<Double_t>
FdRecShower::GetShowerAge()
  const
{
  const std::vector<Double_t>& depth = this->GetDepth();
  const Double_t xMax = this->GetXmax();

  std::vector<Double_t> age;
  age.resize(depth.size());
  for (unsigned int i = 0; i < depth.size(); ++i)
    age[i] = ShowerAge(depth[i], xMax);

  return age;
}


double
FdRecShower::GetDepthFromZ(const double z)
  const
{

  double theDepth = -1;

  if (!fZValVec.empty()) {
    const double depth1 = fXFOVMin;
    const double depth2 = fXFOVMax;
    const double dDepth = (depth2 - depth1) / double(fZValVec.size() - 1);
    double X1 = depth1;
    double X2 = depth1 + dDepth;
    for (unsigned int i = 0; i < fZValVec.size()-1; ++i) {
      const double Z1 = fZValVec[i];
      const double Z2 = fZValVec[i+1];
      if ((Z1 <= z && Z2 >= z) ||
          (Z1 >= z && Z2 <= z)) {

        theDepth = X1 + (X2 - X1) * (z - Z1) / (Z2 - Z1);
        break;

      }
      X1 += dDepth;
      X2 += dDepth;
    }
  }
  return theDepth;
}

pair<double, double>
FdRecShower::GetExpectedFOVRange(const double xiCut,
                                 const double mvaCut)
  const
{

  const double xLow = GetXFOVMin();
  const double xUp  = GetXFOVMax();

  const vector<double>& xiVec = GetZVector();
  const vector<double>& mvaVec = GetMinViewingAngles();

  if ( xiVec.size() < 2 )
    return pair<double, double>(999, -999);

  // only old Xmax-PRL ADSTs have xiVec.size()>0 && mvaVec.empty()
  bool prlXmaxADST = mvaVec.empty();

  const double dX = (xUp-xLow)/(xiVec.size()-1);

  // fill all connected regions with (xi>0 && xi<=xiCut)
  // (may be more than one!)

  vector<double> xiUp;
  vector<double> xiLow;
  unsigned int currRegion = 1;

  double currDepth = xLow;
  for (unsigned int i=0; i<xiVec.size(); ++i) {

    const bool tooSmallViewingAngle = prlXmaxADST?xiVec[i]<0.:(mvaVec[i]<mvaCut);
    const double xiX = fabs(xiVec[i]);
    bool accepted = (!tooSmallViewingAngle && xiX <= xiCut );

    if ( accepted ) {
      // enter new region ?
      if ( xiUp.size() < currRegion ) {
	xiUp.push_back(currDepth);
	xiLow.push_back(currDepth);
      }
      if ( xiUp[currRegion-1] < currDepth )
	xiUp[currRegion-1] = currDepth;

      if ( xiLow[currRegion-1] > currDepth )
	xiLow[currRegion-1] = currDepth;
    }
    else {
      // leave region ?
      if ( xiUp.size() == currRegion )
	currRegion++;
    }

#ifdef _XI_DEBUG_
    cout << "X=" << currDepth << " i=" << currRegion
	 << " xiX=" << xiX;
    if ( ! prlXmaxADST )
      cout  << " angle=" << mvaVec[i]*180./TMath::Pi();
    if ( xiUp.size() == currRegion )
      cout << " xiLow=" << xiLow[currRegion-1]
	   << " xiUp=" << xiUp[currRegion-1];
    cout << endl;
#endif

    currDepth+=dX;
  }

  // search the largest region
  double xiLength = -1.;
  int largestRegion = -1;

  for ( unsigned int i=0;i<xiUp.size(); i++ ) {
    double thisLength = xiUp[i]-xiLow[i];
    if ( thisLength > xiLength ) {
      xiLength = thisLength;
      largestRegion = i;
    }
  }

  double newXUp  = 0;
  double newXLow = 0;
  if ( largestRegion >= 0 && largestRegion< (int) xiUp.size() ) {
    newXUp = xiUp[largestRegion];
    newXLow = xiLow[largestRegion];
  }

#ifdef _XI_DEBUG_
  cout << " nRegion=" << xiUp.size()
       << " iBest=" << largestRegion
       << " dX=" << xiLength
       << " xUp=" << newXUp
       << " xLow=" << newXLow
       << endl;
#endif

  return pair<double, double>(newXLow, newXUp);

}

double
FdRecShower::ShowerAge(const double x, const double xMax)
{
  return 3 * x / (x + 2*xMax);
}


void
FdRecShower::DumpASCII(std::ostream& o)
  const
{
  Shower::DumpASCII(o);
  o << "  Xmax [g/cm^2]          "
    << fXmax << " (+/- " << fXmaxError << ") \n"
    << "  dEdXMax [PeV/(g/cm^2)] "
    << fdEdXmax << " (+/- " << fdEdXmaxError << ") \n"
    << "  lambda [g/cm2]         "
    << fLambda << " (+/- " << fLambdaError << ") \n"
    << "  X0 [g/cm2]             "
    << fX0 << " (+/- " << fX0Error << ") \n";
}

bool
FdRecShower::HasProfileCorrelations()
  const {

  const double absCorrSum =
    fabs(fRhodEdXmaxXMax)+
    fabs(fRhodEdXmaxLambda)+
    fabs(fRhodEdXmaxX0)+
    fabs(fRhoXMaxLambda)+
    fabs(fRhoXMaxX0)+
    fabs(fRhoLambdaX0);

  return (absCorrSum>0.);

}
