// $Id: EventInfo.h 23736 2013-06-05 17:58:35Z dembinski $
#ifndef __EventInfo_H
#define __EventInfo_H

#include <FdRecLevel.h>
#include <SdRecLevel.h>
#ifdef AUGER_RADIO_ENABLED
#include <RdRecLevel.h>
#endif

#include <TObject.h>

#include <string>


//  small (! keep it like that...) event summary
//  to be read for instance at start of EventBrowser
//  for fast navigation through events

class EventInfo : public TObject {

public:
  EventInfo();
  EventInfo(unsigned int nEyes);
  virtual ~EventInfo();

  EventInfo (const EventInfo&);
  EventInfo& operator=(const EventInfo&);

  std::string InfoAsString() const;

  void SetYYMMDD(const UInt_t yymmdd) { fYYMMDD = yymmdd; }
  void SetHHMMSS(const UInt_t hhmmss) { fHHMMSS = hhmmss; }
  void SetSDId(const UInt_t sdid) { fSDId = sdid; }
  void SetAugerId(const ULong_t augerid) { fAugerId = augerid; }
  void SetSDRecLevel(const ESdRecLevel k) { fSDRecLevel = k; }
  void SetSDEnergy(const Double_t e) { fSDEnergy = e; }
  void SetSDZenith(const Double_t z) { fSDZenith = z; }
  void SetNumberOfStations(const UInt_t n) { fSDBits |= (n & kStationBitMask); }

  void SetSDAngChi2Probability(const Double_t p) { fSDAngChi2Prob = p; }
  void SetSDLDFChi2Probability(const Double_t p) { fSDLDFChi2Prob = p; }

  void SetIsT4() { fSDBits |= kT4BitMask; }
  void SetIsT5() { fSDBits |= kT5BitMask; }
  void SetIsT5ICRC() { fSDBits |= kT5ICRCBitMask; }
  void SetIsT5Has() { fSDBits |= kT5HasBitMask; }
  void SetIsSaturated() { fSDBits |= kSaturationBitMask; }  

  void SetEyeId(const int i, const UShort_t eye) { fEyeIds[i] = eye; }
  void SetRunId(const int i, const UInt_t run) { fRunIds[i] = run; }
  void SetEventId(const int i, const UInt_t ev) { fEventIds[i] = ev; }
  void SetFDRecLevel(const int i, const EFdRecLevel rl) { fFDRecLevel[i] = rl; }
  void SetFDEnergy(const int i, const Double_t e) { fFDEnergy[i] = e; }
  void SetFDZenith(const int i, const Double_t z) { fFDZenith[i] = z; }
  void SetNumberOfTriggeredPixels(const int i, const UInt_t ip) { fFDBits[i] |= (ip & kPixelBitMask); }
  void SetXmax(const int i, const double Xmax);
  void SetHybrid(const int i) { fFDBits[i] |= kHybridBitMask; }
  void SetXmaxInFOV(const int i) { fFDBits[i] |= kFoVBitMask; }

  void SetMCEnergy(const Double_t e) { fMCEnergy = e; }
  void SetMCZenith(const Double_t z) { fMCZenith = z; }

  UInt_t GetYYMMDD() const { return fYYMMDD; }
  UInt_t GetHHMMSS() const { return fHHMMSS; }
  UInt_t GetSDId() const { return fSDId; }
  ULong_t GetAugerId() const { return fAugerId; }

  ESdRecLevel GetSDRecLevel() const { return fSDRecLevel; }
  Double_t GetSDEnergy() const { return fSDEnergy; }
  Double_t GetSDZenith() const { return fSDZenith; }
  UInt_t GetNumberOfStations() const
  { return fSDBits & kStationBitMask; }

  Double_t GetSDAngChi2Probability() const { return fSDAngChi2Prob; }
  Double_t GetSDLDFChi2Probability() const { return fSDLDFChi2Prob; }

  bool IsT4() const { return fSDBits & kT4BitMask; }
  bool IsT5() const { return Is6T5(); }
  bool IsT5ICRC() const { return Is5T5(); }

  bool Is6T5() const { return fSDBits & kT5BitMask; }
  bool Is5T5() const { return fSDBits & kT5ICRCBitMask; }
  bool IsT5Has() const { return fSDBits & kT5HasBitMask; }

  bool IsSaturated() const { return fSDBits & kSaturationBitMask; }

  Int_t GetNumberOfEyes() const { return fNEyes;}
  UShort_t GetEyeId(const int i) const
  { return (i < fNEyes) ? fEyeIds[i] : 0;}
  UInt_t GetRunId(const int i) const
  { return (i < fNEyes) ? fRunIds[i] : 0; }
  UInt_t GetEventId(const int i) const
  { return (i < fNEyes) ? fEventIds[i] : 0; }
  EFdRecLevel GetFDRecLevel(const int i) const
  { return (i < fNEyes) ? fFDRecLevel[i] : eNoFdEvent; }
  Double_t GetFDEnergy(const int i) const
  { return (i < fNEyes) ? fFDEnergy[i] : 0; }
  Double_t GetXmax(const int i) const;
  Double_t GetFDZenith(const int i) const
  { return (i < fNEyes) ? fFDZenith[i] : 0; }
  UInt_t GetNumberOfTriggeredPixels(const int i) const
  { return (i < fNEyes) ? (fFDBits[i] & kPixelBitMask) : 0; }
  bool IsHybrid(const int i) const
  { return i < fNEyes && (fFDBits[i] & kHybridBitMask); }
  bool IsXmaxInFOV(const int i) const
  { return i < fNEyes && (fFDBits[i] & kFoVBitMask); }

  Double_t GetMCEnergy() const { return fMCEnergy; }
  Double_t GetMCZenith() const { return fMCZenith; }

  // infos on Xmax compression
  static UInt_t GetNXmax() { return 1 << kNXmaxBits; }
  static Double_t GetMinXmax() { return kMinXmax; }
  static Double_t GetMaxXmax() { return kMinXmax + kXmaxUnits*GetNXmax(); }

#ifdef AUGER_RADIO_ENABLED
  void SetRdRunNumber(const UInt_t rdrunnum) { fRdRunNumber = rdrunnum; }
  UInt_t GetRdRunNumber() const { return fRdRunNumber; }
  void SetRdEventId(const UInt_t rdevtid) { fRdEventId = rdevtid; }
  UInt_t GetRdEventId() const { return fRdEventId; }
  void SetRdRecStage(const Double_t stage) { fRDRecStage = stage; }
  Double_t GetRdRecStage() const  { return fRDRecStage; }
  Double_t GetRdZenith() const { return fRDZenith; }
  void SetRdZenith(const Double_t theta) { fRDZenith = theta; }
  Double_t GetRdAzimuth() const { return fRDAzimuth; }
  void SetRdAzimuth(const Double_t phi) { fRDAzimuth = phi; }
  UInt_t GetRdNumberOfStations() const { return fRDNumberOfStations; }
  void SetRdNumberOfStations(const UInt_t nRdStations) { fRDNumberOfStations = nRdStations; }
#endif

private:
  void Clear();

  // bit masks
  static const unsigned int kPixelBitMask;
  static const unsigned int kHybridBitMask;
  static const unsigned int kFoVBitMask;
  static const unsigned int kXmaxBitMask;
  static const unsigned int kXmaxBitShift;
  static const unsigned int kNXmaxBits;
  static const double kXmaxUnits;
  static const double kMinXmax;

  static const unsigned int kStationBitMask;
  static const unsigned int kT4BitMask;
  static const unsigned int kT5BitMask;
  static const unsigned int kT5ICRCBitMask;
  static const unsigned int kSaturationBitMask;
  static const unsigned int kT5HasBitMask;

  // date of event
  UInt_t fYYMMDD;
  UInt_t fHHMMSS;
  // id of event
  ULong_t fAugerId;
  // id of SD event
  UInt_t fSDId;
  // SD reconstruction level
  ESdRecLevel fSDRecLevel;
  // SD energy
  Double_t fSDEnergy;
  UInt_t fSDBits;
  // SD zenith angle
  Double_t fSDZenith;

  // chi^2 probability of arrival direction fit
  Double_t fSDAngChi2Prob;
  // chi^2 probability of shower size fit
  Double_t fSDLDFChi2Prob;

  // number of FD eyes
  Int_t fNEyes;
  UShort_t* fEyeIds; //[fNEyes]
  UInt_t* fRunIds; //[fNEyes]
  UInt_t* fEventIds; //[fNEyes]
  EFdRecLevel* fFDRecLevel; //[fNEyes]
  Double_t* fFDEnergy; //[fNEyes]
  Double_t* fFDZenith; //[fNEyes]
  UInt_t* fFDBits; //[fNEyes]

  // MC info
  Double_t fMCEnergy;
  Double_t fMCZenith;

#ifdef AUGER_RADIO_ENABLED
  UInt_t fRdRunNumber;
  UInt_t fRdEventId;
  Double_t fRDRecStage;
  Double_t fRDZenith;
  Double_t fRDAzimuth;
  Double_t fRDNumberOfStations;
#endif

  ClassDef(EventInfo, 12);

};


#endif
