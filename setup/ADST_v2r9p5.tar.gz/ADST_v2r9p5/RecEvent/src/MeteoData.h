#ifndef __MeteoData_h_
#define __MeteoData_h_

#include <TObject.h>


enum WeatherInfoType {
  ePressure,
  eTemperature,
  eHumidity,
  eDayPressure,
  eDayTemperature,
  eDayHumidity,
  eNInfoTypes
};

class MeteoData {

  public:
    MeteoData()
    {
      for (int i = 0; i < eNInfoTypes; ++i)
	fWeatherInfo[i] = 0;
    }

    ~MeteoData() { }

    float GetWeatherInformation(const WeatherInfoType wtype) const { return fWeatherInfo[wtype]; }

    void
    SetWeatherInformation(const WeatherInfoType wtype, const float val)
    {
      fWeatherInfo[wtype] = val;
    }

  private:

    float fWeatherInfo[eNInfoTypes];

    ClassDef(MeteoData, 1);

};


#endif
