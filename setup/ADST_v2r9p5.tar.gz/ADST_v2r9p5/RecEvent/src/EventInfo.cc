// $Id: EventInfo.cc 23736 2013-06-05 17:58:35Z dembinski $
#include <EventInfo.h>

#include <iostream>
#include <iomanip>
#include <sstream>
#include <cmath>

using namespace std;


ClassImp (EventInfo);


const unsigned int EventInfo::kPixelBitMask  = 0x007FF; // max 2047
const unsigned int EventInfo::kHybridBitMask = 0x00800;
const unsigned int EventInfo::kFoVBitMask    = 0x01000;
const unsigned int EventInfo::kXmaxBitMask   = 0x1E000;
const unsigned int EventInfo::kXmaxBitShift  = 13;
const unsigned int EventInfo::kNXmaxBits     = 4;
const double       EventInfo::kXmaxUnits     = 50;
const double       EventInfo::kMinXmax       = 350;

const unsigned int EventInfo::kStationBitMask    = 0x007FF; // max 2047
const unsigned int EventInfo::kT4BitMask         = 0x00800;
const unsigned int EventInfo::kT5BitMask         = 0x01000;
const unsigned int EventInfo::kT5ICRCBitMask     = 0x02000;
const unsigned int EventInfo::kSaturationBitMask = 0x04000;
const unsigned int EventInfo::kT5HasBitMask      = 0x08000;


EventInfo::EventInfo() :
  fYYMMDD(0),
  fHHMMSS(0),
  fAugerId(0),
  fSDId(0),
  fSDRecLevel(eNoSdEvent),
  fSDEnergy(0.),
  fSDBits(0),
  fSDZenith(0),
  fSDAngChi2Prob(1),
  fSDLDFChi2Prob(1),
  fNEyes(0),
  fEyeIds(NULL),
  fRunIds(NULL),
  fEventIds(NULL),
  fFDRecLevel(NULL),
  fFDEnergy(NULL),
  fFDZenith(NULL),
  fFDBits(NULL),
  fMCEnergy(0),
  fMCZenith(0)
#ifdef AUGER_RADIO_ENABLED
  ,
  fRdRunNumber(0),
  fRdEventId(0),
  fRDRecStage(0),
  fRDZenith(0),
  fRDAzimuth(0),
  fRDNumberOfStations(0)
#endif
{ }


EventInfo&
EventInfo::operator=(const EventInfo& rhs)
{
  if (&rhs == this)
    return *this;

  this->Clear();
  fNEyes = rhs.fNEyes;
  if (fNEyes > 0) {
    fEyeIds = new UShort_t[fNEyes];
    copy(rhs.fEyeIds, rhs.fEyeIds + fNEyes, fEyeIds);
    fRunIds = new UInt_t[fNEyes];
    copy(rhs.fRunIds, rhs.fRunIds + fNEyes, fRunIds);
    fEventIds = new UInt_t[fNEyes];
    copy(rhs.fEventIds, rhs.fEventIds + fNEyes, fEventIds);
    fFDRecLevel = new EFdRecLevel[fNEyes];
    copy(rhs.fFDRecLevel, rhs.fFDRecLevel + fNEyes, fFDRecLevel);
    fFDEnergy = new Double_t[fNEyes];
    copy(rhs.fFDEnergy, rhs.fFDEnergy + fNEyes, fFDEnergy);
    fFDZenith = new Double_t[fNEyes];
    // prevents crash for old version
    if (rhs.fFDZenith)
      copy(rhs.fFDZenith, rhs.fFDZenith + fNEyes, fFDZenith);
    else
      fill(fFDZenith, fFDZenith + fNEyes, 0);
    fFDBits = new UInt_t[fNEyes];
    // prevents crash for old version
    if (rhs.fFDBits)
      copy(rhs.fFDBits, rhs.fFDBits + fNEyes, fFDBits);
    else
      fill(fFDBits, fFDBits + fNEyes, 0);
  }

  fYYMMDD = rhs.fYYMMDD;
  fHHMMSS = rhs.fHHMMSS;
  fAugerId = rhs.fAugerId;
  fSDId = rhs.fSDId;
  fSDRecLevel = rhs.fSDRecLevel;
  fSDEnergy = rhs.fSDEnergy;
  fSDZenith = rhs.fSDZenith;
  fSDAngChi2Prob = rhs.fSDAngChi2Prob;
  fSDLDFChi2Prob = rhs.fSDLDFChi2Prob;
  fSDBits = rhs.fSDBits;
  
  fMCEnergy = rhs.fMCEnergy;
  fMCZenith = rhs.fMCZenith;
#ifdef AUGER_RADIO_ENABLED
  fRdRunNumber = rhs.fRdRunNumber;
  fRdEventId = rhs.fRdEventId;
  fRDRecStage = rhs.fRDRecStage;
  fRDZenith = rhs.fRDZenith;
  fRDAzimuth = rhs.fRDAzimuth;
  fRDNumberOfStations = rhs.fRDNumberOfStations;
#endif

  return *this;
}


EventInfo::EventInfo(const EventInfo& e) :
  TObject(e),
  fEyeIds(NULL),
  fRunIds(NULL),
  fEventIds(NULL),
  fFDRecLevel(NULL),
  fFDEnergy(NULL),
  fFDZenith(NULL),
  fFDBits(NULL)
{
  (*this) = e;
}


EventInfo::EventInfo(unsigned int nEyes) :
  fYYMMDD(0),
  fHHMMSS(0),
  fAugerId(0),
  fSDId(0),
  fSDRecLevel(eNoSdEvent),
  fSDEnergy(0),
  fSDBits(0),
  fSDZenith(0),
  fSDAngChi2Prob(1),
  fSDLDFChi2Prob(1),
  fNEyes(nEyes),
  fMCEnergy(0),
  fMCZenith(0)
#ifdef AUGER_RADIO_ENABLED
  ,
  fRdRunNumber(0),
  fRdEventId(0),
  fRDRecStage(0),
  fRDZenith(0),
  fRDAzimuth(0),
  fRDNumberOfStations(0)
#endif
{
  fEyeIds = new UShort_t[fNEyes];
  fRunIds = new UInt_t[fNEyes];
  fEventIds = new UInt_t[fNEyes];
  fFDRecLevel = new EFdRecLevel[fNEyes];
  fFDEnergy = new Double_t[fNEyes];
  fFDZenith = new Double_t[fNEyes];
  fill(fFDZenith, fFDZenith + fNEyes, 0);
  fFDBits = new UInt_t[fNEyes];
  fill(fFDBits, fFDBits + fNEyes, 0);
}


EventInfo::~EventInfo()
{
  Clear();
}


void
EventInfo::Clear()
{
  fYYMMDD = 0;
  fHHMMSS = 0;
  fAugerId = 0;
  fSDId = 0;
  fSDRecLevel = eNoSdEvent;
  fSDEnergy = 0;
  fSDZenith = 0;
  fSDAngChi2Prob = 1;
  fSDLDFChi2Prob = 1;
  fSDBits = 0;
  fNEyes = 0;

  delete[] fEyeIds;
  fEyeIds = NULL;

  delete[] fRunIds;
  fRunIds = NULL;

  delete[] fEventIds;
  fEventIds = NULL;

  delete[] fFDRecLevel;
  fFDRecLevel = NULL;

  delete[] fFDEnergy;
  fFDEnergy = NULL;

  delete[] fFDZenith;
  fFDZenith = NULL;

  delete[] fFDBits;
  fFDBits = NULL;

  fMCEnergy = 0;
  fMCZenith = 0;

#ifdef AUGER_RADIO_ENABLED
  fRdRunNumber = 0;
  fRdEventId = 0;
  fRDRecStage = 0;
  fRDZenith = 0;
  fRDAzimuth = 0;
  fRDNumberOfStations = 0;
#endif
}


string
EventInfo::InfoAsString()
  const
{
  stringstream info;
  const int iyear = fYYMMDD / 10000;

  info << (iyear < 10 ? "200" : "20")
       << fYYMMDD / 10000 << '/'
       << (fYYMMDD / 100 % 100) << '/'
       << (fYYMMDD % 100) << ' '
       << setw(2) << setfill('0') << fHHMMSS / 10000 << ':'
       << setw(2) << setfill('0') << (fHHMMSS / 100 % 100) << ':'
       << setw(2) << setfill('0') << (fHHMMSS % 100) << ' ';

  if (fAugerId > 0)
    info << " Auger " << fAugerId;

  if (fSDId > 0)
   info << " SD " << fSDId;

  if (fNEyes > 0)
    info << " FD ";
  for (int i = 0; i < fNEyes; ++i)
    info << fEyeIds[i] << '/'
         << fRunIds[i] << '/'
         << fEventIds[i] << ' ';

  return info.str();
}


void
EventInfo::SetXmax(const int i, const double Xmax)
{
  if (i < fNEyes) {
    const double maxXmax = kMinXmax + kXmaxUnits*pow(2., int(kNXmaxBits)) - 1.;
    unsigned int iXmax =
      ((unsigned int)(fmin(maxXmax, fmax(Xmax - kMinXmax, 0.)) / kXmaxUnits)) << kXmaxBitShift;
    fFDBits[i] |= iXmax;
  }
}


double
EventInfo::GetXmax(const int i)
  const
{
  if (i < fNEyes && fFDRecLevel[i] >= eHasGHParameters)
    return kMinXmax + kXmaxUnits*((fFDBits[i] & kXmaxBitMask) >> kXmaxBitShift);
  return 0;
}
