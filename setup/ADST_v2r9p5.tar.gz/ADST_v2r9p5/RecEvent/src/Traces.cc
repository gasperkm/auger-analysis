// $Id: Traces.cc 23175 2013-03-26 15:58:31Z dembinski $
#include <Traces.h>


ClassImp(Traces);


Traces::Traces() :
  fTraceType(eTotalTrace),
  fVEMPeak(0),
  fVEMCharge(0),
  fVEMPeakEr(0),
  fVEMChargeEr(0),
  fVEMSignal(0),
  fIsVEMPeakFromHistogram(false),
  fIsVEMChargeFromHistogram(false),
  fDynodeAnodeRatio(0),
  fMuonPulseDecayTime(0),
  fMuonPulseDecayTimeEr(0),
  fBaseline(0),
  fBaselineRMS(0),
  fBaselineLG(0),
  fBaselineLGRMS(0),
  fIsTubeOK(true),
  fIsLowGainOK(true),
  fPMTId(0)
{ }


void
Traces::Clear()
{
  fVEMPeak = 0;
  fVEMCharge = 0;
  fVEMPeakEr = 0;
  fVEMChargeEr = 0;
  fVEMSignal = 0;
  fIsVEMPeakFromHistogram = false;
  fIsVEMChargeFromHistogram = false;
  fDynodeAnodeRatio = 0;
  fBaseline = 0;
  fBaselineRMS = 0;
  fBaselineLG = 0;
  fBaselineLGRMS = 0;
  fPMTId = 0;
  fLow.clear();
  fHigh.clear();
  fVEM.clear();
}
