#ifdef AUGER_RADIO_ENABLED
#include <SimRdPulse.h>

#include <iostream>
#include <vector>
#include <cmath>
#include <TMath.h>
#include <stdexcept>
#include <sstream>

//=============================================================================
/*!
  \class   SimRdPulse 
  \brief   Data of reconstructed Radio stations
  \brief   Based on the SD classes by (I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger)
  
  \version 0.0
  \date    Jannuary 2009
  \author  Dani&euml;l Fraenkel

*/
//=============================================================================

using namespace std;

ClassImp(SimRdPulse)

SimRdPulse::SimRdPulse():
  fId(0),
  fRTimeSecond(0),
  fRTimeNSecond(0)
{
}

void SimRdPulse::SetTimeTrace(const vector<Float_t>& timeTrace, int polNb){ 
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) { 
    fTraces[polNb].SetTimeTrace(timeTrace);
  }
  return;
}

void SimRdPulse::SetFreqTrace(const vector<Float_t>& freqTrace, int polNb){
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) {
    fTraces[polNb].SetAbsoluteFreqSpectrum(freqTrace);
  }
}

void SimRdPulse::SetRdTrace(const RdTrace& trac, int polNb) {
  if ((polNb>=0&&polNb<3)||(polNb>=10 && polNb<13)) {
    fTraces[polNb]=trac;
  }                
}

const vector<Float_t>& SimRdPulse::GetTimeTrace(int polNb) const
throw(out_of_range) 
{
  map<int,RdTrace >::const_iterator miter= fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    // vector<Float_t> vret=miter->second.GetTimeTrace();
    // return vret;
    return miter->second.GetTimeTrace();
    // in case of error we return an vector of zero 
    // Need to find a better error management
  } else {
    ostringstream errmsg; 
    errmsg <<" Polarisation or Channel "<<polNb <<" not defined";
          throw (out_of_range(errmsg.str()));         
  }
}


const vector<Float_t>& SimRdPulse::GetFreqTrace(int polNb)  const 
throw(out_of_range)
{
  map<int,RdTrace >::const_iterator miter
          = fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    return miter->second.GetAbsoluteFreqSpectrum();
    // in case of error we return an vector of zero 
    // Need to find a better error management
  } else {
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined" ;
          throw (out_of_range(errmsg.str()));         
  }        
}

const RdTrace& SimRdPulse::GetRdTrace(int polNb) const
  throw (std::out_of_range)
{ 
  map<int,RdTrace>::const_iterator miter =fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    return miter->second;        
  } else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    throw (out_of_range(errmsg.str()));         
  }        
}

RdTrace& SimRdPulse::GetRdTrace(int polNb) 
  throw (std::out_of_range)
{ 
  map<int,RdTrace>::iterator miter =fTraces.find(polNb);
  if (miter!=fTraces.end()) {
    return miter->second;        
  } else { 
    ostringstream errmsg;
    errmsg.str("");
    errmsg << " Polarisation or Channel ``" << polNb << "'' not defined";
    throw (out_of_range(errmsg.str()));         
  }        
}

#endif
