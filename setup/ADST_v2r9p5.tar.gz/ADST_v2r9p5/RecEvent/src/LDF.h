// $Id: LDF.h 23315 2013-04-10 11:32:13Z dembinski $

#ifndef __LDF_H
#define __LDF_H

#include <FileInfo.h>

#include <TObject.h>
#include <TF1.h>

#include <iostream>
#include <string>
#include <cmath>


class LDF : public TObject {

  friend class SdRecShower;

public:
  LDF();
  virtual ~LDF(){;}

  void SetLDFStatus(const double LDFStatus)
  { fLDFStatus = LDFStatus; }
  void SetLDFChi2(const double chi2, const double ndof)
  { fLDFChi2 = chi2; fLDFNdof = ndof; }
  void SetLDFLikelihood(const double likely)
  { fLDFLikelihood = likely; }
  void SetBeta(const double beta, const double error)
  { fBeta = beta; fBetaError = error; }
  void SetBetaSystematics(const double error)
  { fBetaSys = error; }

  void SetGamma(const double gamma, const double error)
  { fGamma = gamma; fGammaError = error; }
  void SetNKGFermiParameters(const double mu, const double tau)
  { fNKGFermiMu = mu; fNKGFermiTau = tau; }
  void SetReferenceDistance(const double r)  ///< set reference distance, where LDF(r) = 1
  { fReferenceDistance = r; }
  void SetShowerSizeLabel(const char* const label)  ///< set label of shower size estimator (S1000, S450, ...)
  { fShowerSizeLabel = label; }
  void SetShowerSize(const double value, const double error)
  { fS1000 = value; fS1000Error = error; }
  void SetShowerSizeSystematics(const double sysError)
  { fS1000BetaSys = sysError; }
  void SetTabulatedValues(const std::vector<double>& x, const std::vector<double>& y)
  { fRhos = x; fValues = y; }

  double GetReferenceDistance() const  ///< get reference distance, where LDF(r) = 1
  { return fReferenceDistance ? fReferenceDistance : 1000; }
  const char* GetShowerSizeLabel() const { return fShowerSizeLabel.c_str(); }
  double GetShowerSize() const { return fS1000; }
  double GetShowerSizeError() const { return fS1000Error; }
  double GetShowerSizeSys() const { return fS1000BetaSys; }

  double GetBeta() const { return fBeta; }
  double GetBetaError() const { return fBetaError; }
  double GetBetaSys() const { return fBetaSys; }

  double GetGamma() const { return fGamma; }
  double GetGammaError() const { return fGammaError; }
  double GetNKGFermiMu() const { return fNKGFermiMu; }
  double GetNKGFermiTau() const { return fNKGFermiTau; }
  double GetLDFChi2() const { return fLDFChi2; }
  double GetLDFNdof() const { return fLDFNdof; }
  double GetLDFLikelihood() const{ return fLDFLikelihood; }
  double GetLDFStatus() const { return fLDFStatus; }

  double Evaluate(const double r, const ELDFType type) const;
  double EvaluateInverted(const double signal, const ELDFType type) const;
  TF1 GetFunction(const ELDFType type) const;

  void DumpASCII(std::ostream &o = std::cout) const;

  // BEGIN: deprecated interface
  void SetS1000(const double s1000, const double error)  ///< (deprecated)
  { fShowerSizeLabel = "S1000"; fS1000 = s1000; fS1000Error = error; }
  void SetS1000BetaSys(const double error)  ///<set s(1000) systematics due to beta assumption (deprecated)
  { fShowerSizeLabel = "S1000"; fS1000BetaSys = error; }
  double GetS1000() const { return fS1000; }  ///< (deprecated)
  double GetS1000Error() const { return fS1000Error; }  ///< (deprecated)
  double GetS1000BetaSys() const { return fS1000BetaSys; }  ///< get S1000 systematics due to beta assumption (deprecated)
  double GetS1000TotalError() const
  { return std::sqrt(std::pow(fS1000BetaSys, 2) + std::pow(fS1000Error, 2)); }  ///< get total error = (stat.^2 + sys.^2)^(1/2) of S1000 (deprecated)
  // END: deprecated interface

 private:
  double NKGFunction(const double r) const;
  double PowerLawFunction(const double r) const;
  double NKGFermiFunction(const double r) const;

  double TabulatedFunction(const double r) const;
  double InvertedTabulatedFunction(const double signal) const;

  std::vector<double> fRhos;
  std::vector<double> fValues;

  double fReferenceDistance;
  std::string fShowerSizeLabel;
  double fS1000;
  double fS1000Error;
  double fS1000BetaSys;
  double fBeta;
  double fBetaError;
  double fBetaSys;
  double fGamma;
  double fGammaError;
  double fNKGFermiMu;
  double fNKGFermiTau;
  double fLDFChi2;
  double fLDFLikelihood;
  double fLDFNdof;
  double fLDFStatus;

  ClassDef(LDF, 11);
};


#endif
