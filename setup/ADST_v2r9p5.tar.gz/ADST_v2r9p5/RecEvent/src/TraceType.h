#ifndef _TRACETYPE_H_
#define _TRACETYPE_H_


enum ESaturationStatus {
  eLowGainSaturated,
  eHighGainSaturated,
  eNoSaturation
};


enum ETraceType {
  eTotalTrace = 0,
  ePhotonTrace = 1,
  eElectronTrace = 2,
  eMuonTrace = 3,
  ePhotonFromMuonTrace = 4,
  eElectronFromMuonTrace = 5,
  eHadronTrace = 6,
  eTotalUnsaturatedTrace = 7,
  eUnknownTrace = 10
};


#endif
