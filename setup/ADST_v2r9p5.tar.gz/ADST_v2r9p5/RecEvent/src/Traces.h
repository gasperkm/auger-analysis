#ifndef __Traces_H_
#define __Traces_H_

#include <TraceType.h>

#include <TObject.h>
#include <vector>


class Traces : public TObject {

public:
  Traces();
  /// returns the trace type (definitions in TraceType.h)
  ETraceType GetType() const { return fTraceType; }

  /// sets the trace type (definitions in TraceType.h)
  void SetType(const ETraceType what) { fTraceType = what; }

  void SetHighGainComponent(const std::vector<UShort_t>& what)
  { fHigh = what; }
  void SetLowGainComponent(const std::vector<UShort_t>& what)
  { fLow = what; }
  void SetVEMComponent(const std::vector<float>& what)
  { fVEM = what; }

  const std::vector<UShort_t>& GetHighGainComponent() const { return fHigh; }
  const std::vector<UShort_t>& GetLowGainComponent() const { return fLow; }
  const std::vector<float>& GetVEMComponent() const { return fVEM; }

  void SetPMTId(const UShort_t what) { fPMTId = what; }
  UShort_t GetPMTId() const { return fPMTId; }

  void SetCharge(const float charge, const float chargeEr) ///< set VEM charge in ADC counts from calibration histogram
  { fVEMCharge = charge; fVEMChargeEr = chargeEr; }
  void SetVEMChargeFromHistogram(const bool is) { fIsVEMChargeFromHistogram = is; }
  float GetCharge() const { return fVEMCharge; } ///< get VEM charge in ADC counts from calibration histogram
  float GetChargeError() const { return fVEMChargeEr; } ///< get VEM charge error in ADC counts from calibration histogram
  bool IsVEMChargeFromHistogram() const { return fIsVEMChargeFromHistogram; }

  void SetPeak(const float peak, const float peakEr) ///< set VEM peak in ADC counts from calibration histogram
  { fVEMPeak = peak; fVEMPeakEr = peakEr; }
  void SetVEMPeakFromHistogram(const bool is) { fIsVEMPeakFromHistogram = is; }
  float GetPeak() const { return fVEMPeak; } ///< get VEM peak in ADC counts from calibration histogram
  float GetPeakError() const { return fVEMPeakEr; } ///< get VEM peak error in ADC counts from calibration histogram
  bool IsVEMPeakFromHistogram() const { return fIsVEMPeakFromHistogram; }

  void SetMuonPulseDecayTime(const float tau,
                             const float tauEr) ///< set the muon pulse decay time
  { fMuonPulseDecayTime = tau; fMuonPulseDecayTimeEr = tauEr; }

  float GetMuonPulseDecayTime() const { return fMuonPulseDecayTime; }
  float GetMuonPulseDecayTimeError() const { return fMuonPulseDecayTimeEr; }

  void SetDynodeAnodeRatio(const float dynAnR) { fDynodeAnodeRatio = dynAnR; }
  float GetDynodeAnodeRatio() const { return fDynodeAnodeRatio; }

  void SetBaseline(const float baseline, const float baselineRMS) ///<set the high gain baseline
  { fBaseline = baseline; fBaselineRMS = baselineRMS; }
  float GetBaseline() const { return fBaseline; } ///< returns the high gain baseline
  float GetBaselineRMS() const { return fBaselineRMS; }

  void SetBaselineLG(const float baseline, const float baselineRMS) ///<set the low gain baseline
  { fBaselineLG = baseline; fBaselineLGRMS = baselineRMS; }
  float GetBaselineLG() const { return fBaselineLG; } ///< returns the low gain baseline
  float GetBaselineLGRMS() const { return fBaselineLGRMS; }

  void SetVEMSignal(const float signal) ///< set calibrated signal
  { fVEMSignal = signal; }
  float GetVEMSignal() const { return fVEMSignal; } ///> get calibrated signal

  void SetIsLowGainOk(const bool flag) { fIsLowGainOK = flag; }
  bool IsLowGainOk() const { return fIsLowGainOK; }
  void SetIsTubeOk(const bool flag) { fIsTubeOK = flag; }
  bool IsTubeOk() const { return fIsTubeOK; }
  void Clear();

private:
  ETraceType fTraceType;

  float fVEMPeak;
  float fVEMCharge;
  float fVEMPeakEr;
  float fVEMChargeEr;
  float fVEMSignal;
  bool fIsVEMPeakFromHistogram;
  bool fIsVEMChargeFromHistogram;
  float fDynodeAnodeRatio;
  float fMuonPulseDecayTime;
  float fMuonPulseDecayTimeEr;

  float fBaseline;
  float fBaselineRMS;
  float fBaselineLG;
  float fBaselineLGRMS;

  std::vector<UShort_t> fLow;
  std::vector<UShort_t> fHigh;
  std::vector<float> fVEM;

  bool fIsTubeOK;
  bool fIsLowGainOK;

  UShort_t fPMTId;

  ClassDef(Traces, 7);

};


#endif
