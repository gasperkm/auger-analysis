
#include <SDEvent.h>

#include <SdTriggerType.h>
#include <SdRecStation.h>
#include <GenStation.h>
#include <SdRecShower.h>

#include <TClonesArray.h>

#include <iostream>
using namespace std;


ClassImp (SDEvent);


//=============================================================================
/*!
  \class   SDEvent
  \brief   General SD event

  \version 1.0
  \date    Sep 21 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

SDEvent::SDEvent() :
  fSdEventId(0),
  fBadPeriodId(0),
  fSdRecLevel(eNoSdEvent),
  fSdGPSSecond(0),
  fSdGPSNanoSecond(0),
  fYYMMDD(0),
  fHHMMSS(0),
  fAverageStationAge(0),
  fNumberOfAccidentalStations(0),
  fNoOfCandidateStations(0),
  fT4Trigger(0),
  fT5Trigger(0),
  fIsLightning(false),
  fCDASSender(" --- "),
  fCDASAlgo(" --- ")
{
#ifdef DEBUGKG
  cout << " SDEvent::SDEvent()   begin" << endl;
#endif

#ifdef DEBUGKG
  cout << " SDEvent::SDEvent()   end" << endl;
#endif
}


SDEvent::~SDEvent()
{
#ifdef DEBUGKG
  cout << "  SDEvent::~SDEvent()  begin" << endl;
#endif

#ifdef DEBUGKG
  cout << "  SDEvent::~SDEvent()  end" << endl;
#endif
}


SdRecShower&
SDEvent::GetSdRecShower()
{
  return fSdRecShower;
}


const SdRecShower&
SDEvent::GetSdRecShower()
  const
{
  return fSdRecShower;
}


MuonMap&
SDEvent::GetMuonMap()
{
  return fMuonMap;
}


const MuonMap&
SDEvent::GetMuonMap()
  const
{
  return fMuonMap;
}


void
SDEvent::AddStation(const SdRecStation& station)
{
  fStations.push_back(station);
}


void
SDEvent::AddSimStation(const GenStation& station)
{
  fGenStations.push_back(station);
}


void
SDEvent::AddBadStation(const SdBadStation& station)
{
  fBadStations.push_back(station);
}


bool
SDEvent::HasStation(const int id)
  const
{
  for (unsigned int i = 0, n = fStations.size(); i < n; ++i)
    if (int(fStations[i].GetId()) == id)
      return true;

  return false;
}


bool
SDEvent::HasSimStation(const int id)
  const
{
  for (unsigned int i = 0, n = fGenStations.size(); i < n; ++i)
    if (int(fGenStations[i].GetId()) == id)
      return true;

  return false;
}


bool
SDEvent::HasBadStation(const int id)
  const
{
  for (unsigned int i = 0, n = fBadStations.size(); i < n; ++i)
    if (int(fBadStations[i].GetId()) == id)
      return true;

  return false;
}


//======================================================================
const SdRecStation*
SDEvent::GetStation(const unsigned int i)
  const
{
  if (i < fStations.size())
    return &fStations[i];
  else
    return NULL;
}


const SdRecStation*
SDEvent::GetStationById(const unsigned int id)
  const
{
  for (unsigned int i = 0, n = fStations.size(); i < n; ++i)
    if (fStations[i].GetId() == id)
      return &fStations[i];

  return NULL;
}


const GenStation*
SDEvent::GetSimStation(const unsigned int i)
  const
{
  if (i < fGenStations.size())
    return &fGenStations[i];
  else
    return NULL;
}


const GenStation*
SDEvent::GetSimStationById(const unsigned int id)
  const
{
  for (unsigned int i = 0, n = fGenStations.size(); i < n; ++i)
    if (fGenStations[i].GetId() == id)
      return &fGenStations[i];

  return NULL;
}


const SdBadStation*
SDEvent::GetBadStationById(const unsigned int id)
  const
{
  for (unsigned int i = 0, n = fBadStations.size(); i < n; ++i)
    if (fBadStations[i].GetId() == id)
      return &fBadStations[i];

  return NULL;
}


std::string
SDEvent::ReturnT4Name()
  const
{
  std::string result;
  if (fT4Trigger & eT4_FD)
    result += "FD & ";
  if (fT4Trigger & eT4_3TOT)
    result += "3TOT & ";
  else if (fT4Trigger & eT4_3TOTd)
    result += "3TOTd & ";
  else if (fT4Trigger & eT4_3MoPS)
    result += "3MoPS & ";
  else if (fT4Trigger & eT4_3TOTMix)
    result += "3TOTMix & ";
  if (fT4Trigger & eT4_4C1)
    result += "4C1";

  if (result.empty())
    result = "no T4 trigger";
  else
    if (result.compare(result.size()-3,3," & ") == 0)
      result.erase(result.size()-3,3);

  return result;
}


std::string
SDEvent::ReturnT5Name()
  const
{
  std::string s;
  if (fT5Trigger & eT5_6T5)
    s += "6T5 ";
  if (fT5Trigger & eT5_5T5)
    s += "5T5 ";
  if (fT5Trigger & eT5_Has)
    s += "T5Has";
  return s;
}


bool
SDEvent::IsT5()
  const
{
  return (fT5Trigger & eT5_6T5) || (fT5Trigger & eT5_5T5) || (fT5Trigger & eT5_Has);
}


bool
SDEvent::Is5T5()
  const
{
  return fT5Trigger & eT5_5T5;
}


bool
SDEvent::Is6T5()
  const
{
  return fT5Trigger & eT5_6T5;
}


bool
SDEvent::IsT5Has()
  const
{
  return fT5Trigger & eT5_Has;
}


bool
SDEvent::HasVEMTraces()
  const
{
  for (unsigned int i = 0, n = fStations.size(); i < n; ++i)
    for (unsigned int pmtId = 1; pmtId < 4; ++pmtId)
      if (!fStations[i].GetVEMTrace(pmtId).empty())
	return true;
  return false;
}


bool
SDEvent::HasFADCTraces()
  const
{
  for (unsigned int i = 0, n = fStations.size(); i < n; ++i)
    for (unsigned int pmtId = 1; pmtId < 4; ++pmtId)
      if (!fStations[i].GetLowGainTrace(pmtId).empty() ||
	  !fStations[i].GetHighGainTrace(pmtId).empty())
	return true;

  return false;
}


bool
SDEvent::HasAllTraces()
  const
{
  return (HasFADCTraces() && HasVEMTraces());
}


bool
SDEvent::IsSaturated()
  const
{
  for (vector<SdRecStation>::const_iterator it = fStations.begin(), end = fStations.end();
       it != end; ++it)
    if (it->IsLowGainSaturated())
      return true;
  return false;
}


bool
SDEvent::HasSaturatedCandidates()
  const
{
  for (vector<SdRecStation>::const_iterator it = fStations.begin(), end = fStations.end();
       it != end; ++it)
    if (it->IsCandidate() && it->GetRejectionStatus() == eNoRejection && it->IsLowGainSaturated())
      return true;
  return false;
}


Int_t
SDEvent::GetNumberOfCandidates(const bool loop)
  const
{
  if (loop) {
    int nrOfCandidates = 0;
    for (vector<SdRecStation>::const_iterator it = fStations.begin(), end = fStations.end();
         it != end; ++it)
      if (it->IsCandidate() && it->GetRejectionStatus() == eNoRejection)
        ++nrOfCandidates;
    return nrOfCandidates;
  }
  return fNoOfCandidateStations;
}


bool
SDEvent::HasParticles()
  const
{
  if (HasGenStations())
    for (std::vector<GenStation>::const_iterator stIter = fGenStations.begin(),
         end = fGenStations.end(); stIter != end; ++stIter)
      if (stIter->HasParticles())
        return true;
  return false;
}


bool
SDEvent::HasPEDistributions()
  const
{
  if (HasGenStations())
    for (std::vector<GenStation>::const_iterator stIter = fGenStations.begin(),
         end = fGenStations.end(); stIter != end; ++stIter)
      if (stIter->HasPETimeDistributions())
        return true;
  return false;
}


int
SDEvent::GetNumberOfAccidentalStations()
  const
{
  cerr << "Function GetNumberOfAccidentalStations() is deprecated "
       << "use GetNoOfAccidentalStations() " << endl;
  return fNumberOfAccidentalStations;
}


int
SDEvent::GetNoOfAccidentalStations()
  const
{
  unsigned int nrOfAccidentals = 0;
  if (fStations.empty())
    return -1;

  for (unsigned int i = 0, n = fStations.size(); i < n; ++i)
    if (fStations[i].GetRejectionStatus() == eOutOfTime ||
        fStations[i].GetRejectionStatus() == eLonely)
      ++nrOfAccidentals;

  return nrOfAccidentals;
}


void
SDEvent::DumpASCII(std::ostream& o)
  const
{
  if (!fSdEventId)
    return;
  o << "\n"
       "  SD Id                  " << fSdEventId
    << "   (trigger: T4 = " << fT4Trigger
    << "   T5 = " <<  fT5Trigger  << ")\n";
  fSdRecShower.DumpASCII(o);
}
