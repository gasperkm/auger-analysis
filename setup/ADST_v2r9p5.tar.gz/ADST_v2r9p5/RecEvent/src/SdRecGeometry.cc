
#include <SdRecGeometry.h>

ClassImp(SdRecGeometry);

//=============================================================================
/*!
  \class   SdRecGeometry
  \brief   Shower axis parameters (SDP, \f$\chi_0\f$ etc.) as measured by SD
  
  \version 1.0
  \date    July 2006
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================



