#ifndef __RecEvent_H
#define __RecEvent_H

#include <TObject.h>
#include <vector>


/*! \mainpage RecEvent

ROOT classes for storing the Auger FD and SD
Reconstruction and Simulation output.<br><br>
Implemented in the Offline module RecDataWriterKG
<br><br>
Some example programs can be found in the util/ subdirectory:
- RecSelectAndMerge: select events and merge them in one file.

<br>
RecEvent ROOT files can be visualized with the EventBrowser.
<br>
<br>
Some hints for installation can be found in the README file

$Id: RecEvent.h 23215 2013-03-28 15:08:21Z porcelli $
$Date: 2013-03-28 16:08:21 +0100 (Thu, 28 Mar 2013) $
I. Maris, S. M&uuml;ller, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/

#include <Detector.h>
#include <SDEvent.h>
#include <FDEvent.h>
#include <GenShower.h>
#include <unistd.h>

#ifdef AUGER_RADIO_ENABLED
#include <RdEvent.h>
#endif

#include <string>
#include <iostream>

//
//  class to hold SD and FD data
//

class RecEvent : public TObject {

public:
  typedef std::vector<FDEvent>::iterator EyeIterator;
  typedef std::vector<FDEvent>::const_iterator ConstEyeIterator;

public:
  RecEvent();
  virtual ~RecEvent();

  /// get complete Offline-Auger ID of this event (style: 'auger_yyyydddxxxxx__sd_xxxxxx')
  const std::string& GetEventId() const { return fEventId; }
  /// get AugerId (style: 'yyyydddxxxxx')
  std::string GetAugerId() const;
  /// get AugerId (style: 'yyyydddxxxxx')
  ULong_t GetAugerIdNumber() const;
  /// get date yymmdd
  UInt_t GetYYMMDD() const { return fYYMMDD; }
  /// get date hhmmss
  UInt_t GetHHMMSS() const { return fHHMMSS; }
  /// get modified Julian Date
  Double_t GetMJD() const { return fMJD; }

  bool HasEye(int id) const;
  const FDEvent& GetEye(const int id) const;
  FDEvent& GetEye(const int id);
  int GetNEyes() const;
  int GetHottestEyeId() const; ///< get ID of eye with largest # of pixel
  const FDEvent& GetHottestEye() const
  { return GetEye(GetHottestEyeId()); }
 
  Detector& GetDetector();
  const Detector& GetDetector() const;
  void SetDetector(const Detector& detector) { fDetector = detector; }

  SDEvent& GetSDEvent();
  const SDEvent& GetSDEvent() const;

  void SetSDEvent(const SDEvent& sdevent) { fSDEvent = sdevent; }
  void SetFDEvents(const std::vector<FDEvent>& fdevents) { fFDEvents = fdevents; }

#ifdef AUGER_RADIO_ENABLED
  RdEvent &GetRdEvent();
  const RdEvent& GetRdEvent() const;
#endif

  GenShower& GetGenShower();
  const GenShower& GetGenShower() const;

  EyeIterator EyesBegin();
  EyeIterator EyesEnd();
  ConstEyeIterator EyesBegin() const;
  ConstEyeIterator EyesEnd() const;

  std::vector<FDEvent>& GetFDEvents() { return fFDEvents; }
  const std::vector<FDEvent>& GetFDEvents() const { return fFDEvents; }
  void AddEye(const FDEvent& fd);

  /// set complete Offline-AugerId (style: 'auger_yyyydddxxxxx__sd_xxxxxx')
  void SetEventId(const std::string& id) { fEventId = id; }
  /// set date yymmdd
  void SetYYMMDD(const UInt_t arg) { fYYMMDD = arg; }
  /// set date hhmmss
  void SetHHMMSS(const UInt_t arg) { fHHMMSS = arg; }
  /// set modified Julian Date
  void SetMJD(const Double_t mjd) { fMJD = mjd; }

  /// add a double to UserData
  void AddUserData(const Double_t data) { fUserData.push_back(data); }
  /// set UserData
  void SetUserData(std::vector<Double_t>& data) { fUserData = data; }
  /// retrieve UserData (read-only)
  const std::vector<Double_t>& GetUserData() const { return fUserData; }
  /// retrieve UserData (read-write)
  std::vector<Double_t>& GetUserData() { return fUserData; }
  /// check if UserData is filled
  bool HasUserData() const { return !fUserData.empty(); }

  /// set UserDataMap
  void SetUserDataMap(std::map<TString, Double_t>& data) { fUserDataMap = data; }
  /// retrieve UserData from map (read-only)
  const std::map<TString, Double_t>& GetUserDataMap() const { return fUserDataMap; }
  /// retrieve UserData (read-write)
  std::map<TString, Double_t>& GetUserDataMap() { return fUserDataMap; }
  /// check if UserDataMap is filled
  bool HasUserDataMap() const { return !fUserDataMap.empty(); }

  // below follow algorithms on RecEvent data

  //------------- selection algorithms

  /// returns vector of FD eyes with Xlow+deltaX<Xmax<Xup-deltaX
  std::vector<FDEvent*> GetInFoVHybrids(const double deltaX = 0);
  std::vector<const FDEvent*> GetInFoVHybrids(double deltaX = 0) const;

  //------------- averaging algorithms

  /// controls averaging of FD only or FD and SD
  enum EAverageFlag {
    eFDs,
    eFDsAndSD
  };

  /// implemented averagings for single measurements
  enum ESingleAverageFlag {
    eEnergy,
    eXmax
  };

  /// calculate weighted average of of FD and SD measurements
  void CalculateAverage(const EAverageFlag avFlag, 
                        const ESingleAverageFlag singleFlag,
                        double& average, double& error,
                        double& chi2, int& Ndof) const;

  /// implemented averagings for correlated pair measurements
  enum EPairAverageFlag {
    eCoreSiteCS
  };

  /// calculate weighted average of a correlated pairs of FD and SD measurements
  bool CalculatePairAverage(const EAverageFlag avFlag, 
                            const EPairAverageFlag pairFlag,
                            std::pair<double,double>& average,
                            std::pair<double,double>& avError,
                            double& avCorrel) const;

  //------------- misc. algorithms

  void DumpASCII(std::ostream& o = std::cout) const;

  friend ostream& operator<<(ostream& os, const RecEvent& z);

private:
  /// utility function to calculate the average of a vector of correlated measurement pairs
  bool CalculatePairAverage(const std::vector<std::pair<double, double> >& values,
                            const std::vector<std::pair<double, double> >& errors,
                            const std::vector<double>& correlations,
                            std::pair<double, double>& average,
                            std::pair<double, double>& avError,
                            double& avCorrel) const;

  Detector fDetector;
  SDEvent fSDEvent;
  std::vector<FDEvent> fFDEvents;
#ifdef AUGER_RADIO_ENABLED
  RdEvent fRdEvent;
#endif
  GenShower fGenShower;

  std::string fEventId;
  UInt_t fYYMMDD;
  UInt_t fHHMMSS;
  Double_t fMJD;

  std::vector<Double_t> fUserData;
  std::map<TString, Double_t> fUserDataMap;

public:
  static std::string GetVersion();
  static std::string GetReleaseName();
  static std::string GetSVNVersion();
  static std::string GetSVNDate();
  static std::string GetSVNRevision();

private:
  static const std::string fgRecEventRelease; //!  don't stream
  static const std::string fgRecEventSVNid;   //!  don't stream
  static const std::string fgRecEventSVNname; //!  don't stream

  ClassDef(RecEvent, 9);
};


ostream& operator<<(ostream& os, const RecEvent& z);

#endif
