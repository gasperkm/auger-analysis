
#include <DetectorGeometry.h>
#include <TelescopeGeometry.h>
#include <EyeGeometry.h>

#include <TGraph.h>
#include <TBits.h>
#include <TLine.h>
#include <TPad.h>
#include <TMath.h>
#include <cmath>

#include <iostream>
using namespace std;

ClassImp(DetectorGeometry);

const unsigned int DetectorGeometry::knPixelPerMirror = 440;

DetectorGeometry::DetectorGeometry() :
  fNeedCacheRebuild(true),
  fMaxX (-1.e99),
  fMaxY (-1.e99),
  fMaxZ (-1.e99),
  fMinX (1.e99),
  fMinY (1.e99),
  fMinZ (1.e99)
{
#ifdef DEBUGKG
  cout << " DetectorGeometry::DetectorGeometry() " << endl;
#endif
}


// -------------- FD part ------------------


void
DetectorGeometry::GetMinMaxPhi(const UInt_t eyeid,
                               const TBits& MiBits,
                               double& MinPhi,
                               double& MaxPhi)
  const
{

  if (HasEye(eyeid)) {
    const EyeGeometry& eye = GetEye(eyeid);
    eye.GetMinMaxPhi(MiBits, MinPhi, MaxPhi);
    return;
  }

  cerr << " ERROR: Detector not available " << endl;
}


void
DetectorGeometry::GetMinMaxOmega(const UInt_t eyeid,
                                 const TBits & MiBits,
                                 double &MinOmega,
                                 double &MaxOmega)
  const
{
  if (HasEye(eyeid)) {
    const EyeGeometry& eye = GetEye(eyeid);
    eye.GetMinMaxOmega(MiBits, MinOmega, MaxOmega);
    return;
  }

  cerr << " ERROR: Detector not available " << endl;
}


void
DetectorGeometry::AddEye(UInt_t eyeid, const EyeGeometry& eye)
{
  if (HasEye(eyeid)) {
    cerr << "ERROR: cannot add eye id=" << eyeid << " it does already exist!"
         << endl;
    return;
  }

  fEyes[eyeid] = eye;
}


EyeGeometry&
DetectorGeometry::GetEye(UInt_t eyeid)
{
  if (HasEye(eyeid))
    return fEyes.find(eyeid)->second;

  cerr << "ERROR: eye id=" << eyeid << " not existing" << endl;
  return fEyes.begin()->second;
}


const EyeGeometry&
DetectorGeometry::GetEye(UInt_t eyeid)
  const
{
  if (HasEye(eyeid))
    return fEyes.find(eyeid)->second;

  cerr << "ERROR: eye id=" << eyeid << " not existing" << endl;
  return fEyes.begin()->second;
}


void
DetectorGeometry::SetEye(const UInt_t eyeid,
                         const double X, const double Y,
                         const double Z,
                         const double phi, const double phiEye,
                         const double thetaEye,
                         const string & eyeName,
                         const string & eyeNameAbbr)
{
  if (HasEye(eyeid)) {
    cerr << "ERROR: Eye with id=" << eyeid << " exists already!" << endl;
    return;
  }

  EyeGeometry eye(X, Y, Z,
                  phi,
                  phiEye,
                  thetaEye,
                  eyeName,
                  eyeNameAbbr);
  AddEye(eyeid, eye);
}


void
DetectorGeometry::SetTelescope(const UInt_t eyeId, const UInt_t mirrorId,
                               const std::map<TString, Double_t>& telElevations,
                               const std::map<TString, Double_t>& telAzimuths,
                               UInt_t nFADC, Double_t bFADC,
                               const std::map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                               const std::map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas)
{
  if (!HasEye(eyeId)) {
    cerr << "ERROR: Cannot add telescope id=" << mirrorId
         << " to non existing eye id=" << eyeId
         << endl;
    return;
  }

  GetEye(eyeId).AddTelescope(mirrorId,
                             telElevations, telAzimuths,
                             nFADC, bFADC,
                             telPixPhis, telPixOmegas);
}


vector<UShort_t>
DetectorGeometry::GetEyeNumbers()
  const
{
  vector <UShort_t> eyeNums;
  for (ConstEyeIterator iEye = fEyes.begin();
       iEye != fEyes.end(); ++iEye)
    eyeNums.push_back(iEye->first);

  return eyeNums;
}


unsigned int
DetectorGeometry::GetFdTriggerReadoutSection(const unsigned int stationID)
  const
{
  if (fNeedCacheRebuild)
    RebuildCache();

  map<unsigned int, unsigned int>::const_iterator triggerSection = fFdTriggerSections.find(stationID);
  if (triggerSection != fFdTriggerSections.end())
    return triggerSection->second;
  else
    return 0;
}


bool
DetectorGeometry::MergeFDFrom(const DetectorGeometry& source)
{
  bool retval = false;

  for (ConstEyeIterator srcEyeIt = source.EyesBegin();
       srcEyeIt != source.EyesEnd(); ++srcEyeIt) {

    UInt_t srcEyeId = srcEyeIt->first;
    // eye doesn't exist yet, copy it
    if (!HasEye(srcEyeId)) {
      fEyes[srcEyeId] = srcEyeIt->second;
      retval = true;
    }
    else // eye exists, merge telescopes
      retval = GetEye(srcEyeId).MergeEyeFrom(srcEyeIt->second) || retval;

  } // end foreach source eye

  fNeedCacheRebuild = retval;
  return retval;
}


// -------------- SD part ------------------

void
DetectorGeometry::SetStation(const unsigned int iStation,
                             const double X, const double Y,
                             const double Z, const int gridType)
{
  if (fStationPos.count(iStation))
    cerr << " DetectorGeometry::SetStation("
         << iStation << ",...) overwrites existing entry"
         << endl;

  fStationPos[iStation] = TVector3(X, Y, Z);
  fStationGridType[iStation] = gridType;
}


void
DetectorGeometry::SetStationName(const unsigned int iStation,
                                 const TString name)
{
  if (fStationName.count(iStation)) {
    cerr << "WARNING DetectorGeometry::SetStationName("
         << iStation << ",...) overwrites existing entry"
         << endl;
  }
  fStationName[iStation] = name;
}


void
DetectorGeometry::SetStationCommissionTime(const unsigned int iStation,
                                           const double gpsSecond)
{
  if (fStationCommissionTime.count(iStation)) {
    cerr << "WARNING DetectorGeometry::SetStationCommissionTime("
         << iStation << ",...) overwrites existing entry"
         << endl;
  }
  fStationCommissionTime[iStation] = gpsSecond;
}


const TString&
DetectorGeometry::GetStationName(const unsigned int i)
  const
{
  StationNameMap::const_iterator it = fStationName.find(i);
  if (it == fStationName.end()) {
    cerr << " ERROR DetectorGeometry::GetStationName("
         << i << " ) nonexisting station" << endl;
    return fStationName.begin()->second;
  }
  return it->second;
}


const TVector3&
DetectorGeometry::GetStationPosition(const unsigned int i)
  const
{
  StationPosMapConstIterator it = fStationPos.find(i);
  if (it == fStationPos.end()) {
    cerr << " ERROR DetectorGeometry::GetStationPosition("
         << i << ") nonexisting station" << endl;
    return fStationPos.begin()->second;
  }
  return it->second;
}


double
DetectorGeometry::GetStationCommissionTime(const unsigned int i)
  const
{
  StationCommissionTimeMap::const_iterator it = fStationCommissionTime.find(i);
  if (it == fStationCommissionTime.end())
  {
    cerr << " ERROR DetectorGeometry::GetStationCommissionTime("
         << i << ") nonexisting station" << endl;
    return fStationCommissionTime.begin()->second;
  }
  return it->second;
}


/// get min and max X coordinate
double DetectorGeometry::GetMinX() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMinX;
}


double DetectorGeometry::GetMaxX() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMaxX;
}


/// get min and max Y coordinate
double DetectorGeometry::GetMinY() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMinY;
}


double DetectorGeometry::GetMaxY() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMaxY;
}


/// get min and max Z coordinate
double DetectorGeometry::GetMinZ() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMinZ;
}


double DetectorGeometry::GetMaxZ() const {
  if (fNeedCacheRebuild)
    RebuildCache();
  return fMaxZ;
}


/// get Id of station closest to (x,y) units: [m]
UInt_t DetectorGeometry::GetClosestStationId(const double x,
                                             const double y)
  const
{
  double minDist2 = -1.;
  unsigned int closestStationId = 0;

  for (StationPosMapConstIterator iStation = fStationPos.begin();
       iStation != fStationPos.end();
       ++iStation) {

    double dist2 = (iStation->second.X()-x) * (iStation->second.X()-x) +
                   (iStation->second.Y()-y) * (iStation->second.Y()-y);
    if(closestStationId == 0 || dist2 < minDist2) {
      closestStationId = iStation->first;
      minDist2         = dist2;
    }
  }

  return closestStationId;
}


/// get distance of station closest to (x,y) units: [m]
double
DetectorGeometry::GetClosestStationDistance(const double x, const double y)
  const
{
  Int_t id = GetClosestStationId(x, y);

  if (fStationPos.count(id)) {
    const TVector3& pos = fStationPos.find (id)->second;
    const double dist2  = (pos.X()-x) * (pos.X()-x) + (pos.Y()-y) * (pos.Y()-y);
    return sqrt(dist2);
  }
  return -1;
}


/// test whether a point is inside the hexagon cell of a station
bool
DetectorGeometry::IsInStationHexagon(const Int_t stId,
                                     const double x,
                                     const double y,
                                     const double gridScale)
  const
{
  const StationPosMapConstIterator it = fStationPos.find(stId);
  if (it == fStationPos.end())
    return false;

  const double dx = (x-it->second.X())/gridScale;
  const double dy = (y-it->second.Y())/gridScale;
  const double rr = dx*dx + dy*dy;

  static const double dphi = TMath::Pi()/3.0;

  double phi = TMath::ATan2(dx,dy)+TMath::Pi();
  phi -= int(phi / dphi)*dphi + TMath::Pi()/6.0;

  const double cosPhi = TMath::Cos(phi);
  const double rrMax = 0.25/(cosPhi*cosPhi);
  return rr < rrMax;
}


vector<int>
DetectorGeometry::GetStationIds()
  const
{
  vector<int> ids;

  for (StationPosMapConstIterator iter = GetStationsBegin();
       iter != GetStationsEnd(); ++iter )
    ids.push_back( iter->first );

  return ids;
}


vector<double>
DetectorGeometry::GetStationXPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetStationsBegin();
       iter != GetStationsEnd(); ++iter )
    pos.push_back( (iter->second)[0] );

  return pos;
}


vector<double>
DetectorGeometry::GetStationYPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetStationsBegin();
       iter != GetStationsEnd(); ++iter )
    pos.push_back( (iter->second)[1] );

  return pos;
}


vector<double>
DetectorGeometry::GetStationZPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetStationsBegin();
       iter != GetStationsEnd(); ++iter )
    pos.push_back( (iter->second)[2] );

  return pos;
}


double
DetectorGeometry::GetStationAxisDistance(const TVector3& tank,
                                         const TVector3& axis,
                                         const TVector3& core)
  const
{
  const TVector3 coreTankVec   = tank - core;
  const double tankProj        = (coreTankVec * axis)/axis.Mag2();
  const TVector3 tankAxisVec   = coreTankVec - (tankProj * axis);
  return tankAxisVec.Mag();
}


double
DetectorGeometry::GetStationAxisDistance(const int stId,
                                         const TVector3& axis,
                                         const TVector3& core)
  const
{
  const TVector3& tank = fStationPos.find(stId)->second;
  return GetStationAxisDistance(tank, axis, core);
}


/// get station coordinates in Shower plane [m]
const TVector2
DetectorGeometry::GetStationShowerPosition(const TVector3& tank,
                                           const TVector3& axis,
                                           const TVector3& core)
  const
{
  const TVector3 coreTankVec = tank - core ;
  const double tankProj = (coreTankVec * axis)/axis.Mag2();
  const TVector3 tankAxisVec =  (tankProj * axis)-coreTankVec;
  const TVector3 xyVector(axis.X(), axis.Y(), 0);
  TVector3 xyProjection = (xyVector*axis)*axis-xyVector;
  double phiSP = xyProjection.Angle(tankAxisVec);
  xyProjection.Rotate(TMath::Pi(), axis);
  const TVector3 cross = xyProjection.Cross(tankAxisVec);

  if (cross.Z()>0)
    phiSP = -phiSP;
  const double mag = tankAxisVec.Mag();
  const double x = mag*cos(phiSP);
  const double y = mag*sin(phiSP);
  return TVector2(x, y);
}


TVector2
DetectorGeometry::GetStationShowerPosition(const int stId,
                                           const TVector3& axis,
                                           const TVector3& core) const
{
  const TVector3& tank = fStationPos.find(stId)->second;
  return GetStationShowerPosition(tank, axis, core);

}


const vector<unsigned int>&
DetectorGeometry::GetHexagon(const unsigned int stationID, const EGridFlag flag) const
{
  if (fNeedCacheRebuild)
    RebuildCache();

  const size_t type = flag == eRegularArray ? 0 : 1;
  HexagonCache::const_iterator iter = fHexagons[type].find(stationID);
  if (iter != fHexagons[type].end())
    return iter->second;
  else
    return fHexagons[0][0];
}


void DetectorGeometry::RebuildCache() const
{
  fNeedCacheRebuild = false;

  // find the closest eye for each station
  fFdTriggerSections.clear();
  for (StationPosMapConstIterator iStation = fStationPos.begin();
       iStation != fStationPos.end(); ++iStation) {

    unsigned int closestEye      = 0; //closest EyeId == FdTriggerSection
    double closestEyeDistance    = 0;
    const TVector3 & iStationVec = iStation->second;

    for (ConstEyeIterator eyeIter = this->EyesBegin();
         eyeIter != this->EyesEnd(); ++eyeIter) {

      UInt_t eyeId                = eyeIter->first;
      const EyeGeometry & eyeGeom = eyeIter->second;
      const TVector3 & eyeVec     = eyeGeom.GetEyePos();

      double distance = (iStationVec-eyeVec).Mag();
      if (distance < closestEyeDistance || closestEyeDistance == 0) {
        closestEye = eyeId;
        closestEyeDistance = distance;
      }
    }

    fFdTriggerSections[iStation->first] = closestEye;
  }

  // get extension of experiment
  bool first = true;
  for (StationPosMapConstIterator iStation = fStationPos.begin();
       iStation != fStationPos.end();
       ++iStation) {

    const double x = iStation->second.X();
    const double y = iStation->second.Y();
    const double z = iStation->second.Z();

    if (first) {
      first = false;
      fMinX = x;
      fMaxX = x;
      fMinY = y;
      fMaxY = y;
      fMinZ = z;
      fMaxZ = z;
    } else {

      if (x > fMaxX) fMaxX = x;
      if (x < fMinX) fMinX = x;
      if (y > fMaxY) fMaxY = y;
      if (y < fMinY) fMinY = y;
      if (z > fMaxZ) fMaxZ = z;
      if (z < fMinZ) fMinZ = z;
    }

  }

  for (ConstEyeIterator iEye = fEyes.begin();
       iEye!=fEyes.end();
       ++iEye) {

    TVector3 eyePos = iEye->second.GetEyePos();
    const double x = eyePos.X();
    const double y = eyePos.Y();
    const double z = eyePos.Z();

    if (first) {
      first = false;
      fMinX = x;
      fMaxX = x;
      fMinY = y;
      fMaxY = y;
      fMinZ = z;
      fMaxZ = z;
    } else {
      if (x > fMaxX) fMaxX = x;
      if (x < fMinX) fMinX = x;
      if (y > fMaxY) fMaxY = y;
      if (y < fMinY) fMinY = y;
      if (z > fMaxZ) fMaxZ = z;
      if (z < fMinZ) fMinZ = z;
    }
  }

#ifdef AUGER_RADIO_ENABLED
  // Search for the size of the RStation
  for (StationPosMapConstIterator antiter = fRdStationsPos.begin();
       antiter != fRdStationsPos.end(); ++antiter) {
    const double x = antiter->second.X();
    const double y = antiter->second.Y();
    const double z = antiter->second.Z();
    if (x > fMaxX) fMaxX = x;
    if (x < fMinX) fMinX = x;
    if (y > fMaxY) fMaxY = y;
    if (y < fMinY) fMinY = y;
    if (z > fMaxZ) fMaxZ = z;
    if (z < fMinZ) fMinZ = z;
  }
#endif

  // find first crown for different grids
  const double gridScales[] = { 1500, 750 };
  const double tolerances[] = { 150, 100 };
  for (size_t iType = 0; iType < 2; ++iType)
    fHexagons[iType].clear();
  for (StationPosMapConstIterator iStation = fStationPos.begin();
       iStation != fStationPos.end(); ++iStation) {

    vector<unsigned int> stationIds[2];
    for (size_t iType = 0; iType < 2; ++iType)
      stationIds[iType].push_back(iStation->first);
    const TVector3& iStationVec = iStation->second;
    for (StationPosMapConstIterator jStation = fStationPos.begin();
         jStation != fStationPos.end(); ++jStation) {

      if (iStation == jStation) continue;

      const TVector3& jStationVec = jStation->second;

      const double distance = (jStationVec-iStationVec).Mag();

      for (size_t iType = 0; iType < 2; ++iType)
        if (fabs(distance-gridScales[iType]) < tolerances[iType])
          stationIds[iType].push_back(jStation->first);
    }

    for (size_t iType = 0; iType < 2; ++iType)
      fHexagons[iType][iStation->first] = stationIds[iType];
  }
}


unsigned int
DetectorGeometry::MergeStationsFrom(const DetectorGeometry& source)
{
  if (source.fStationName.size() < fStationName.size())
    return 0;

  const unsigned int newStations = source.fStationName.size() - fStationName.size();
  fNeedCacheRebuild = true;

  for (StationNameMap::const_iterator it = source.fStationName.begin(),
       end = source.fStationName.end(); it != end; ++it)
  {
    const unsigned int i = it->first;
    if (isKnown(i)) continue;
    fStationPos[i] = source.fStationPos.find(i)->second;
    fStationName[i] = source.fStationName.find(i)->second;
    fStationGridType[i] = source.fStationGridType.find(i)->second;
    fStationCommissionTime[i] = source.fStationCommissionTime.find(i)->second;
  }

  return newStations;
}


//-------------------------------------------------------------------

#ifdef AUGER_RADIO_ENABLED
// -------------- Radio part ------------------

void
DetectorGeometry::SetRdStation(unsigned int iAnt, double X, double Y, double Z)
{
  if (fRdStationsPos.count(iAnt))
    cerr << " DetectorGeometry::SetStation> overwrite station " << iAnt << endl;

  fRdStationsPos[iAnt] = TVector3(X, Y, Z);
}


void
DetectorGeometry::SetRdStationName(unsigned int iAnt, TString name)
{
  if (fRdStationName.count(iAnt))
    cerr << " DetectorGeometry::SetRdStation> overwrite station name " << iAnt << endl;

  fRdStationName[iAnt] = name;
}


TString& DetectorGeometry::GetRdStationName(unsigned int i) {
  if (fRdStationName.count(i))
    return fRdStationName[i];
  else {
    cout << " ERROR DetectorGeometry::GetRdStationName "
         << i << " (int i) nonexisting station" << endl;
    return fRdStationName.begin()->second;
  }
}


const TString&
DetectorGeometry::GetRdStationName(unsigned int i)
  const
{
  if (fRdStationName.count(i))
    return fRdStationName.find(i)->second;
  else {
    cout << " ERROR DetectorGeometry::GetRdStationName(int i) "
         << i << " nonexisting station" << endl;
    return fRdStationName.begin()->second;
  }
}


TVector3& DetectorGeometry::GetRdStationPosition(unsigned int i) {
  if (fRdStationsPos.count(i))
    return fRdStationsPos[i];
  else {
    cout << " ERROR DetectorGeometry::GetRdStationPosition(int i) nonexisting station " << i << endl;
    return fRdStationsPos.begin()->second;
  }
}


const TVector3&
DetectorGeometry::GetRdStationPosition(unsigned int i)
  const
{
  if (fRdStationsPos.count(i))
    return fRdStationsPos.find(i)->second;
  else {
    cout << " ERROR DetectorGeometry::GetRdStationPosition(int i) nonexisting station " << i <<  endl;
    return fRdStationsPos.begin()->second;
  }
}


/// get station coordinates in Shower plane [m]
TVector3
DetectorGeometry::GetRdStationShowerPosition(const TVector3& tank,
                                           const TVector3& axis,
                                           const TVector3& core)
  const
{
  TVector3 coreTankVec   = tank - core ;
  double theta=axis.Theta();
  double phi=axis.Phi();
  coreTankVec.RotateZ(-phi);
  coreTankVec.RotateY(-theta);
  return coreTankVec;

}


/// get Id of station closest to (x,y) units: [m]
UInt_t
DetectorGeometry::GetClosestRdStationId(double x, double y)
  const
{
  double minDist2 = -1.;
  unsigned int closestRdStationId = 0;

  for (StationPosMapConstIterator iRdStation = fRdStationsPos.begin();
       iRdStation != fRdStationsPos.end(); ++iRdStation) {

    double dist2 = (iRdStation->second.X()-x)*(iRdStation->second.X()-x) +
                   (iRdStation->second.Y()-y)*(iRdStation->second.Y()-y);
    if(closestRdStationId == 0 || dist2 < minDist2) {
      closestRdStationId = iRdStation->first;
      minDist2         = dist2;
    }
  }

  return closestRdStationId;
}


/// get distance of station closest to (x,y) units: [m]
double
DetectorGeometry::GetClosestRdStationDistance(double x, double y)
  const
{
  Int_t id = GetClosestRdStationId(x, y);

  if (fRdStationsPos.count(id)) {
    const TVector3 &pos = fRdStationsPos.find(id)->second;
    const double dist2  = (pos.X()-x) * (pos.X()-x) + (pos.Y()-y) * (pos.Y()-y);
    return sqrt(dist2);
  }
  return -1;
}


double
DetectorGeometry::GetRdStationAxisDistance(const TVector3& tank,
                                         const TVector3& axis,
                                         const TVector3& core)
  const
{
  TVector3 coreTankVec   = tank - core ;
  double tankProj        = (coreTankVec * axis) ;
  TVector3 tankAxisVec   = coreTankVec - (tankProj * axis) ;
  return tankAxisVec.Mag();
}


vector<double>
DetectorGeometry::GetRdStationXPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetRdStationsBegin();
       iter != GetRdStationsEnd(); ++iter)
    pos.push_back( (iter->second)[0] );

  return pos;
}


vector<double>
DetectorGeometry::GetRdStationYPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetRdStationsBegin();
       iter != GetRdStationsEnd(); ++iter)
    pos.push_back( (iter->second)[1] );

  return pos;
}


vector<double>
DetectorGeometry::GetRdStationZPositions()
  const
{
  vector<double> pos;
  for (StationPosMapConstIterator iter = GetRdStationsBegin();
       iter != GetRdStationsEnd(); ++iter)
    pos.push_back( (iter->second)[2] );

  return pos;
}


double
DetectorGeometry::GetRdStationAxisDistance(int stId,
                                         const TVector3& axis,
                                         const TVector3& core)
  const
{
  const TVector3& tank = fRdStationsPos.find(stId)->second;
  return GetRdStationAxisDistance(tank, axis, core);
}


TVector3
DetectorGeometry::GetRdStationShowerPosition(int stId,
                                           const TVector3& axis,
                                           const TVector3& core)
{
  const TVector3& tank = fRdStationsPos.find(stId)->second;
  return GetRdStationShowerPosition(tank, axis, core);
}


#endif
