// $Id: FdMultiTrace.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdMultiTrace.h>


ClassImp(FdMultiTrace);
