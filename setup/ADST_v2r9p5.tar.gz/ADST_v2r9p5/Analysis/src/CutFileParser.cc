
#include <CutFileParser.h>
#include <CutFileParserV1.h>

// ROOT regexp stuff
#include <TPRegexp.h>
#include <TObjArray.h>
#include <TObjString.h>
#include <TString.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <ios>
#include <cstdlib>

using namespace std;

CutFileParser::CutFileParser(const string& selectionName) :
  fVerbosity(0)
{
  SetSelectionName(selectionName);
}


CutFileVersion CutFileParser::DetermineCutFileType(const std::string& cutFileName) {
  CutFileVersion version;
  version.majorType = eLegacyCutFile;
  version.minorVersion = 0;

  ifstream in;

  in.open(cutFileName.c_str());
  if (!in.good()) {
    string errMsg = " CutFileParser::DetermineCutFileType() - Error reading cut file "
      + cutFileName
      + " \n  ********* no cuts will be applied!!! ********* ";
    throw std::runtime_error(errMsg);
  }

  while (!in.eof()) {
    string buffer;
    if (!in.good()) break;
    getline(in, buffer);

    StripComments(buffer);

    TString rootBuffer(buffer);
    if (CutFileParserV1::fgIsEmptyLine->MatchB(rootBuffer))
      continue;

    TObjArray* matches = CutFileParserV1::fgIsNewTypeRegexp->MatchS(rootBuffer); // should be cleared by the regexp obj!? Thanks, ROOT!
    if (matches->GetLast() > 0) {
      const TString majorVersion = ((TObjString *)matches->At(1))->GetString();
      const TString minorVersion = ((TObjString *)matches->At(2))->GetString();

      // check major version validity
      const int majorVersionInt = atoi(majorVersion);
      if (majorVersionInt == 1)
        version.majorType = eStdCutFileV1;
      else if (majorVersionInt == 0)
        version.majorType = eLegacyCutFile;
      else {
        string errMsg = " CutFileParser::DetermineCutFileType() - Cut file "
          + cutFileName
          + " specifies invalid major cut file format version '" + majorVersion.Data()
          + "'\n  ********* no cuts will be applied!!! ********* ";
        throw std::runtime_error(errMsg);
      }

      const char* minorV = minorVersion.Data()+1;
      version.minorVersion = atoi(minorV);
    }
    // "else:"
    // If that if didn't match:
    // It's not an empty line, but it doesn't match the version
    // pattern  ==>   must be old style file
    else {
      string errMsg = "CutFileParser::DetermineCutFileType() - Cut file '"
        + cutFileName + "'"
        + " does not specify a file format version. In previous versions"
        + " of the ADST Analysis package, this was silently tolerated and"
        + " the default behaviour was to use the old (pre 1.0) cut file"
        + " syntax and parser. No longer! The old behaviour is buggy and"
        + " deprecated! Please convert to the new syntax using the tool"
        + " provided in your Offline source tree under:\n"
        + "    ADST/Analysis/util/ConvertOldCutFilesToNewCutFiles\n"
        + "For details, check the ADST Analysis manual.\n";
      cerr << "===========\n  WARNING\n===========\n"<< errMsg<<"\n"<<endl;
    }

    // found first non-empty line, done.
    break;
  }
  in.close();

  return version;
}


void CutFileParser::ReadCuts(const vector<string>& cutFiles, vector<Cut>& cutList, bool makeNMinusOne) {
  // read cuts from files

  if (fVerbosity > -1)
    cout << " \n\tinitializing " << fSelectionName <<" cuts... \n" << endl;

  const unsigned int nCutFiles = cutFiles.size();
  if (nCutFiles == 0) {
    string errMsg = " CutFileParser::ReadCuts() - No cut file for selection '"
      + fSelectionName
      + "'.";
    //throw std::runtime_error(errMsg);
    if (fVerbosity > -1)
      cout << errMsg << endl;
  }

  for (unsigned int cutFileNo = 0; cutFileNo < nCutFiles; ++cutFileNo) {
    const string& cutFile = cutFiles[cutFileNo];
    CutFileVersion version = DetermineCutFileType(cutFile);

    if (version.majorType == eLegacyCutFile)
      LegacyReadCuts(cutFile, cutList, makeNMinusOne);
    else {
      CutFileParserV1 parser;
      parser.SetVerbosity(fVerbosity);
      //parser.SetVerbosity(5); // debugging
      try {
        parser.Parse(cutFile, cutList, makeNMinusOne);
      }
      catch(...) {
        cerr << "Exception from the cut file parser!" << endl;
        throw;
      }
    }
  } // end for files
  cout << endl;
}


void CutFileParser::LegacyReadCuts(const string& cutFile, vector<Cut>& cutList, bool makeNMinusOne) {
  char preFix[] = "\t   --> ";

  ifstream in;

  in.open(cutFile.c_str());
  if (!in.good()) {
    string errMsg = " CutFileParser::LegacyReadCuts() - Error reading cut file "
      + cutFile
      + " \n  ********* no cuts will be applied!!! ********* ";
    throw std::runtime_error(errMsg);
  }

  bool beginning = true;
  while (!in.eof()) {
    string buffer;
    if (!in.good()) break;
    getline(in, buffer);

    // This is all just to ignore leading cut file version declarations
    if (beginning) {
      StripComments(buffer);
      RemoveLeadingAndTrailingWhiteSpace(buffer);
      TString rootBuffer(buffer);
      if (CutFileParserV1::fgIsEmptyLine->MatchB(rootBuffer))
        continue;
      beginning = false; // first non-empty, non-comment line

      // Skip optional version declaration
      if (CutFileParserV1::fgIsNewTypeRegexp->MatchB(rootBuffer))
        continue;
    }

    double cutValue;
    double cutSlope=0.;
    int nBins=100;
    double xMin=0.;
    double xMax=0.;

    vector<string> lineTokens = LegacyTokenizeLine(buffer);
    const unsigned int nTokens = lineTokens.size();

    string cutName;
    if (nTokens <= 1 || lineTokens[0] == "\n" || lineTokens[0] == "")
      continue;

    // The following cases are currently recognized:
    // 2 tokens: name value
    // 3 tokens: name value slope
    // 4 tokens: INVALID!
    // 5 tokens: name value nbins xmin xmax (for n-1 histograms)
    // 6 tokens: name value slope nbins xmin xmax
    if (nTokens >= 2) {
      cutName  = lineTokens[0];
      stringstream conv(lineTokens[1]);
      conv >> cutValue;
    }

    if (nTokens == 3) {
      stringstream conv(lineTokens[2]);
      conv >> cutSlope;
    }
    else if (nTokens == 4) {
      string errMsg = string("Invalid number of parameters to cut '") + cutName + string("'");
      throw std::runtime_error(errMsg);
    }
    else if (nTokens == 5) {
      // stringstreams don't seem to take recycling well (with str())
      stringstream conv(lineTokens[2]);
      conv >> nBins;
      stringstream conv2(lineTokens[3]);
      conv2 >> xMin;
      stringstream conv3(lineTokens[4]);
      conv3 >> xMax;
    }
    else if (nTokens >= 6) {
      stringstream conv(lineTokens[2]);
      conv >> cutSlope;
      stringstream conv2(lineTokens[3]);
      conv2 >> nBins;
      stringstream conv3(lineTokens[4]);
      conv3 >> xMin;
      stringstream conv4(lineTokens[5]);
      conv4 >> xMax;
    }

    // check for duplicate cuts
    //    bool haveCut = false;
    //    bool existingCutIsAntiCut = false;
    // for ( unsigned int i=0; i< cutList.size(); i++ ) {
    //   if ( cutList[i].GetName() == cutName ) {
    //     haveCut = true; // unused
    //     existingCutIsAntiCut = cutList[i].IsAntiCut();
    //     break;
    //   }
    // }  // loop contains only unused variables

    // check for anti-Cut
    bool isAntiCut=false;
    string::size_type loc = cutName.find( "!", 0 );
    int firstLoc=0;
    int length=cutName.size();
    if( loc == 0 ) {
      firstLoc=1;
      length--;
      isAntiCut=true;
    }

    // Add cut
    Cut theCut(string(cutName,firstLoc,length),
               cutValue,cutSlope, isAntiCut, makeNMinusOne, nBins, xMin, xMax);
    if (fVerbosity > -1)
      cout << preFix << theCut.Info() << endl;
    cutList.push_back(theCut);

  } // end for lines

  if (fVerbosity > -1)
    cout << endl;
}

vector<string> CutFileParser::LegacyTokenizeLine(string buffer) {
  RemoveLeadingAndTrailingWhiteSpace(buffer);
  stringstream inputStream(buffer);

  vector<string> tokens;
  string token;

  while ( !inputStream.eof()
          && !(inputStream.rdstate() & ios_base::failbit)
          && !(inputStream.rdstate() & ios_base::eofbit)  ) {

    inputStream >> token;

    if ( token.length() == 0
         || token[0] == '|'
         || token[0] == '#'
         || token[0] == '\n' )
      return tokens;
    RemoveLeadingAndTrailingWhiteSpace(token);
    if (token.length() == 0)
      return tokens;

    tokens.push_back(token);
  }

  return tokens;
}

void CutFileParser::RemoveLeadingAndTrailingWhiteSpace (string& line) {
  TString buffer(line);
  TPRegexp front("^\\s+");
  TPRegexp back("\\s+$");
  front.Substitute(buffer, "");
  back.Substitute(buffer, "");
  line = string(buffer.Data());
}

void CutFileParser::StripComments(string& line) {
  TString buffer(line);
  TPRegexp comments("#.*$");
  comments.Substitute(buffer, "");
  line = string(buffer.Data());
}

