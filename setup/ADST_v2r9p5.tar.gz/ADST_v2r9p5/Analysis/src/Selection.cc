// $Id: Selection.cc 18212 2010-12-21 14:16:51Z darko $

#include <Selection.h>
#include <CutFileParser.h>

#include <RecEvent.h>
#include <FDEvent.h>
#include <DetectorGeometry.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <ios>

using namespace std;


map<string, CutSpec> Selection::fgCutNameFunctionMap;
map<string, string> Selection::fgUserConfiguration;

const FDEvent* Selection::fCurrFD = NULL;
const RecEvent* Selection::fCurrEvent = NULL;
const DetectorGeometry * Selection::fCurrGeometry = NULL;


Selection::Selection(const DetectorGeometry* const* geom,
                     const RecEvent* const* event,
                     int verbosity,
                     bool nMinusOne,
                     const string& /*cutFile*/) :
  fDetectorGeometry(geom),
  fEvent(event),
  fVerbosity(verbosity),
  fNMinusOne(nMinusOne),
  fNAugerEvents(0.),
  fNFDEvents(0.),
  fCutWhichKilledEvent(-1)
{
}


Selection::Selection(const DetectorGeometry* const* geom,
                     const RecEvent* const* event,
                     int verbosity,
                     bool nMinusOne,
                     const vector<string>& /*cutFiles*/) :
  fDetectorGeometry(geom),
  fEvent(event),
  fVerbosity(verbosity),
  fNMinusOne(nMinusOne),
  fNAugerEvents(0.),
  fNFDEvents(0.),
  fCutWhichKilledEvent(-1)
{
}


void Selection::ReadCuts(const string& cutFile) {
  // just a proxy for the variant that accepts vectors of
  // cut file names
  vector<string> cutFiles;
  cutFiles.push_back(cutFile);
  ReadCuts(cutFiles);
}

void Selection::ReadCuts(const vector<string>& cutFiles) {
  // read cuts from files
  CutFileParser parser(fSelectionName);
  parser.ReadCuts(cutFiles, fCuts, fNMinusOne);
}

// Fill a C array of cut specifications into the global cut map
void Selection::AddToCutRegistry(const CutSpec* cuts) {
  if (cuts == NULL)
    return;

  unsigned int cutNo = 0;
  while (cuts[cutNo].GetCutName() != string("END")) {
    fgCutNameFunctionMap[ cuts[cutNo].GetCutName() ] = cuts[cutNo];
    cutNo++;
  }
}

// Fill a single new cut into the global cut map
void Selection::AddToCutRegistry(const string& cutName, CutSpec::CutFunctionPtr cutFunctionPtr) {
  fgCutNameFunctionMap[ cutName ] = CutSpec(cutName, cutFunctionPtr);
}

// Fill a single new cut into the global cut map
void Selection::AddToCutRegistry(const string& cutName, CutSpec::CutFunctionPtr cutFunctionPtr, int nParams) {
  fgCutNameFunctionMap[ cutName ] = CutSpec(cutName, cutFunctionPtr, nParams);
}

// Insert those cuts which exist in the cut name => ptr map into the list
// of cut functions to apply
void Selection::InitializeCutFunctions() {
  const vector<Cut>& theCuts = GetCuts();

  map<string, CutSpec>::iterator iter = fgCutNameFunctionMap.begin();
  for (unsigned int i = 0; i < theCuts.size(); ++i) {
    iter = fgCutNameFunctionMap.find( theCuts[i].GetName() );

    if (iter != fgCutNameFunctionMap.end()) {
      AddCutFunction( iter->second.GetCutFunction() );
    }
    else
      cerr << "Unknwon cut specified. The cut name was " << theCuts[i].GetName() << ". Skipping." << endl;
  }
}

bool Selection::IsSelected(int eyeID, double weight) {
  fCutWhichKilledEvent = -1;

  if (fCuts.empty()) // nothing to cut...
    return true;

  vector<bool> passedCut(fCuts.size());

  fCurrGeometry = (*fDetectorGeometry);
  fCurrEvent = (*fEvent);

  if (eyeID > 0) {
    if (fCurrEvent->HasEye(eyeID)) {
      fNFDEvents += weight;
      fCurrFD = &(fCurrEvent->GetEye(eyeID));
    }
    else
      return false;
  }
  else {
    fCurrFD = NULL;
    fNAugerEvents += weight;
  }

  unsigned int nNotSelected = 0;

  for (unsigned int i = 0; i < fCuts.size(); ++i) {
    bool sel = fCutFunctions[i](fCuts[i]);
    if (fVerbosity > 1)
      cout << fCuts[i].GetName() << " " << sel << endl;
    if (!fNMinusOne && !sel) {
      fCutWhichKilledEvent = i;
      return false;
    }
    else {
      passedCut[i]=sel;
      if (!sel) {
        if (fCutWhichKilledEvent < 0)
          fCutWhichKilledEvent = i;
        nNotSelected++;
      }
      else if (nNotSelected == 0)
        fCuts[i].IncrementEventCounter(weight);

      if (nNotSelected > 1)
        return false;
    }
  }

  if (!fNMinusOne)
    return true;
  else {
    for (unsigned int i = 0; i < fCuts.size(); ++i) {
      bool fillit = true;
      for (unsigned int j = 0; j < fCuts.size(); ++j) {
        if (j != i)
          fillit &= passedCut[j];
        if (!fillit)
          break;
      }

      fCuts[i].SetNMinusOne(fillit);
      if (fillit)
        fCuts[i].FillNMinusOne(weight);
    }
    if (nNotSelected == 0)
      return true;
    else
      return false;
  }
}

double Selection::GetEfficiency(unsigned int iCut) const {
  const vector<Cut>& theCuts = GetCuts();
  if (iCut > theCuts.size() - 1)
    return 0.;
  else {
    double denom;
    if (iCut == 0)
      denom = GetNEvents();
    else
      denom = theCuts[iCut-1].GetNEvents();

    if (denom == 0.)
      return 0.;
    else
      return theCuts[iCut].GetNEvents()/denom;
  }
}

void Selection::WriteNMinusOne() {
  for (unsigned int i = 0; i < fCuts.size(); ++i)
    fCuts[i].Write();
}

void Selection::WriteCutStatistics(const string& prefix) const {
  const vector<Cut>& theCuts = GetCuts();

  const unsigned int nCuts = theCuts.size();
  string nEventsName = prefix + fSelectionName + string("NumberOfEventsAfterCuts");
  string cutEfficiencyName = prefix + fSelectionName + string("CutEfficiency");
  TH1I* nEvents = new TH1I(
    nEventsName.c_str(), "number of events after cuts",
      nCuts+1, 0, nCuts+1
  );
  nEvents->GetYaxis()->SetTitle("number of events");
  TH1D* cutEfficiency = new TH1D(
    cutEfficiencyName.c_str(), "selection efficiency",
      nCuts+1, 0, nCuts+1
  );
  cutEfficiency->GetYaxis()->SetTitle("selection efficiency [%]");
  nEvents->GetXaxis()->SetBinLabel(1, "input");
  cutEfficiency->GetXaxis()->SetBinLabel(1, "input");
  nEvents->SetBinContent(1, GetNEvents());
  cutEfficiency->SetBinContent(1, 100.);

  for (unsigned int i = 0; i < theCuts.size(); ++i) {
    const Cut& cut = theCuts[i];
    const string& name = cut.GetName();
    const unsigned int binIndex = i+2;
    nEvents->GetXaxis()->SetBinLabel(binIndex, name.c_str());
    cutEfficiency->GetXaxis()->SetBinLabel(binIndex, name.c_str());
    nEvents->SetBinContent(binIndex, cut.GetNEvents());
    cutEfficiency->SetBinContent(binIndex, GetEfficiency(i)*100.);
  }

  nEvents->Write();
  cutEfficiency->Write();
  delete cutEfficiency;
  delete nEvents;
}


void Selection::PrintCutStatistics(bool latex) const {
  const string separator = (latex?"&":"");
  const string nextLine  = (latex?"\\\\":"");

  _Ios_Fmtflags oldFormat = cout.flags();
  int oldPrecision             = cout.precision();

  const vector<Cut>& theCuts = GetCuts();

  // max length of cut string
  unsigned int maxCutStringSize = 0;
  for (unsigned int i = 0; i < theCuts.size(); ++i)
    if (theCuts[i].GetName().size() > maxCutStringSize)
      maxCutStringSize = theCuts[i].GetName().size();

  // TeX header (if needed)
  if (latex) {
    cout << "\\begin{tabular}{| l| r | c |}\\hline" << "\n"
         << "\\bf cut & \\bf events & \\bf efficiency [\\%]"
         << nextLine << "\\hline\\hline \n";
  }

  // total number of events
  cout << setw(maxCutStringSize+3) << " nTot " << separator;
  if (GetNEvents() < 1e6 && GetNEvents() >= 1.)
    cout  << setw(10)  << (int) GetNEvents();
  else
    cout  << setprecision(3) << setw(10)  << GetNEvents();
  cout << separator << setw(10) << " -- " << nextLine << "\n";

  // print cut names, #events, efficiency
  for (unsigned int i = 0; i <theCuts.size(); ++i) {
    cout << setw(maxCutStringSize+3) << theCuts[i].GetName()
         << separator;
    if  (theCuts[i].GetNEvents() < 1e6 && theCuts[i].GetNEvents() >= 1.)
      cout << setw(10)  << (int) theCuts[i].GetNEvents();
    else
      cout << setprecision(3) << setw(10)  << theCuts[i].GetNEvents();

    cout << separator << setw(10) << showpoint << setprecision(1)
         << setiosflags(ios::fixed)
         << GetEfficiency(i)*100. << nextLine;
    if (latex && i == theCuts.size()-1)
      cout << "\\hline";
    cout << endl;
  }

  if (latex)
    cout << "\\end{tabular}" << endl;

  cout.flags(oldFormat);
  cout.precision(oldPrecision);
}

CutSpec* Selection::GetCutFromRegistry(const string& cutName) {
  map<string, CutSpec>::iterator iter = Selection::fgCutNameFunctionMap.find(cutName);
  if (iter != fgCutNameFunctionMap.end()) {
    return &(iter->second);
  }
  else
    return NULL;
};

