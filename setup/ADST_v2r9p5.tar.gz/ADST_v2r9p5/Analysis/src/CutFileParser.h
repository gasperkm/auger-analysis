#ifndef __include_CutFileParser_H
#define __include_CutFileParser_H

#include <Cut.h>

#include <TString.h>

#include <vector>
#include <string>
#include <sstream>

class TPRegexp;

enum CutFileType {
  eLegacyCutFile = 0, // the old, limited format
  eStdCutFileV1,      // the tentative new, "better" format
};

struct CutFileVersion {
  CutFileType majorType;
  unsigned int minorVersion;
};

class CutFileParser {
public:
  CutFileParser(const std::string& selectionName);

  int GetVerbosity() { return fVerbosity; }
  void SetVerbosity(int v) { fVerbosity = v; }

  const std::string& GetSelectionName() { return fSelectionName; }
  void SetSelectionName (const std::string& name) { fSelectionName = name; }

  void ReadCuts(const std::vector<std::string>& cutFiles, std::vector<Cut>& cutList, bool makeNMinusOne);
  CutFileVersion DetermineCutFileType(const std::string& cutFileName);

private:
  // routines for legacy cuts file parsing
  void LegacyReadCuts(const std::string& cutFile, std::vector<Cut>& cutList, bool makeNMinusOne);
  std::vector<std::string> LegacyTokenizeLine(std::string buffer);

  void RemoveLeadingAndTrailingWhiteSpace (std::string& line); // also used by legacy code
  void StripComments(std::string& line);

  std::string fSelectionName;
  int fVerbosity;
};
#endif
