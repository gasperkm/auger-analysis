
#include <CutSpec.h>

using namespace std;

CutSpec::CutSpec(const std::string cutName, CutFunctionPtr cutFunction, int nParams)
  : fCutName(cutName), fCutFunction(cutFunction), fNParams(nParams)
{
}

CutSpec::CutSpec(const std::string cutName, CutFunctionPtr cutFunction)
  : fCutName(cutName), fCutFunction(cutFunction), fNParams(-1)
{
}

CutSpec::CutSpec(const std::string cutName)
  : fCutName(cutName), fCutFunction(NULL), fNParams(-1)
{
}

CutSpec::CutSpec()
  : fCutName(string("")), fCutFunction(NULL), fNParams(-1)
{
}
