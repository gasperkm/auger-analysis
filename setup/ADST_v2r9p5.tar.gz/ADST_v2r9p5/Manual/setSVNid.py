import sys
import os
import time
import re
# $Id: Manual.tex 18212 2010-12-21 14:16:51Z darko $
fn = sys.argv[1]
fnShort = os.path.split(fn)[-1]
rev = "unknown"
haveGit = bool(os.popen("which git").read())
haveSVN = bool(os.popen("which svn").read())
if haveGit :
  output = os.popen("git svn info").read()
  match = re.search("Revision: (\d+)", output)
  if match:
    rev = match.group(1)
if haveSVN and rev == "unknown":
  output = os.popen("test -e .svn && svn info").read()
  match = re.search("Revision: (\d+)", output)
  if match:
    rev = match.group(1)
fdatetime = time.strftime("%Y-%M-%d %H:%m:%SZ", time.gmtime(os.stat(fn).st_mtime))
content = file(fn).read()
idStr = "$Id: %(fnShort)s %(rev)s %(fdatetime)s unknown $" % locals()

if "$Id$" in content:
  file(fn,"w").write(content.replace("$Id$",idStr))
