#ifndef __include__EventBrowserSignale_h_
#define __include__EventBrowserSignale_h_

// list of signals
enum EButtonSignals {


  // file menu
  eFileOpen,
  eFileSavePS,
  eFileSaveROOT,
  eFileSaveSelection,
  eFileDumpASCII,
  eViewOfflineConfig,
  eLoadSources,
  eLoadStyle,
  eFileClear,
  eFileTreeViewer,
  eFileQuit,

  // options menu
  eAnimate,
  eSaveAnimations,
  eSpeedAnimations,
  eShowerPlaneArray,
  eCumulativeFDAperture,
  eShowZeta,
  eShowFDT3SDP,
  eShowXmaxInSDP,
  eShowSDinFD,
  eShowAerosols,
  eShowTelsInDAQ,
  eShowViewableFOV,
  eUseLCEfficiency,

  // FD/aperture light options (RB==radio buttons)
  eRBShowEyeApertureLight,
  eRBShowTelApertureLight,
  eRBShowEyeAndTelApertureLight,

  //MC options
  eShowMC,
  eShowMCTraces,

  //SD options
  eShowBadStations,
  eShowPMTSignals,
  eShowLDFOnArray,
  eShowAllTraces,
  eShowFDinSD,

  // signals for tab navigation control
  eNextTab,
  ePreviousTab,

  // signals for event navigation control
  eFirstEvent,
  eCurrentEvent,
  eNextEvent,
  ePreviousEvent,
  eLastEvent,

  // signals from selection tab
  eUpdateSelection,
  eResetSelection,
  eHQSDSelection,
  eHQFDSelection,
  eFileSelection,
  eEnableSelection,
  eT4Trigger,
  e5T5Trigger,
  e6T5Trigger,
  eSaturation,
  eFindGPSTime,
  eFindSDID,
  eFindFDID,
  eFindRDID,
  eSDEnergySelection,
  eFDEnergySelection,
  eMCEnergySelection,
#ifdef AUGER_RADIO_ENABLED
  eRDEnergySelection,
#endif


  // FD signals
  eFDElectrons,
  eFDdEdX,
  eFDdEdXShowerAge,
  eFDAperture,
  eFDLight,
  eFDresiduals,
  eFDAllPixels,
  eFDAllStations,
  eFDEyeView,
  eFDTimeColors,
  eFDSignalColors,
  eFDLogSignalColors,
  eFDCloudColorMode,
  eAnimateFD,
  eProfileRebin,

  // SD signals
  eSDZoomToCore,
  eSDNoColors,
  eSDGroundTimeColors,
  eSDGroundResidualColors,
  eSDShowerPlaneAzimuthColors,
  //  eSDGeoMagneticAngleColors,

  eSDNextEvent,
  eSDPreviousEvent,
  eSDFirstEvent,
  eSDLastEvent,

  eSDTimeRes,
  eSDCurvTimeRes,
  eSDNoTimeRes,

  eSDFallTime,
  eSDT50,
  eSDRiseTime,

  eSDLDFResiduals,
  eSDAllStations,

  eSDArray,
  eSDTraces,
  eSDLDF,


  //Rise Time Tab

  eSDMuons,
  eSDElectrons,
  eSDPhotons,
  eSDOtherParticles,
  eSDAllParticles,
  eVEM,
  ePhotoelectrons,
  eParticles,
  eTracesSliderLow,
  eTracesSliderUp,
  eParticlesUpdate,



  // AUGER tab
  eFDLightRays,
  eFDSignalTrace,
  eShowRadiusIn3D,
  eSDShowAllTanks,
  eMCShowFirstInteraction,
  ePrint3D,

  eHammerAitoff,
  eSansonFlamsteed,
  eParabolic,

  // help menu
  eAbout,
  eFDHelp,
  eSDHelp,

  eStatusBarEventList

// Radio Part
#ifdef AUGER_RADIO_ENABLED
  ,
  eShowRadio,
  eRDStation,
  eRdTriggerWindow,
  eRdNoiseWindow,
  eRDPeakLine,
  eRdVertPolarization,
  eRdEastPolarization,
  eRdNorthPolarization,
  eRDChannel,
  eResAxis,
  eResStation,
  eRadioAxis,
  eSdAxis
#endif
};


#endif
