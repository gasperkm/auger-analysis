/******************************************************
*                                                     *
*             Radio ADST simple merger                *
*  a very basic merger to merge Rd ADST file with     *
* normal ADST file                                    *
* current version only work with file containing one  *
* event, but improvement are comming                  *
* \author M.Melissas                                  *
* \date May 2011                                      *
*******************************************************/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <getopt.h>

#include <TCanvas.h>
#include <TH2F.h>
#include <TMath.h>
#include <TROOT.h>
#include <TPad.h> 
#include <TPaveText.h>
#include <TStyle.h>
#include <TLine.h>
#include <TPaveLabel.h>
#include <TGraph.h> 
#include <TMarker.h>
#include <TFile.h> 
#include <TVector3.h>

#ifdef AUGER_RADIO_ENABLED
#include "RecEventFile.h"
#include "RecEvent.h"
#include "RdEvent.h" 
#include "GenShower.h"
#include "DetectorGeometry.h"
#include "RdPolarizationId.h"

#include "RdADSTsimplemerger.h"
using namespace std;

RdADSTsimplemerger::RdADSTsimplemerger(string outputfile) : 
fOutFile(outputfile,RecEventFile::eWrite),
fmergedEvent(NULL)
{
  fmergedEvent=new RecEvent();
  fOutFile.SetBuffers(&fmergedEvent); 
  
  }

RdADSTsimplemerger::~RdADSTsimplemerger() {
  }

void RdADSTsimplemerger::WriteGeometry(DetectorGeometry* geo) { 
  
  fOutFile.WriteDetectorGeometry(*geo);
  }

void RdADSTsimplemerger::MergeAndWriteFileInfo(FileInfo obsinfo,FileInfo radioinfo) {
  if (radioinfo.HasRdStation()) 
    obsinfo.SetHasRdStation();
  if (radioinfo.HasRdChannel())
    obsinfo.SetHasRdChannel();
  fOutFile.WriteFileInfo(obsinfo); 
  }
  
void RdADSTsimplemerger::Merge(RecEvent* recevent, RdEvent& radioevent) { 
  recevent->GetRdEvent()=radioevent;
  fmergedEvent=recevent;
  }
void RdADSTsimplemerger::WriteEvent() { 
  fOutFile.WriteEvent();
  }

void RdADSTsimplemerger::CloseMergedFile() { 
  fOutFile.Close(); 
  }


inline void displayhelp() { 
  cout << " usage : $RdADSTsimplemerger --ObserverFile /path/to/adstfile --Rdfile /path/to/Rdadstfile --help  --outfile /path/to/output_file \n";
  cout << "                       --Observerfile file with the Sd/Fd reconstruction you want to use\n";
  cout << "                       --Rdfile : file with the Rd reconstruction\n";
  cout << "                       --outfile : outputfile  \n"; 
  cout << "                       --help :display this help sheet"<<endl;
  }
int main(int argc, char* argv[]) { 

  string hybridfilename("");
  string radiofilename("");
  string outputfilename("");
  int option_index = 0;

//Parsing command line arguments 

  while (1) { 
    static struct option long_options[] = {
      /* These options set a flag. */
      /* These options don't set a flag.  We distinguish them by their indices. */
      {"help", 0, 0, 'h'},
      {"outfile",1, 0, 'f'},
      {"Observerfile",1,0,'o'},
      {"Rdfile",1,0,'r'},
      {0, 0, 0, 0}
      };

    int c= getopt_long (argc, argv, "hfor:",long_options, &option_index);
    if (c==-1) 
      break;
    if (c==0) 
      continue;
    switch(c) {
      case 'h':
        displayhelp();
        return -1;
        break;
      case 'f': 
        if (!optarg) { 
          cout << "--outfile  Needs an argument " << endl;
          displayhelp(); 
          return -1;
          }
        else { 
          outputfilename=optarg;
          }
        break;
      case 'o':
        if (!optarg) { 
          cout << "--Observerfile  Needs an argument " << endl;
          displayhelp();
          return -1;
          }
        else { 
          hybridfilename=optarg;
          }
        break;

      case 'r':
        if (!optarg) { 
          cout << "--Rdfile  Needs an argument " << endl;
          displayhelp();
          return -1;
          }
        radiofilename=optarg;
                
 /*     default:
        cerr << " Unknown option " << optarg << endl;
        displayhelp();
        return(-1);
        break; */
      }
    }
  if (radiofilename=="") { 
    cout << "--Rdfile  Needs an argument " << endl;
    displayhelp();
    return -1;
    }
  
  if (hybridfilename=="") { 
    cout << "--ObserverFile  Needs an argument " << endl;
    displayhelp();
    return -1;
    }

  if (outputfilename=="") { 
    outputfilename="Merged.root";
    }
//Command line argument parsed ! 
  cout << " Will merge " << radiofilename << " with hybridfile " << hybridfilename << " output file will be " << outputfilename << endl;
//Starting to initialize RecEventFiles and RecEvents 
  RecEventFile radiofile(radiofilename);
  RecEventFile hybridfile(hybridfilename);
  RecEvent *radioevent = new RecEvent(); 
  FileInfo radioInfo;
  radiofile.SetBuffers(&radioevent);
  radiofile.ReadFileInfo(radioInfo);

  DetectorGeometry *geo =new DetectorGeometry();
  radiofile.ReadDetectorGeometry(*geo);

  RecEvent *observerdevent = new RecEvent();
  hybridfile.SetBuffers(&observerdevent);


  FileInfo ObsInfo;
  hybridfile.ReadFileInfo(ObsInfo);

  
  RdADSTsimplemerger merger(outputfilename);
  //Geometry comes from the RdFile, which must also includes Sd and Fd Geomotry, check your bootstrap !!! 
  merger.WriteGeometry(geo);

  
  merger.MergeAndWriteFileInfo(ObsInfo,radioInfo);

  // Later this kind of stuff should go in a loop but not for the moment 
  radiofile.ReadNextEvent();
  hybridfile.ReadNextEvent();
  RdEvent& zeRd=radioevent->GetRdEvent();

  //Merge the Event 
  merger.Merge(observerdevent,zeRd);
  merger.WriteEvent();

  //This should go after the loop
  merger.CloseMergedFile();


}


#else 


int main(int argc, char* argv[]) { 
  std::cout << " Radio Need to be enabled to use this program" << std::endl;
}
#endif
