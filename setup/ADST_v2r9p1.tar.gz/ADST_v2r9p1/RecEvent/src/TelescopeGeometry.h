// $Id: TelescopeGeometry.h 20050 2011-12-24 03:07:37Z darko $
#ifndef __TelescopeGeometry_H
#define __TelescopeGeometry_H

#include <TObject.h>
#include <TString.h>

#include <vector>
#include <map>


//  class to hold FD event

class TelescopeGeometry : public TObject {

public:
  typedef std::vector<Double_t> PixelList_t;
  typedef PixelList_t::iterator PixelIterator;
  typedef PixelList_t::const_iterator ConstPixelIterator;

public:
  TelescopeGeometry(const std::map<TString, Double_t>& telElevations,
                    const std::map<TString, Double_t>& telAzimuths,
                    const UInt_t nFADC, const Double_t bFADC,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixPhis,
                    const std::map<TString, TelescopeGeometry::PixelList_t>& telPixOmegas);

  TelescopeGeometry();

  bool HasPixel(const UInt_t id) const { return id < fPixelPhi.size(); }
  /// pixel ID iPix [0:TelescopeGeometry::fgNumberOfPixels[
  Double_t GetPixelPhi(const UInt_t iPix, TString pointingId) const;
  /// pixel ID iPix [0:TelescopeGeometry::fgNumberOfPixels[
  Double_t GetPixelOmega(const UInt_t iPix, TString pointingId) const;

  /// Get the azimuthal PixelList_t for a given pointing id (cf. Detector)
  const PixelList_t& GetPixelsPhi(TString pointingId) const;
  /// Get the zenith PixelList_t for a given pointing id (cf. Detector)
  const PixelList_t& GetPixelsOmega(TString pointingId) const;

  Double_t GetPixelMinPhi(const TString& pointingId) const;
  Double_t GetPixelMaxPhi(const TString& pointingId) const;
  Double_t GetPixelMinOmega(const TString& pointingId) const;
  Double_t GetPixelMaxOmega(const TString& pointingId) const;

  UInt_t GetFADCSize() const { return fNBinsFADC; }
  Double_t GetFADCBinning() const { return fBinningFADC; }

  /// get the number of mirrors of eye "eyeid"
  UShort_t GetNumberOfPixels() const;
  Double_t GetElevation(TString pointingId) const;
  Double_t GetAzimuth(TString pointingId) const;

  /// get the camera column given pixel ID [1-fgNumberOfPixels]
  static unsigned int GetRow(const unsigned int id);
  /// get the camera row given pixel ID [1-fgNumberOfPixels]
  static unsigned int GetColumn(const unsigned int id);

  /// Check if a telescope pointing of the given id exists
  bool HasPointing(const TString& pointingId) const;
  /// Add a new telescope pointing to the object
  void AddPointing(const TString& pointingId,
                   const Double_t phi, const Double_t elevation,
                   const TelescopeGeometry::PixelList_t& pixPhis,
                   const TelescopeGeometry::PixelList_t& pixOmegas);

  /// Returns a vector of telescope pointing ids
  std::vector<TString> GetPointingIds() const;

  /** Merge the telescope pointings with those of another
   *  TelescopeGeometry and store them in the object.
   *  Returns ture if the object was modified.
   *  The object into which the information is merged takes precedence
   *  on conflicts.
   */
  bool MergeTelescopeFrom(const TelescopeGeometry& source);

private:
  void CalculateMinMaxFOV(TString pointingId) const;

  /** Infers the default pointing id from the available ones.
   *  Chooses the lowest pointing by default.
   */
  void GuessDefaultPointing();

public:
  static const UInt_t fgNumberOfPixels;

private:
  // from Offlines fdet::Telescope
  static const unsigned int fgFirstPixel   = 1;
  static const unsigned int fgLastPixel    = 440;

  static const unsigned int fgFirstChannel = 1;
  static const unsigned int fgLastChannel  = 480;

  static const unsigned int fgFirstRow     = 1;
  static const unsigned int fgFirstColumn  = 1;
  static const unsigned int fgLastRow      = 22;
  static const unsigned int fgLastColumn   = 20;

private:
  TString fDefaultFOVId; /// The default id of the telescope pointing

  PixelList_t fPixelPhi;    /// default azimuth [deg]
  PixelList_t fPixelOmega;  /// default elevation angle [deg]

  std::map<TString, PixelList_t> fTelPointingPixelPhi;    /// azimuths for various telescope pointings [deg]
  std::map<TString, PixelList_t> fTelPointingPixelOmega;  /// elevation angles for various telescope pointings [deg]

  UInt_t   fNBinsFADC;
  Double_t fBinningFADC;

  Double_t fElevation;
  Double_t fAzimuth;

  std::map<TString, Double_t> fTelPointingElevation;
  std::map<TString, Double_t> fTelPointingAzimuth;

  // fast access pfusch ---------
  // The "slash-slash-exclamation-mark" pfusch means that these aren't streamed.
  mutable TString fCurrentFOVId; //!
  mutable Double_t fMinPhi;      //!
  mutable Double_t fMinOmega;    //!
  mutable Double_t fMaxPhi;      //!
  mutable Double_t fMaxOmega;    //!
  // -----------------------------

  ClassDef(TelescopeGeometry, 6);

};


#endif
