#include "FdTelescopeData.h"
#include <iostream>
#include <cmath>

using namespace std;


ClassImp(FdTelescopeData);


//=============================================================================
/*!
      \class   FdTelescopeData
       \brief   Event properties for a telescope

       \version 1.0
       \date    Jul 16 2010
       \author  S.Mueller

*/
//=============================================================================
