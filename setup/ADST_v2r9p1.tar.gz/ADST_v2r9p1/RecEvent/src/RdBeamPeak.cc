#ifdef AUGER_RADIO_ENABLED
#include <RdBeamPeak.h>

ClassImp(RdBeamPeak)

RdBeamPeak::RdBeamPeak()
  : height (0.0), time (0.0), RMS (0.0), offset (0.0) {}
#endif
