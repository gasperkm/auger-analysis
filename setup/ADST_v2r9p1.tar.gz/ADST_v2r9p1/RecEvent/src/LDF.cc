
#include <LDF.h>

#include <algorithm>
#include <iostream>
#include <cmath>
using namespace std;

ClassImp(LDF);

LDF::LDF():
  fReferenceDistance(1000),  // for backward compatibility
  fShowerSizeLabel("S1000"), // for backward compatibility
  fS1000(0),                 // general shower size, but called fS1000 for backward compatibility
  fS1000Error(0),
  fS1000BetaSys(0),
  fBeta(0),                  // LDF parameters
  fBetaError(0),
  fBetaSys(0),
  fGamma(0),
  fGammaError(0),
  fLDFChi2(0),
  fLDFLikelihood(0),
  fLDFNdof(0),
  fLDFStatus(0){
}


double LDF::NKGFunction(const double r) const {
  const double k1000m = GetReferenceDistance(); //*meter;

  return fS1000*pow(r/k1000m, fBeta)*pow((700 + r)/(k1000m+700.), fGamma + fBeta); 
  
} 

double LDF::NKGFermiFunction(const double r) const {
  const double k1000m = GetReferenceDistance(); //*meter;

  return fS1000*pow(r/k1000m, fBeta)*pow((700 + r)/(k1000m+700.), fGamma + fBeta) 
    / (exp((r-fNKGFermiMu)/fNKGFermiTau)+1.);
} 


double LDF::PowerLawFunction(const double r) const {


  const double kNearRadius = 300;//*meter;
  const double k1000m = GetReferenceDistance(); //*meter;
  const double nearCore = kNearRadius / k1000m;
  const double relR = r / k1000m;

  
  if (relR > nearCore)
    return fS1000*pow(relR, fBeta + fGamma*log(relR));
    
  const double gf = fGamma*log(nearCore);
  
  return  fS1000*pow(relR, fBeta + 2*gf) * pow(nearCore, -gf);
  
  
}

double LDF::TabulatedFunction(const double r) const {

  if (fRhos.empty()) return 0;

  const size_t i = upper_bound(fRhos.begin(),fRhos.end(), r) - fRhos.begin();

  if (i<1)
    return fS1000*fValues.front();

  if (i >= fRhos.size())
    return 0.0;

  const double a = log(fRhos[i-1]);
  const double b = log(fRhos[i]);
  const double fa = log(fValues[i-1]);
  const double fb = log(fValues[i]);

  const double z = (log(r)-a)/(b-a);

  return fS1000*exp(fa*(1.0-z) + fb*z);

}

double LDF::Evaluate(const double r, const ELDFType type) const {

  switch (type) {
  case ePL:
    return PowerLawFunction(r);
  case eNKG: 
    return NKGFunction(r);
  case eNKGFermi:
    return NKGFermiFunction(r);
  case eTabulated:
    return TabulatedFunction(r);
  default:
    cerr << "Error: no handler for requested LDF type" << endl;
  };

  return 0; 
}   



double TF1PowerLawFunction(const double *x, const double* par){
  
  const double r= x[0];
  const double s1000= par[0];
  const double beta= par[1];
  const double gamma= par[2];
  const double k1000m = par[3];
  const double kNearRadius = 300;//*meter;
  const double nearCore = kNearRadius / k1000m;
  const double relR = r / k1000m;
  
  

  if (relR > nearCore)
    return s1000*pow(relR, beta + gamma*log(relR));
    
  const double gf = gamma*log(nearCore);
  return  s1000*pow(relR, beta + 2*gf) * pow(nearCore, -gf);
  
  
}



double TF1NKGFunction(const double *x, const double* par){
  
  const double r= x[0];
  const double s1000= par[0];
  const double beta= par[1];
  const double gamma= par[2];
  const double k1000 = par[3];
  return s1000*pow(r/k1000, beta)*pow((700 + r)/(k1000+700.), gamma + beta); // (exp((r-2660.)/242.)+1.);  
  
  
}

double TF1NKGFermiFunction(const double *x, const double* par){
  
  const double r= x[0];
  const double s1000= par[0];
  const double beta= par[1];
  const double gamma= par[2];
  const double mu= par[3];
  const double tau= par[4];
  const double k1000 = par[5];

  return s1000*pow(r/k1000, beta)*pow((700 + r)/(k1000+700.), gamma + beta) / (exp((r-mu)/tau)+1.);  
  
  
}



TF1 LDF::GetFunction(const ELDFType type) const {

  const double refDistance = GetReferenceDistance(); //*meter;
  switch (type){
  case eNKG:{
    
    TF1 f("LDF_function", TF1NKGFunction, 10,  6000., 4);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, refDistance); 
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    return f;
    
  }
  case ePL: { 
    TF1 f("LDF_function", TF1PowerLawFunction, 10, 6000, 4);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, refDistance);
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    return f;
  }  
  case eHP: {
    cout << "Not Implemeted yet !!" << endl; 
  }
  case eNKGFermi:{
    TF1 f("LDF_function", TF1NKGFermiFunction, 10,  6000., 6);
    f.SetParameter(0, fS1000);
    f.SetParameter(1, fBeta);
    f.SetParameter(2, fGamma);
    f.SetParameter(3, fNKGFermiMu);
    f.SetParameter(4, fNKGFermiTau);
    f.SetParameter(5, refDistance);
    f.SetParError(0, fS1000Error);
    f.SetParError(1, fBetaError);
    f.SetParError(2, fGammaError);
    f.SetParameter(3, 0.);
    f.SetParameter(4, 0.);
    return f;
  }
  case eLOG: {
    cout << "Not Implemeted yet !!" << endl; 
  }

  case eTabulated: {
    cout << "GetFunction(...) cannot be called for tabulated LDF" << endl;
  }
  };
  return TF1("dummy","1"); 
}





void LDF::DumpASCII(ostream& o) const {
  o << "  ShowerSize            " << fS1000 << " (+/- " << fS1000Error << ")\n";
}
