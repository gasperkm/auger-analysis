/**
   \file


   \author Javier Gonzalez
   \version $Id$
   \date 20 Apr 2012
*/

static const char CVSId[] =
  "$Id$";


#include "SdFootprintData.h"

ClassImp(SdFootprintData);


// Configure (x)emacs for this file ...
// Local Variables:
// mode:c++
// compile-command: "make -C .. -k"
// End:
