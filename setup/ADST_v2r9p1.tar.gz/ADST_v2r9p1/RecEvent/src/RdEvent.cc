#ifdef AUGER_RADIO_ENABLED
#include <RdEvent.h>

#include <RdRecStation.h> 
#include <SimRdPulse.h> 

#include <TClonesArray.h>

#include <iostream>
#include <TF1.h>
using namespace std;

ClassImp (RdEvent);

//=============================================================================
/*!
  \class   RdEvent
  \brief   General RD Event 

  \version 1.0
  \date    May  2010
  \author  M. Melissas 
*/
//=============================================================================

RdEvent::RdEvent() :
  fRdEventId (0),
  fRdRunNumber(0),
  fRRecLevel (eNoRd),
  fRGPSSecond(0),
  fRGPSNanoSecond(0),
  fHasShower(false)
{
    

#ifdef DEBUGKG
  cout << " RdEvent::RdEvent()   begin" << endl;
#endif


#ifdef DEBUGKG
  cout << " RdEvent::RdEvent()   end" << endl;
#endif

}


RdEvent::~RdEvent() {

#ifdef DEBUGKG
  cout << "  RdEvent::~RdEvent()  begin" << endl;
#endif


#ifdef DEBUGKG
  cout << "  RdEvent::~RdEvent()  end" << endl;
#endif

}


RdRecShower& RdEvent::GetRdRecShower() { 

   return fRdRecShower;

}

const RdRecShower& RdEvent::GetRdRecShower() const { 
    return fRdRecShower;
}


void RdEvent::AddRdStation (RdRecStation &station) { 
    
  fRStations.push_back(station);
}

void RdEvent::AddRdStationWithId(UInt_t id) { 
  RdRecStation station;
  station.SetId(id);
  fRStations.push_back(station);
  }

void RdEvent::AddSimRdPulse(SimRdPulse &station) {
    
  fSimRdPulses.push_back(station);
}

void RdEvent::AddSimRdPulseWithId(UInt_t id) {
  SimRdPulse spulse;
  spulse.SetId(id);
  fSimRdPulses.push_back(spulse);
}

bool RdEvent::HasRdStation (int id) const {
  
  for(int i=0; i<(int)fRStations.size(); ++i)
    if((int)fRStations[i].GetId()== id) return true;

  return false;
}

bool RdEvent::HasSimRdPulse (int id) const {
  
  for(int i=0; i<(int)fSimRdPulses.size(); ++i)
    if((int)fSimRdPulses[i].GetId()== id) return true;

  return false;
}

//======================================================================
RdRecStation&  RdEvent::GetRdStation(UInt_t i)  throw(std::out_of_range) { 
    
  if(i<(UInt_t)fRStations.size()) 
    return fRStations[i];
  else
    throw(out_of_range("Station does not exist"));
}



RdRecStation&  RdEvent::GetRdStationById(UInt_t id)  throw(std::out_of_range) {

  for(unsigned int i=0; i<fRStations.size(); ++i)
      if(fRStations[i].GetId()== id) return fRStations[i];

  throw(out_of_range("Station does not exist "));
}

const RdRecStation&  RdEvent::GetRdStation(UInt_t i)  const throw(std::out_of_range) { 
    
  if(i<(UInt_t)fRStations.size()) 
    return fRStations[i];
  else
    throw(out_of_range("Station does not exist"));
}



const RdRecStation&  RdEvent::GetRdStationById(UInt_t id)  const throw(std::out_of_range) {

  for(unsigned int i=0; i<fRStations.size(); ++i)
      if(fRStations[i].GetId()== id) return fRStations[i];

  throw(out_of_range("Station does not exist "));
}

SimRdPulse& RdEvent::GetSimRdPulse(UInt_t i) throw(std::out_of_range) {
    
  if(i<(UInt_t)fSimRdPulses.size()) 
    return fSimRdPulses[i];
  else
    throw(out_of_range("Station does not exist"));
}



SimRdPulse&  RdEvent::GetSimRdPulseById(UInt_t id) throw (std::out_of_range) {

  for(unsigned int i=0; i<fSimRdPulses.size(); ++i)
      if(fSimRdPulses[i].GetId()== id) return fSimRdPulses[i];
  throw(out_of_range("Station does not exist"));
}

const SimRdPulse& RdEvent::GetSimRdPulse(UInt_t i) const throw(std::out_of_range) {
    
  if(i<(UInt_t)fSimRdPulses.size()) 
    return fSimRdPulses[i];
  else
    throw(out_of_range("Station does not exist"));
}



const SimRdPulse&  RdEvent::GetSimRdPulseById(UInt_t id) const throw (std::out_of_range) {

  for(unsigned int i=0; i<fSimRdPulses.size(); ++i)
      if(fSimRdPulses[i].GetId()== id) return fSimRdPulses[i];
  throw(out_of_range("Station does not exist"));
}


bool RdEvent::HasRdSignalTraces() const {

  if ( !fRStations.empty() )
    for ( unsigned int i = 0; i < fRStations.size(); i++)
      if ( !fRStations[i].GetRdTimeTrace(1).empty() )
        return true;

   return false;
}
bool RdEvent::HasRdSignalAbsSpectra() const {
        if ( !fRStations.empty() )
                for ( unsigned int i = 0; i < fRStations.size(); i++)
                        if ( !fRStations[i].GetRdAbsSpectrum(1).empty() )
                                return true;

        return false;
        }



void RdEvent::DumpASCII(std::ostream &o) const {

  if (!fRdEventId) 
    return;
  
  o << "\n"
    << "  Radio Id           " << fRdEventId <<  "\n"
    <<"   Run Id             " << fRdRunNumber << "\n";
  
  fRdRecShower.DumpASCII(o);
  
}

#endif
