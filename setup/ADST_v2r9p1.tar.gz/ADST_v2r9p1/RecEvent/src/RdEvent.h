#ifdef AUGER_RADIO_ENABLED
#ifndef __RdEvent_H
#define __RdEvent_H

#include <RdRecShower.h> 
#include <RdRecStation.h> 
#include <RdRecLevel.h>
#include <SimRdPulse.h>

#include <TObject.h>
#include <TF1.h>

#include <vector>
#include <iostream>

class TClonesArray;
//
//  class to hold Radio event
//
class RdEvent : public TObject {
    
    
public:
  RdEvent();
  ~RdEvent();
        
  RdRecShower& GetRdRecShower(); 
  const RdRecShower& GetRdRecShower() const; 
  /// get station with index "i"
  RdRecStation& GetRdStation(UInt_t i)  throw(std::out_of_range); 
  SimRdPulse& GetSimRdPulse(UInt_t i) throw(std::out_of_range);
  SimRdPulse& GetSimRdPulseById(UInt_t id) throw(std::out_of_range);
  RdRecStation& GetRdStationById(UInt_t id) throw(std::out_of_range); 
  const RdRecStation& GetRdStation(UInt_t i) const throw(std::out_of_range); 
  const RdRecStation& GetRdStationById(UInt_t id) const throw(std::out_of_range); 
  const SimRdPulse& GetSimRdPulse(UInt_t i) const throw(std::out_of_range);
  const SimRdPulse& GetSimRdPulseById(UInt_t id) const  throw(std::out_of_range);
  const std::vector<RdRecStation> & GetRdStationVector() const {return fRStations;} 
  const std::vector<SimRdPulse> & GetSimRdPulseVector() const {return fSimRdPulses;} 


  /// ask for presence of station with ID "id"
  bool HasRdStation (int id) const;
  bool HasSimRdPulse (int id) const;


  bool HasRdStations() const {return !fRStations.empty(); }


  void AddRdStation (RdRecStation &s);
  void AddRdStationWithId(UInt_t id);
  void AddSimRdPulse (SimRdPulse &s);
  void AddSimRdPulseWithId(UInt_t id); //< Create a new SimRdPulse with id =id

  Int_t GetRdEventId() const {return fRdEventId;}
  Int_t GetRdRunNumber() const {return fRdRunNumber;}
  ERdRecLevel GetRdRecLevel() const {return fRRecLevel;} 
  Int_t GetGPSSecond() const {return fRGPSSecond;}
  Int_t GetGPSNanoSecond() const {return fRGPSNanoSecond;}


  


  void SetRdEventId ( const Int_t event) {fRdEventId=event;}
  void SetRdRunNumber(Int_t run) {fRdRunNumber=run;}
  void SetRdRecLevel (ERdRecLevel l) {fRRecLevel=l;}
  void SetRdEventTime(const Int_t gPSSec, const Int_t gPSNSec)
    {fRGPSSecond = gPSSec; fRGPSNanoSecond = gPSNSec;  }

//  void SetBadPeriodId(const Int_t badId){fRBadPeriodId= badId; } ///< set the bad period id
  bool inline HasRdShower() {return fHasShower;};
  void inline SetHasRdShower() {fHasShower=true; fRRecLevel=eHasRdShower;};
  bool HasRdSignalTraces() const;
  bool HasRdSignalAbsSpectra() const;
  bool HasRdLDF() const {return (fRRecLevel>=eHasRdLDF);}
  //int  GetBadPeriodId() const {return fRBadPeriodId; }

  void DumpASCII(std::ostream &o=std::cout) const;

private:
    
  Int_t fRdEventId;
  Int_t fRdRunNumber;
//  Int_t fRBadPeriodId;
  ERdRecLevel fRRecLevel;
  Int_t fRGPSSecond;
  Int_t fRGPSNanoSecond;
  bool fHasShower; 
  std::string fRCDASSender;
  std::string fRCDASAlgo;

  RdRecShower fRdRecShower;
  std::vector<RdRecStation> fRStations;        
  std::vector<SimRdPulse>   fSimRdPulses;       

  ClassDef (RdEvent,7)
};


#endif
#endif
