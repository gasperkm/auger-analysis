// $Id: RecEventFile.h 20048 2011-12-24 02:02:01Z darko $
#ifndef RecEventFile_H
#define RecEventFile_H

#include <Rtypes.h>

#include <vector>
#include <map>
#include <string>


class TTree;
class TFile;
class TEventList;
class TBranch;

class DetectorGeometry;
class FileInfo;
class RecEvent;
class EventInfo;


/**
Object to do the handling of RecEventFiles files for reading/writing
*/

class RecEventFile {

private:
  RecEventFile();
  RecEventFile(const RecEventFile&);
  RecEventFile& operator=(const RecEventFile&);

public:
  /// Open modes
  enum Mode { eRead, eWrite, eAppend };

  /// return status
  enum Status { eSuccess, eFailure };

  /// constructor to read or write events (depending on option)
  /*RecEventFile(const char* const fname, const Mode mode = eRead,
               const Int_t zipLevel = 9, const int saveSelf = -1);*/
  RecEventFile(const std::string& fname, const Mode mode = eRead,
               const Int_t zipLevel = 9, const int saveSelf = -1);

  /// constructor to read a list of files
  RecEventFile(const std::vector<std::string>& fname);
  RecEventFile(const char* const * fnames);

  /// open providing an ASCII list of file names (one per line)
  static RecEventFile* OpenFromASCIIList(const char* const flist);

  /// open either a .root file or all .root files from an ASCII list
  /// as with OpenFromASCIIList
  static RecEventFile* SmartOpen(const std::string& fileName);

  virtual ~RecEventFile();

  /// change directory to ROOT directory of RecEventFile (only in write mode)
  void cd();

private:
  void AddFile(const std::string& fname, const Mode mode, const Int_t zipLevel = 9);

public:
  /// pass pointers to the objects (needed before the first reading/writing)
  Status SetBuffers(RecEvent** rec);

  const std::vector<std::string>& GetFileList() const { return fFileList; }

  /// close everything
  void Close(const bool writeEventInfo = true);

  /// this should be used to select a subset of the chain entries !
  Status SetSelection(TEventList& list);

  /// this is the detector geomtry (pixels/stations)
  Status ReadDetectorGeometry(DetectorGeometry& geom) const;
  Status WriteDetectorGeometry(const DetectorGeometry& geom);

  // this is the file info
  Status ReadFileInfo(FileInfo& info) const;
  Status WriteFileInfo(const FileInfo& info);

  // write event
  Status WriteEvent();
  /// read next event
  Status ReadNextEvent();
  /// read event given TTree entry number
  Status ReadEvent(const int iEvent);
  /// search and read event for given Auger event ID
  Status SearchForAugerEvent(const ULong_t augerEventID);
  /// search and read event for given SD event ID
  Status SearchForSDEvent(const UInt_t sdEventID);
  /// read first event
  Status Rewind() { return SeekEvent(0); }

  /// get a branch given its name
  TBranch* GetBranch(const std::string& branchname, void* const address);
  /// set branch status 1: active, 0: deactivated
  /// (to be called before SetBuffers() )
  void SetBranchStatus(const char* const branchname, const Bool_t status);
  /// deactivate all but high level branches
  void SetMicroADST();
  /// check for MicroADST file
  bool IsMicroADST();
  /// deactivate the high/low gain SD traces and particles
  void SetMiniADST();
  /// check for MiniADST file
  bool IsMiniADST();

  /// get event TTree
  TTree* GetEventTree() { return fEventTree; }

  std::string GetActiveFileName() const;
  unsigned int GetNFiles() const { return fFileList.size(); }
  unsigned int GetNEvents() const { return fNEvents; }
  int GetCurrentEvent() const { return fCurrentEvent; }
  bool GetEventInfo(const int, EventInfo* const);
  bool GetEventInfos(const int iFirst, const int nEntries,
                     std::vector<EventInfo>& eventInfoData);

  /// event number, auger ID, file position [%] of current event
  std::string GetCurrentEventString() const;
  
  bool IsMC() const { return fHasMC; }

private:
  Status SeekEvent(const int iEvent);

  void FillEventInfo();

  /// creates a map of SD event IDs from EventInfo Tree
  void CreateSDEventMap();

  /// creates a map of Auger event IDs from EventInfo Tree
  void CreateAugerEventMap();

  std::map<UInt_t, UInt_t> fSDEventIndex;
  std::map<ULong_t, UInt_t> fAugerEventIndex;

  std::vector<std::string> fFileList;
  TFile* fFile;                       // ONLY for writing !
  Mode fMode;
  int fSaveSelf;
  bool fHasMC;

  int fNEvents;

  RecEvent** fRecEvent;
  EventInfo* fEventInfo;

  TTree* fEventInfoTree;
  TTree* fEventTree;

  int fCurrentEvent;

  static const char* const kDetectorGeometryName;
  static const char* const kFileInfoName;

  static const char* const kDataTreeName;
  static const char* const kEventInfoTreeName;

  static const char* const kDataBranchName;
  static const char* const kEventInfoBranchName;

  // FD event & sub-objects
  static const char* const kFDEventsBranchName;
  static const char* const kFdRecShowerBranchName;
  static const char* const kFdRecApertureLightBranchName;
  static const char* const kFdRecGeometryBranchName;
  static const char* const kSdRecGeometryBranchName;
  static const char* const kFdRecPixelBranchName;
  static const char* const kFdGenGeometryBranchName;
  static const char* const kFdGenApertureLightBranchName;

  // SDEvent &  sub-objects
  static const char* const kSDEventBranchName;
  static const char* const kSdRecShowerBranchName;

  // RdEvent & sub-object
#ifdef AUGER_RADIO_ENABLED
  static const char* const kRdEventBranchName;
  static const char* const kRStationVectorBranchName;
#endif

  // GenShower
  static const char* const kGenShowerBranchName;

  // vector branches
  static const char* const kDepthVectorBranchName;
  static const char* const kHeightVectorBranchName;
  static const char* const kElectronVectorBranchName;
  static const char* const kEnergyDepositVectorBranchName;
  static const char* const kStationVectorBranchName;
  static const char* const kGenStationVectorBranchName;

};


#endif
