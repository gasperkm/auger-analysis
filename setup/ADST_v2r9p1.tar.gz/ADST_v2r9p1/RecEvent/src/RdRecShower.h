#ifdef AUGER_RADIO_ENABLED
#ifndef __RdRecShower_H
#define __RdRecShower_H
#include <RdRecLevel.h>
#include <RecShower.h>
#include <RdLDF.h>
#include <RdBeamQuants.h>
#include "ShowerRRecDataQuantities.h"
#include "RdRecShowerParameterStorageMap.h"

#include <iostream>
#include <stdexcept>

//
//  Shower data definition
//


class RdRecShower : public RecShower {

public:

  RdRecShower();
  virtual ~RdRecShower() { }
 

  void SetParameter(const revt::ShowerRRecDataQuantities eIndex,const double value) {
    fShowerQuantities.SetParameter(eIndex,value);
  }
  void SetParameterError(const revt::ShowerRRecDataQuantities eIndex,const double value) {
    fShowerQuantities.SetParameterError(eIndex,value);
  }
  void SetParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const revt::ShowerRRecDataQuantities eIndex2 ,const double value) {
    fShowerQuantities.SetParameterCovariance(eIndex1, eIndex2 ,value);
  }

  double GetParameter(const revt::ShowerRRecDataQuantities eIndex) const {
    return fShowerQuantities.GetParameter(eIndex);
  }
  
  double GetParameterError(const revt::ShowerRRecDataQuantities eIndex) const {
    return fShowerQuantities.GetParameterError(eIndex);
  }
  
  double GetParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const  revt::ShowerRRecDataQuantities eIndex2) const {
    return fShowerQuantities.GetParameterCovariance(eIndex1,eIndex2);
  }

  bool HasParameter(const revt::ShowerRRecDataQuantities eIndex) const  {
    return fShowerQuantities.HasParameter(eIndex);
  }

  bool HasParameterCovariance(const revt::ShowerRRecDataQuantities eIndex1, const  revt::ShowerRRecDataQuantities eIndex2) const  {
    return fShowerQuantities.HasParameterCovariance( eIndex1, eIndex2);
  }



  /// return the radius (from the spherical wave fit) radius (in AugerUnits = m), return NaN if radius is not defined
  double GetRadius() const;
  /// return the error on the radius (in AugerUnits = m), return NaN if radius error is not defined. ATTENTION: This error is not correct, because covariances are not considered.
  double GetRadiusError() const { return fRadiusError; };
  void SetRadiusError(const double error) { fRadiusError = error; }

  /// return the Azimuth given by the prefit (in AugerUnits = radian) or NaN if the variable is not defined 
  double GetAzimuthPreFit()  const;

  double GetAzimuthPreFitError() const { return fAzimuthPreFitError; }
  void SetAzimuthPreFitError(const double error) { fAzimuthPreFitError = error; }
  
  /// return the Azimuth given by the fit (in AugerUnits = radian) or NaN if the variable is not defined 
  double GetAzimuth() const ;

  double GetAzimuthError() const { return fAzimuthError; }
  void SetAzimuthError(const double error) { fAzimuthError = error; }

  /// return the Zenith given by the prefit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetZenithPreFit()  const;

  double GetZenithPreFitError()  const { return fZenithPreFitError; }
  void SetZenithPreFitError(const double error) { fZenithPreFitError = error; }
  
  /// return the Zenith given by the fit (in AugerUnits = radian) or NaN if the variable is not defined
  double GetZenith()  const;
  double GetZenithError() const { return fZenithError; }
  void SetZenithError(const double error) { fZenithError = error; }


/////////////////////////////////////////////////////////
/// old getter functions /////////////////////
/////////////////////////////////////////////////////////


  /// get the chi2 from the wave fit, return nan if not defined
  Double_t GetRdPlaneFitChi2() const;

  /// get the no of degrees of freedom from the wave fit, return nan if not defined
  Double_t GetRdPlaneFitNDoF() const;


  /** Get the reconstruction stage of the wave fit (defined in ShowerRRecData.cc)
  *   kBary                    = 0.5;
  *   kPreWaveFit              = 1;
  *   kPlaneFitLinear2         = 1.1;
  *   kPlaneFit3d              = 1.2;
  *   kSphericalWaveFit        = 1.5;
  *   kSphericalWaveFitVarC    = 1.6;
  **/
  double GetRdRecStage() const ; 

  double GetRdFitConvergenceStatus() const ;
  double GetRdFitSuccess() const;


  const RdBeamQuants &GetRdBeamResult () {return fRdBeamResult; }
  void SetRdBeamResult (const RdBeamQuants &result)  { fRdBeamResult = result; }
  
  void DumpASCII(std::ostream &o=std::cout) const;

private:

  Double_t fRadiusError;
  Double_t fAzimuthError;
  Double_t fZenithError;

  Double_t fZenithPreFitError;
  Double_t fAzimuthPreFitError;
  

  RdRecShowerParameterStorageMap fShowerQuantities;

  RdBeamQuants fRdBeamResult;


  ClassDef(RdRecShower,15);
};


#endif
#endif
