// $Id: Traces.cc 20929 2012-04-15 20:19:10Z darko $
#include <Traces.h>
#include <numeric>


ClassImp(Traces);


Traces::Traces() :
  fTraceType(eTotalTrace),
  fVEMPeak(0),
  fVEMCharge(0),
  fVEMPeakEr(0),
  fVEMChargeEr(0),
  fIsVEMPeakFromHistogram(false),
  fIsVEMChargeFromHistogram(false),
  fDynodeAnodeRatio(0),
  fMuonPulseDecayTime(0),
  fMuonPulseDecayTimeEr(0),
  fBaseline(0),
  fBaselineRMS(0),
  fBaselineLG(0),
  fBaselineLGRMS(0),
  fIsTubeOK(true),
  fIsLowGainOK(true),
  fPMTId(0)
{ }


void
Traces::Clear()
{
  fVEMPeak = 0;
  fVEMCharge = 0;
  fVEMPeakEr = 0;
  fVEMChargeEr = 0;
  fIsVEMPeakFromHistogram = false;
  fIsVEMChargeFromHistogram = false;
  fDynodeAnodeRatio = 0;
  fBaseline = 0;
  fBaselineRMS = 0;
  fBaselineLG = 0;
  fBaselineLGRMS = 0;
  fPMTId = 0;
  fLow.clear();
  fHigh.clear();
  fVEM.clear();
}


double
Traces::GetVEMSignal()
  const
{
  if (fVEMCharge)
    return accumulate(fVEM.begin(), fVEM.end(), 0) * fVEMPeak/fVEMCharge;
  else
    return 0;
}
