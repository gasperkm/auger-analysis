#ifndef __FdAerosols_H
#define __FdAerosols_H

#include <TObject.h>
#include <vector>


class FdAerosols : public TObject {

public:
  //getters
  const std::vector<Double_t>& GetMieAttenuationLength() const { return fMieAttenuationLength; } ///< returns Mie attenuation lengths
  const std::vector<Double_t>& GetMieAttenuationHeight() const { return fMieAttenuationHeight; } ///< returns heights for the Mie attenuation length data points

  //setters
  void SetMieAttenuationLength(const std::vector<Double_t>& mieAtt) { fMieAttenuationLength = mieAtt; } ///< sets Mie attenuation lengths
  void SetMieAttenuationHeight(const std::vector<Double_t>& mieAttH) { fMieAttenuationHeight = mieAttH; } ///< sets heights for the Mie attenuation lengths

private:
  std::vector<Double_t> fMieAttenuationLength;
  std::vector<Double_t> fMieAttenuationHeight;

  ClassDef(FdAerosols, 1);

};


#endif
