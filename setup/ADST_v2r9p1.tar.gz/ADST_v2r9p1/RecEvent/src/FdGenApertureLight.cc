// $Id: FdGenApertureLight.cc 20035 2011-12-22 02:46:23Z darko $
#include <FdGenApertureLight.h>


ClassImp(FdGenApertureLight);
