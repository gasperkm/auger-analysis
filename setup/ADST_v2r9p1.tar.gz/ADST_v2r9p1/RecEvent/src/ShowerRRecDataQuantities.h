#ifdef AUGER_RADIO_ENABLED
/**
   \file
   ShowerRRecDataQuantities quantities to be stored in ParameterStorage objects of ShowerRecData
*/

#ifndef _revt_ShowerRRecDataQuantities_h_
#define _revt_ShowerRRecDataQuantities_h_

static const char CvsId_revt_ShowerRRecDataQuantities[] =
 "$Id: StationRecData.h ";

namespace revt {

/** ATTENTION: - Numerate enum
 *             - never change an index
 *  all values are in Auger base units
 *  a comment explaining a parameter and its origin is mandatory
 */
enum ShowerRRecDataQuantities {

  eCoordinateOriginX = 1,   // X origin of the coordinate system in ePampaAmarilla Coordinate System [RdPreWaveFit]
  eCoordinateOriginY = 2,   // Y origin of the coordinate system in ePampaAmarilla Coordinate System [RdPreWaveFit]
  eCoordinateOriginZ = 3,   // Z origin of the coordinate system in ePampaAmarilla Coordinate System [RdPreWaveFit]

  eShowerAxisX = 4, //Shower axis X [Rd*Fit] in the local coordinate system
  eShowerAxisY = 5, //Shower axis Y [Rd*Fit] in the local coordinate system
  eShowerAxisZ = 6, //Shower axis Z [Rd*Fit] in the local coordinate system

  eGamma = 7,               // variation of speed of light for horizontal showers [RdWaveFit]
  eWaveFitChi2 = 8,         // chi^2 of wave fit [RdWaveFit]
  eWaveFitNDF = 9,          // Number of degrees of freedom of wave fit [RdWaveFit]

  eNumberOfStationsWithPulseFound = 10,   // Number of stations with pulse found [RdPreWaveFit, RdStationSignalReconstructor]

  eCoreX = 11,  // core position X [Rd*Fit] in the ePampaAmarilla Coordinate System
  eCoreY = 12,  // core position Y [Rd*Fit] in the ePampaAmarilla Coordinate System
  eCoreZ = 13,  // core position Z [Rd*Fit] in the ePampaAmarilla Coordinate System

  eRecStage = 14, // the reconstruction stage of the shower (defined in ShowerRRecData.cc) [RdPreWaveFit, RdWaveFit, RdPlaneFit]
  eEnergy = 15,  // Not yet reconstructed (coming soon...)

  ePreFitShowerAxisX = 16, // PreFit axis X [RdPreWaveFit] in the local coordinate system
  ePreFitShowerAxisY = 17, // PreFit axis Y [RdPreWaveFit] in the local coordinate system
  ePreFitShowerAxisZ = 18, // PreFit axis Z [RdPreWaveFit] in the local coordinate system

  ePreFitChi2 = 19,           // chi^2 of pre plane wave fit [RdPreWaveFit]
  ePreFitNDF = 20,            // Number of degrees of freedom of pre plane wave fit [RdPreWaveFit]

  eFitSuccess = 21,           // shows if iterative shower fit worked or failed
  eFitConvergence = 22,        // shows if iterative fit procedure converged [RdDirectionConvergenceChecker]
  eCoreTime = 23              // time where the showeraxis hits the ground [RdPlaneFit]
  
};

}

#endif
#endif

// Configure (x)emacs for this file ...
// Local Variables:
// mode: c++
// compile-command: "make -C .. -k"
// End:
