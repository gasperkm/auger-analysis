// $Id: FdApertureLight.cc 20049 2011-12-24 02:25:01Z darko $
#include <FdApertureLight.h>

#include <iostream>

using namespace std;


ClassImp(FdApertureLight)


//=============================================================================
/*!
  \class   FdApertureLight
  \brief   light at aperture

  \version 1.0
  \date    Sep 21 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/

//=============================================================================
int
FdApertureLight::GetNumberTimePoints()
  const
{
  return fTime.size();
}


//=============================================================================
void
FdApertureLight::SetTime(const std::vector<Double_t>& tim)
{
  fTime = tim;
}


//=============================================================================
void
FdApertureLight::SetTotalLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_total = phot;
}


//=============================================================================
void
FdApertureLight::SetFluorLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_fluor = phot;
}


//=============================================================================
void
FdApertureLight::SetCherLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_direct_cher = phot;
}


//=============================================================================
void
FdApertureLight::SetMieCherLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_mie_cher = phot;
}


//=============================================================================
void
FdApertureLight::SetRayCherLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_ray_cher = phot;
}


//=============================================================================
void
FdApertureLight::SetMultScatFluorLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_multScat_fluor = phot;
}


//=============================================================================
void
FdApertureLight::SetMultScatCherLightAtAperture(const std::vector<Double_t>& phot)
{
  fDia_multScat_cher = phot;
}


#ifdef PRIM_CHER
//=============================================================================
vector<Double_t>
FdApertureLight::GetLightFluxSumVector(const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                       const bool fMult, const bool cMult,
                                       const bool cPrimDir, const bool cPrimMie, const bool cPrimRay)
  const
{
  vector<Double_t> sum;
  for (unsigned int i = 0, n = fDia_fluor.size(); i < n; ++i)
    sum.push_back(GetLightFluxSum(i, fluo, cDir, cMie, cRay, fMult, cMult,
                                  cPrimDir, cPrimMie, cPrimRay));
  return sum;
}


//=============================================================================
Double_t
FdApertureLight::GetLightFluxSum(const unsigned int iTime,
                                 const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                 const bool fMult, const bool cMult,
                                 const bool cPrimDir, const bool cPrimMie, const bool cPrimRay)
  const
{
  double sum = 0;

  sum += GetLightFluxSum(iTime, fluo, cDir, cMie, cRay, fMult, cMult);

  if (cPrimDir && iTime < fDia_direct_cherPrimary.size())
    sum += fDia_direct_cherPrimary[iTime];

  if (cPrimMie && iTime < fDia_mie_cherPrimary.size())
    sum += fDia_mie_cherPrimary[iTime];

  if (cPrimRay && iTime < fDia_ray_cherPrimary.size())
    sum += fDia_ray_cherPrimary[iTime];

  return sum;
}
#endif


//=============================================================================
vector<Double_t>
FdApertureLight::GetLightFluxSumVector(const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                       const bool fMult, const bool cMult)
  const
{
  vector<Double_t> sum;
  for (unsigned int i = 0, n = fDia_fluor.size(); i < n; ++i)
    sum.push_back(GetLightFluxSum(i, fluo, cDir, cMie, cRay, fMult, cMult));
  return sum;
}


//=============================================================================
Double_t
FdApertureLight::GetLightFluxSum(const unsigned int iTime,
                                 const bool fluo, const bool cDir, const bool cMie, const bool cRay,
                                 const bool fMult, const bool cMult)
  const
{
  double sum = 0;

  if (fluo && iTime < fDia_fluor.size())
    sum += fDia_fluor[iTime];

  if (cDir && iTime < fDia_direct_cher.size())
    sum += fDia_direct_cher[iTime];

  if (cMie && iTime < fDia_mie_cher.size())
    sum += fDia_mie_cher[iTime];

  if (cRay && iTime < fDia_ray_cher.size())
    sum += fDia_ray_cher[iTime];

  if (fMult && iTime < fDia_multScat_fluor.size())
    sum += fDia_multScat_fluor[iTime];

  if (cMult && iTime < fDia_multScat_cher.size())
    sum += fDia_multScat_cher[iTime];

  return sum;
}


//=============================================================================
Double_t
FdApertureLight::GetLightFraction(const ELightComponent iWhat)
  const
{
  double sum = 0;
  double csum = 0;

  for (unsigned int i = 0, n = fDia_total.size(); i < n; ++i) {

    sum += fDia_total[i];

    switch (iWhat) {

    case eTotalCherenkov:
      if (i < fDia_ray_cher.size() &&
          i < fDia_mie_cher.size() &&
          i < fDia_direct_cher.size())
        csum += fDia_direct_cher[i] + fDia_mie_cher[i] + fDia_ray_cher[i];
      break;

    case eDirect:
      if (i < fDia_direct_cher.size())
        csum += fDia_direct_cher[i];
      break;

    case eMie:
      if (i < fDia_mie_cher.size())
        csum += fDia_mie_cher[i];
      break;

    case eRayleigh:
      if (i < fDia_ray_cher.size())
        csum += fDia_ray_cher[i];
      break;

    case eScattered:
      if (i < fDia_multScat_cher.size())
        csum += fDia_multScat_cher[i];
      break;

    default:
      cerr << " Error in FdApertureLight::GetLightFraction(): unknown light source "
           << iWhat << endl;
      break;
    }
  }

  return (sum <= 0) ? -0.005 : csum / sum;
}


bool
FdApertureLight::HasMultipleScatteredLight()
  const
{
  return !fDia_multScat_fluor.empty() || !fDia_multScat_cher.empty();
}
