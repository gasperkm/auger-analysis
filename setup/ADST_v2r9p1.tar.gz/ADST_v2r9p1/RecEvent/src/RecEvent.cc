#include <RecEvent.h>

#include <FDEvent.h>
#include <SDEvent.h>
#include <Detector.h>
#include <DetectorGeometry.h>
#include <FdRecLevel.h>
#ifdef AUGER_RADIO_ENABLED
#include <RdEvent.h>
#endif

#include <GenShower.h>

#include <iostream>
#include <sstream>
#include <stdexcept>

using namespace std;


ClassImp(RecEvent);


#define _RECEVENT_RELEASE "development"


// this serves as unique identification of the RecEvent version and source of up-to-date SVN information
const string RecEvent::fgRecEventSVNname =
  "$HeadURL: https://devel-ik.fzk.de/svn/auger/Offline/trunk/ADST/RecEvent/src/RecEvent.cc $";
const string RecEvent::fgRecEventSVNid = "$Id: RecEvent.cc 19705 2011-10-18 10:03:12Z darko $";
const string RecEvent::fgRecEventRelease = ""_RECEVENT_RELEASE;


string
RecEvent::GetReleaseName()
{
  return ""_RECEVENT_RELEASE;
}


string
RecEvent::GetVersion()
{
  // Since ADST/RecEvent is now part of Offline, this is the same as the Offline release.
  return GetSVNVersion();
}


string
RecEvent::GetSVNVersion()
{
  vector<string> releases;
  releases.push_back("/tags/");
  releases.push_back("/branches/");

  for (unsigned int i = 0; i < releases.size(); ++i) {
    const size_t pos = fgRecEventSVNname.find(releases[i]);
    if (pos != string::npos) {
      return fgRecEventSVNname.substr(pos + releases[i].size(),
                                      fgRecEventSVNname.find("/", pos + releases[i].size() + 1) -
                                      pos - releases[i].size());
    }
  }

  return string("trunk");
}


string
RecEvent::GetSVNDate()
{
  istringstream info(fgRecEventSVNid);
  string date;
  info >> date >> date >> date >> date;
  return date;
}


string
RecEvent::GetSVNRevision()
{
  istringstream info(fgRecEventSVNid);
  string rev;
  info >> rev >> rev >> rev;
  return rev;
}


#undef _RECEVENT_RELEASE


//=============================================================================
/*!
  \class   RecEvent
  \brief   class to hold SD, FD and simulated data

  \version 1.0
  \date    Aug 20 2005
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

RecEvent::RecEvent() :
  fEventId("1234567890"),
  fYYMMDD(0),
  fHHMMSS(0),
  fMJD(0)
{
}


RecEvent::~RecEvent()
{
  Clear();
}


Detector&
RecEvent::GetDetector()
{
  return fDetector;
}


const Detector&
RecEvent::GetDetector()
  const
{
  return fDetector;
}


SDEvent&
RecEvent::GetSDEvent()
{
  return fSDEvent;
}


const SDEvent&
RecEvent::GetSDEvent()
  const
{
  return fSDEvent;
}


#ifdef AUGER_RADIO_ENABLED
RdEvent&
RecEvent::GetRdEvent()
{
  return fRdEvent;
}


const RdEvent&
RecEvent::GetRdEvent()
  const
{
  return fRdEvent;
}
#endif


GenShower&
RecEvent::GetGenShower()
{
  return fGenShower;
}


const GenShower&
RecEvent::GetGenShower()
  const
{
  return fGenShower;
}


RecEvent::EyeIterator
RecEvent::EyesBegin()
{
  return fFDEvents.begin();
}


RecEvent::EyeIterator
RecEvent::EyesEnd()
{
  return fFDEvents.end();
}


RecEvent::ConstEyeIterator
RecEvent::EyesBegin()
  const
{
  return fFDEvents.begin();
}


RecEvent::ConstEyeIterator
RecEvent::EyesEnd()
  const
{
  return fFDEvents.end();
}


int
RecEvent::GetNEyes()
  const
{
  return fFDEvents.size();
}


void
RecEvent::AddEye(const FDEvent& fd)
{
  fFDEvents.push_back(fd);
}


bool
RecEvent::HasEye(const int id)
  const
{
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye)
    if (iEye->GetEyeId() == id)
      return true;

  return false;
}


int
RecEvent::GetHottestEyeId()
  const
{
  int idHot = 0;
  int nPixHot = 0;

  // ---- time fit
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    const int nPix = iEye->GetFdRecGeometry().GetTimeFitNdof() - 3 -
      iEye->GetFdRecGeometry().GetNHybridStations();
    if (nPix > nPixHot) {
      nPixHot = nPix;
      idHot = iEye->GetEyeId();
    }
  }
  if (idHot)
    return idHot;

  // --- SDP fit
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    const int nPix = iEye->GetFdRecGeometry().GetSDPNdF() - 2;
    if (nPix > nPixHot) {
      nPixHot = nPix;
      idHot = iEye->GetEyeId();
    }
  }
  if (idHot)
    return idHot;

  // --- pulsed pixels
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    const int nPix = iEye->GetFdRecPixel().GetNumberOfPulsedPixels();
    if (nPix > nPixHot) {
      nPixHot = nPix;
      idHot = iEye->GetEyeId();
    }
  }
  if (idHot)
    return idHot;

  // triggered
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    const int nPix = iEye->GetFdRecPixel().GetNumberOfTriggeredPixels();
    if (nPix > nPixHot) {
      nPixHot = nPix;
      idHot = iEye->GetEyeId();
    }
  }

  return idHot;
}


const FDEvent&
RecEvent::GetEye(const int id)
  const
{
  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye)
    if (iEye->GetEyeId() == id)
      return *iEye;

  throw out_of_range("No such eye");
}


FDEvent&
RecEvent::GetEye(const int id)
{
  for (EyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye)
    if (iEye->GetEyeId() == id)
      return *iEye;

  throw out_of_range("No such eye");
}


//=============================================================================
vector<FDEvent*>
RecEvent::GetInFoVHybrids(const double deltaX)
{
  vector<FDEvent*> theEyes;

  for (EyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    if (iEye->IsHybridEvent()) {
      const FdRecShower& theShower = iEye->GetFdRecShower();
      if (theShower.IsXmaxInFOV(deltaX))
        theEyes.push_back(&(*iEye));
    }
  }
  return theEyes;
}


vector<const FDEvent*>
RecEvent::GetInFoVHybrids(const double deltaX)
  const
{
  vector<const FDEvent*> theEyes;

  for (ConstEyeIterator iEye = fFDEvents.begin();
       iEye != fFDEvents.end(); ++iEye) {
    if (iEye->IsHybridEvent()) {
      const FdRecShower& theShower = iEye->GetFdRecShower();
      if (theShower.IsXmaxInFOV(deltaX))
        theEyes.push_back(&(*iEye));
    }
  }
  return theEyes;
}


//=============================================================================
void
RecEvent::CalculateAverage(const EAverageFlag avFlag, const ESingleAverageFlag singleFlag,
                           double& average, double& error,
                           double& chi2, int& Ndof)
  const
{
  // reset on entry
  average = 0;
  error = 0;
  chi2 = 0;
  Ndof = -1;

  vector<double> values;
  vector<double> errors;

  // first loop over FDs

  for (ConstEyeIterator eyeIter = fFDEvents.begin();
       eyeIter != fFDEvents.end(); ++eyeIter) {
    if (singleFlag == eEnergy) {
      if (eyeIter->GetRecLevel() >= eHasEnergy) {
        values.push_back(eyeIter->GetFdRecShower().GetEnergy());
        errors.push_back(eyeIter->GetFdRecShower().GetEnergyError());
      }
    } else if (singleFlag == eXmax) {
      if (eyeIter->GetRecLevel() >= eHasGHParameters) {
        values.push_back(eyeIter->GetFdRecShower().GetXmax());
        errors.push_back(eyeIter->GetFdRecShower().GetXmaxError());
      }
    }
  }

  // if required continue with SD

  if (avFlag == eFDsAndSD) {

    if (singleFlag == eEnergy) {
      if (fSDEvent.GetRecLevel() >= eHasLDF) {
        values.push_back(fSDEvent.GetSdRecShower().GetEnergy());
        errors.push_back(fSDEvent.GetSdRecShower().GetEnergyError());
      }
    } else if (singleFlag == eXmax) {
      ; // nothing to do so far (wait for an SD Xmax estimator ;-))
    }
  }

  if (!values.empty()) {

    double sum = 0;
    double wsum = 0;

    for (unsigned int i = 0; i < values.size(); ++i) {
      const double E = values[i];
      const double eE = errors[i];

      if (eE < numeric_limits<double>::epsilon()) {
        cerr << " RecEvent::CalculateAverage() - Error: measurement "
                "with zero error ... " << endl;
        return;
      }

      const double w = 1 / (eE*eE);

      sum += w*E;
      wsum += w;

    }

    average = sum / wsum;
    error = sqrt(1/wsum);

    for (unsigned int i = 0; i < values.size(); ++i) {
      const double pull = (values[i] - average) / errors[i];
      chi2 += (pull*pull);
    }

    Ndof = values.size() - 1;
  }
}


//=============================================================================
bool
RecEvent::CalculatePairAverage(const EAverageFlag avFlag, const EPairAverageFlag pairFlag,
                               pair<double, double>& average,
                               pair<double, double>& avError,
                               double& avCorrel)
  const
{
  vector<pair<double, double> > values;
  vector<pair<double, double> > errors;
  vector<double> correlations;

  // FD
  for (ConstEyeIterator eyeIter = fFDEvents.begin();
       eyeIter < fFDEvents.end(); ++eyeIter) {
    if (pairFlag == eCoreSiteCS) {
      const FdRecShower& theRecShower = eyeIter->GetFdRecShower();
      if (eyeIter->GetRecLevel() >= eHasAxis) {
        values.push_back(make_pair(theRecShower.GetCoreSiteCS().X(),
                                   theRecShower.GetCoreSiteCS().Y()));
        errors.push_back(make_pair(theRecShower.GetCoreEastingError(),
                                   theRecShower.GetCoreNorthingError()));
        correlations.push_back(theRecShower.GetCoreNorthingEastingCorrelation());
      }
    }
  }

  // SD
  if (avFlag == eFDsAndSD) {
    if (pairFlag == eCoreSiteCS) {
      const SdRecShower& theRecShower = fSDEvent.GetSdRecShower();
      if (fSDEvent.GetRecLevel() >= eHasSdAxis) {
        values.push_back(make_pair(theRecShower.GetCoreSiteCS().X(),
                                   theRecShower.GetCoreSiteCS().Y()));
        errors.push_back(make_pair(theRecShower.GetCoreEastingError(),
                                   theRecShower.GetCoreNorthingError()));
        correlations.push_back(theRecShower.GetCoreNorthingEastingCorrelation());
      }
    }
  }

  // average
  return CalculatePairAverage(values, errors, correlations, average, avError, avCorrel);
}


/*=============================================================================

  utility function to calculate the average of a vector of
  correlated measurement pairs

  average is calculated via


  <values> = [ sum A_i^(-1) ]^(-1) * [ sum A_i^(-1) a_i ]

  where a denotes the vector of pair values and A the vector
  of covariance matrices V(a)

  returns false if one of the A_i is singular

\*=============================================================================*/
bool
RecEvent::CalculatePairAverage(const vector<pair<double, double> >& values,
                               const vector<pair<double, double> >& errors,
                               const vector<double>& correlations,
                               pair<double, double>& average,
                               pair<double, double>& avError,
                               double& avCorrel)
  const
{
  // check if averaging is really needed

  if (values.empty())
    return false;

  if (values.size() == 1) {
    average = values[0];
    avError = errors[0];
    avCorrel = correlations[0];
    return true;
  }

  // calculate covariances and invert them

  const double epsilon = numeric_limits<double>::epsilon();

  vector<vector<double> > invCov;

  for (unsigned int i = 0; i < errors.size(); ++i) {
    vector<double> inv(3);
    const double eX = errors[i].first;
    const double eY = errors[i].second;
    const double Vx = eX * eX;
    const double Vy = eY * eY;
    const double Vxy = correlations[i] * eX * eY;

    const double det = Vx * Vy - Vxy * Vxy;

    // check singularity
    if (det < epsilon) {
      cerr << " RecEvent::CalculatePairAverage() - Error: singular covariance matrix at "
           << i << endl;
      return false;
    }

    inv[0] =  Vy / det;
    inv[1] = -Vxy / det;
    inv[2] =  Vx / det;

    invCov.push_back(inv);
  }

  double matrixSum[3] = { 0 };        // sum A_i^(-1)
  double matrixVectorSum[2] = { 0 };  // sum A_i^(-1) a_i

  for (unsigned int i = 0; i < invCov.size(); ++i) {

    for (unsigned int j = 0; j < 3; ++j)
      matrixSum[j] += invCov[i][j];

    const double x = values[i].first;
    const double y = values[i].second;

    matrixVectorSum[0] += invCov[i][0] * x + invCov[i][1] * y;
    matrixVectorSum[1] += invCov[i][1] * x + invCov[i][2] * y;
  }

  // invert sum of inverse cov matrices
  // to get covariance of average ...

  double avCovariance[3];

  const double det = matrixSum[0] * matrixSum[2] - matrixSum[1] * matrixSum[1];

  if (det < epsilon) {
    cerr << " RecEvent::CalculatePairAverage() - Error: covariance matrix "
         << " of average is singular!" << endl;
    return false;
  }

  avCovariance[0] =  matrixSum[2] / det;
  avCovariance[1] = -matrixSum[1] / det;
  avCovariance[2] =  matrixSum[0] / det;

  avError.first  = sqrt(avCovariance[0]);
  avError.second = sqrt(avCovariance[2]);
  avCorrel       = avCovariance[1] / (avError.first * avError.second);

  // ... and finally calculate the average itself
  average.first = avCovariance[0] * matrixVectorSum[0] + avCovariance[1] * matrixVectorSum[1];
  average.second = avCovariance[1] * matrixVectorSum[0] + avCovariance[2] * matrixVectorSum[1];

  return true;
}


void
RecEvent::DumpASCII(ostream& o)
  const
{
  // general info
  o << " ******************************************************************************************\n"
       "  event Id               " << fEventId << "\n"
       "  date (YYMMDD)          " << fYYMMDD << "\n"
       "  time (HHMMSS)          " << fHHMMSS << "\n"
       "  julian date            " << fMJD << "\n";

  fSDEvent.DumpASCII(o);
  for (ConstEyeIterator iEye = EyesBegin(); iEye != EyesEnd(); ++iEye)
    iEye->DumpASCII(o);

#ifdef AUGER_RADIO_ENABLED
  fRdEvent.DumpASCII(o);
#endif

  o << " ******************************************************************************************"
    << endl;
}


ostream&
operator<<(ostream& os, const RecEvent& z)
{
  z.DumpASCII(os);
  return os;
}


string
RecEvent::GetAugerId()
  const
{
  const unsigned int kAugerIDLength = 12;
  string augerIDstring = fEventId;
  string augerString = "123456789";
  const string auger = "uger";
  const string event = "event"; //MC ID
  const string sdMC = "R_";     //MC SD Id
  
  if (augerIDstring.find(auger) != string::npos) {
    augerString.assign(augerIDstring.begin() + augerIDstring.find(auger) + 5,
                       augerIDstring.begin() + augerIDstring.find(auger) + 5 + kAugerIDLength);
  } else {
    if (augerIDstring.find(event) != string::npos) {
      augerIDstring.erase(0, augerIDstring.find(event) + 5);
      augerString = augerIDstring;
    } else {
      if (augerIDstring.find(sdMC) != string::npos) {
        augerIDstring.erase(0, augerIDstring.find(sdMC) + sdMC.length());
        if (augerIDstring.find(":") != string::npos)
          augerIDstring.erase(augerIDstring.find(":"), augerIDstring.length());
        augerString = augerIDstring;
      } else
        augerString = "Unknown";
    }
  }
  
  return augerString;
}

ULong_t
RecEvent::GetAugerIdNumber()
  const
{
  const string& augerId = GetAugerId();
  istringstream iss(augerId);
  unsigned long int numericalAugerId = 0;
  if (augerId != "Unknown")
    iss >> numericalAugerId;
  return numericalAugerId;
}
