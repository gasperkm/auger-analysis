
#include <MuonMap.h>

#include <iostream>
using namespace std;

ClassImp(MuonMap);
ClassImp(MuonMapContour);
ClassImp(MuonMapPoint);

//Muon map points
MuonMapPoint::MuonMapPoint(): 
  fX(0), 
  fY(0), 
  fElectronSignal(0){
  
}

MuonMapPoint::MuonMapPoint(const double x, const double y, 
                           const double electronSignal): 
  fX(x), 
  fY(y), 
  fElectronSignal(electronSignal){

}

MuonMapPoint::~MuonMapPoint() {
}


//Muon map contours
MuonMapContour::MuonMapContour():
fContourSignal(0){
}

MuonMapContour::~MuonMapContour(){

}


//Muon map
MuonMap::MuonMap():
  fMagneticFieldAzimuth(0),
  fMuonMapType("unknown") {
}


MuonMap::~MuonMap() {
}

unsigned int MuonMap::GetNumberOfContours() const{
  return fContours.size();

}

void MuonMap::ClearMap(){
  fContours.clear(); 
}
