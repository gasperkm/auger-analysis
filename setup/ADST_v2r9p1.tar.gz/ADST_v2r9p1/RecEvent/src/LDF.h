#ifndef __LDF_H
#define __LDF_H

#include <FileInfo.h>

#include <TObject.h>
#include <TF1.h>

#include <iostream>
#include <string>
#include <cmath>

class LDF : public TObject {
 
  friend class SdRecShower;

public:

  LDF();
  virtual ~LDF(){;}

  void SetLDFStatus(const double LDFStatus) 
  {fLDFStatus=LDFStatus;}                                ///< set LDF status
  void SetLDFChi2(const double chi2, const double ndof) 
  { fLDFChi2 = chi2; fLDFNdof = ndof; }                  ///< set LDF chi2 and degrees of freedom
  void SetLDFLikelihood(const double likely)             ///< set the maximum likelihood value
  { fLDFLikelihood = likely; }
  void SetBeta(const double beta, const double error)  ///<set beta and beta error
  { fBeta = beta; fBetaError = error; }
  void SetBetaSystematics(const double error)  ///<set beta systematics
  {fBetaSys = error; }
  
  void SetGamma(const double gamma, const double error)///<set gamma and gamma error 
  { fGamma = gamma; fGammaError = error; }
  void SetNKGFermiParameters(double mu, double tau)///< set parameters of NKGFermi Fermi extension
  { fNKGFermiMu = mu; fNKGFermiTau = tau; }
  void SetReferenceDistance(double r)
  { fReferenceDistance = r; }///< set reference distance, where LDF(r) = 1
  void SetShowerSizeLabel(const char* label)
  { fShowerSizeLabel = label; } ///< set label of shower size estimator (S1000, S450, ...)
  void SetShowerSize(const double value, const double error)
  { fS1000 = value; fS1000Error = error; } ///< set shower size and error
  void SetShowerSizeSystematics(const double sysError)
  { fS1000BetaSys = sysError; } ///< set systematic error of shower size
  void SetS1000(const double s1000, const double error)///<set s(1000) and s(1000) error (deprecated)
  { fShowerSizeLabel = "S1000"; fS1000 = s1000; fS1000Error = error; }
  void SetS1000BetaSys(const double error)///<set s(1000) systematics due to beta assumption (deprecated)
  { fShowerSizeLabel = "S1000"; fS1000BetaSys = error; }
  void SetTabulatedValues(const std::vector<double>& x, const std::vector<double>& y)
  { fRhos = x; fValues = y; }

  double GetReferenceDistance() const { return fReferenceDistance?fReferenceDistance:1000; }///< get reference distance, where LDF(r) = 1
  const char* GetShowerSizeLabel() const { return fShowerSizeLabel.c_str(); } ///< get label of shower size estimator
  double GetShowerSize() const { return fS1000; } ///< get shower size
  double GetShowerSizeError() const { return fS1000Error; } ///< get shower size error
  double GetShowerSizeSys() const { return fS1000BetaSys; } ///< get systematic error of shower size
  double GetS1000() const { return fS1000; } ///< get S1000 (deprecated)
  double GetS1000Error() const { return fS1000Error; } ///< get S1000 error (deprecated)
  double GetS1000BetaSys() const { return fS1000BetaSys; }  ///< get S1000 systematics due to beta assumption (deprecated)
  
  double GetS1000TotalError() const
  { return std::sqrt(std::pow(fS1000BetaSys, 2) + std::pow(fS1000Error, 2)); } ///< get total error = (stat.^2 + sys.^2)^(1/2) of S1000 (deprecated)
  

  double GetBeta() const { return fBeta; }                 ///get beta
  double GetBetaError() const { return fBetaError; }       ///<get beta error
  double GetBetaSys() const { return fBetaSys; }       ///<get beta systematics
  
  double GetGamma() const { return fGamma; }               ///<get gamma
  double GetGammaError() const { return fGammaError; }     ///<get gamma error
  double GetNKGFermiMu() const { return fNKGFermiMu; }     ///<get parameter mu of NKGFermi
  double GetNKGFermiTau() const { return fNKGFermiTau; }   ///<get parameter tau of NKGFermi
  double GetLDFChi2() const { return fLDFChi2; }           ///< get LDF chi2
  double GetLDFNdof() const { return fLDFNdof; }           ///< get LDF number of degrees of freedom
  double GetLDFLikelihood() const{ return fLDFLikelihood; }///< get the LDF maximum likelihood value
  double GetLDFStatus() const {return fLDFStatus;}         ///< get the ldf stage reconstruction
  
  double Evaluate(const double r, const ELDFType type ) const; 
  TF1 GetFunction(const ELDFType type) const;
  
  void DumpASCII(std::ostream &o=std::cout) const;
  
 private:

  
  double NKGFunction (const double r) const;
  double PowerLawFunction(const double r) const;
  double NKGFermiFunction(const double r) const;

  double TabulatedFunction(const double r) const;

  std::vector<double> fRhos;
  std::vector<double> fValues;

  double fReferenceDistance;
  std::string fShowerSizeLabel;
  double fS1000;                 
  double fS1000Error;
  double fS1000BetaSys;
  double fBeta;                 
  double fBetaError;
  double fBetaSys;
  double fGamma;
  double fGammaError; 
  double fNKGFermiMu;
  double fNKGFermiTau;
  double fLDFChi2;
  double fLDFLikelihood;
  double fLDFNdof;
  double fLDFStatus;
  
  ClassDef(LDF,9);
};

#endif
