#include <RecEvent.h>
#include <RecEventFile.h>
#include <DetectorGeometry.h>
#include <FileInfo.h>
#include <EventInfo.h>
#include <AnalysisConsts.h>
#include <Analysis.h>
#include <UtilityFunctions.h>



#include <cmath>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>

using namespace std;

bool gMicroADST              = false;
string gOutputFile = "mergedEvents.root";


/*========================================================

   print some usage hints

==========================================================*/
void usage() {

  cout <<  "\n  Usage: mergeFDAndSD recoFD.root recoSD.root\n" 
       <<  "           mergeFDAndSD \"recoFD*.root\" \"recoSD*.root\" \n "
       << endl;
  cout <<  "  Options: -m: read files in microADST mode \n"
       <<  "           -o: output file (default: mergedEvents.root) \n"

       << endl;
}  

/*========================================================

   reads command line options

==========================================================*/
int getOptions(int argc, char** argv){
  
  int c;
  while ((c = getopt (argc, argv, "m:")) != -1) {
    switch (c) {
    case 'm': 
      gMicroADST=true;
      break;
    case 'o': 
      gOutputFile = string(optarg);
      break;
    case 'h': 
      return -1;
    default:
      return -1;
    }
  }
  return optind;
}

/*========================================================

   compareADSTs main()

==========================================================*/
int main(int argc, char** argv) {


  int nOptions = getOptions(argc,argv);

  if ( nOptions < 0 || argc-nOptions != 2 ) {
    usage();
    return 1;
  }



  EventInfo eventInfo;
  RecEventFile* dataFile[2];
  RecEvent* recEvent[2];
  DetectorGeometry* theGeometry[2];
  Analysis* analysis[2]={NULL,NULL};
  
  for ( unsigned int i=0;i<2;i++) {
    dataFile[i]    = new RecEventFile(argv[nOptions+i]); 
    cout << " opening file " << argv[nOptions+i];
    recEvent[i]    = new RecEvent();
    theGeometry[i] = new DetectorGeometry();
    dataFile[i]->ReadDetectorGeometry(*(theGeometry[i]));
    if (gMicroADST)
      dataFile[i]->SetMicroADST(); 
    dataFile[i]->SetBuffers(&(recEvent[i]));
  }

  RecEventFile* outFile = new RecEventFile(gOutputFile,
					   RecEventFile::eWrite);
  RecEvent *mergedEvent = new RecEvent();
  outFile->SetBuffers(&mergedEvent);
  cout << " building search map... " << flush;
  dataFile[1]->SearchForSDEvent(0);
  cout << " done " << endl;
  
  int nMatch=0;
  int nAna=0;

  unsigned int nEv0=dataFile[0]->GetNEvents();
  cout << " reading events... " << endl;
  for ( unsigned int i=0;i<nEv0;i++) {
    dataFile[0]->GetEventInfo(i,&eventInfo);
    UInt_t sdEventId = eventInfo.GetSDId();
    if ( dataFile[1]->SearchForSDEvent(sdEventId)==RecEventFile::eSuccess  ) {
      nMatch++;
      dataFile[0]->ReadEvent(i);
      *mergedEvent = *recEvent[0];
      mergedEvent->SetSDEvent(recEvent[1]->GetSDEvent());
      outFile->WriteEvent();
    }
    if ( i%100 == 0 )
      UtilityFunctions::ShowProgress(i,nEv0);
  }
  
  UtilityFunctions::ShowProgress(nEv0,nEv0);

  cout << "\n\n " << nMatch << " matching event" 
       << (nMatch>1?"s":"") 
       << " out of " << dataFile[0]->GetNEvents() 
       << endl;
  cout << " " << nAna << " Auger event" 
       << (nAna>1?"s":"") << " merged" << endl; 

  FileInfo theInfo;
  dataFile[1]->ReadFileInfo(theInfo);
  outFile->WriteDetectorGeometry (*theGeometry[0]);
  outFile->WriteFileInfo(theInfo);
  outFile->Close();
  
}
