#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"

#include <TTree.h>

#include <vector>
#include <string>
#include <iostream>
#include <fstream>

#include "AsciiConverter.h"
#include "AsciiSDConverter.h"
#include "AsciiFDConverter.h"
#include "AsciiHybridConverter.h"

using namespace std;
using namespace ADST;

int getOptions(int argc, char **argv);
void usage();

enum EAsciiMode {
  eSD = 0,
  eHybrid
};

bool gWriteDescriptionLaTeX = false;
bool gWriteDescriptionText = false;
EAsciiMode gAsciiMode = eSD;

int main(int argc, char **argv) {
  TTree::SetMaxTreeSize(200000000000ll);

  const int nOptions = getOptions(argc, argv);
  if ( nOptions < 0 || argc-nOptions < 1 ) {
    usage();
    return 1;
  }

  RecEvent* theRecEvent = new RecEvent();
  DetectorGeometry* theGeometry = new DetectorGeometry();

  vector<string> dataFileNames(argc-nOptions);
  std::copy(argv + nOptions, argv + argc, dataFileNames.begin());
  RecEventFile dataFile(dataFileNames);

  dataFile.SetBuffers(&theRecEvent);
  dataFile.ReadDetectorGeometry(*theGeometry);

  AsciiConverter* cv;
  if (gAsciiMode == eSD)
    cv = (AsciiConverter*)new AsciiSDConverter();
  else
    cv = (AsciiConverter*)new AsciiHybridConverter();

  cv->WriteFileHeader();

  while (dataFile.ReadNextEvent() == RecEventFile::eSuccess)
    cv->Convert(*theRecEvent);

  if (gWriteDescriptionText) {
    ofstream htxt("header.dat");
    cv->WriteColumnTextDescription(htxt);
  }

  if (gWriteDescriptionLaTeX) {
    ofstream htxt("header.tex");
    cv->WriteColumnLaTeXDescription(htxt);
  }
}

void usage() {
    cout << " usage: ADST2ASCII [<options>] <fileNames> \n"
	 << endl;
    cout << " Options:\n"
	 << "          -m: mode (sd/hybrid)               (default: sd) \n"
	 << "          -t: enable writing of the textual column description \n"
	 << "          -l: enable writing of the LaTeX column description \n"
	 << endl;
}

/*========================================================

   reads command line options

==========================================================*/
int getOptions(int argc, char **argv){
  int c;
  while ((c = getopt(argc, argv, "m:htl")) != -1) {
    switch (c) {
    case 'm': {
      const string mode(optarg);
      if (mode == "sd" || mode == "s") {
	gAsciiMode = eSD;
	cerr << " ASCII-mode: SD" << endl;
      } else if (mode == "hybrid" || mode == "h") {
	gAsciiMode = eHybrid;
	cout << " ADST-mode: hybrid" << endl;
      } else {
	return -2;
      }
      break;
    }
    case 't':
      gWriteDescriptionText = true;
      break;
    case 'l':
      gWriteDescriptionLaTeX = true;
      break;
    case 'h':
      return -2;
    default:
      return -2;
    }
  }
  cout << endl;
  return optind;
}

