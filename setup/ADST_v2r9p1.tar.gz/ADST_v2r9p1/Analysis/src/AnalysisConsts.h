
#ifndef __AnalysisConsts_H
#define __AnalysisConsts_H

#include <TMath.h>

static const double kFDSpeedOfLight = 29.9792458; // in units if m/100 ns
static const double kdegRad = TMath::Pi()/180.;
static const double kradDeg = 180./TMath::Pi();
static const double degree  = kdegRad;

// WGS84 radius at Malargue latitude
const double kEarthRadius = 6.37093738e6;

static const int kPhotonID = 22;
static const int kProtonID = 2212;
static const int kIronID   = 1000026056;

static const unsigned int kNTelescopes = 27;
static const unsigned int kNEyes       = 5;

// FD T3 classes

enum ET3Classes {
  eT3Undefined = 0,
  eT3Shower,
  eT3Noise,
  eT3Muon,
  eT3Large
};


// meaning of hybrid spectrum analysis RecEvent:fUserData indices

enum EHySpecUserData {
  eSlope0 = 0,
  eSlope1,
  eSlope2,
  eCompo,
  eT3Veto,
  eNHySpecParameters
};

#endif
