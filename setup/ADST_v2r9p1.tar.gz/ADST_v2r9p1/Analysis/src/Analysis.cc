#include <Analysis.h>
#include <FDSelection.h>
#include <SDSelection.h>
#include <SimSelection.h>
#include <AugerUpTime.h>

#include <RecEvent.h>
#include <DetectorGeometry.h>

#include <TRandom.h>
#include <TString.h>
#include <TPRegexp.h>

#include <cmath>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cstdlib>
#include <string>

using namespace std;

Analysis::Analysis(const DetectorGeometry* const* geom,
                   const RecEvent* const* event,
                   const string& configFile, bool withNMinusOne,
                   const std::string& analysisName) :
  fFDSelection(NULL),
  fSDSelection(NULL),
  fSimSelection(NULL),
  fAugerUpTime(NULL),
  fAnalysisName(analysisName),
  fDetectorGeometry(geom),
  fEvent(event),
  fT2TriggerProb(geom),
  fWithNMinusOne(withNMinusOne)
{
  ifstream in;
  in.open(configFile.c_str());

  if ( ! in.good() ) {
    string errMsg = " Analysis::Analysis() - Error reading config file "
      + configFile;
    cout << errMsg << endl;
    throw std::runtime_error(errMsg);
  }

  const string path = ((configFile.rfind('/')==string::npos) ?       // if path use for config file
                       "./" :                                        // local path (pwd)
                       configFile.substr(0, configFile.rfind('/')+1)); // use global path

  string buffer;
  TPRegexp isEmptyLine("^\\s*$"); // ie. only whitespace
  while (!in.eof()) {
    getline(in, buffer);
    StripComments(buffer);

    if ( !isEmptyLine.MatchB(TString(buffer.c_str())) ) {
      stringstream line(buffer);
      string descriptor;
      string value;
      line >> descriptor;
      if ( descriptor == "\n" || descriptor == "" )
        continue;

      // lots of conversion going on. I bet this can be simplified.
      std::getline(line, value);
      TString buffer(value);
      // remove whitespace from beginning and end
      TPRegexp("^\\s+").Substitute(buffer, "");
      TPRegexp("\\s+$").Substitute(buffer, "");
      value = string(buffer.Data());

      // if the descriptor has "file" in the name, absolutify the path.
      // FIXME: if somebody figures out how the stupid ROOT modifiers work, we can do better case-insensitive matches.
      TPRegexp hasFileInName("[fF][iI][lL][eE]");
      if (hasFileInName.MatchB(descriptor))
        value = MakeAbsolutePath(value, path);

      if ( descriptor == "FDCutFile" )
        fFDCutFileNames.push_back( value );
      else if  ( descriptor == "SDCutFile" )
        fSDCutFileNames.push_back( value );
      else if  ( descriptor == "SimCutFile" )
        fSimCutFileNames.push_back( value );
      else if  ( descriptor == "FDUpTimeFile" ) // FIXME: this should be in user config
        fFDLifeFileName = value;
      else if  ( descriptor == "SDUpTimeFile" ) // FIXME: this should be in user config
        fSDLifeFileName = value;
      else
        fUserConfiguration[descriptor] = value;
    } // end if line not empty
    if (!in.good()) break;
  } // end while not eof

  Selection::SetUserConfiguration(fUserConfiguration);
}

Analysis::~Analysis() {
  const size_t n = fSDSelection->GetIds().size();
  if (n)
  {
    cout << "idsFromFile: " << n << " events not found:";
    size_t count = 0;
    for (set<unsigned long int>::const_iterator id = fSDSelection->GetIds().begin();
         id != fSDSelection->GetIds().end(); ++id,++count)
    {
      if (n < 10 || (n >= 10 && (count < 3 || count > n-4)) )
        cout << " " << *id;
      else if (count == 3)
        cout << " [...]";
    }
    cout << endl;
  }

  delete fSDSelection;
  delete fSimSelection;
  delete fFDSelection;
  delete fAugerUpTime;
}

bool Analysis::HasSDSelection() {
  if (fSDCutFileNames.empty())
    return false;

  if (!fSDSelection)
    InitSDCuts();

  return (!fSDSelection->GetCuts().empty());
}

bool Analysis::HasFDSelection() {
  if (fFDCutFileNames.empty())
    return false;

  if (!fFDSelection)
    InitFDCuts();

  return (!fFDSelection->GetCuts().empty());
}

bool Analysis::HasSimSelection() {
  if (fSimCutFileNames.empty())
    return false;

  if (!fSimSelection)
    InitSimCuts();

  return (!fSimSelection->GetCuts().empty());
}

bool Analysis::IsGoodSD(double weight) {
  if (!HasSDSelection())
    return true;

  if (fSDSelection != NULL)
    return fSDSelection->IsSelected(-1, weight);
  else
    return true;
}

bool Analysis::IsGoodSim(double weight) {
  if (!HasSimSelection())
    return true;

  if (fSimSelection != NULL)
    return fSimSelection->IsSelected(-1, weight);
  else
    return true;
}

bool Analysis::IsGoodEye(unsigned int iEye, double weight) {
  if (!HasFDSelection())
    return true;

  if (fFDSelection != NULL)
    return fFDSelection->IsSelected(iEye, weight);
  else
    return true;
}

int Analysis::GetFDCutWhichKilledEvent() const {
  if (fFDSelection != NULL)
    return fFDSelection->GetCutWhichKilledEvent();
  else
    return -1;
}

int Analysis::GetSDCutWhichKilledEvent() const {
  if (fSDSelection != NULL)
    return fSDSelection->GetCutWhichKilledEvent();
  else
    return -1;
}

int Analysis::GetSimCutWhichKilledEvent() const {
  if (fSimSelection != NULL)
    return fSDSelection->GetCutWhichKilledEvent();
  else
    return -1;

}

void Analysis::WriteNMinusOne() {
  if (fFDSelection != NULL)
    fFDSelection->WriteNMinusOne();

  if (fSDSelection != NULL)
    fSDSelection->WriteNMinusOne();

  if (fSimSelection != NULL)
    fSimSelection->WriteNMinusOne();
}

void Analysis::WriteCutStatistics() const {
  if (fFDSelection != NULL)
    fFDSelection->WriteCutStatistics(fAnalysisName);

  if (fSDSelection != NULL)
    fSDSelection->WriteCutStatistics(fAnalysisName);

  if (fSimSelection != NULL)
    fSimSelection->WriteCutStatistics(fAnalysisName);
}

void Analysis::PrintCutStatistics(bool latex) const {
  if (fSDSelection != NULL) {
    cout << "\n" << (latex?"%":"")
         << " ----- SD cuts ---------------------------- " << endl;
    fSDSelection->PrintCutStatistics(latex);
    cout << (latex?"%":"")
         << " ------------------------------------------ \n" << endl;
  }

  if (fFDSelection != NULL) {
    cout << (latex?"%":"")
         << " ----- FD cuts ---------------------------- " << endl;
    fFDSelection->PrintCutStatistics(latex);
    cout << (latex?"%":"")
         << " ------------------------------------------ \n" << endl;
  }

  if (fSimSelection != NULL) {
    cout << (latex?"%":"")
         << " ----- Sim cuts ---------------------------- " << endl;
    fSimSelection->PrintCutStatistics(latex);
    cout << (latex?"%":"")
         << " ------------------------------------------ \n" << endl;
  }
}

const FDSelection& Analysis::GetFDSelection()  {
  if (!fFDSelection)
    InitFDCuts();

  return *fFDSelection;
}

const SDSelection& Analysis::GetSDSelection() {
  if (!fSDSelection)
    InitSDCuts();

  return *fSDSelection;
}

const SimSelection& Analysis::GetSimSelection() {
  if (!fSimSelection)
    InitSimCuts();

  return *fSimSelection;
}


AugerUpTime* Analysis::GetAugerUpTime() {
  if (!fAugerUpTime)
    InitUpTime();

  return fAugerUpTime;
}


void Analysis::InitFDCuts() {
  if (fFDSelection != NULL)
    return;

  try {
    fFDSelection = new FDSelection(fDetectorGeometry,
                                   fEvent,
                                   1, fWithNMinusOne,
                                   fFDCutFileNames);
  }
  catch (std::runtime_error& s) {
    cout << s.what() << endl;
    fFDSelection = NULL;
    throw std::runtime_error(string(s.what()));
  }
}


void Analysis::InitSDCuts() {
  if (fSDSelection != NULL)
    return;

  try {
    fSDSelection = new SDSelection(fDetectorGeometry,
                                   fEvent,
                                   1, fWithNMinusOne,
                                   fSDCutFileNames);
  }
  catch (std::runtime_error& s) {
    cout << s.what() << endl;
    fSDSelection = NULL;
    throw std::runtime_error(string(s.what()));
  }
}


void Analysis::InitSimCuts() {
  if (fSimSelection != NULL)
    return;

  try {
    fSimSelection = new SimSelection(fDetectorGeometry,
                                     fEvent,
                                     1, fWithNMinusOne,
                                     fSimCutFileNames);
  }
  catch (std::runtime_error& s) {
    cout << s.what() << endl;
    fSimSelection = NULL;
    throw std::runtime_error(string(s.what()));
  }
}

void Analysis::InitUpTime() {
  if (fAugerUpTime != NULL)
    return;

  try {
    fAugerUpTime = new AugerUpTime(fFDLifeFileName.empty()?NULL:fFDLifeFileName.c_str(),
                                   fSDLifeFileName.empty()?NULL:fSDLifeFileName.c_str());
  }
  catch (std::runtime_error& s) {
    cout << s.what() << endl;
    throw std::runtime_error(string(s.what()));
  }
}

const TBits* Analysis::GetCurrentArrayStatus() {
  if (!fAugerUpTime)
    InitUpTime();
  Int_t iGPS = (*fEvent)->GetSDEvent().GetGPSSecond();
  if (iGPS <= 0)
    return NULL;
  else
    return fAugerUpTime->GetArrayStatus((unsigned int) iGPS);
}

T2TriggerProb& Analysis::GetT2TriggerProb() {
  return fT2TriggerProb;
}

double Analysis::GetFDUpFraction(int GPSTime, int iTel) {
  return fAugerUpTime->GetTotalTelescopeUpFraction(iTel, GPSTime);
}


int Analysis::GetXmaxPixel(unsigned int iEye) {
  if ((*fEvent)->HasEye(iEye)) {
    const FDEvent& eye = (*fEvent)->GetEye(iEye);

    if (eye.GetRecLevel() >= eHasGHParameters) {
      const FdRecShower& rec = eye.GetFdRecShower();
      double xMax = rec.GetXmax();

      // find Xmax bin
      int maxBin = -1;
      const vector<Double_t> &depth = rec.GetDepth();
      const vector<Double_t> &depthError = rec.GetDepthError();
      int nProf = depth.size();
      if (nProf <= 1)
        return -5;
      bool first = true;
      double minXmaxDist = 0;
      for (int iProf = 0; iProf < nProf; ++iProf) {
        double binXmax = depth[iProf];// - depthError[iProf]/2.;
        double distXmax = std::fabs(binXmax-xMax);
        if (first) {
          minXmaxDist = distXmax;
          maxBin = iProf;
          first = false;
        }
        else if (distXmax<minXmaxDist) {
          minXmaxDist = distXmax;
          maxBin = iProf;
        }
      } // end find xmax bin
      if (maxBin == -1) {
        cerr << " WARNING: could not find Xmax bin: "
             << " xmax=" << xMax
             << " nP=" << nProf
             << " depthMin=" << depth[0] << " (" << depthError[0] << ")"
             << " depthMax=" << depth[nProf-1] << " (" << depthError[nProf-1] << ")"
             << endl;
        return -2;
      }

      // get bin time
      double timeXmax = eye.GetFdRecApertureLight().GetTime()[maxBin];

      // find xMax pixel
      int maxPixel = -1;
      double maxCharge = 0;
      first = true;
      const FdRecPixel &recPixel = eye.GetFdRecPixel();
      int nPixel = recPixel.GetNumberOfPixels();
      for (int iPixel = 0; iPixel < nPixel; ++iPixel) {

        if (recPixel.GetStatus(iPixel) < ePulseRecPix)
          continue;

        int id = recPixel.GetID(iPixel); // (iTel-1)*440+(idPix-1), where iTel is from 1-6
        double charge = recPixel.GetCharge(iPixel);
        double pixStart = recPixel.GetPulseStart(iPixel);
        double pixStop = recPixel.GetPulseStop(iPixel);

        if (timeXmax >= pixStart && timeXmax <= pixStop) {
          if (first) {
            maxCharge = charge;
            maxPixel = id;
            first = false;
          }
          else if (charge>maxCharge) {
            maxCharge = charge;
            maxPixel = id;
          }
        }
      } // loop pixels

      return maxPixel;
    } // has GH parameters

  } // has eye

  cerr << " eye " << iEye << " not available"  << endl;
  return -1;

} // GetXmaxPixel()


// TODO: This is the same as in CutFileParser.cc, this should be in only one place.
void Analysis::StripComments(string& line) {
  TString buffer(line);
  TPRegexp comments("#.*$");
  comments.Substitute(buffer, "");
  line = string(buffer.Data());
}

string Analysis::MakeAbsolutePath(const string& file, const string& path) {
  string returnStr;
  if (file.find('/') == 0)
    returnStr = file;
  else
    returnStr = path+file;
  return returnStr;
}

unsigned int Analysis::ADSTAnalysisRevision() {
  // This could have been so simple if only...
  const char id[] = "$Rev: 21462 $";
  TString idStr(id);
  TPRegexp("^\\s*\\$\\s*Rev\\s*:?\\s*").Substitute(idStr, "");
  unsigned int rev = (unsigned int)atoi(idStr.Data());
  return rev;
}
