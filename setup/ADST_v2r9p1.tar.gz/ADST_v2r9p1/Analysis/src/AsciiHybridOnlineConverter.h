#ifndef __AsciiHybridOnlineConverter_h
#define __AsciiHybridOnlineConverter_h

#include <AsciiFDConverter.h>

class RecEvent;

namespace ADST {

  /*!
   * @class AsciiHybridOnlineConverter
   * @brief ASCII streamer appropriate for online Hybrid reconstruction
   */
  class AsciiHybridOnlineConverter : protected AsciiFDConverter {
  public:

    AsciiHybridOnlineConverter();
    AsciiHybridOnlineConverter(const std::string& outfile);
    AsciiHybridOnlineConverter(std::ostream& outstream);
    ~AsciiHybridOnlineConverter();

    virtual void WriteFileHeader();

  protected:
    virtual std::string GetOutputDescription();

  private:
    void Init();
  };
} // end namespace ADST

#endif
