// $Id: UtilityFunctions.cc 22123 2012-10-30 00:15:10Z darko $
#include <UtilityFunctions.h>
#include <MonthlyAverageAtmosphere.h>
#include <AnalysisConsts.h>

#include <DetectorGeometry.h>
#include <GenShower.h>

#include <TMath.h>

#include <stdexcept>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <sys/ioctl.h>
#include <cmath>

using namespace std;


namespace UtilityFunctions {

  //****************************************************************
  //
  //  energy from S1000 and cosTheta as in PRL spectrum paper
  //
  //****************************************************************

  double
  GetSDEnergy(const double s1000, const double cosTheta)
  {
    const double cossq = cosTheta*cosTheta - 0.621;
    const double a = 0.92; //+- 0.06
    const double b = -1.13; //+- 0.27
    const double s38 = s1000 / (1. + a*cossq + b*cossq*cossq);

    /// PRL
    ///A=1.49* 10^17
    ///B=1.08

    // spectrum PRL
    return 1e18 * 0.149 * pow(s38, 1.08);
  }


  //****************************************************************
  //
  //  calculation of generator surface [m^2] used in
  //  eye centric EventGeneratorKG for LL/CO only
  //
  //****************************************************************

  double
  GeneratorSurfaceLLCO(const double lgE, const double deltaPhi,
                       const double distanceLLCO)
  {
    const double r = Rcutoff(lgE);
    const double overLap = CircCircIntersectionArea(distanceLLCO, r, r);
    const double oneEyeArea = r*r * deltaPhi;

    return (2 - overLap) * oneEyeArea;
  }


  //****************************************************************
  //
  //  calculation of overlap area between two
  //  circles radius r and rr at distance dd
  //
  //   returns relative area in units of r^2*pi
  //
  //****************************************************************

  double
  CircCircIntersectionArea(const double dd, const double r, const double rr)
  {
    const double d = fabs(dd);

    const double r2 = pow(r, 2);

    if (d >= r + rr)                        // no intercept
      return 0;
    else {
      double minr = r;
      double maxr = rr;
      if (r > rr) {
        minr = rr;
        maxr = r;
      }
      if (d <= maxr - minr) {
        // small circle fully contained
        const double c = minr / r;
        return c*c;
      }
    }

    const double rr2 = pow(rr, 2);
    const double d2 = pow(d, 2);

    const double a1 = -d + r + rr;
    const double a2 =  d + r - rr;
    const double a3 =  d - r + rr;
    const double a4 =  d + r + rr;
    const double t = a1*a2*a3*a4;

    if (t > 0) {
      const double t1 = -0.5 * sqrt(t);

      const double t2 = r2*acos((d2+r2-rr2) / (2*d*r));

      const double t3 = rr2*acos((d2+rr2-r2) / (2*d*rr));

      return (t1+t2+t3) / (r2*M_PI);
    } else              // should never happen ...
      return 0;
  }


  //****************************************************************
  //
  //  max eye-centric radius from EventGenerator
  //
  //****************************************************************

  double
  Rcutoff(const double lgE)
  {
    const double x = fmax(16.5, fmin(21., lgE));

    const double p[] = { 4.86267e+05, -6.72442e+04, 2.31169e+03 };

    return p[0] + x*(p[1] + x*p[2]);
  }


  //****************************************************************
  //
  //   MC-surface from MC-integration of energy dependent distance cut Rcutoff
  //
  //   LosLeones and Coihueco only!!
  //****************************************************************

  double
  GetMCSurface(const double lgE) //[km^2]
  {
    const double x = fmax(17., fmin(21., lgE));

    const double p[] = { -1526678.483135, 261491.190833, -15001.450475, 288.442987 };

    const double surface = p[0] + x*(p[1] + x*(p[2] + x*p[3]));

    return surface;
  }


  //****************************************************************
  //
  //   returns weight for MC in order to
  //   reproduce <Xmax> from GAP2007005
  //   assuming originally nP proton
  //   and nF iron in your MC sample
  //   (and QGSJET01 as generator interaction model)
  //****************************************************************

  double
  GetCompositionWeight(const int genPrimary,
                       const double lgE,
                       const unsigned int nP,
                       const unsigned int nF)
  {
    if (nP <= 0 || nF <= 0) {
      cerr << " UtilityFunctions::GetCompositionWeight(): zero MC sample "
           << nP << " " << nF << endl;
      return 0;
    }

    const double mcProtonFraction = double(nP) / (nP + nF);

    // polynomial fit parameters to QGSJET01 Xmax , lgE=[17.,21.]

    const double pPar[3] = { -7.339266e+02, 1.107229e+02, -1.640423e+00 };
    const double fPar[3] = { -1.009215e+03, 1.237630e+02, -1.798518e+00 };

    const double protonXmax = pPar[0] + lgE*(pPar[1] + lgE*pPar[2]);
    const double ironXmax   = fPar[0] + lgE*(fPar[1] + lgE*fPar[2]);

    // ICRC07 ER parameters
    const double lgE0 = 18.346;
    const double X_E0 = 725.572;
    const double D10 = (lgE > lgE0) ? 40.375 : 70.504;

    const double dataXmax = X_E0 + D10*(lgE - lgE0);

    const double dataProtonFraction =
      (dataXmax-ironXmax) / (protonXmax-ironXmax);

    if (genPrimary != kProtonID && genPrimary != kIronID) {
      ostringstream errMsg;
      errMsg  << " GetCompositionWeight(): primary " << genPrimary
              << " not implemented ";
      throw std::runtime_error(errMsg.str());
    }

    if (genPrimary == kProtonID)
      return dataProtonFraction / mcProtonFraction;
    else
      return (1 - dataProtonFraction) / (1 - mcProtonFraction);
  }


  //****************************************************************
  //
  //   same thing as above but with genShower as argument
  //
  //****************************************************************

  double
  GetCompositionWeight(const GenShower& genShower,
                       const unsigned int Np,
                       const unsigned int Nf)
  {
    return GetCompositionWeight(genShower.GetPrimary(),
                                log10(genShower.GetEnergy()),
                                Np, Nf);
  }


  //****************************************************************
  //
  // Converts slant depth to distance from core using parameters from
  //   Keilhauer et al., GAP-2005-021
  // these correspond to the MonthlyAverageProfileDB
  //
  //   input:  month [1,12], slant depth [g/cm^2],
  //   coreHeight [m a.s.l.] and cos(zenith)
  //
  //   output: height a.s.l. [m]
  //
  //****************************************************************

  double
  DistanceFromSlantDepth(const unsigned int iMonth,
                         const double slantDepth,
                         const double coreHeightASL,
                         const double cosTheta,
                         const double tolerance)
  {
    if (iMonth < 1 || iMonth > gNAvDBMonths) {
      ostringstream errMsg;
      errMsg  << " DistanceFromSlantDepth() - illegal month "
              << iMonth << endl;
      cerr << errMsg.str() << endl;
      throw std::runtime_error(errMsg.str());
    }

    const int theMonth = iMonth - 1;

    const double coreHeight  = coreHeightASL + kEarthRadius;
    const double coreHeight2 = coreHeight*coreHeight;

    // start at lower boundary of last layer
    const MonthlyAverageParameters & cosmosPar =
      gAvDBParameters[theMonth][gNAvDBLayers-1];
    double slantSum = cosmosPar.aParam;
    double currentHeight = cosmosPar.layerHeight;

    // distance from cosine law
    const double h1 = coreHeight;
    const double h2 = currentHeight + kEarthRadius;
    const double b = 2*h1*cosTheta;
    const double c = h1*h1 - h2*h2;
    const double signB = b > 0 ? 1 : -1;
    const double q = -0.5*(b + signB*sqrt(b*b - 4*c));
    double currentDistance = c / q;

    double dDistance = 100;

    const int maxIter = 1000000;
    int nIter = 0;

    while (true) {
      ++nIter;

      const double lastHeight = currentHeight;
      const double lastDistance = currentDistance;
      currentDistance -= dDistance;

      const double t2 =
        pow(currentDistance, 2) +
        coreHeight2 + 2*coreHeight*currentDistance*cosTheta;

      currentHeight = sqrt(t2) - kEarthRadius;

      bool foundLayer = false;

      for (unsigned int i = 0; i < gNAvDBLayers-1; ++i) {
        const MonthlyAverageParameters& par1 = gAvDBParameters[theMonth][i];
        const MonthlyAverageParameters& par2 = gAvDBParameters[theMonth][i+1];

        if (par1.layerHeight <= currentHeight && currentHeight < par2.layerHeight) {
          const double X1 = par1.GetDepth(lastHeight);
          const double X2 = par1.GetDepth(currentHeight);
          const double localCosTheta =
            (lastHeight - currentHeight) / (lastDistance - currentDistance);
          const double dSlant = (X2 - X1) / localCosTheta;

          if (slantSum+dSlant > slantDepth) {
            dDistance /= 10;
            currentDistance = lastDistance;
            currentHeight = lastHeight;
          } else
            slantSum += dSlant;

          foundLayer = true;
          break;
        }
      } // end foreach gNAvDBLayers

      if (!foundLayer) {
        ostringstream errMsg;
        errMsg << " DistanceFromSlantDepth():"
               << " reached end of atmosphere " << endl;
        cerr << errMsg.str() << endl;
        throw std::runtime_error(errMsg.str());
      }

      if (nIter > maxIter) {
        ostringstream errMsg;
        errMsg << " DistanceFromSlantDepth():"
               << " reached max number of iterations "
               << nIter << endl;
        cerr << errMsg.str() << endl;
        throw std::runtime_error(errMsg.str());
      }

      if (fabs(slantSum - slantDepth) < tolerance)
        break;
    } // end while true

    //    cout << "DFSD "<< currentDistance  << " " << currentHeight
    //         << " " << slantSum << " " << nIter << endl;

    return currentDistance;
  }


  //****************************************************************
  //
  // Converts vertical depth to height using parameters from
  //   Keilhauer et al., GAP-2005-021
  // these correspond to the MonthlyAverageProfileDB
  //
  //   input:  month [1,12] and vertical depth [g/cm^2]
  //   output: height a.s.l. [m]
  //
  //****************************************************************

  double
  HeightFromVerticalDepth(const double vertDepth,
                          const unsigned int iMonth)
  {
    if (iMonth < 1 || iMonth > gNAvDBMonths) {
      ostringstream errMsg;
      errMsg  << " HeightFromVerticalDepth() - illegal month "
              << iMonth << endl;
      cerr << errMsg.str() << endl;
      throw std::runtime_error(errMsg.str());
    }

    const int theMonth = iMonth - 1;

    double height = gAvDBParameters[theMonth][0].layerHeight - 1;

    for (unsigned int i = 0; i < gNAvDBLayers-1; ++i) {
      const MonthlyAverageParameters& par1 = gAvDBParameters[theMonth][i];
      const MonthlyAverageParameters& par2 = gAvDBParameters[theMonth][i+1];

      const double depth1 = par1.aParam + par1.bParam *
        exp(-par1.layerHeight / par1.cParam);
      const double depth2 = par2.aParam + par2.bParam *
        exp(-par2.layerHeight / par2.cParam);

      if (depth1 >= vertDepth && vertDepth > depth2)
        height = -par1.cParam * log((vertDepth - par1.aParam) / par1.bParam);
    }

    if (height < gAvDBParameters[theMonth][0].layerHeight) {
      ostringstream errMsg;
      errMsg  << " HeightFromVerticalDepth() - depth outside "
              << " atmosphere? "
              << " month=" << iMonth
              << " depth = " << vertDepth
              << endl;
      cerr << errMsg.str() << endl;
      throw std::runtime_error(errMsg.str());
    }

    return height;
  }


  //****************************************************************
  //
  // get vertical depth given height a.s.l.
  //
  //   input:  month [1,12], height a.s.l. [m]
  //   output: vertical depth [g/cm^2]
  //
  //****************************************************************

  double
  VerticalDepthFromHeight(const double heightASL, const unsigned int iMonth)
  {
    if (iMonth < 1 || iMonth > gNAvDBMonths) {
      ostringstream errMsg;
      errMsg << " VerticalDepthFromHeight() - illegal month "
             << iMonth << endl;
      cerr << errMsg.str() << endl;
      throw std::runtime_error(errMsg.str());
    }

    const int theMonth = iMonth - 1;

    const MonthlyAverageParameters& cosmosPar =
      gAvDBParameters[theMonth][gNAvDBLayers-1];

    if (heightASL > cosmosPar.layerHeight)
      return cosmosPar.GetDepth(heightASL);
    else {
      for (unsigned int i = 0; i < gNAvDBLayers-1; ++i) {
        const MonthlyAverageParameters& par1 = gAvDBParameters[theMonth][i];
        const MonthlyAverageParameters& par2 = gAvDBParameters[theMonth][i+1];
        if (par1.layerHeight <= heightASL && heightASL < par2.layerHeight)
          return par1.GetDepth(heightASL);
      }
    }

    ostringstream errMsg;
    errMsg  << " VerticalDepthFromHeight() - height below "
            << " ground? "
            << " month=" << iMonth
            << " height = " << heightASL
            << endl;
    cerr << errMsg.str() << endl;
    throw std::runtime_error(errMsg.str());

    return -1;
  }


  //****************************************************************
  //
  // Convert slant depth to height using Malargue spring
  // atm. parametrization after Keilhauer et al.
  //
  //****************************************************************
  double
  SlantDepthToHeightApproximation(const double depth, const double cosZenith)
  {
    // Parametrization taken from:
    // Keilhauer et al: Investigation of Atmospheric Effects on the Development
    // of Extensive Air Showers and their Detection with the Pierre Auger Observatory
    //
    // atmosphere layers:
    // 1 0-5.9km
    // 2 5.9-12km
    // 3 12-34.5km
    // 4 34.5-100km
    // 5 >100km
    // i=1..4: x = a_i + b_i * exp(h/c_i)
    // i=5:    x = a_5 - b_5/c_5 * h
    // i=1..4: h = -c_i * ln( (x - a_i) / b_i )
    // i=5:    h = (a_5 - x) * (c_5/b_5)
    //
    // Comment: These are the constants for Malargue spring. According to Bianca,
    // the values for spring correspond most closely to the yearly average.
    const double a[5] = { -159.683519, -79.5570480, 0.98914795, 4.87191289e-4, 0.01128292 };
    const double b[5] = { 1202.8804, 1148.6275, 1432.0312, 696.42788, 1 };
    const double c[5] = { 9771.3952, 8580.8701, 6144.5160, 7308.7573, 1e7 };

    const double boundaryX1 = a[0] + b[0] * exp(  5900/c[0]);
    const double boundaryX2 = a[1] + b[1] * exp( 12000/c[1]);
    const double boundaryX3 = a[2] + b[2] * exp( 34500/c[2]);
    const double boundaryX4 = a[3] + b[3] * exp(100000/c[3]);

    if (depth > boundaryX4) {
      // section = 5
      const double height = (a[4] - cosZenith*depth) * (c[4]/b[4]);
      return height;
    } else  {
      unsigned int section = 0;
      if (depth > boundaryX3)
        section = 3;
      else if (depth > boundaryX2)
        section = 2;
      else if (depth > boundaryX1)
        section = 1;

      const double height = -c[section] *
        log((cosZenith*depth - a[section]) / b[section]);
      return height;
    }
  }


  //****************************************************************
  //
  // Same for a vector of slant depths
  //
  //****************************************************************

  std::vector<double>
  SlantDepthVectorToHeightApproximation(const std::vector<double>& sldepth,
                                        const double cosZenith)
  {
    const unsigned int len = sldepth.size();
    vector<double> height(len);
    for (unsigned int i = 0; i < len; ++i)
      height[i] =
        UtilityFunctions::SlantDepthToHeightApproximation(sldepth[i], cosZenith);
    return height;
  }


  //---------------------------------------------------------------

  void
  ShowProgress(const unsigned int currEvent, const unsigned int nEvent)
  {
    int nProgWidth = 50;
    struct winsize winsize;

    if (ioctl(fileno(stdout), TIOCGWINSZ, &winsize) != -1)
      nProgWidth = (winsize.ws_col ? winsize.ws_col : 50);

    nProgWidth -= 8;

    if (!nEvent)
      return;

    if (currEvent) {
      for (int i = 0; i < nProgWidth+8; ++i)
        cout << "\b";
    }

    const double percent = double(currEvent) / nEvent;
    const int nBars = int(percent*nProgWidth);

    cout << " |";
    for (int i = 0; i < nBars-1; ++i)
      cout << '=';
    if (nBars > 0)
      cout << '>';
    for (int i = nBars; i < nProgWidth; ++i)
      cout << ' ';
    cout << "| " << setw(3) << int(percent*100) << '%' << flush;
  }


  //---------------------------------------------------

  double
  SigmaFromProb(const double prob)
  {
    // see http://mathworld.wolfram.com/ConfidenceInterval.html
    return TMath::ErfInverse(1 - prob) * sqrt(2.);
  }

} // end namespace UtilityFunctions
