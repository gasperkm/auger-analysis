
#include <CutFileParserV1.h>
#include <CutSpec.h>
#include <Selection.h>

// ROOT regexp stuff
#include <TPRegexp.h>
#include <TObjArray.h>
#include <TObjString.h>
#include <TString.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <ios>
#include <cstdlib> // for atoi

using namespace std;

TPRegexp* const CutFileParserV1::fgIsEmptyLine = new TPRegexp("^\\s*$");
TPRegexp* const CutFileParserV1::fgIsRestOfLineEmpty = new TPRegexp("\\G\\s*$");
// matches the format version id
TPRegexp* const CutFileParserV1::fgIsNewTypeRegexp = new TPRegexp("^(?i)\\s*adst\\s*cuts\\s*version\\s*:\\s*(\\d+)((?:\\.\\d+)?)\\s*$");
// matches cut names
TPRegexp* const CutFileParserV1::fgCutNameToken = new TPRegexp("^\\s*(!?)\\s*(\\w+)\\b");
// matches opening brace
TPRegexp* const CutFileParserV1::fgOpeningBrace = new TPRegexp("\\G\\s*\\{");
// matches closing brace
TPRegexp* const CutFileParserV1::fgClosingBrace = new TPRegexp("\\G\\s*\\}");
// matches list of numbers
TString* const  CutFileParserV1::fgFloatRegexp = new TString("[+-]?(?=\\d|\\.\\d)\\d*(?:\\.\\d*)?(?:[Ee][+-]?\\d+)?");
TPRegexp* const CutFileParserV1::fgNumbers = new TPRegexp(
  TString("\\G\\s*((?:") + *CutFileParserV1::fgFloatRegexp + "\\s+)*"
  + *CutFileParserV1::fgFloatRegexp + ")"
);
// matches option names
TPRegexp* const CutFileParserV1::fgOptionNameParams = new TPRegexp("\\G(?i)\\s*par(?:am)?(?:eter)?s?\\s*:");
TPRegexp* const CutFileParserV1::fgOptionNameNMinusOne = new TPRegexp("\\G(?i)\\s*nminusone(?:hist(?:ogram)?)?\\s*:");


CutFileParserV1::CutFileParserV1() :
  fVerbosity(0)
{
}


void CutFileParserV1::Parse(const string& cutFile, vector<Cut>& cutList, bool makeNMinusOne) {
  ifstream in;

  in.open(cutFile.c_str());
  if ( ! in.good() ) {
    string errMsg = " CutFileParserV1::Parse() - Error reading cut file "
      + cutFile
      + " \n  ********* no cuts will be applied!!! ********* ";
    throw std::runtime_error(errMsg);
  }

  // parser state:
  fState = eStart;
  fVersion.majorType = eStdCutFileV1; // just for consistency
  fLineNo = 0;
  fErrMsg << " CutFileParserV1::ParseCutFileV1() - Error parsing cut file '"
          << cutFile << "': ";
  fCuts = &cutList;
  fMakeNMinusOne = makeNMinusOne;

  while (!in.eof()) {
    string buffer;
    if (!in.good()) break;
    getline(in, buffer);
    StripComments(buffer);
    fLine = TString(buffer);
    fLineNo++;
    fLineOffset = 0;
    if (fVerbosity > 2)
      cout << "line: '" << buffer << "'" << endl;

    while (1) {
      if (fgIsRestOfLineEmpty->MatchB(fLine, "", fLineOffset))
        break;

      bool nextLine = false;
      switch (fState) {
        case eStart:
          if (fVerbosity > 2)
            cout << "Matching state eStart" << endl;
          nextLine = ParserStateStart();
          break;
        case eExpectCut:
          if (fVerbosity > 2)
            cout << "Matching state eExpectCut" << endl;
          nextLine = ParserStateExpectCut();
          break;
        case eNumbersOrBrace:
          if (fVerbosity > 2)
            cout << "Matching state eNumbersOrBrace" << endl;
          nextLine = ParserStateNumbersOrBrace();
          break;
        case eExpectOption:
          if (fVerbosity > 2)
            cout << "Matching state eExpectOption" << endl;
          nextLine = ParserStateExpectOption();
          break;
        case eBraceOrNewCut:
          if (fVerbosity > 2)
            cout << "Matching state eBraceOrNewCut" << endl;
          nextLine = ParserStateBraceOrNewCut();
          break;
        default:
          fErrMsg << "Unknown parser state -- shouldn't happen.";
          throw std::runtime_error(fErrMsg.str());
      }
      if (nextLine) {
        if (fVerbosity > 2)
          cout << "reading next line" << endl;
        break;
      }

    } // end while matching this line

  } // end for lines

  // if potentially looking at a bare boolean cut,
  // finalize it at the end of the file
  if (fState == eBraceOrNewCut)
    FinishCutParse();

  fCuts = NULL;
}


bool CutFileParserV1::ParserStateExpectCut() {
  TObjArray* matches = fgCutNameToken->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast() > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fCurrentCutName   = ((TObjString *)matches->At(2))->GetString();
    fCurrentIsAntiCut = ((TObjString *)matches->At(1))->GetString().Length() >= 1;
    fLineOffset      += ((TObjString *)matches->At(0))->GetString().Length();
    fState            = eNumbersOrBrace;
  }
  else {
    delete matches;
    ThrowError("Expecting new cut name.");
  }
  delete matches;

  if (fgIsRestOfLineEmpty->MatchB(fLine, "", fLineOffset)) {
    if (fVerbosity > 2)
      cout << "Rest of line is empty. Suspecting bare boolean cut: Switching to state eBraceOrNewCut." << endl;
    fState = eBraceOrNewCut;
    return true;
  }

  return false;
}


bool CutFileParserV1::ParserStateBraceOrNewCut() {
  TObjArray* matches = fgOpeningBrace->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    fState       = eExpectOption;
    delete matches;
    return false;
  }
  delete matches;
  matches = fgCutNameToken->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast() > 0) {
    if (fVerbosity > 2)
      cout << "Look-ahead match: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;

    // finish up the bare cut
    fCurrentCutParameters = vector<double>(0);
    FinishCutParse();

    // reparse this line as the start of a new cut
    fState = eExpectCut;
  }
  else {
    delete matches;
    ThrowError("Expecting new cut name.");
  }
  delete matches;
  return false;
}


bool CutFileParserV1::ParserStateNumbersOrBrace() {
  TObjArray* matches = fgOpeningBrace->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    fState       = eExpectOption;
    delete matches;
    return false;
  }
  delete matches;
  matches = fgNumbers->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 1) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    fCurrentCutParameters = SplitNumbers( ((TObjString *)matches->At(1))->GetString() );
    FinishCutParse();
    fState = eExpectCut;
    delete matches;
    return true;
  }
  else {
    delete matches;
    ThrowError("Expecting opening brace or parameter list.");
  }
  delete matches;
  return false;
}


bool CutFileParserV1::ParserStateExpectOption() {
  TObjArray* matches = fgOptionNameParams->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    fCurrentCutParameters = MatchNumbers();
    fState                = eExpectOption;
    delete matches;
    return false;
  }
  delete matches;
  matches = fgOptionNameNMinusOne->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    fNMinusOneParameters = MatchNumbers();
    fState               = eExpectOption;
    delete matches;
    return false;
  }
  delete matches;
  matches = fgClosingBrace->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    FinishCutParse();
    fState = eExpectCut;
    delete matches;
    return true;
  }
  else {
    delete matches;
    ThrowError("Expecting cut option name 'parameters' or 'nMinusOne' followed by a colon or a closing brace.");
  }
  delete matches;
  return true;
}


bool CutFileParserV1::ParserStateStart() {
  TObjArray* matches = fgIsNewTypeRegexp->MatchS(fLine);
  if (matches->GetLast() > 0) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    //const TString majorVersion = ((TObjString *)matches->At(1))->GetString();
    const TString minorVersion = ((TObjString *)matches->At(2))->GetString();
    fVersion.minorVersion = atoi(minorVersion.Data()+1);
    fState = eExpectCut;
    delete matches;
    return true;
  }
  else {
    delete matches;
    ThrowError("First non-empty line should be of the form 'adst cuts version: VERSION'.");
  }
  delete matches;
  return false;
}


vector<double> CutFileParserV1::MatchNumbers() {
  vector<double> numbers;
  TObjArray* matches = fgNumbers->MatchS(fLine, "", fLineOffset);
  if (matches->GetLast()+1 > 1) {
    if (fVerbosity > 2)
      cout << "Matched: '" << ((TObjString *)matches->At(0))->GetString().Data() << "'"<< endl;
    fLineOffset += ((TObjString *)matches->At(0))->GetString().Length();
    numbers = SplitNumbers( ((TObjString *)matches->At(1))->GetString() );
  }
  else {
    delete matches;
    ThrowError("Expecting list of numbers.");
  }
  delete matches;
  return numbers;
}


void CutFileParserV1::ThrowError(const string& msg) {
  fErrMsg << msg << " (at line " << fLineNo << ")";
  throw std::runtime_error(fErrMsg.str());
}

void CutFileParserV1::FinishCutParse() {
  string cutName = string(fCurrentCutName.Data());
  //// check for duplicate cuts [not used!]
  // bool haveCut = false;
  // bool existingCutIsAntiCut = false;
  // for ( unsigned int i = 0; i < fCuts->size(); i++ ) {
    // if ( (*fCuts)[i].GetName() == cutName ) {
      // haveCut = true;
      // existingCutIsAntiCut = (*fCuts)[i].IsAntiCut();
      // break;
    // }
  // }

  // Verify cut
  CutSpec* cutSpecVerification = Selection::GetCutFromRegistry(cutName);
  if (cutSpecVerification == NULL) {
    ostringstream error;
    error << "Invalid cut '" << cutName << "'. A cut of that name does not exist.";
    ThrowError(error.str());
  }
  else if ( cutSpecVerification->GetNParams() > -1 &&
            cutSpecVerification->GetNParams() != (int)fCurrentCutParameters.size() )
  {
    // bad no. parameters
    ostringstream error;
    int nparams = cutSpecVerification->GetNParams();

    ostringstream tmp;
    tmp << nparams;
    error << "Invalid number of parameters to cut '" << cutName << "': The cut takes "
          << (nparams == 0 ? "no" : tmp.str() )
          << " parameter" << (nparams == 1 ? "" : "s") << " but you supplied " << fCurrentCutParameters.size();
    ThrowError(error.str());
  }

  // Add cut
  unsigned int nBins = 100;
  double xMin = 0.;
  double xMax = 0.;
  if (fMakeNMinusOne) {
    if (fNMinusOneParameters.size() >= 1)
      nBins = (unsigned int)fNMinusOneParameters[0];
    if (fNMinusOneParameters.size() >= 2)
      xMin  = fNMinusOneParameters[1];
    if (fNMinusOneParameters.size() >= 3)
      xMax  = fNMinusOneParameters[2];
  }

  char preFix[] = "\t   --> ";
  Cut theCut(cutName, fCurrentCutParameters, fCurrentIsAntiCut, fMakeNMinusOne, nBins, xMin, xMax);
  if ( fVerbosity > -1 )
    cout << preFix << theCut.Info() << endl;
  fCuts->push_back(theCut);

  fCurrentCutName = TString("");
  fCurrentCutParameters.clear();
  fNMinusOneParameters.clear();
  fCurrentIsAntiCut = false;
}

vector<double> CutFileParserV1::SplitNumbers(TString str) {
  vector<double> numbers;
  TObjArray* tokens = str.Tokenize(" \t\n");
  const unsigned int nTokens = tokens->GetLast()+1;
  for (unsigned int i = 0; i < nTokens; i++) {
    const double number = atof( ((TObjString *)tokens->At(i))->GetString().Data() );
    numbers.push_back( number );
  }
  delete tokens;
  return numbers;
}

void CutFileParserV1::StripComments(string& line) {
  TString buffer(line);
  TPRegexp comments("#.*$");
  comments.Substitute(buffer, "");
  line = string(buffer.Data());
}

