
#include <Cut.h>

#include <TROOT.h>

#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <vector>
#include <iostream>
using namespace std;


Cut::Cut(const std::string & name, const vector<double>& parameters, bool isAntiCut,
         bool storeHisto, int nBins, double xMin, double xMax) :
  fParameters(parameters),
  fName(name),
  fWarnedAboutBooleanCut(false),
  fIsNMinusOne(false),
  fIsAntiCut(isAntiCut),
  fNEvents(0.)
{
  if (storeHisto) {
    // make sure the n-1 histograms have unique names even if
    // there are multiple cuts with the same name.
    string histoName = name;
    TObject* obj = gROOT->FindObject(histoName.c_str());
    int suffix = 1;
    char buffer[1024] = "";
    while (obj != NULL) {
      sprintf(buffer, "_%i", suffix++);
      obj = gROOT->FindObject( (histoName+string(buffer)).c_str() );
    }
    if (buffer[0] != '\0')
      histoName = histoName + string(buffer);

    fHisto = new TH1F(histoName.c_str(),Info().c_str(),nBins,xMin,xMax);
    fHisto->Sumw2();
  }
  else
    fHisto = NULL;
}


Cut::Cut(const std::string & name, double value, double slope, bool isAntiCut,
         bool storeHisto, int nBins, double xMin, double xMax) :
  fName(name),
  fWarnedAboutBooleanCut(false),
  fIsNMinusOne(false),
  fIsAntiCut(isAntiCut),
  fNEvents(0.)
{
  fParameters.push_back(value);
  fParameters.push_back(slope);
  if (storeHisto) {
    // make sure the n-1 histograms have unique names even if
    // there are multiple cuts with the same name.
    string histoName = name;
    TObject* obj = gROOT->FindObject(histoName.c_str());
    int suffix = 1;
    char buffer[1024] = "";
    while (obj != NULL) {
      sprintf(buffer, "_%i", suffix++);
      obj = gROOT->FindObject( (histoName+string(buffer)).c_str() );
    }
    if (buffer[0] != '\0')
      histoName = histoName + string(buffer);

    fHisto = new TH1F(histoName.c_str(),Info().c_str(),nBins,xMin,xMax);
    fHisto->Sumw2();
  }
  else
    fHisto = NULL;
}

Cut::~Cut() {
  //delete fHisto;
}

Cut::Cut(const Cut& p) {
  if (&p != this) {
    fParameters = p.fParameters;
    fCurrValues = p.fCurrValues;
    if (p.fHisto)
      fHisto = new TH1F(*p.fHisto);
    else
      fHisto = NULL;
    fName        = p.fName;
    fIsNMinusOne = p.fIsNMinusOne;
    fIsAntiCut   = p.fIsAntiCut;
    fNEvents     = p.fNEvents;
    fWarnedAboutBooleanCut = p.fWarnedAboutBooleanCut;
  }
}

const Cut & Cut::operator = ( const Cut & p) {
  if (&p != this) {
    fParameters = p.fParameters;
    fCurrValues = p.fCurrValues;
    delete fHisto;
    if (p.fHisto)
      fHisto = new TH1F(*p.fHisto);
    else
      fHisto = NULL;
    fName        = p.fName;
    fIsNMinusOne = p.fIsNMinusOne;
    fIsAntiCut   = p.fIsAntiCut;
    fNEvents     = p.fNEvents;
    fWarnedAboutBooleanCut = p.fWarnedAboutBooleanCut;
  }
  return *this;
}

void Cut::SetCurrValue(double val) {
  if (fCurrValues.empty())
    fCurrValues.resize(1);
  fCurrValues[0] = val;
}

std::string Cut::Info() {
  ostringstream info;
  if (fParameters.empty()) {
    info << setw(25) << fName << " (boolean cut)";
  }
  else if (fParameters.size() == 1) {
    info << setw(25) << fName << " " << setw(6) << fParameters[0];
  }
  else {
    info << setw(25) << fName << "(" << setw(6) << fParameters[0];
    for (unsigned int i = 1; i < fParameters.size(); i++)
      info << ", " << fParameters[i];
    info << ")";
  }
  if ( fIsAntiCut )
    info << " (anti-cut) ";
  return info.str();
}

void Cut::IsBooleanCut() {
  if (fWarnedAboutBooleanCut || GetCutParameters().empty())
    return;

  fWarnedAboutBooleanCut = true;
  cerr << "WARNING: (about cut " << GetName() << ")\n"
       << "         You configured the cut " << GetName() <<"\n"
       << "         with " << GetCutParameters().size() << " parameter(s). However,\n"
       << "         " << GetName() << " is a boolean cut. That means it does not take\n"
       << "         any parameters. Check your cut file. If you are using old cut\n"
       << "         files, you may have to convert them to cut file format 1.0 or newer." << endl;
}

