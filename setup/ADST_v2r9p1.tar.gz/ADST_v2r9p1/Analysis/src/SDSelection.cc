#include <SDSelection.h>

#include <FdRecLevel.h>
#include <RecEvent.h>
#include <DetectorGeometry.h>

#include <vector>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cstdlib>
using namespace std;

// Associate all cut names with their functions
const CutSpec SDSelection::fgSDCutSpecs[] = {
  // ATTENTION: keep this in sync with allSD.cuts

  CutSpec("T4Trigger",                   T4Cut),
  CutSpec("T5Trigger",                   T5Cut),
  CutSpec("minZenithSD",                 minZenithCut, 1),
  CutSpec("maxZenithSD",                 maxZenithCut, 1),
  CutSpec("minRecLevel",                 minRecLevelCut),
  CutSpec("minCandidateStations",        minStationsCut),
  CutSpec("maxCandidateStations",        maxStationsCut),
  CutSpec("badPeriodsRejection",         badPeriodsCut),
  CutSpec("badPeriodsRejectionFromFile", badPeriodsCutFromFile),
  CutSpec("selectSaturation",            saturationCut),
  CutSpec("minLgEnergySD",               minLgEnergyCut, 1),
  CutSpec("maxLgEnergySD",               maxLgEnergyCut, 1),
  CutSpec("Saturation",                  saturationCut),
  CutSpec("timeInterval",                timeIntervalCut, 2),
  CutSpec("heraldSelection",             heraldCut),
  CutSpec("fixBeta",                     betaCut),
  CutSpec("sdId",                        sdIdCut),
  CutSpec("augerId",                     augerIdCut),
  CutSpec("temperature",                 temperature, 2),
  CutSpec("idsFromFile",                 idsFromFile, 1),
  CutSpec("lightning",                   lightning),
  CutSpec("maxRelativeShowerSizeError",  maxRelativeShowerSizeError, 1),
  CutSpec("badSilentStations",           badSilentStations, 2),
  CutSpec("hasStation",                  hasStation, 1),
  // this must be always the last cutspec. Think \0
  CutSpec("END"),
};

bool SDSelection::fgCutSpecsInitialized = false;
set<unsigned long int> SDSelection::fSdIds;
bool SDSelection::fInitiatedIdsFromFile = false;
vector<unsigned int> SDSelection::fGPSStart;
vector<unsigned int> SDSelection::fGPSStop;

SDSelection::SDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const vector<string>& cutFiles) :
  Selection(geom, event, verbosity, nMinusOne, cutFiles)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSDCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("SD"));
  ReadCuts(cutFiles);
  InitializeCutFunctions();
}

SDSelection::SDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const string& cutFile) :
  Selection(geom, event, verbosity, nMinusOne, cutFile)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgSDCutSpecs);
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("SD"));
  ReadCuts(cutFile);
  InitializeCutFunctions();
}

bool SDSelection::minZenithCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  if (!currSDEvent.HasAxis())
    return false;
  const SdRecShower& theShower = currSDEvent.GetSdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();
  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  return cut.IsAntiCut() ? (zenith < cutVal):(zenith > cutVal);
}

bool SDSelection::maxZenithCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  if (!currSDEvent.HasAxis())
    return false;
  const SdRecShower& theShower = currSDEvent.GetSdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();
  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  return cut.IsAntiCut() ? (zenith > cutVal):(zenith < cutVal);
}

bool SDSelection::T4Cut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int t4Flag = currSDEvent.GetT4Trigger();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(t4Flag);

  if (cut.IsAntiCut())
    cerr << " SDSelection::T4Cut()  anti-cut not defined and ignored " << endl;
  if (cutVal == 0) // no T4
    return (t4Flag == 0);
  if (cutVal == 1) // FD triggered
    return (t4Flag & 1);
  if (cutVal == 2) // SD triggered
    return (t4Flag & 2 || t4Flag & 4);
  else /* if (cutVal == 3) */ // both FD && SD triggered
    return (t4Flag & 1 && (t4Flag & 2 || t4Flag & 4));
}

bool SDSelection::T5Cut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int t5Flag = currSDEvent.GetT5Trigger();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(t5Flag);

  if (cut.IsAntiCut())
    cerr << " SDSelection::T5Cut()  anti-cut not defined and ignored " << endl;
  if (cutVal == 0)
    return (t5Flag == 0);
  if (cutVal == 1)
    return (t5Flag & 2);
  else
    return ( t5Flag == 3 );
}

bool SDSelection::betaCut(Cut& cut) {
  cut.IsBooleanCut();
  const bool floatBeta = CurrEvent().GetSDEvent().GetSdRecShower().GetLDF().GetBetaError() > 0;
  return ( cut.IsAntiCut() ? (floatBeta) : (!floatBeta) );
}

bool SDSelection::heraldCut(Cut& cut) {
  cut.IsBooleanCut();

  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const bool estAndRec = (currSDEvent.GetRecLevel()== eHasTriggeredStations);
  const int t5 = currSDEvent.GetT5Trigger();

  const bool heraldGood= (!estAndRec) && (t5 > 1);
  return  ( cut.IsAntiCut() ? !heraldGood : heraldGood );
}

bool SDSelection::minStationsCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int nCand = currSDEvent.GetNumberOfCandidates();
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(nCand);
  return ( cut.IsAntiCut() ? nCand<cutVal : nCand>=cutVal);
}

bool SDSelection::maxStationsCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int nCand = currSDEvent.GetNumberOfCandidates();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(nCand);
  return ( cut.IsAntiCut() ? nCand > cutVal : nCand <= cutVal );
}

bool SDSelection::minRecLevelCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  const int recLevel = currSDEvent.GetRecLevel();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(recLevel);
  return ( cut.IsAntiCut() ? recLevel < cutVal : recLevel>=cutVal );
}

bool SDSelection::minLgEnergyCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();

  if (currSDEvent.GetRecLevel() < eHasLDF)
    return false;

  const double lgE = log10(currSDEvent.GetSdRecShower().GetEnergy());
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(lgE);
  return ( cut.IsAntiCut() ? lgE < cutVal : lgE >= cutVal );
}

bool SDSelection::maxLgEnergyCut(Cut& cut) {
  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();

  if (currSDEvent.GetRecLevel() < eHasLDF)
    return false;

  const double lgE = log10(currSDEvent.GetSdRecShower().GetEnergy());
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(lgE);
  return ( cut.IsAntiCut() ? lgE > cutVal : lgE <= cutVal );
}

bool SDSelection::badPeriodsCut(Cut& cut) {
  cut.IsBooleanCut();
  const bool badPeriod = (CurrEvent().GetSDEvent().GetBadPeriodId()>0);
  return ( cut.IsAntiCut() ? badPeriod : !badPeriod );
}

bool SDSelection::badPeriodsCutFromFile(Cut& cut) {
  cut.IsBooleanCut();

  // do only once
  if (fGPSStart.empty()) {
    string badFileName;
    if ( GetUserConfiguration().find("SDBadPeriodsFile") != GetUserConfiguration().end() ) {
      badFileName = GetUserConfiguration().find("SDBadPeriodsFile")->second;
    } else {
      cout << "Please specify a Bad Periods file in analysis.config" << endl;
      exit(1);
    }

    ifstream badFile(badFileName.c_str(), ios::in);
    if (badFile.is_open()){
      while (badFile.good()){
        int dummy;
        unsigned int gpsSecondStart;
        unsigned int gpsSecondStop;
        badFile >> dummy >> gpsSecondStart >> dummy >>
	  dummy >> dummy >> dummy >> dummy >> dummy
		>> dummy >> gpsSecondStop >> dummy
		>> dummy >> dummy >> dummy >> dummy >> dummy;

        if (gpsSecondStart > gpsSecondStop){
          cout << "Please check your bad periods file: "
	    " gps start > gps stop " << endl;
          exit(1);
        }
        fGPSStart.push_back(gpsSecondStart);
        fGPSStop.push_back(gpsSecondStop);
      }
    }
    else
    {
      cout << "Could not open bad periods file: "
	   << badFileName.c_str() << endl;
      exit(1);
    }
  }

  const unsigned int eventGPS = CurrEvent().GetSDEvent().GetGPSSecond();
  bool badPeriod = false;

  const unsigned int low = int(lower_bound(fGPSStop.begin(), fGPSStop.end(),
					   eventGPS)
                               - fGPSStop.begin());
  if (eventGPS > fGPSStart[low])
    badPeriod = true;

  return ( cut.IsAntiCut() ? badPeriod : !badPeriod );
}


bool SDSelection::saturationCut(Cut& cut) {
  cut.IsBooleanCut();
  const bool saturated=(CurrEvent().GetSDEvent().IsSaturated());
  return ( cut.IsAntiCut() ? !saturated : saturated );
}

bool SDSelection::timeIntervalCut(Cut& cut) {
  const int time = CurrEvent().GetYYMMDD();
  const double cutVal1 = cut.GetCutValue();
  const double cutVal2 = cut.GetCutSlope();
  const bool inside = ( (cutVal1< time) && (time < cutVal2) );
  cut.SetCurrValue(time);

  return ( cut.IsAntiCut() ? !inside : inside );
}

bool SDSelection::sdIdCut(Cut& cut) {
  const int& sdId = CurrEvent().GetSDEvent().GetEventId();

  return ( cut.IsAntiCut() ?
           !(cut.GetCutValue() == sdId) :
           (cut.GetCutValue() == sdId) );
}

bool SDSelection::idsFromFile(Cut& cut){

  // do only once
  if (!fInitiatedIdsFromFile) {
    fInitiatedIdsFromFile = true;
    if ( GetUserConfiguration().find("SDIdsFile") != GetUserConfiguration().end() ) {
      const string& sdIdsFileName = GetUserConfiguration().find("SDIdsFile")->second;
      ifstream idFile(sdIdsFileName.c_str(), ios::in);
      if (idFile.is_open()) {
        while (true) {
          unsigned long int id = 0;
          idFile >> id;
          if (idFile.eof()) break;
          fSdIds.insert(id);
        }
      }
      else
      {
        cout << "Could not open SDIdsFile: " << sdIdsFileName << endl;
        exit(1);
      }
    }

    if (fSdIds.empty())
      cout << "Warning: No events ids found in SDIdsFile" << endl;
  }

  const bool isAugerId = cut.GetCutValue();
  const unsigned long id = isAugerId ? CurrEvent().GetAugerIdNumber() : CurrEvent().GetSDEvent().GetEventId();
  set<unsigned long int>::iterator it = fSdIds.find(id);
  const bool found = it != fSdIds.end();

  #ifndef DISABLE_IDSFROMFILE_OPTIMIZATION
  if (found)
    fSdIds.erase(it);
  #endif

  return (cut.IsAntiCut()? !found : found);
}


bool SDSelection::augerIdCut(Cut& cut) {
  const string& augerId = CurrEvent().GetAugerId();
  istringstream iss(augerId);
  unsigned long int numericalAugerId = 0;
  iss >> numericalAugerId;
  return ( cut.IsAntiCut() ?
           !(cut.GetCutValue() == numericalAugerId) :
           (cut.GetCutValue() == numericalAugerId) );
}



bool SDSelection::temperature(Cut& cut) {
  const double kelvinToCelsiusCt=  -273.15;

  const double temperature = CurrEvent().GetDetector().GetTemperature()
    +kelvinToCelsiusCt;
  const double cutVal1 = cut.GetCutValue();
  const double cutVal2  = cut.GetCutSlope();
  const bool inside = ( (cutVal1< temperature) && (temperature < cutVal2) );
  cut.SetCurrValue(temperature);
  return ( cut.IsAntiCut() ? !inside : inside );
}


bool SDSelection::badSilentStations(Cut& cut) {

  if (!CurrEvent().GetSDEvent().HasAxis())
    return false;
  const double allowedDistance = cut.GetCutValue();
  const double maxLDFValue  = cut.GetCutSlope();


  const Detector &det= CurrEvent().GetDetector();
  const vector<SdBadStation>& badStations =
    CurrEvent().GetSDEvent().GetBadStationVector();
  TBits array = det.GetActiveStations();
  const DetectorGeometry& detGeom = *GetDetectorGeometry();
  const SdRecShower& sdRecShower = CurrEvent().GetSDEvent().GetSdRecShower();

  const TVector3 & showerCore = sdRecShower.GetCoreSiteCS();
  const TVector3 & showerAxis = sdRecShower.GetAxisSiteCS();

  for (size_t i=0;i<badStations.size();++i)
    array[badStations[i].GetId()] = false;

  bool returnValue = false;
  for (DetectorGeometry::StationPosMapConstIterator iStation =
         detGeom.GetStationsBegin();
       iStation != detGeom.GetStationsEnd();
       ++iStation) {
    if (array.TestBitNumber(iStation->first)) {
      const int id= iStation->first;
      if ( CurrEvent().GetSDEvent().HasStation(id))
	continue;
      const double distance=detGeom.GetStationAxisDistance(id,
							   showerAxis,
							   showerCore);

      const double ldf = sdRecShower.GetLDF().Evaluate(distance, eNKG);

      if (distance < allowedDistance &&
	  ldf > maxLDFValue){
	returnValue = true;
	cut.SetCurrValue(ldf);
	break;
      }
    }
  }



  return ( cut.IsAntiCut() ? !returnValue : returnValue );
}




bool SDSelection::lightning(Cut& cut) {
  cut.IsBooleanCut();
  const bool lightning = (CurrEvent().GetSDEvent().IsLightning());
  return ( cut.IsAntiCut() ? !lightning : lightning );


}

bool SDSelection::maxRelativeShowerSizeError(Cut& cut) {
  const SdRecShower& curr = CurrEvent().GetSDEvent().GetSdRecShower();
  const double relErr = curr.GetShowerSizeError()/curr.GetShowerSize();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(relErr);
  return (cut.IsAntiCut() ? relErr > cutVal : relErr <= cutVal);
}


bool SDSelection::hasStation(Cut& cut) {

  const bool hasIt = (CurrEvent().GetSDEvent().HasStation(cut.GetCutValue()));
  return (cut.IsAntiCut() ? !hasIt : hasIt);
}
