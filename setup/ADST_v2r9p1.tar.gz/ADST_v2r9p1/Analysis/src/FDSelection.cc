
#include <FDSelection.h>
#include <AnalysisConsts.h>
#include <UtilityFunctions.h>
#include <T2TriggerProb.h>
#include <GetTriggerProbRealStations.h>

#include <FdRecLevel.h>
#include <StationStatus.h>
#include <RecEvent.h>
#include <DetectorGeometry.h>

#include <TH1F.h>

#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <stdexcept> 
using namespace std;


// Associate all cut names with their functions
const CutSpec FDSelection::fgFDCutSpecs[] = {
  // ATTENTION: keep this in sync with allFD.cuts

  // profile related cuts
  CutSpec("xMaxInFOV",              IsInFOV),
  CutSpec("xMaxError",              xMaxErrorCut, 1),
  CutSpec("energyError",            energyErrorCut, 1),
  CutSpec("energyTotError",         energyTotalErrorCut, 1),
  CutSpec("profileChi2",            profileFitChi2Cut, 1),
  CutSpec("profileProb",            profileFitProbCut, 1),
  CutSpec("profileChi2Sigma",       profileFitChi2SigmaCut, 1),
  CutSpec("maxCFrac",               cFracCut, 1),
  CutSpec("maxDirCFrac",            dirCFracCut, 1),
  CutSpec("minTotalLight",          minTotalLightCut, 1),
  CutSpec("minViewAngle",           minViewAngleCut, 1),
  CutSpec("depthTrackLength",       depthTrackLengthCut, 1),
  CutSpec("maxDepthHole",           maxDepthHoleCut, 1),
  CutSpec("deltaProfileChi2",       deltaProfileChi2Cut, 1),
  CutSpec("deltaProfileChi2Spot",   deltaProfileChi2SpotCut, 1),
  CutSpec("profileChi2Ratio",       profileChi2RatioCut, 1),
  CutSpec("depthVelocity",          depthVelocityCut, 1),
  CutSpec("minXFOV",                minXFOVCut, 1),
  CutSpec("maxXFOV",                maxXFOVCut, 1),
  CutSpec("minShowerAge",           minShowerAgeCut, 1),
  CutSpec("maxShowerAge",           maxShowerAgeCut, 1),
  CutSpec("minRelativeDepth",       minRelativeDepthCut, 1),
  CutSpec("maxRelativeDepth",       maxRelativeDepthCut, 1),
  CutSpec("minX0",                  minX0Cut, 1),
  CutSpec("maxX0",                  maxX0Cut, 1),
  CutSpec("xRise",                  xRiseCut, 2),
  CutSpec("XmaxErrorLessThenXmax",  XmaxErrorLessThenXmaxCut),

  // geometry related cuts
  CutSpec("nAxisPixels",            axisPixelCut, 1),
  CutSpec("nSDPPixels",             sdpPixelCut, 1),
  CutSpec("nTriggeredPixels",       trigPixelCut, 1),
  CutSpec("hybridDeltaT",           hybridDeltaTCut, 1),
  CutSpec("hybridTankTrigger",      hybridTankTriggerCut),
  CutSpec("angleTrackLength",       angleTrackLengthCut, 1),
  CutSpec("timeTrackLength",        timeTrackLengthCut, 1),
  CutSpec("timeFitChi2",            timeFitChi2Cut, 1),
  CutSpec("axisFitChi2",            axisFitChi2Cut, 1),
  CutSpec("maxCoreEyeDistance",     maxCoreEyeDistanceCut, 1),
  CutSpec("coreUncertaintyCut",     coreUncertaintyCut,1),
  CutSpec("AAARGWG4",               AAARGWG4, 1),

  // range cuts
  CutSpec("maxZenithFD",            maxZenithCut, 1),
  CutSpec("minZenithFD",            minZenithCut, 1),
  CutSpec("minCosZFDE",             minCosZFDECut, 2),
  CutSpec("minLgECalFD",            minLgECalCut, 1),
  CutSpec("minLgEnergyFD",          minLgEnergyCut, 1),
  CutSpec("maxLgEnergyFD",          maxLgEnergyCut, 1),
  CutSpec("maxCoreTankDist",        coreTankDistCut, 1),
  CutSpec("maxCoreTankDistE",       coreTankDistECut, 2),

  // fiducial cuts
  CutSpec("HDSpectrumDistance",     HDSpectrumDistanceCut, 1),
  CutSpec("HDSpectrumDistance2012", HDSpectrumDistance2012Cut, 1),
  CutSpec("brassHybridProb",        brassHybridProb, 3),
  CutSpec("ICRC2005PhotonDistance", ICRC2005PhotonDistanceCut, 0),
  CutSpec("GAP2007049FidFOV",       GAP2007049FiducialFOV, 1),
  CutSpec("GAP2007005FidFOV",       GAP2007005FiducialFOV, 1),
  CutSpec("GAP2007005FidDist",      GAP2007005FiducialDistance, 0),
  CutSpec("GAP2007005FidZen",       GAP2007005FiducialZenith, 0),
  CutSpec("FidFOVICRC07",           FiducialFOVICRC07, 1),
  CutSpec("FidFOVPRL10",            FiducialFOVPRL10),
  CutSpec("FidFOVICRC11",           FiducialFOVICRC11, 2),
  CutSpec("xMaxObsInExpectedFOV",   xMaxObsInExpectedFOV, 2),
  CutSpec("ICRC2007GoodCalibration",ICRC2007CalibPeriod, 0),
  CutSpec("badFDPeriodRejection",   badFDPeriodRejection, 0),
  CutSpec("RejectCDASVetoPeriods",  RejectCDASVetoPeriods, 2),
  CutSpec("RejectFDASVetoPeriods",  RejectFDASVetoPeriods, 2),
  CutSpec("RejectT3VetoPeriods",    RejectT3VetoPeriods, 2),
  CutSpec("minPBrass",              minPBrass, 1),
  CutSpec("maxPBrassProtonIronDiff", pbrassMaxProtonIronDifference, 1),

  // atmosphere
  CutSpec("LidarCloudRemoval",      LidarCloudRemovalCut, 1),
  CutSpec("MinCloudDepthDistance",  MinCloudDepthDistanceCut, 2),
  CutSpec("MaxCloudThickness",      MaxCloudThicknessCut, 1),
  CutSpec("maxVAOD",                maxVAODCut, 1),
  CutSpec("hasMieDatabase",         mieDatabaseCut, 0),
  CutSpec("hasGDASDatabase",        GDASDatabaseCut, 0),
  CutSpec("hasLidarDatabase",       lidarDatabaseCut, 0),
  CutSpec("maxCloudFractionStrict", MaxCloudFractionStrictCut,1),
  CutSpec("maxCloudFractionRelaxed", MaxCloudFractionRelaxedCut,1),
  CutSpec("maxCloudFractionWithLidarStrict", MaxCloudFractionWithLidarStrictCut,1),
  CutSpec("maxCloudFractionWithLidarRelaxed", MaxCloudFractionWithLidarRelaxedCut,1),

  // detector related
  CutSpec("eyeCut",                 eyeCut, 1),
  CutSpec("badPixels",              badPixelCut, 1),
  CutSpec("mismatchedPixels",       mismatchedPixelCut, 0),
  CutSpec("skipSaturated",          saturationCut, 0),
  CutSpec("allTelescopesHaveCorrectorRing", allTelescopesHaveCorrectorRingCut, 0),
  CutSpec("heatOrientationUp",      heatOrientationUpCut, 0),
  CutSpec("potentialSDT5",          potentialSDT5,1),
  CutSpec("minimumAverageADCVariance",  minimumAverageADCVarianceCut, 1),
  CutSpec("selectTelescope",        selectTelescopeCut, 3),
  CutSpec("noBadPixelsInPulse",     noBadPixelsInPulseCut),

  // misc cuts
  CutSpec("minPrimCFrac",           primCFracCut, 1),
  CutSpec("minDirPrimCFrac",        dirPrimCFracCut, 1),
  CutSpec("numberOfMirrors",        numberOfMirrorsCut, 1),
  CutSpec("T3Class",                t3Cut, 1),
  CutSpec("T3TimeAtGround",         t3TimeAtGroundCut, 0),
  CutSpec("CDASFDTrigger",          CDASFDTriggerCut, 0),

  // deprecated: do NOT list in allFD.cuts
  CutSpec("angleToShower",          minViewAngleCut, 1),
  CutSpec("xiMaxError",             xiMaxErrorCut, 1),

  // this must be always the last cutspec. Think \0
  CutSpec("END"),
};

bool FDSelection::fgCutSpecsInitialized = false;

FDSelection::FDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const string& cutFile) :
  Selection(geom,event,verbosity,nMinusOne,cutFile)
{
  if (!fgCutSpecsInitialized) {
    Selection::AddToCutRegistry( fgFDCutSpecs );
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("FD"));
  ReadCuts(cutFile);
  InitializeCutFunctions();
}


FDSelection::FDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const vector<string>& cutFiles) :
  Selection(geom,event,verbosity,nMinusOne,cutFiles)
{
  if (!fgCutSpecsInitialized) {
    Selection::AddToCutRegistry( fgFDCutSpecs );
    fgCutSpecsInitialized = true;
  }

  SetSelectionName(string("FD"));
  ReadCuts(cutFiles);
  InitializeCutFunctions();
}

bool FDSelection::brassHybridProb(Cut& cut) {
  vector<double> cutValues(3);
  // we need energy reconstruction
  if (CurrFDEvent().GetRecLevel() < eHasEnergy) {
    cut.SetCurrValues(cutValues);
    return false;
  }

  const double pProbLimit = cut.GetCutParameters()[0];
  const double feProbLimit = cut.GetCutParameters()[1];
  const double probDiffLimit = cut.GetCutParameters()[2];

  const DetectorGeometry* detGeo = GetDetectorGeometry();
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const TBits& activeStations = CurrEvent().GetDetector().GetActiveStations();

  // sanity check
  if (theShower.GetEnergy() < 10. || theShower.GetEnergy() > 1e90) {
    cut.SetCurrValues(cutValues);
    return false;
  }

  const T2TriggerProb t2triggerprob(&detGeo);

  cutValues[0] = t2triggerprob.GetBrassProb(theShower, activeStations, kProtonID);
  cutValues[1] = t2triggerprob.GetBrassProb(theShower, activeStations, kIronID);
  cutValues[2] = fabs(cutValues[0] - cutValues[1]);
  cut.SetCurrValues(cutValues);

  bool result = cutValues[0] < pProbLimit || cutValues[1] < feProbLimit ||
    cutValues[2] > probDiffLimit;

  return cut.IsAntiCut() ? result : !result;
}

bool FDSelection::profileFitChi2Cut(Cut& cut) {
  if (CurrFDEvent().GetRecLevel() < eHasGHParameters)
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double chi2 = theShower.GetGHChi2();
  const double ndof = theShower.GetGHNdf();
  const double redChi2 = chi2/ndof;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(redChi2, 50.));
  if (cut.IsAntiCut())
    return redChi2 > cutVal;
  else
    return redChi2 < cutVal;
}

bool FDSelection::profileFitProbCut(Cut& cut) {
  if (CurrFDEvent().GetRecLevel() < eHasGHParameters)
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double chi2 = theShower.GetGHChi2();
  const int    ndof = theShower.GetGHNdf();
  const double chi2Prob = TMath::Prob(chi2,ndof);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(chi2Prob);
  if (cut.IsAntiCut())
    return chi2Prob<cutVal;
  else
    return chi2Prob>cutVal;
}

bool FDSelection::profileFitChi2SigmaCut(Cut& cut) {
  if (CurrFDEvent().GetRecLevel() < eHasGHParameters)
    return cut.IsAntiCut();

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double chi2 = theShower.GetGHChi2();
  const int    ndof = theShower.GetGHNdf();
  const double z = (chi2-ndof)/sqrt(2*ndof);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(z);
  const bool accept = z < cutVal;
  return cut.IsAntiCut() ? !accept : accept;
}

bool FDSelection::timeFitChi2Cut(Cut& cut) {
  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const double chi2 = theGeometry.GetTimeFitChi2();
  const double ndof = theGeometry.GetTimeFitNdof();

  if (ndof <= 0.)
    return false;

  const double redChi2 = chi2/ndof;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(redChi2, 50.));
  if (cut.IsAntiCut())
    return redChi2>cutVal;
  else
    return redChi2<cutVal;
}

bool FDSelection::axisFitChi2Cut(Cut& cut) {
  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const double chi2 = theGeometry.GetAxisFitChi2();
  const double ndof = theGeometry.GetAxisFitNdof();

  if (ndof <= 0.)
    return false;

  const double redChi2 = chi2/ndof;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(redChi2, 50.));
  if (cut.IsAntiCut())
    return redChi2>cutVal;
  else
    return redChi2<cutVal;
}

bool FDSelection::maxDepthHoleCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasLongitudinalProfile )
    return false;
  const vector<double>& depth = CurrFDEvent().GetFdRecShower().GetDepth();
  double maxDepth=0.;
  for ( unsigned int i=0;i<depth.size()-1;i++) {
    double dDepth=depth[i+1]-depth[i];
    if ( dDepth > maxDepth )
      maxDepth = dDepth;
  }

  // convert to percent
  maxDepth=maxDepth/(depth[depth.size()-1]-depth[0])*100.;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(maxDepth);

  if ( cut.IsAntiCut() )
    return (maxDepth>cutVal);
  else
    return (maxDepth<cutVal);
}

bool FDSelection::xMaxErrorCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMaxErr    = theShower.GetXmaxError();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(xMaxErr,200.));

  if ( cut.IsAntiCut() )
    return (xMaxErr>cutVal);
  else
    return (xMaxErr<cutVal);


}

bool FDSelection::xiMaxErrorCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMaxErr    = theShower.GetZXmax();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(xMaxErr,200.));

  if ( cut.IsAntiCut() )
    return (xMaxErr>cutVal);
  else
    return (xMaxErr<cutVal);


}

bool FDSelection::energyTotalErrorCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double energy     = theShower.GetEnergy();
  const double energyErr  = theShower.GetEnergyError();
  const double relErr     = energyErr/energy;
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(fmin(relErr,1.));

  if ( cut.IsAntiCut() )
    return (relErr>cutVal);
  else
    return (relErr<cutVal);


}

bool FDSelection::energyErrorCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double energy       = theShower.GetEnergy();
  const double energyTotErr = theShower.GetEnergyError();
  const double energyAtmErr = theShower.GetEnergyAtmError();

  if ( energyTotErr < energyAtmErr ) {
    cerr << " FDSelection::energyErrorCut() - this should never happen:"
         << " energyTotErr < energyAtmErr!!! "  << energyTotErr
         << " " << energyAtmErr << endl;
    return false;
  }

  const double energyErr = sqrt(energyTotErr*energyTotErr-energyAtmErr*energyAtmErr);
  const double relErr     = energyErr/energy;
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(fmin(relErr,1.));

  if ( cut.IsAntiCut() )
    return (relErr>cutVal);
  else
    return (relErr<cutVal);


}

bool FDSelection::IsInFOV(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax    = theShower.GetXmax();
  const double dX1 = fmin(
                          xMax - theShower.GetXTrackMin(),
                          xMax - theShower.GetXFOVMin()
                           );
  const double dX2 = fmin(
                          theShower.GetXTrackMax() - xMax,
                          theShower.GetXFOVMax() - xMax
                          );
  const double cutVal = cut.GetCutValue();

  const double minDist = fmin(dX1,dX2);
  cut.SetCurrValue(fmin(500.,fmax(-500.,minDist)));
  if ( cut.IsAntiCut() )
    return (minDist<cutVal);
  else
    return (minDist>cutVal);

}

bool FDSelection::axisPixelCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  // const int ndf = theGeometry.GetTimeFitNdof();
  const int nStations = theGeometry.GetNHybridStations();
  // const double nPix = ndf-nStations+3;

#warning misuse of number of hybrid stations -> real cut value is one higher than expected
  // DKH: To not break analysis code using this cut, I leave the number of stations,
  // however, this will (and always have...) result in a real cut value one
  // higher than expected because the number of stations is not used in the
  // time fit.
  const int nPix = theGeometry.GetNTimeFitPixels() - nStations;

  const int cutVal = (int)cut.GetCutValue();
  cut.SetCurrValue(fmin(50.,nPix));

  if ( cut.IsAntiCut() )
    return (nPix<cutVal);
  else
    return (nPix>cutVal);

}

bool FDSelection::sdpPixelCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasSDP )
    return false;

  const FdRecPixel& thePixel = CurrFDEvent().GetFdRecPixel();
  const int nPix = thePixel.GetNumberOfSDPFitPixels();

  const int cutVal  = (int)cut.GetCutValue();
  cut.SetCurrValue(fmin(50,nPix));

  if ( cut.IsAntiCut() )
    return (nPix<cutVal);
  else
    return (nPix>cutVal);

}

bool FDSelection::trigPixelCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasSDP )
    return false;

  const FdRecPixel& thePixel = CurrFDEvent().GetFdRecPixel();
  const int nPix = thePixel.GetNumberOfTriggeredPixels();

  const int cutVal  = (int)cut.GetCutValue();
  cut.SetCurrValue(fmin(50,nPix));

  if ( cut.IsAntiCut() )
    return (nPix<cutVal);
  else
    return (nPix>cutVal);

}


bool FDSelection::hybridTankTriggerCut(Cut& cut) {

  const int cutVal  = (int) cut.GetCutValue();
  EStationTrigger currVal = eNone;
  const vector<FdRecStation>& stations= CurrFDEvent().GetStationVector();
  for ( unsigned int iS=0;iS<stations.size();iS++) {
    if(!stations[iS].IsHybrid() )
      continue;
    currVal = stations[iS].GetTriggerType();

    if ( (int) currVal == cutVal )
      break;
  }

  cut.SetCurrValue((double) currVal );

  if ( cut.IsAntiCut() )
    return (currVal!=cutVal);
  else
    return (currVal==cutVal);

}

bool FDSelection::coreUncertaintyCut(Cut& cut){

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const double cutVal = cut.GetCutValue();

  const double coreAltitude = 1450; //m
  const TVector3& showerCore=
    CurrFDEvent().GetFdRecShower().GetCoreAtAltitudeSiteCS(coreAltitude);

  const double xC=showerCore.X();
  const double yC=showerCore.Y();

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const EyeGeometry& eye = GetDetectorGeometry()->GetEye(CurrFDEvent().GetEyeId());
  const TVector3&  eyePos = eye.GetEyePos();
  const double xEye=eyePos.X();
  const double yEye=eyePos.Y();
  const double dx=xC-xEye;
  const double dy=yC-yEye;
  const double R = theGeometry.GetCoreEyeDistance();
  const double Rerr = theGeometry.GetCoreEyeDistanceError();
  const double phi1=atan2(dy,dx)+ theGeometry.GetSDPPhiError();
  const double phi2=atan2(dy,dx)- theGeometry.GetSDPPhiError();
  const double xx1=xEye+cos(phi1)*R;
  const double yy1=yEye+sin(phi1)*R;
  const double xx2=xEye+cos(phi2)*R;
  const double yy2=yEye+sin(phi2)*R;
  const double dist=sqrt( (xx1-xx2)*(xx1-xx2)+(yy1-yy2)*(yy1-yy2) );
  const double perpErr=dist/2.;
  const double area = TMath::Pi()*perpErr*Rerr;
  cut.SetCurrValue(area);
 // cout << area << endl;
  if ( cut.IsAntiCut() )
    return (area>cutVal);
  else
    return (area<cutVal);

}


bool FDSelection::hybridDeltaTCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const int nStations = theGeometry.GetHottestStation();
  if ( nStations < 1 )
    return false;

  const double dT = fabs(theGeometry.GetSDFDTimeOffset());
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(fmin(500.,dT));

  if ( cut.IsAntiCut() )
    return (dT>cutVal);
  else
    return (dT<cutVal);

}

bool FDSelection::maxZenithCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  if ( cut.IsAntiCut() )
    return (zenith>cutVal);
  else
    return (zenith<cutVal);

}

bool FDSelection::minZenithCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double zenith = theShower.GetZenith()*180./TMath::Pi();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(zenith);

  if ( cut.IsAntiCut() )
    return (zenith<cutVal);
  else
    return (zenith>cutVal);

}

bool
FDSelection::maxLgEnergyCut(Cut& cut)
{
  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgE = log10(theShower.GetEnergy());

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(lgE);

  if ( cut.IsAntiCut() )
    return (lgE>cutVal);
  else
    return (lgE<cutVal);

}

bool FDSelection::minLgEnergyCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgE = log10(theShower.GetEnergy());

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(lgE);

  if ( cut.IsAntiCut() )
    return (lgE<cutVal);
  else
    return (lgE>cutVal);

}

bool FDSelection::minLgECalCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgE = log10(theShower.GetEcal());

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(lgE);

  if ( cut.IsAntiCut() )
    return (lgE<cutVal);
  else
    return (lgE>cutVal);
}

bool FDSelection::eyeCut(Cut& cut) {
  const double eyeID = CurrFDEvent().GetEyeId();

  const int cutVal  = (int) cut.GetCutValue();

  const int eyeBit = (cutVal / (int) (pow(10.,eyeID-1)))%10;

  cut.SetCurrValue(eyeID);

  if ( cut.IsAntiCut() )
    return (eyeBit!=1);
  else
    return (eyeBit==1);
}


bool FDSelection::cFracCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAperturePhotons)
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double cFrac = theShower.GetCherenkovFraction();

  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(cFrac);

  if ( cut.IsAntiCut() )
    return (cFrac>cutVal);
  else
    return (cFrac<cutVal);


}


#ifdef PRIM_CHER
bool
FDSelection::primCFracCut(Cut& cut)
{
  const FdGenApertureLight& genProfile = CurrFDEvent().GetGenApertureLight();
  vector<double> totalLight =
    genProfile.GetLightFluxSumVector(true,true,true,true,true,true,true,true,true);
  vector<double> primaryLight =
    genProfile.GetLightFluxSumVector(false,false,false,false,false,false,true,true,true);

  const double totSum = accumulate(totalLight.begin(), totalLight.end(), 0);
  const double primSum = accumulate(primaryLight.begin(), primaryLight.end(), 0);

  if (totSum > 0) {
    const double frac = primSum / totSum;
    const double cutVal = cut.GetCutValue();
    cut.SetCurrValue(frac);

    return cut.IsAntiCut() ? frac < cutVal : frac > cutVal;
  }

  return false;
}
#else
bool
FDSelection::primCFracCut(Cut&)
{
  cerr << " FDSelection::dirPrimCFracCut() - no primary cherenkov light simulated!!" << endl;
  return true;
}
#endif


#ifdef PRIM_CHER
bool
FDSelection::dirPrimCFracCut(Cut& cut)
{
  const FdGenApertureLight& genProfile = CurrFDEvent().GetGenApertureLight();
  const vector<double> totalLight =
    genProfile.GetLightFluxSumVector(true,true,true,true,true,true,true,true,true);
  const vector<double> primaryLight =
    genProfile.GetLightFluxSumVector(false,false,false,false,false,false,true,false,false);

  double totSum = 0;
  double primSum = 0;

  for (unsigned int i = 0; i < totalLight.size(); ++i) {
    totSum += totalLight[i];
    primSum += primaryLight[i];
  }

  if (totSum > 0) {
    const double frac = primSum / totSum;
    const double cutVal = cut.GetCutValue();
    cut.SetCurrValue(frac);

    return cut.IsAntiCut() ? frac < cutVal : frac > cutVal;
  }

  return false;
}
#else
bool
FDSelection::dirPrimCFracCut(Cut&)
{
  cerr << " FDSelection::dirPrimCFracCut() - no primary cherenkov light simulated!!" << endl;
  return true;
}
#endif


bool FDSelection::dirCFracCut(Cut& cut) {
  if ( CurrFDEvent().GetRecLevel() < eHasAperturePhotons)
    return false;

  const FdRecApertureLight& apertureLight = CurrFDEvent().GetFdRecApertureLight();
  const vector<double>& total = apertureLight.GetTotalLightAtAperture();
  const vector<double>& directCh = apertureLight.GetCherLightAtAperture();

  double sumTotal = 0;
  double sumDCh = 0;
  const unsigned int max = (total.size() < directCh.size() ? total.size() : directCh.size());

  for (unsigned int i = 0; i < max; i++) {
    sumTotal += total[i];
    sumDCh   += directCh[i];
  }

  const double fraction = 100*sumDCh / sumTotal;
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(fraction);

  if ( cut.IsAntiCut() )
    return (fraction > cutVal);
  else
    return (fraction < cutVal);
}


bool FDSelection::minTotalLightCut(Cut&cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAperturePhotons)
    return false;

  const FdRecApertureLight& apertureLight =
    CurrFDEvent().GetFdRecApertureLight();

  const double TotalLightAtAperture=apertureLight.GetTotalLightIntegral();
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(TotalLightAtAperture);

  if(cut.IsAntiCut())
    return (TotalLightAtAperture<cutVal);
  else
    return (TotalLightAtAperture>=cutVal);
}


bool FDSelection::coreTankDistCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const int nStations = theGeometry.GetHottestStation();
  if ( nStations < 1 )
    return false;

  const double dist = theGeometry.GetStationAxisDistance();
  const double cutVal = cut.GetCutValue();

  cut.SetCurrValue(dist);

  if ( cut.IsAntiCut() )
    return (dist>cutVal);
  else
    return (dist<cutVal);
}


bool FDSelection::depthTrackLengthCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasLongitudinalProfile )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double length = theShower.GetTrackLength();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(length);

  if ( cut.IsAntiCut() )
    return (length<cutVal);
  else
    return (length>cutVal);

}

bool FDSelection::angleTrackLengthCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double length = theShower.GetAngTrackObs()*180./TMath::Pi();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(length);

  if ( cut.IsAntiCut() )
    return (length<cutVal);
  else
    return (length>cutVal);

}

bool FDSelection::timeTrackLengthCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double dT = theShower.GetTimTrackObs();
  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(dT);

  if ( cut.IsAntiCut() ) {
    return (dT<cutVal);
  } else {
    return (dT>cutVal);
  }

}

bool FDSelection::minViewAngleCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double minAng = theShower.GetMinAngle()*180./TMath::Pi();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(minAng);

  if ( cut.IsAntiCut() )
    return (minAng<cutVal);
  else
    return (minAng>cutVal);

}

bool FDSelection::coreTankDistECut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgEEeV = log10(theShower.GetEnergy()/1.e18);

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const int nStations = theGeometry.GetHottestStation();
  if ( nStations < 1 )
    return false;

  const double dist = theGeometry.GetStationAxisDistance();

  const double cutVal    = cut.GetCutValue();
  const double cutSlope  = cut.GetCutSlope();

  cut.SetCurrValue(dist);

  if ( cut.IsAntiCut() )
    return (dist>cutVal+cutSlope*lgEEeV);
  else
    return (dist<cutVal+cutSlope*lgEEeV);

}

bool FDSelection::minCosZFDECut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgEEeV = log10(theShower.GetEnergy()/1.e18);

  const double cosZen   = cos(theShower.GetZenith());

  const double cutVal   = cut.GetCutValue();
  const double cutSlope = cut.GetCutSlope();

  cut.SetCurrValue(cosZen);

  if ( cut.IsAntiCut() )
    return (cosZen<cutVal+cutSlope*lgEEeV);
  else
    return (cosZen>cutVal+cutSlope*lgEEeV);

}


bool FDSelection::ICRC2005PhotonDistanceCut(Cut& cut) {
  cut.IsBooleanCut();

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();

  const double lgE=log10(theShower.GetEcal());
  const double dCore=(theGeometry.GetCoreEyeDistance())/1000.; // [km]
  const double maxDist=24.+12.*(lgE-19.);

  if ( cut.IsAntiCut() )
    return( dCore > maxDist );
  else
    return( dCore < maxDist );
}


bool FDSelection::minXFOVCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() <eHasAxis )
    return false;

  const double cutVal = cut.GetCutValue();

  if (cutVal) {
    const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
    const double minFOV = theShower.GetXFOVMin();

    cut.SetCurrValue(minFOV);

    if ( cut.IsAntiCut() )
      return (minFOV > cutVal);
    else
      return (minFOV <= cutVal);
  }
  else
    return true;
}


bool FDSelection::maxXFOVCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() <eHasAxis )
    return false;

  const double cutVal = cut.GetCutValue();

  if (cutVal) {
    const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
    const double maxFOV = theShower.GetXFOVMax();

    cut.SetCurrValue(maxFOV);

    if ( cut.IsAntiCut() )
      return (maxFOV < cutVal);
    else
      return (maxFOV >= cutVal);
  }
  else
    return true;
}


bool FDSelection::profileChi2RatioCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double chi2GH   = theShower.GetGHChi2();
  const double chi2Line = theShower.GetLinearProfileFitChi2();
  const double cutVal   = cut.GetCutValue();

  const double chi2Ratio = chi2GH/chi2Line;

  cut.SetCurrValue(fmin(chi2Ratio,10.));
  if ( cut.IsAntiCut() )
    return (chi2Ratio>cutVal);
  else
    return (chi2Ratio<cutVal);

}

//-------------------------------------------------
bool FDSelection::badPixelCut(Cut& cut) {

  const double cutVal = cut.GetCutValue();

  if ( cutVal == 0. )
    return true;

  bool hasBadPixels = false;

  const set<int>& badPixels = CurrEvent().GetDetector().GetBadPixelSet();

  const int eyeId = CurrFDEvent().GetEyeId();

  // 'misuse' mirror time offsets for tels in DAQ
  const map<UShort_t,Int_t>& mirrorDeltaTs =
    CurrFDEvent().GetMirrorTimeOffsets();

  for (set<int>::const_iterator badPixIter = badPixels.begin();
       badPixIter != badPixels.end();
       ++badPixIter) {
    const int badPixID = *badPixIter;
    const int pixID    = badPixID%TelescopeGeometry::fgNumberOfPixels;
    const int tmp      = (badPixID - pixID)/TelescopeGeometry::fgNumberOfPixels;
    int telID = tmp%6;
    if ( telID == 0 )
      telID = 6;
    const int eyeID = (tmp-telID)/6;
    if ( eyeID == eyeId ) {
      if (mirrorDeltaTs.find(telID) != mirrorDeltaTs.end()) {
        hasBadPixels = true;
        break;
      }
    }
  }

  cut.SetCurrValue( (hasBadPixels ? 0 : 1) );

  if (cut.IsAntiCut())
    return !hasBadPixels;
  else
    return hasBadPixels;

}

bool FDSelection::mismatchedPixelCut(Cut& cut) {
  cut.IsBooleanCut();

  bool hasMismatchedPixel = false;

  if ( CurrFDEvent().GetRecLevel() >= eHasReconstructedPixels ) {

    const int eyeId = CurrFDEvent().GetEyeId();

    const FdRecPixel& thePixels = CurrFDEvent().GetFdRecPixel();

    const vector<UShort_t>& pixelIDs    = thePixels.GetID();
    const vector<EPixelStatus>& pixelStatus = thePixels.GetStatus();

    for ( unsigned int i=0; i< pixelIDs.size(); i++ ) {

      if ( pixelStatus[i]>=ePulseRecPix ) {

        const int pixNumber = pixelIDs[i];
        const int telId = pixNumber/TelescopeGeometry::fgNumberOfPixels + 1;
        const int pixId = (pixNumber%TelescopeGeometry::fgNumberOfPixels)+1;

        if (CurrEvent().GetDetector().IsMismatchedPixel(eyeId, telId, pixId)) {
          hasMismatchedPixel = true;
          break;
        }
      }
    }
  }

  cut.SetCurrValue( (hasMismatchedPixel ? 0 : 1) );

  if (cut.IsAntiCut())
    return !hasMismatchedPixel;
  else
    return hasMismatchedPixel;
}

bool FDSelection::deltaProfileChi2SpotCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  double chi2GH   = 0.;
  const vector<double>& depth   = theShower.GetDepth();
  const vector<double>& dEdX    = theShower.GetEnergyDeposit();
  const vector<double>& dEdXErr = theShower.GetEnergyDepositError();

  for ( unsigned int i=0;i<depth.size(); i++ ) {

    const double variance = dEdXErr[i]*dEdXErr[i];
    const double residual = dEdX[i]-theShower.EvaluateGaisserHillas(depth[i]);
    chi2GH += residual*residual/variance;
  }

  const double chi2Line  = theShower.GetLinearProfileFitChi2();
  const double cutVal    = cut.GetCutValue();
  const double deltaChi2 = chi2Line-chi2GH;

  cut.SetCurrValue(fmin(deltaChi2,50.));
  if ( cut.IsAntiCut() )
    return (deltaChi2<cutVal);
  else
    return (deltaChi2>cutVal);

}


bool FDSelection::deltaProfileChi2Cut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  const double chi2GH   = theShower.GetGHChi2();
  const double chi2Line = theShower.GetLinearProfileFitChi2();
  const double cutVal = cut.GetCutValue();

  const double deltaChi2 = chi2Line-chi2GH;

  cut.SetCurrValue(fmin(deltaChi2,50.));
  if ( cut.IsAntiCut() )
    return (deltaChi2<cutVal);
  else
    return (deltaChi2>cutVal);

}

bool FDSelection::depthVelocityCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double dT= theShower.GetTimTrackObs();
  const double X1=theShower.GetXTrackMin();
  const double X2=theShower.GetXTrackMax();

  if ( dT <= 0. )
    return false;

  const double dSpeed = (X2-X1)/dT;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(dSpeed);
  if ( cut.IsAntiCut() )
    return (dSpeed>cutVal);
  else
    return (dSpeed<cutVal);

}

bool FDSelection::GAP2007005FiducialZenith(Cut& cut) {
  cut.IsBooleanCut();

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double cZen = theShower.GetAxisCoreCS().Z();

  const double lgEEv = log10(theShower.GetEnergy())-18.;

  double cosCut;
  if ( lgEEv < 0. ) {
    cosCut=0.55;
  }
  else if  ( lgEEv > 1.5 ) {
    cosCut=0.175;
  }
  else {
    cosCut=0.55-.25*lgEEv;
  }

  cut.SetCurrValue(cZen);
  if ( cut.IsAntiCut() )
    return( cZen < cosCut );
  else
    return( cZen > cosCut );
}

bool FDSelection::GAP2007005FiducialDistance(Cut& cut) {
  cut.IsBooleanCut();

  if ( CurrFDEvent().GetRecLevel() < eHasAxis )
    return false;

  const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();
  const int nStations = theGeometry.GetHottestStation();
  if ( nStations < 1 )
    return false;

  const double dist = theGeometry.GetStationAxisDistance();

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double lgEEv = log10(theShower.GetEnergy())-18.;

  double distCut;

  if ( lgEEv < 0. )
    distCut=750.;
  else if  ( lgEEv > 1.5 )
    distCut=2000.;
  else
    distCut=750.+833.*lgEEv;

  cut.SetCurrValue(dist);
  if ( cut.IsAntiCut() )
    return( dist > distCut );
  else
    return( dist < distCut );
}

bool FDSelection::GAP2007005FiducialFOV(Cut& cut) {

  const double cutVal = cut.GetCutValue();

  if ( CurrFDEvent().GetRecLevel() <eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double maxFOV=theShower.GetXFOVMax();
  const double minFOV=theShower.GetXFOVMin();

  const double lgE=log10(theShower.GetEnergy());

  double minFOVcut;
  if ( lgE<19.06 )
    minFOVcut=550.-61.*(lgE-19.06)*(lgE-19.06)-cutVal;
  else
    minFOVcut=550.-cutVal;

  const double maxFOVcut=900.+6.*(lgE-18.)+cutVal;

  if ( cut.IsAntiCut() )
    return !(maxFOV>=maxFOVcut&&minFOV<=minFOVcut);
  else
    return (maxFOV>=maxFOVcut&&minFOV<=minFOVcut);

}

bool FDSelection::GAP2007049FiducialFOV(Cut& cut) {

  const double cutVal = cut.GetCutValue();

  if ( CurrFDEvent().GetRecLevel() <eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double maxFOV=theShower.GetXFOVMax();
  const double minFOV=theShower.GetXFOVMin();

  const double lgE=log10(theShower.GetEnergy());

  double minFOVcut;
  if ( lgE <= 17.6 )
    minFOVcut=510.;
  else if ( lgE <= 17.9 )
    minFOVcut=540.;
  else
    minFOVcut=600.;

  double maxFOVcut;
  if ( lgE <= 17.6 )
    maxFOVcut=900;
  else
    maxFOVcut=1100;

  maxFOVcut+=cutVal;
  minFOVcut-=cutVal;

  if ( cut.IsAntiCut() )
    return !(maxFOV>=maxFOVcut&&minFOV<=minFOVcut);
  else
    return (maxFOV>=maxFOVcut&&minFOV<=minFOVcut);

}

bool FDSelection::FiducialFOVICRC07(Cut& cut) {

  const double cutVal = cut.GetCutValue();

  if ( CurrFDEvent().GetRecLevel() <eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double maxFOV=theShower.GetXFOVMax();
  const double minFOV=theShower.GetXFOVMin();

  const double lgE=log10(theShower.GetEnergy());

  double minFOVcut;
  if ( lgE<1.94216e+01)
    minFOVcut=5.81858e+02-4.68045e+01*(lgE-1.94216e+01)*(lgE-1.94216e+01)-cutVal;
  else
    minFOVcut=5.81858e+02-cutVal;

  double maxFOVcut=9.30207e+02+cutVal;

  if ( cut.IsAntiCut() )
    return !(maxFOV>=maxFOVcut&&minFOV<=minFOVcut);
  else
    return (maxFOV>=maxFOVcut&&minFOV<=minFOVcut);

}

inline double prl10FovCut(const double* p,const double lgE) {
  return (lgE>p[2]?
	  p[0]:
	  p[0]+p[1]*pow(lgE-p[2],2));
}

bool
FDSelection::FiducialFOVPRL10(Cut& cut)
{

  if ( CurrFDEvent().GetRecLevel() <eHasEnergy )
    return false;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const pair<double, double>& fovBoundaries =
    theShower.GetExpectedFOVRange(40., 20.*degree);
  const double xLo = fovBoundaries.first;
  const double xUp = fovBoundaries.second;

  const double lgE = log10(theShower.GetEnergy());
  const double xUpPars[3]={849.6, 22.4405, 19.5};
  const double xLoPars[3]={679.345, -41.9299, 19.5};
  const double xUpCut = prl10FovCut(xUpPars, lgE);
  const double xLoCut = prl10FovCut(xLoPars, lgE);
  const bool fidFOV = (xUp > xUpCut && xLo < xLoCut);
  cut.SetCurrValue(fidFOV);

  if (cut.IsAntiCut())
    return !fidFOV;
  else
    return fidFOV;

}

bool
FDSelection::FiducialFOVICRC11(Cut& cut)
{
  const double xmaxResoCut = cut.GetCutParameters()[0]; // g cm-2
  const double mvaCut = cut.GetCutParameters()[1]*degree;

  bool inFOV = false;
  if (CurrFDEvent().GetRecLevel() >= eHasEnergy) {

    const double xUpPars[3] = {877.187,-0.63424,19.5};
    const double xLoPars[3] = {687.749,-49.2971,19.5};

    const FdRecShower& shower = CurrFDEvent().GetFdRecShower();
    const double lgE = log10(shower.GetEnergy());
    const double xUpCut = prl10FovCut(xUpPars,lgE);
    const double xLoCut = prl10FovCut(xLoPars,lgE);

    const pair<double, double>& fovs =
      shower.GetExpectedFOVRange(xmaxResoCut, mvaCut);

    const double xLo = fovs.first;
    const double xUp = fovs.second;

    inFOV = (xUp > xUpCut && xLo < xLoCut);
  }

  cut.SetCurrValue(inFOV);

  if (cut.IsAntiCut())
    return !inFOV;
  else
    return inFOV;

}

bool
FDSelection::xMaxObsInExpectedFOV(Cut& cut)
{

  if ( CurrFDEvent().GetRecLevel() < eHasGHParameters )
    return false;

  const double xmaxResoCut = cut.GetCutParameters()[0]; // g cm-2
  const double mvaCut = cut.GetCutParameters()[1]*degree;

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax = theShower.GetXmax();
  const pair<double, double>& fovBoundaries =
    theShower.GetExpectedFOVRange(xmaxResoCut, mvaCut);
  const double maxFOV = fovBoundaries.second;
  const double minFOV = fovBoundaries.first;

  const double dX1 = fmin(
                          xMax - theShower.GetXTrackMin(),
                          xMax - minFOV
                           );
  const double dX2 = fmin(
                          theShower.GetXTrackMax() - xMax,
                          maxFOV - xMax
                          );

  const double minDist = fmin(dX1,dX2);
  cut.SetCurrValue(minDist);
  if ( cut.IsAntiCut() )
    return (minDist<0);
  else
    return (minDist>0);

}

bool FDSelection::minShowerAgeCut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax = theShower.GetXmax();
  if (xMax == 0.0)
    return cut.IsAntiCut();

  const vector<double>& depth = theShower.GetDepth();
  if (depth.size() == 0)
    return cut.IsAntiCut();

  const double minAge = FdRecShower::ShowerAge(depth[0], xMax);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(minAge);

  if ( cut.IsAntiCut() )
    return (minAge>cutVal);
  else
    return (minAge<cutVal);
}


bool FDSelection::maxShowerAgeCut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax = theShower.GetXmax();
  if (xMax == 0.0)
    return cut.IsAntiCut();

  const vector<double>& depth = theShower.GetDepth();
  if (depth.size() == 0)
    return cut.IsAntiCut();

  const double maxAge = FdRecShower::ShowerAge(depth[depth.size()-1], xMax);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(maxAge);

  if ( cut.IsAntiCut() )
    return (maxAge<cutVal);
  else
    return (maxAge>cutVal);
}


bool FDSelection::minRelativeDepthCut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax = theShower.GetXmax();
  if (xMax == 0.0)
    return cut.IsAntiCut();

  const vector<double>& depth = theShower.GetDepth();
  if (depth.size() == 0)
    return cut.IsAntiCut();

  const double minRelDepth = depth[0]-xMax;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(minRelDepth);

  if ( cut.IsAntiCut() )
    return (minRelDepth>cutVal);
  else
    return (minRelDepth<cutVal);
}


bool FDSelection::maxRelativeDepthCut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double xMax = theShower.GetXmax();
  if (xMax == 0.0)
    return cut.IsAntiCut();

  const vector<double>& depth = theShower.GetDepth();
  if (depth.size() == 0)
    return cut.IsAntiCut();

  const double maxRelDepth = depth[depth.size()-1]-xMax;

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(maxRelDepth);

  if ( cut.IsAntiCut() )
    return (maxRelDepth<cutVal);
  else
    return (maxRelDepth>cutVal);
}


bool FDSelection::minX0Cut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double x0 = theShower.GetX0();
  if (theShower.GetXmax() ==0.0) // no reconstruction
    return cut.IsAntiCut();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(x0);

  if ( cut.IsAntiCut() )
    return (x0<cutVal);
  else
    return (x0>cutVal);
}


bool FDSelection::maxX0Cut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const double x0 = theShower.GetX0();
  if (theShower.GetXmax() ==0.0) // no reconstruction
    return cut.IsAntiCut();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(x0);

  if ( cut.IsAntiCut() )
    return (x0>cutVal);
  else
    return (x0<cutVal);
}


bool FDSelection::xRiseCut(Cut& cut) {
  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();

  if (theShower.GetXmax() == 0.0) // no reconstruction
    return cut.IsAntiCut();

  const double xRise = theShower.GetXmax() - theShower.GetX0();

  cut.SetCurrValue(xRise);

  const double minCutVal = cut.GetCutParameters()[0];
  const double maxCutVal = cut.GetCutParameters()[1];

  const double accept = (minCutVal <= xRise) && (xRise <= maxCutVal);

  return cut.IsAntiCut() ? !accept : accept;
}


bool FDSelection::maxCoreEyeDistanceCut(Cut& cut) {
  const double distance = CurrFDEvent().GetFdRecGeometry().GetCoreEyeDistance();
  if ( (distance - 1.e-10 <= 0.) && (distance + 1.e-10 >= 0.) )
    return cut.IsAntiCut();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(distance);

  if ( cut.IsAntiCut() )
    return (distance > cutVal);
  else
    return (distance <= cutVal);
}


bool FDSelection::numberOfMirrorsCut(Cut& cut) {
  const TBits& telBits = CurrFDEvent().GetMirrorsInEvent();
  const int nMirrors = telBits.CountBits();

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(nMirrors);

  if ( cut.IsAntiCut() )
    return (nMirrors!=cutVal);
  else
    return (nMirrors==cutVal);
}

bool FDSelection::saturationCut(Cut& cut) {
  cut.IsBooleanCut();

  const bool hasSaturated = CurrFDEvent().GetFdRecPixel().HasHighGainSaturatedPixels();

  cut.SetCurrValue(hasSaturated);

  if ( cut.IsAntiCut() )
    return( hasSaturated );
  else
    return( !hasSaturated );
}


bool
FDSelection::badFDPeriodRejection(Cut& cut) {
  cut.IsBooleanCut();

  // LL, LM, LA, CO, HE, HECO
  const unsigned int maxEyes = kNEyes + 1;

  // ------- calbration constants --------
  // info from Jeff Brack (LL,CO,LM) and Rossella Caruso (LA)
  // HEAT calibration valid from June 2010
  const unsigned int firstValidDate[maxEyes]={41201, 50602, 70501, 41201,
                                              100601, 100601};

  const unsigned int eyeId = CurrFDEvent().GetEyeId();
  if (eyeId < 1 || eyeId > maxEyes) {
    cerr << " FDSelection::badFDPeriodRejection() - unexpected eye "
         << eyeId << endl;
    return false;
  }

  const unsigned int yymmdd = CurrEvent().GetYYMMDD();
  const bool hasGoodCalib = yymmdd >= firstValidDate[eyeId-1];


  // --------- GPS-clock glitches -----------
  // (Loma Amarilla, from Jose Bellido CLF analysis)

  const unsigned int gpsLAGPSglitchStart = 887000000;
  const unsigned int gpsLAGPSglitchStop  = 908800000;
  bool hasGoodGPS = true;
  if (eyeId == 3 &&
      CurrFDEvent().GetGPSSecond() > gpsLAGPSglitchStart &&
      CurrFDEvent().GetGPSSecond() <= gpsLAGPSglitchStop) {
    hasGoodGPS = false;
  }

  // ---------- periods of unstable baselines ------
  // (MU analysis, August 2010)

  bool hasGoodBaseline = true;
  // LM mirror 4, [2009/03/20,2009/12/11]
  if (eyeId == 2) {
    if (CurrFDEvent().MirrorIsInEvent(4)  &&
        CurrFDEvent().GetGPSSecond() > 921542415 &&
        CurrFDEvent().GetGPSSecond() <= 944524815)
      hasGoodBaseline = false;
  }
  // LA mirror 3, [2010/04/01,2010/05/12]
  else if (eyeId == 3) {
    if (CurrFDEvent().MirrorIsInEvent(3)  &&
        CurrFDEvent().GetGPSSecond() > 954115215 &&
        CurrFDEvent().GetGPSSecond() <= 957657615)
      hasGoodBaseline = false;
  }

  // ---------- bad alignments ------
  // (JB/SF analysis: mirror misalignment in LA/4, fixed in August 2012)
  bool hasGoodAlignment = true;
  if (eyeId == 3 && CurrFDEvent().MirrorIsInEvent(4) &&
      yymmdd < 120913)
    hasGoodAlignment = false;

  const bool isGoodPeriod =
      hasGoodGPS && hasGoodCalib && hasGoodBaseline && hasGoodAlignment;

  if (cut.IsAntiCut())
    return !isGoodPeriod;
  else
    return isGoodPeriod;

}

bool FDSelection::ICRC2007CalibPeriod(Cut& cut) {
  cut.IsBooleanCut();

  const unsigned int firstValidDate[kNEyes]={41201,50602,999999,41201,999999};

  const int eyeId = CurrFDEvent().GetEyeId();

  if ( eyeId < 1 || eyeId > (int) kNEyes ) {
    cerr << " FDSelection::ICRC2007CalibPeriod() - unexpected eye "
         << eyeId << endl;
    return false;
  }

  const unsigned int yymmdd = CurrEvent().GetYYMMDD();

  const bool isGoodCalib = (yymmdd>=firstValidDate[eyeId-1]);

  if ( cut.IsAntiCut() )
    return( !isGoodCalib );
  else
    return( isGoodCalib );
}



bool FDSelection::mieDatabaseCut(Cut& cut) {
  cut.IsBooleanCut();

  const bool hasMieDatabase= CurrEvent().GetDetector().HasMieDatabase();

  if ( cut.IsAntiCut() )
    return( !hasMieDatabase );
  else
    return( hasMieDatabase );
}

bool FDSelection::GDASDatabaseCut(Cut& cut) {
  cut.IsBooleanCut();

  const bool hasGDASDatabase= CurrEvent().GetDetector().HasGDASDatabase();

  if ( cut.IsAntiCut() )
    return( !hasGDASDatabase );
  else
    return( hasGDASDatabase );
}

bool FDSelection::lidarDatabaseCut(Cut& cut) {

  cut.IsBooleanCut();
  const bool hasLidarDatabase= CurrEvent().GetDetector().HasLidarData();

  if ( cut.IsAntiCut() )
    return( !hasLidarDatabase );
  else
    return( hasLidarDatabase );
}

bool FDSelection::MaxCloudThicknessCut(Cut& cut){
  // rejects events covered by clouds with a thickness > cutVal

  const int thisEye = CurrFDEvent().GetEyeId();
  bool hasLidarData=false;
  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const double profileDepth = CurrFDEvent().GetFdRecShower().GetDepth()[0];
  double cloudDepth = 0;
  double cloudThickness = 0;
  if ( CurrEvent().GetDetector().HasLidarData(thisEye) ) {
    const FdLidarData& lidar = CurrEvent().GetDetector().GetLidarData(thisEye);
    cloudDepth = lidar.GetCloudDepth();
    cloudThickness = lidar.GetCloudSlantThickness();
    hasLidarData=true;
  }
  else {
    for ( unsigned int lidarZone=1; lidarZone<=4; lidarZone++) {
      if ( CurrEvent().GetDetector().HasLidarData(lidarZone) ) {
	const FdLidarData& lidar = CurrEvent().GetDetector().GetLidarData(lidarZone);
	if ( lidar.GetCloudDepth() > cloudDepth){
	  cloudDepth = lidar.GetCloudDepth();
	  cloudThickness = lidar.GetCloudSlantThickness();
	}
	hasLidarData=true;
      }
    }
  }
  bool rejected = false;

  if(!hasLidarData) {
    return cut.IsAntiCut() ? rejected : !rejected;
  }

  const double cutVal = cut.GetCutParameters()[0];
  cloudDepth /= CurrFDEvent().GetFdRecShower().GetAxisCoreCS().Z();
  cut.SetCurrValue(cloudThickness);
  if ( profileDepth < cloudDepth && cloudThickness > cutVal){
    rejected = true;
  }

  return cut.IsAntiCut() ? rejected : !rejected;
}

bool FDSelection::MinCloudDepthDistanceCut(Cut& cut){

//functionality: reject events with profile-cloud slant distance in(max, min)

  const int thisEye = CurrFDEvent().GetEyeId();
  bool hasLidarData=false;
  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const double profileDepth = CurrFDEvent().GetFdRecShower().GetDepth()[0];
  double cloudDepth = 0;
  if ( CurrEvent().GetDetector().HasLidarData(thisEye) ) {
    const FdLidarData& lidar = CurrEvent().GetDetector().GetLidarData(thisEye);
    cloudDepth = lidar.GetCloudDepth();
    hasLidarData=true;
  }
  else {
    for ( unsigned int lidarZone=1; lidarZone<=4; lidarZone++) {
      if ( CurrEvent().GetDetector().HasLidarData(lidarZone) ) {
	const FdLidarData& lidar = CurrEvent().GetDetector().GetLidarData(lidarZone);
	cloudDepth = max(lidar.GetCloudDepth(), cloudDepth);
	hasLidarData=true;
      }
    }
  }

  if(!hasLidarData) {
    if (CurrEvent().GetDetector().HasOverallQualityDatabase()){
      cloudDepth = CurrEvent().GetDetector().GetQDBMinCloudBaseDepth();
    }
  }

  const double profileCloudDepth = profileDepth - cloudDepth/
    CurrFDEvent().GetFdRecShower().GetAxisCoreCS().Z();

  cut.SetCurrValue(profileCloudDepth);

  const double minCutVal = cut.GetCutParameters()[0];
  const double maxCutVal = cut.GetCutParameters()[1];
  bool rejected = false;
  if (profileCloudDepth < maxCutVal && profileCloudDepth > minCutVal){
    rejected = true;
  }
  return cut.IsAntiCut() ? rejected : !rejected;

}

bool FDSelection::LidarCloudRemovalCut(Cut& cut) {
  //functionality: keep ALL events expect those with known
  //average cloud coverages higher than the cut-value

  const int thisEye = CurrFDEvent().GetEyeId();
  bool hasLidarData=false;
  double lidarCloudCoverage=0.;

  if ( CurrEvent().GetDetector().HasLidarData(thisEye) ) {
    lidarCloudCoverage=CurrEvent().GetDetector().GetLidarData(thisEye).GetCloudCoverage()*100.;
    hasLidarData=true;
  }
  else {
    int nLidarData=0;
    for ( unsigned int LidarZone=1; LidarZone<=4;LidarZone++) {
      if ( CurrEvent().GetDetector().HasLidarData(LidarZone) ) {
        lidarCloudCoverage+=CurrEvent().GetDetector().GetLidarData(LidarZone).GetCloudCoverage()*100.;
        nLidarData++;
        hasLidarData=true;
      }
    }

    if(hasLidarData) {
      if(nLidarData>0) {
        lidarCloudCoverage/=(double)nLidarData;
      }
      else
        cerr<<"FDSelection::LidarCloudRemovalCut this should never happen: "
            <<nLidarData<<" entries found after counting Lidar data"<<endl;
    }
  }

  cut.SetCurrValue(lidarCloudCoverage);
  const double cutVal = cut.GetCutParameters()[0];

  if(hasLidarData) {
    if ( cut.IsAntiCut() )
      return (lidarCloudCoverage > cutVal);
    else
      return (lidarCloudCoverage <= cutVal);
  }
  else {
    if ( cut.IsAntiCut() )
      return false;
    else
      return true;
  }
}

bool FDSelection::MaxCloudFractionStrictCut(Cut& cut) {
  //functionality: keep events with
  //cloud fraction < cut value in zeta pixels

  const double maxCloudFractionInZeta =
    CurrFDEvent().GetFdRecApertureLight().GetMaxCloudCameraFractionInZeta();
  cut.SetCurrValue(maxCloudFractionInZeta);

  const double cutVal = cut.GetCutParameters()[0];

  const bool keepEvent =
    (maxCloudFractionInZeta <= cutVal && maxCloudFractionInZeta >= 0.);

  if ( cut.IsAntiCut() )
    return (!keepEvent);
  else
    return keepEvent;
}
bool FDSelection::MaxCloudFractionRelaxedCut(Cut& cut) {
  //functionality: keep ALL events expect those with known
  //cloud fraction > cut value in zeta pixels

  const double maxCloudFractionInZeta =
    CurrFDEvent().GetFdRecApertureLight().GetMaxCloudCameraFractionInZeta();
  cut.SetCurrValue(maxCloudFractionInZeta);

  const double cutVal = cut.GetCutParameters()[0];

  const bool keepEvent =
    (maxCloudFractionInZeta <= cutVal);

  if ( cut.IsAntiCut() )
    return (!keepEvent);
  else
    return keepEvent;
}

bool FDSelection::MaxCloudFractionWithLidarStrictCut(Cut& cut) {
  //functionality: keep events with
  //cloud fraction < cut value in zeta pixels (with lidar)

  const double maxCloudFractionInZeta =
    CurrFDEvent().GetFdRecApertureLight().GetMaxCloudCameraFractionWithLidarInZeta();
  cut.SetCurrValue(maxCloudFractionInZeta);

  const double cutVal = cut.GetCutParameters()[0];

  const bool keepEvent =
    (maxCloudFractionInZeta <= cutVal && maxCloudFractionInZeta >= 0.);

  if ( cut.IsAntiCut() )
    return (!keepEvent);
  else
    return keepEvent;
}

bool FDSelection::MaxCloudFractionWithLidarRelaxedCut(Cut& cut) {
  //functionality: keep ALL events expect those with known
  //cloud fraction > cut value in zeta pixels (with lidar)

  const double maxCloudFractionInZeta =
    CurrFDEvent().GetFdRecApertureLight().GetMaxCloudCameraFractionWithLidarInZeta();
  cut.SetCurrValue(maxCloudFractionInZeta);

  const double cutVal = cut.GetCutParameters()[0];

  const bool keepEvent =
    (maxCloudFractionInZeta <= cutVal);

  if ( cut.IsAntiCut() )
    return (!keepEvent);
  else
    return keepEvent;
}

bool FDSelection::maxVAODCut(Cut& cut) {
  //functionality: keep ALL events expect those with known vaod larger than the cut-value

  const int thisEye = CurrFDEvent().GetEyeId();
  bool hasVAOD=false;
  double vaod=0.;

  if ( CurrEvent().GetDetector().HasVAOD(thisEye) ) {
    vaod=CurrEvent().GetDetector().GetVAODAtReferenceHeight(thisEye);
    hasVAOD=true;
  }
  else {
    const map<int,double>& vaodMap =
      CurrEvent().GetDetector().GetVAODsAtReferenceHeight();
    hasVAOD = (!vaodMap.empty());
    for ( map<int,double>::const_iterator iter = vaodMap.begin();
          iter != vaodMap.end();
          ++iter) {
      vaod+=iter->second;
    }

    if(hasVAOD)
      vaod/=(double) vaodMap.size();

  }

  cut.SetCurrValue(vaod);
  const double cutVal = cut.GetCutValue();

  if(hasVAOD) {
    if ( cut.IsAntiCut() )
      return (vaod > cutVal);
    else
      return (vaod <= cutVal);
  }
  else {
    if ( cut.IsAntiCut() )
      return false;
    else
      return true;
  }
}



bool FDSelection::t3TimeAtGroundCut(Cut& cut) {
  cut.IsBooleanCut();

  const unsigned int timeAtGround = CurrFDEvent().GetT3TimeAtGround();

  const bool hasTimeAtGround = (timeAtGround!=0);
  cut.SetCurrValue(hasTimeAtGround);

  if ( cut.IsAntiCut() )
    return (!hasTimeAtGround);
  else
    return (hasTimeAtGround);
}

bool FDSelection::t3Cut(Cut& cut) {


  const double cutVal = cut.GetCutValue();
  const string& evClass = CurrFDEvent().GetEventClass();

  bool isRequiredClass = false;
  int currVal=eT3Undefined;
  if ( cutVal == eT3Shower ) {
    if ( evClass=="\'Shower Candidate\'" ||
         evClass=="\'Close Shower\'"  ||
         evClass=="\'Horizontal Shower\'"
         ) {
      isRequiredClass = true;
      currVal=eT3Shower;
    }
  }
  else if ( cutVal == eT3Noise ) {
    if ( evClass=="\'Noise\'" ) {
      isRequiredClass = true;
      currVal=eT3Noise;
    }
  }
  else if ( cutVal == eT3Muon ) {
    if ( evClass=="\'Muon\'" ) {
      isRequiredClass = true;
      currVal=eT3Muon;
    }
  }
  else if ( cutVal == eT3Large ) {
    if ( evClass=="\'Large Event\'" ) {
      isRequiredClass = true;
      currVal=eT3Large;
    }
  }

  cut.SetCurrValue(currVal);

  if ( cut.IsAntiCut() )
    return !isRequiredClass;
  else
    return isRequiredClass;

}


bool FDSelection::CDASFDTriggerCut(Cut& cut) {
  cut.IsBooleanCut();

  const string CDASSender = CurrEvent().GetSDEvent().GetTriggerSender();
  const string CDASAlgorithm = CurrEvent().GetSDEvent().GetTriggerAlgorithm();

  bool hasFDTrigger = true;

  const size_t SenderPos1=CDASSender.find("FD");
  const size_t SenderPos2=CDASSender.find("Fd");
  const size_t AlgoPos1=CDASAlgorithm.find("Hybrid");
  const size_t AlgoPos2=CDASAlgorithm.find("FD");

  if (SenderPos1==string::npos
      && SenderPos2==string::npos
      && AlgoPos1==string::npos
      && AlgoPos2==string::npos
      ) {
    hasFDTrigger=false;
  }

  cut.SetCurrValue(hasFDTrigger);

  if ( cut.IsAntiCut() )
    return( !hasFDTrigger );
  else
    return( hasFDTrigger );
}


bool FDSelection::allTelescopesHaveCorrectorRingCut(Cut& cut) {
  cut.IsBooleanCut();

  const Detector& theDetector = CurrEvent().GetDetector();
  const int eyeId = CurrFDEvent().GetEyeId();
  const EyeGeometry& detEye = GetDetectorGeometry()->GetEye(eyeId);

  bool allRingsOkay = true;

  for (EyeGeometry::ConstTelescopeIterator iTel = detEye.TelescopesBegin();
       iTel != detEye.TelescopesEnd();
       ++iTel) {

    const int telId = iTel->first;
    if (CurrEvent().GetEye(eyeId).MirrorIsInEvent(telId)) {
      if ( !theDetector.HasCorrectorRing(eyeId, telId) ) {
        allRingsOkay = false;
        break;
      }
    }
  }

  cut.SetCurrValue(allRingsOkay);

  if ( cut.IsAntiCut() )
    return( !allRingsOkay );
  else
    return( allRingsOkay );
}



bool FDSelection::AAARGWG4(Cut& cut) {

  const FDEvent& fdEvent = CurrFDEvent();
  const bool isHybrid = fdEvent.IsHybridEvent();
  const double Rp = fdEvent.GetFdRecGeometry().GetRp();
  const double Chi0 = fdEvent.GetFdRecGeometry().GetChi0();
  const int RecLevel = fdEvent.GetRecLevel();
  const double SDPChi2 = fdEvent.GetFdRecGeometry().GetSDPChi2();
  const double SDPndf = fdEvent.GetFdRecGeometry().GetSDPNdF();
  const double TimeFitChi2 = fdEvent.GetFdRecGeometry().GetTimeFitChi2();
  const double TimeFitNdf = fdEvent.GetFdRecGeometry().GetTimeFitNdof();
  const double axisDistance = fdEvent.GetFdRecGeometry().GetStationAxisDistance();
  const double timeOffset = fdEvent.GetFdRecGeometry().GetSDFDTimeOffset();
  const double angularTrackLength = fdEvent.GetFdRecShower().GetAngTrackObs()*180./TMath::Pi();

  const double cutCrit  = cut.GetCutValue();

  bool cutVal =
    isHybrid &&
    Rp > 0 &&
    Chi0 > 0 &&
    RecLevel >= 5 &&
    SDPChi2/SDPndf < 7 &&
    TimeFitChi2/TimeFitNdf < 8 &&
    axisDistance < 2000 &&
    timeOffset < 200 &&
    angularTrackLength > cutCrit;

  cut.SetCurrValue(cutVal);

  if ( cut.IsAntiCut() )
    return (!cutVal);
  else
    return (cutVal);
}



bool FDSelection::XmaxErrorLessThenXmaxCut(Cut & cut) {

  cut.IsBooleanCut();

  if ( cut.IsAntiCut() )
    return (CurrFDEvent().GetFdRecShower().GetXmaxError() >= CurrFDEvent().GetFdRecShower().GetXmax());
  else
    return (CurrFDEvent().GetFdRecShower().GetXmaxError() <  CurrFDEvent().GetFdRecShower().GetXmax());
}



bool FDSelection::HDSpectrumDistanceCut(Cut& cut) {

  if ( CurrFDEvent().GetRecLevel() < eHasEnergy )
    return false;

  const bool cutVal  = cut.GetCutValue();

  if(cutVal){

    const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
    const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();

    const double lgE=log10(theShower.GetEcal());
    const double dCore=(theGeometry.GetCoreEyeDistance())/1000.; // [km]
    double maxDist=0.;
    if(lgE<=18.5)
      maxDist=24.+12.*(lgE-19.);
    else
      maxDist=24.+12.*(lgE-19.)+ 6.*(lgE-18.5);

    cut.SetCurrValue(dCore);

    if ( cut.IsAntiCut() )
      return (dCore>maxDist);
    else
      return (dCore<maxDist);

  }
  else
    return true;
}


bool FDSelection::HDSpectrumDistance2012Cut(Cut& cut) {

  if (CurrFDEvent().GetRecLevel() < eHasEnergy)
    return false;

  const bool cutVal  = cut.GetCutValue();

  if(cutVal){

    const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
    const FdRecGeometry& theGeometry = CurrFDEvent().GetFdRecGeometry();

    const double lgE = log10(theShower.GetEcal());
    const double dCore = (theGeometry.GetCoreEyeDistance())/1000.; // [km]
    double maxDist=0.;
    if(lgE <= 18.5)
      maxDist= 24 + 14 * (lgE - 18.7);
    else
      maxDist= 24 + 14 * (lgE - 18.7) + 6 * (lgE - 18.5);

    cut.SetCurrValue(dCore);

    if (cut.IsAntiCut())
      return dCore > maxDist;
    else
      return dCore < maxDist;

  }
  else
    return true;
}


bool
FDSelection::minimumAverageADCVarianceCut(Cut& cut) {

  const double variance =
    pow(CurrFDEvent().GetFdRecPixel().GetMeanPixelRMS(), 2);
  cut.SetCurrValue(variance);

  const bool result = variance > cut.GetCutValue();
  return cut.IsAntiCut() ? result : !result;

}


bool FDSelection::noBadPixelsInPulseCut(Cut& cut) {

  cut.IsBooleanCut();

  const Detector&   detector = CurrEvent().GetDetector();
  const FdRecPixel& pixRec   = CurrFDEvent().GetFdRecPixel();

  if (pixRec.GetID().empty()) {
    string error = "FDSelection::noBadPixelInPulse - ERROR:"
      " no pixels found in ADST: if you are in MicroADST, probably you want use badPixel cut... ";
    throw runtime_error(error);
  }

  const vector<UShort_t>&     ids    = pixRec.GetID();
  const vector<EPixelStatus>& status = pixRec.GetStatus();

  bool IsBadPixelsInPulse = false;

  for(unsigned int i = 0; i<ids.size(); ++i) {
    if (status[i]>=ePulseRecPix &&
	detector.IsBadPixel(CurrFDEvent().GetEyeId(), pixRec.GetTelescopeId(i), pixRec.GetPixelId(i))) {
      IsBadPixelsInPulse=true;
      break;
    }
  }
  cut.SetCurrValue( (IsBadPixelsInPulse ? 1 : 0) );
  return cut.IsAntiCut() ? IsBadPixelsInPulse : !IsBadPixelsInPulse;

}



bool
FDSelection::heatOrientationUpCut(Cut& cut) {

  // the anticut selects the downward postion

  cut.IsBooleanCut();
  if (!CurrEvent().HasEye(5) && !CurrEvent().HasEye(6)){
    cut.SetCurrValue(1);
    return true;
  }
  const unsigned int eyeId = CurrFDEvent().GetEyeId();
  
  if ( eyeId != 5 && eyeId != 6) {
    // No HEAT => no influence of cut
    cut.SetCurrValue(1);
    return true;
  }
  
  const Detector& theDetector = CurrEvent().GetDetector();
  const unsigned int firstTelId = (eyeId==5)? 1:7; 
  
  unsigned int firstTelPos = 0; 
  unsigned int currentTelPos = 0;
  
  for (unsigned int telId = firstTelId; telId < firstTelId+3; ++telId) {
    
    if (!CurrFDEvent().MirrorIsInEvent(telId))
      continue;
    
    const TString& position = theDetector.GetPointingId(5, telId-firstTelId+1);
    if (position != TString("upward") && position != TString("downward")){
      string error = "FDSelection::heatdowncut - ERROR:"
        " unknown position ";
      error +=  position;
      error += " for run:";
      error += CurrFDEvent().GetRunId();
      error += " eye: ";
      error += CurrFDEvent().GetEyeId();
      throw runtime_error(error);
    }
    
    if (!firstTelPos)
      firstTelPos = (position == TString("upward")? 1:2); 
  
    currentTelPos = (position == TString("upward")? 1:2);
    
    if (firstTelPos != currentTelPos){
      // reject events crossing  mirrors with different orientations
      return false;
    }
    
  }
  //upward position
  if (firstTelPos == 1 && cut.IsAntiCut())
    return false;
 
  //downward position
  if (firstTelPos == 2 && !cut.IsAntiCut())
    return false;

  return true;

}




bool
FDSelection::potentialSDT5(Cut& cut) {

  const FdRecShower& theShower = CurrFDEvent().GetFdRecShower();
  const Detector& theDetector = CurrEvent().GetDetector();
  const DetectorGeometry& theGeometry = *GetDetectorGeometry();

  // figure out core altitude, pick station closest to projected core
  size_t sId = theGeometry.GetClosestStationId(
    theShower.GetCoreSiteCS().X(),
    theShower.GetCoreSiteCS().Y()
  );

  const double coreZ = theGeometry.GetStationPosition(sId).Z();
  const TVector3& showerCore =
    theShower.GetCoreAtAltitudeSiteCS(coreZ);

  const std::vector<unsigned int>& hexagonIds =
    theGeometry.GetHexagon(
      theGeometry.GetClosestStationId(
        showerCore.X(), showerCore.Y()
      ),
      static_cast<EGridFlag>(cut.GetCutParameters()[0])
    );

  unsigned short nActive=0;
  for (unsigned short i=0;i<hexagonIds.size();++i) {
    const size_t sId = hexagonIds[i];
    if (!theDetector.GetActiveStations()[sId])
      continue;

    bool inGridAndOk = true;
    const std::vector<SdBadStation>& badStations = CurrEvent().GetSDEvent().GetBadStationVector();
    for (size_t j = 0; j < badStations.size(); ++j)
      if (badStations[j].GetId() == sId)
      {
        inGridAndOk = false;
        break;
      }

    if (!inGridAndOk)
      continue;

    ++nActive;
  }
  const bool isPotentialSDT5 = nActive >= 7;

  cut.SetCurrValue(isPotentialSDT5 ? 1 : 0);

  return cut.IsAntiCut() ? !isPotentialSDT5 : isPotentialSDT5;
}

bool FDSelection::RejectCDASVetoPeriods(Cut& cut) {
  static vector<unsigned long long int> gpsStartCo;
  static vector<unsigned long long int> gpsStopCo;
  static vector<unsigned long long int> gpsStartHEAT;
  static vector<unsigned long long int> gpsStopHEAT;

  if (gpsStartCo.empty()) {
    string fileName;
    if (GetUserConfiguration().find("CDASVetoFileCo") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("CDASVetoFileCo")->second;
    else {
      cout << "Please specify a CDASVetoFileCo file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str());
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpsSecStart;
        unsigned int gpsNsStart;
        unsigned int gpsSecStop;
        unsigned int gpsNsStop;
        file >> gpsSecStart >> gpsNsStart >> gpsSecStop >> gpsNsStop;

        if (gpsSecStart > gpsSecStop) {
          cout << "Please check your CDASVetoFileCo file: gps start > gps stop"
               << endl;
          exit(1);
        }
        gpsStartCo.push_back(gpsSecStart*1000000000ULL+gpsNsStart);
        gpsStopCo.push_back(gpsSecStop*1000000000ULL+gpsNsStop);
      }
    }
    else {
      cout << "CDASVetoFileCo cannot be opened" << endl;
      exit(1);
    }
  }

  if (gpsStartHEAT.empty()) {
    string fileName;
    if (GetUserConfiguration().find("CDASVetoFileHEAT") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("CDASVetoFileHEAT")->second;
    else {
      cout << "Please specify a CDASVetoFileHEAT file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str());
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpsSecStart;
        unsigned int gpsNsStart;
        unsigned int gpsSecStop;
        unsigned int gpsNsStop;
        file >> gpsSecStart >> gpsNsStart >> gpsSecStop >> gpsNsStop;

        if (gpsSecStart > gpsSecStop) {
          cout << "Please check your CDASVetoFileHEAT file: gps start > gps stop"
               << endl;
          exit(1);
        }
        gpsStartHEAT.push_back(gpsSecStart*1000000000ULL+gpsNsStart);
        gpsStopHEAT.push_back(gpsSecStop*1000000000ULL+gpsNsStop);
      }
    }
    else {
      cout << "CDASVetoFileHEAT cannot be opened" << endl;
      exit(1);
    }
  }

  const int eyeId = CurrFDEvent().GetEyeId();
  const int eyeBits = static_cast<int>(cut.GetCutParameters()[0]);
  const bool eyeSet = (eyeBits / static_cast<int>(pow(10., eyeId-1))) % 10 ? true : false;
  if (!eyeSet)
    return cut.IsAntiCut() ? false : true;

  const int cutVal = static_cast<int>(cut.GetCutParameters()[1]);

  const unsigned long long int eventGPS =
      CurrFDEvent().GetGPSSecond() * 1000000000ULL +
      CurrFDEvent().GetGPSNanoSecond();

  bool vetoPeriod = false;
  if (eyeId == 4 || eyeId == 5) {
    const unsigned long long int t3Time = GetT3Time(eventGPS, eyeId);
    switch (cutVal) {
      case 1:
        if (eyeId == 4) {
          if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, true))
            vetoPeriod = true;
        }
        if (eyeId == 5) {
          if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        break;
      case 2:
        if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, true))
          vetoPeriod = true;
        break;
      case 3:
        if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, true))
          vetoPeriod = true;
        break;
      case 4:
        if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, true) ||
            CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, true))
          vetoPeriod = true;
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectCDASVetoPeriod" << endl;
        break;
    }
  }
  if (eyeId == 6) {
    bool hasCo = false;
    for (unsigned int i = 1; i <= 6; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasCo = true;
        break;
      }
    }
    bool hasHEAT = false;
    for (unsigned int i = 7; i <= 9; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasHEAT = true;
        break;
      }
    }

    // If the event has HEAT and Coihueco data, one has to take care with
    // the time stamps because they are slightly different (HEAT is usually
    // before Co). I.e. the HEAT time stamp might be outside a veto window
    // while the Co time is inside.
    const unsigned long long int t3TimeCo = hasCo ? GetT3Time(eventGPS, 4) : 0ULL;
    const unsigned long long int t3TimeHEAT = hasHEAT ? GetT3Time(eventGPS, 5) : 0ULL;
    switch (cutVal) {
      case 1:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        break;
      case 2:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartCo, gpsStopCo, true))
            vetoPeriod = true;
        }
        break;
      case 3:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        break;
      case 4:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, true) ||
              CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartCo, gpsStopCo, true) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, true))
            vetoPeriod = true;
        }
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectCDASVetoPeriod" << endl;
        break;
    }
  }

  return (cut.IsAntiCut() ? vetoPeriod : !vetoPeriod);
}

bool FDSelection::RejectFDASVetoPeriods(Cut& cut) {
  static vector<unsigned long long int> gpsStartCo;
  static vector<unsigned long long int> gpsStopCo;
  static vector<unsigned long long int> gpsStartHEAT;
  static vector<unsigned long long int> gpsStopHEAT;

  if (gpsStartCo.empty()) {
    string fileName;
    if (GetUserConfiguration().find("FDASVetoFileCo") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("FDASVetoFileCo")->second;
    else {
      cout << "Please specify a FDASVetoFileCo file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str());
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpsSecStart;
        unsigned int gpsNsStart;
        unsigned int gpsSecStop;
        unsigned int gpsNsStop;
        file >> gpsSecStart >> gpsNsStart >> gpsSecStop >> gpsNsStop;

        if (gpsSecStart > gpsSecStop) {
          cout << "Please check your FDASVetoFileCo file: gps start > gps stop"
               << endl;
          exit(1);
        }
        gpsStartCo.push_back(gpsSecStart*1000000000ULL+gpsNsStart);
        gpsStopCo.push_back(gpsSecStop*1000000000ULL+gpsNsStop);
      }
    }
    else {
      cout << "FDASVetoFileCo cannot be opened" << endl;
      exit(1);
    }
  }

  if (gpsStartHEAT.empty()) {
    string fileName;
    if (GetUserConfiguration().find("FDASVetoFileHEAT") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("FDASVetoFileHEAT")->second;
    else {
      cout << "Please specify a FDASVetoFileHEAT file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str());
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpsSecStart;
        unsigned int gpsNsStart;
        unsigned int gpsSecStop;
        unsigned int gpsNsStop;
        file >> gpsSecStart >> gpsNsStart >> gpsSecStop >> gpsNsStop;

        if (gpsSecStart > gpsSecStop) {
          cout << "Please check your FDASVetoFileHEAT file: gps start > gps stop"
               << endl;
          exit(1);
        }
        gpsStartHEAT.push_back(gpsSecStart*1000000000ULL+gpsNsStart);
        gpsStopHEAT.push_back(gpsSecStop*1000000000ULL+gpsNsStop);
      }
    }
    else {
      cout << "FDASVetoFileHEAT cannot be opened" << endl;
      exit(1);
    }
  }

  const int eyeId = CurrFDEvent().GetEyeId();
  const int eyeBits = static_cast<int>(cut.GetCutParameters()[0]);
  const bool eyeSet =
      (eyeBits / static_cast<int>(pow(10., eyeId-1))) % 10 ? true : false;
  if (!eyeSet)
    return cut.IsAntiCut() ? false : true;

  const int cutVal = static_cast<int>(cut.GetCutParameters()[1]);

  const unsigned long long int eventGPS =
      CurrFDEvent().GetGPSSecond() * 1000000000ULL +
      CurrFDEvent().GetGPSNanoSecond();

  bool vetoPeriod = false;
  if (eyeId == 4 || eyeId == 5) {
    const unsigned long long int t3Time = GetT3Time(eventGPS, eyeId);
    switch (cutVal) {
      case 1:
        if (eyeId == 4) {
          if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, false))
            vetoPeriod = true;
        }
        if (eyeId == 5) {
          if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 2:
        if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, false))
          vetoPeriod = true;
        break;
      case 3:
        if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
          vetoPeriod = true;
        break;
      case 4:
        if (CheckT3Time(t3Time, gpsStartCo, gpsStopCo, false) ||
            CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
          vetoPeriod = true;
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectFDASVetoPeriod" << endl;
        break;
    }
  }
  if (eyeId == 6) {
    bool hasCo = false;
    for (unsigned int i = 1; i <= 6; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasCo = true;
        break;
      }
    }
    bool hasHEAT = false;
    for (unsigned int i = 7; i <= 9; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasHEAT = true;
        break;
      }
    }

    // If the event has HEAT and Coihueco data, one has to take care with
    // the time stamps because they are slightly different (HEAT is usually
    // before Co). I.e. the HEAT time stamp might be outside a veto window
    // while the Co time is inside.
    const unsigned long long int t3TimeCo = hasCo ? GetT3Time(eventGPS, 4) : 0ULL;
    const unsigned long long int t3TimeHEAT = hasHEAT ? GetT3Time(eventGPS, 5) : 0ULL;
    switch (cutVal) {
      case 1:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 2:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartCo, gpsStopCo, false))
            vetoPeriod = true;
        }
        break;
      case 3:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 4:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartCo, gpsStopCo, false) ||
              CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartCo, gpsStopCo, false) ||
              CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectFDASVetoPeriod" << endl;
        break;
    }
  }

  return (cut.IsAntiCut() ? vetoPeriod : !vetoPeriod);
}

bool FDSelection::RejectT3VetoPeriods(Cut& cut) {
  static vector<unsigned long long int> gpsStartCo;
  static vector<unsigned long long int> gpsStopCo;
  static vector<unsigned long long int> gpsStartHEAT;
  static vector<unsigned long long int> gpsStopHEAT;

  if (gpsStartHEAT.empty()) {
    string fileName;
    if (GetUserConfiguration().find("T3VetoFileHEAT") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("T3VetoFileHEAT")->second;
    else {
      cout << "Please specify a T3VetoFileHEAT file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str());
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpsSecStart;
        unsigned int gpsNsStart;
        unsigned int gpsSecStop;
        unsigned int gpsNsStop;
        file >> gpsSecStart >> gpsNsStart >> gpsSecStop >> gpsNsStop;

        if (gpsSecStart > gpsSecStop) {
          cout << "Please check your T3VetoFileHEAT file: gps start > gps stop"
               << endl;
          exit(1);
        }
        gpsStartHEAT.push_back(gpsSecStart*1000000000ULL+gpsNsStart);
        gpsStopHEAT.push_back(gpsSecStop*1000000000ULL+gpsNsStop);
      }
    }
    else {
      cout << "T3VetoFileHEAT cannot be opened" << endl;
      exit(1);
    }
  }

  const int eyeId = CurrFDEvent().GetEyeId();
  const int eyeBits = static_cast<int>(cut.GetCutParameters()[0]);
  const bool eyeSet =
      (eyeBits / static_cast<int>(pow(10., eyeId-1))) % 10 ? true : false;
  if (!eyeSet)
    return cut.IsAntiCut() ? false : true;

  const int cutVal = static_cast<int>(cut.GetCutParameters()[1]);

  const unsigned long long int eventGPS =
      CurrFDEvent().GetGPSSecond() * 1000000000ULL +
      CurrFDEvent().GetGPSNanoSecond();

  bool vetoPeriod = false;
  if (eyeId == 4 || eyeId == 5) {
    const unsigned long long int t3Time = GetT3Time(eventGPS, eyeId);
    switch (cutVal) {
      case 1:
        if (eyeId == 4) {
          // Not useful, there is no T3Veto in Coihueco
        }
        if (eyeId == 5) {
          if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 2:
        // Not useful, there is no T3Veto in Coihueco
        break;
      case 3:
        if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
          vetoPeriod = true;
        break;
      case 4:
        if (CheckT3Time(t3Time, gpsStartHEAT, gpsStopHEAT, false))
          vetoPeriod = true;
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectT3VetoPeriod" << endl;
        break;
    }
  }
  if (eyeId == 6) {
    bool hasCo = false;
    for (unsigned int i = 1; i <= 6; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasCo = true;
        break;
      }
    }
    bool hasHEAT = false;
    for (unsigned int i = 7; i <= 9; ++i) {
      if (CurrFDEvent().MirrorIsInEvent(i)) {
        hasHEAT = true;
        break;
      }
    }

    // If the event has HEAT and Coihueco data, one has to take care with
    // the time stamps because they are slightly different (HEAT is usually
    // before Co). I.e. the HEAT time stamp might be outside a veto window
    // while the Co time is inside.
    const unsigned long long int t3TimeCo = hasCo ? GetT3Time(eventGPS, 4) : 0ULL;
    const unsigned long long int t3TimeHEAT = hasHEAT ? GetT3Time(eventGPS, 5) : 0ULL;
    switch (cutVal) {
      case 1:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          // Not useful, there is no T3Veto in Coihueco
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 2:
        // Not useful, there is no T3Veto in Coihueco
        break;
      case 3:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      case 4:
        if (hasCo && hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasCo) {
          if (CheckT3Time(t3TimeCo, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        else if (hasHEAT) {
          if (CheckT3Time(t3TimeHEAT, gpsStartHEAT, gpsStopHEAT, false))
            vetoPeriod = true;
        }
        break;
      default:
        cout << "Unknown cutValue " << cutVal << " in RejectT3VetoPeriod" << endl;
        break;
    }
  }

  return (cut.IsAntiCut() ? vetoPeriod : !vetoPeriod);
}



bool FDSelection::pbrassMaxProtonIronDifference(Cut & cut) {

  vector<Double_t> userData = CurrEvent().GetUserData();

  if (userData.size() < 3) {
    const DetectorGeometry* theGeometry = GetDetectorGeometry();
    T2TriggerProb t2prob(&theGeometry);
    
    userData.resize(3);
    userData[0] = 0.;
    userData[1] = GetTriggerProbProton(CurrEvent(), t2prob);
    userData[2] = GetTriggerProbIron(CurrEvent(), t2prob);
  }

  const double protonIronDiff = fabs(userData[1]-userData[2]);
  cut.SetCurrValue(protonIronDiff);
  const double cutVal = cut.GetCutValue();

  bool ok = protonIronDiff <= cutVal;
  if (cut.IsAntiCut())
    ok = !ok;
  return ok;
}



bool FDSelection::minPBrass(Cut & cut) {

  vector<Double_t> userData = CurrEvent().GetUserData();

  if (userData.size() < 3) {
    const DetectorGeometry* theGeometry = GetDetectorGeometry();
    T2TriggerProb t2prob(&theGeometry);
    
    userData.resize(3);
    userData[0] = 0.;
    userData[1] = GetTriggerProbProton(CurrEvent(), t2prob);
    userData[2] = GetTriggerProbIron(CurrEvent(), t2prob);
  }

  const double meanPBrass = userData[1];
  cut.SetCurrValue(meanPBrass);
  const double cutVal = cut.GetCutValue();

  bool ok = meanPBrass >= cutVal;
  if (cut.IsAntiCut())
    ok = !ok;
  return ok;
}


bool FDSelection::selectTelescopeCut(Cut & cut) {

  const int    eyeVal = (int) cut.GetCutParameters()[0];
  const int    telVal = (int) cut.GetCutParameters()[1];
  const bool   single = (bool) cut.GetCutParameters()[2];

  const double eyeID  = CurrFDEvent().GetEyeId();
  const int    eyeBit = (eyeVal / (int) (pow(10.,eyeID-1)))%10;

  bool telInEvent = true;
  if ( eyeBit==1 ) {
    bool acceptMirror = single ? CurrFDEvent().GetMirrorsInEye()==1 : true;
    telInEvent = CurrFDEvent().MirrorIsInEvent(telVal) && CurrFDEvent().IsXmaxInTelFOV(telVal) && acceptMirror;
  }

  cut.SetCurrValue( (telInEvent ? 0 : 1) );
  return telInEvent;
}



bool FDSelection::CheckT3Time(const unsigned long long int t3Time,
    const vector<unsigned long long int>& startTimes,
    const vector<unsigned long long int>& stopTimes,
    const bool cdasVeto) {
  bool inDeadTime = false;
  vector<unsigned long long int>::const_iterator bound =
      lower_bound(stopTimes.begin(), stopTimes.end(), t3Time);
  if (bound != stopTimes.end()) {
    const unsigned int low =
        static_cast<unsigned int>(bound - stopTimes.begin());
    if (cdasVeto) {
      if (t3Time >= startTimes[low] && t3Time < stopTimes[low])
        inDeadTime = true;
    }
    else {
      if (t3Time > startTimes[low] && t3Time <= stopTimes[low])
        inDeadTime = true;
    }
  }
  return inDeadTime;
}

unsigned long long int FDSelection::GetT3Time(const unsigned long long int eventGPS,
    const unsigned int eyeId) {
  static vector<unsigned long long int> t3TimesCo;
  static vector<unsigned long long int> t3TimesHEAT;

  // Only for Coihueco and HEAT
  if (eyeId < 4 || eyeId > 5)
    return eventGPS;

  if (t3TimesCo.empty()) {
    string fileName;
    if (GetUserConfiguration().find("T3TimesFileCo") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("T3TimesFileCo")->second;
    else {
      cout << "Please specify a T3TimesFileCo file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str(), ios::in);
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpssec;
        unsigned int gpsns;
        file >> gpssec >> gpsns;

        t3TimesCo.push_back(gpssec * 1000000000ULL + gpsns);
      }
    }
    else {
      cout << "T3TimesFileCo cannot be opened" << endl;
      exit(1);
    }
  }
  if (t3TimesHEAT.empty()) {
    string fileName;
    if (GetUserConfiguration().find("T3TimesFileHEAT") !=
        GetUserConfiguration().end())
      fileName = GetUserConfiguration().find("T3TimesFileHEAT")->second;
    else {
      cout << "Please specify a T3TimesFileHEAT file in analysis.config" << endl;
      exit(1);
    }

    ifstream file(fileName.c_str(), ios::in);
    if (file.is_open()) {
      while (file.good()) {
        unsigned int gpssec;
        unsigned int gpsns;
        file >> gpssec >> gpsns;

        t3TimesHEAT.push_back(gpssec * 1000000000ULL + gpsns);
      }
    }
    else {
      cout << "T3TimesFileHEAT cannot be opened" << endl;
      exit(1);
    }
  }

  unsigned long long int t3Time = eventGPS;
  if (eyeId == 4) {
    vector<unsigned long long int>::const_iterator bound =
        lower_bound(t3TimesCo.begin(), t3TimesCo.end(), eventGPS);
    if (bound != t3TimesCo.end()) {
      const unsigned int low =
          static_cast<unsigned int>(bound - t3TimesCo.begin());
      if (eventGPS - t3TimesCo[low-1] < t3TimesCo[low] - eventGPS)
        t3Time = t3TimesCo[low-1];
      else
        t3Time = t3TimesCo[low];
    }
  }
  if (eyeId == 5) {
    vector<unsigned long long int>::const_iterator bound =
        lower_bound(t3TimesHEAT.begin(), t3TimesHEAT.end(), eventGPS);
    if (bound != t3TimesHEAT.end()) {
      const unsigned int low =
          static_cast<unsigned int>(bound - t3TimesHEAT.begin());
      if (eventGPS - t3TimesHEAT[low-1] < t3TimesHEAT[low] - eventGPS)
        t3Time = t3TimesHEAT[low-1];
      else
        t3Time = t3TimesHEAT[low];
    }
  }

  return t3Time;
}
