#include <iostream>
#include <fstream>
#include <string>
#include <set>

#include "RecEventFile.h"
#include "RecEvent.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"
#include "Analysis.h"
#include "UtilityFunctions.h"

#include "IoAuger.h"
#include "AugerEvent.h"

#include <TDatime.h>
#include <TTree.h>

using namespace std;

// global variables
AugerFile* fgAugerFile;
unsigned int fgAugerFileNumber;
unsigned int fgNoEventsPerFile;


struct EventIdStruct {

  EventIdStruct(std::string augerId, unsigned int sdId, unsigned int yymmdd) :
    fAugerId(augerId), fSDId(sdId), fYYMMDD(yymmdd)
  {}

  std::string fAugerId;
  unsigned int fSDId;
  unsigned int fYYMMDD;

};

inline bool operator<(const EventIdStruct& lhs, const EventIdStruct& rhs) {

  if ( lhs.fAugerId < rhs.fAugerId )
    return true;
  else
    return false;

}


/************************************************************/
void usage(){
  cout << "\n  SelectAndFindIoAugerEvent: utility program to select\n"
       << "    events from ADST file's and find&extract the corresponding\n"
       << "    IoAuger events.\n\n"

       << "Usage: SelectAndFindIoAugerEvent <textFileWithRawDataFileNames> <noEventsPerOutputFile> <ADSTFileNames ...>\n"
       << endl;
}

/******************************************************************/
void nextOutputFile() {

  if (fgAugerFile != NULL)
    fgAugerFile->Close();

  if (fgAugerFileNumber == 0) {
    fgAugerFile = new AugerFile("SelectedEvents_IoAuger.root", AugerFile::eWrite);
  }
  else {
    char buffer[1024];
    sprintf(buffer, "SelectedEvents_IoAuger_%u.root", fgAugerFileNumber);
    fgAugerFile = new AugerFile(buffer, AugerFile::eWrite);
  }
  fgAugerFileNumber++;
}


/*********************************************************/
string parseAugerIdFromKeyName(string keyname) {
  string id;
  int indexhash = -1;
  for (unsigned int i = 0; i < keyname.size()-1; i++) {
    if (keyname[i] == '#') {
      indexhash = i;
      break;
    }
  }
  if (indexhash < 0) {
    cerr << "This should never happen! There is no hash '#' in the key name! The key is:\n" << keyname << endl;
    return id;
  }

  id = keyname.substr(0, indexhash);
  return id;
}

/*********************************************************/
int findRawEvents(string filelistfile, set<EventIdStruct>& selectedEvents) {

  ifstream fileList;
  fileList.open(filelistfile.c_str());
  if ( !fileList.is_open() ) {
    cerr << " RecSelectAndFindIoAugerEvent: - Error could not read IoAuger file list from file " 
         << filelistfile << "\n"
         << "             exit ..." << endl;
    exit(1);
  }

  cout << " Searching IoAuger events in the raw data files."
       << "\n This may take a while..." << endl;
  int nRaw = 0;
  while (1) {
    if (fileList.good() ) {
      string thisFile;
      fileList >> thisFile;
      if (thisFile == "")
        break;
      cout << "==[findRawEvents]==> " << thisFile << " (found " 
           << nRaw << " of " << selectedEvents.size() << ")" << endl;
      TFile* rootfile = new TFile(thisFile.c_str(), "READ");
      if (rootfile == NULL) {
        cout << "Could not open root file " << thisFile << ". Skipping it." << endl;
        continue;
      }
      rootfile->cd();
      TIter nextkey(rootfile->GetListOfKeys());
      TKey *key;
      while ( (key = (TKey*)nextkey()) ) {
        string name(key->GetName());
        string augerId = parseAugerIdFromKeyName(name);
        EventIdStruct thisId = EventIdStruct(augerId,0,0);
        set<EventIdStruct>::iterator selectIter = selectedEvents.find(thisId);
        bool exists = (selectIter != selectedEvents.end());
 
        if (exists) {
          if (nRaw != 0 && nRaw % fgNoEventsPerFile == 0)
            nextOutputFile();

          nRaw++;

          AugerEvent *event = (AugerEvent*)key->ReadObj();
          event->EventId = strtoll(augerId.c_str(), NULL, 0);

          fgAugerFile->Write(*event, false); // bool is verbosity
          delete event;
          selectedEvents.erase(selectIter);
        }
      }
      if (key != NULL) delete key;
      rootfile->Close();
      if (rootfile != NULL) delete rootfile;

      if ( fileList.eof() )
        break;
    }
    else
      break;
  }

  cout << "\nWrote " << nRaw << " IoAuger events to output file." << endl;

  return nRaw;
}


/******************************************************************/
int main(int argc, char **argv) {
  TTree::SetMaxTreeSize(200000000000ll);
  fgAugerFileNumber = 0;

  if ( argc < 4 ) {
    usage();
    exit(1);
  }

  set<EventIdStruct> selectedEvents;

  string filelistFile(argv[1]);

  fgNoEventsPerFile= (unsigned int) atoi(argv[2]);

  int j=3;
  vector<string> fileNames;
  while ( argv[j] != NULL ) {
    fileNames.push_back(string(argv[j]));
    j++;
  }

  if ( fileNames.empty() ) {
    usage();
    return 1;
  }

  RecEvent * theRecEvent = new RecEvent();
  DetectorGeometry * theGeometry = new DetectorGeometry();

  RecEventFile dataFile(fileNames); 
  dataFile.SetBuffers(&theRecEvent);
  
  dataFile.ReadDetectorGeometry(*theGeometry);

  Analysis analysis(&theGeometry,&theRecEvent,"analysis.config", false);

  unsigned int noADSTs = 0;
  while (dataFile.ReadNextEvent()==RecEventFile::eSuccess ) {
    noADSTs++;
    if (noADSTs % 100 == 0)
      UtilityFunctions::ShowProgress(noADSTs,dataFile.GetNEvents());

    if ( ! analysis.IsGoodSD() ) continue;
    if ( ! analysis.IsGoodSim() ) continue;

    if ( analysis.HasFDSelection() ) {
      bool goodEye = false;
      for ( RecEvent::EyeIterator iEye = theRecEvent->EyesBegin();
            iEye != theRecEvent->EyesEnd(); ++iEye ) {
        if ( analysis.IsGoodEye(iEye->GetEyeId()) ) {
          goodEye = true;
          break;
        }
      }
      if ( !goodEye ) continue;
    }

    EventIdStruct thisId(theRecEvent->GetAugerId(),theRecEvent->GetSDEvent().GetEventId(),
                   theRecEvent->GetYYMMDD());
    selectedEvents.insert(thisId);
  }


  UtilityFunctions::ShowProgress(noADSTs,dataFile.GetNEvents());
  cout << "\n\nFinished analysing. Selected " << selectedEvents.size() << " events."<<endl;

  // open the first output file
  nextOutputFile();

  findRawEvents(filelistFile, selectedEvents);
  fgAugerFile->Close();

  for ( set<EventIdStruct>::iterator selectIter = selectedEvents.begin();
        selectIter != selectedEvents.end(); ++selectIter )
      cout << " auger Id " << selectIter->fAugerId 
           << " SD Id " << selectIter->fSDId 
           << " yymmdd " << selectIter->fYYMMDD << " not found in raw data! " << endl;


}

  
