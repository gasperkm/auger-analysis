#ifndef _include_SdPlots_h__
#define _include_SdPlots_h__

#include <TQObject.h>
#include "VPlots.h"
#include "ArrayPlot.h"
#include "FileInfo.h"

#include <string>

class TGCompositeFrame;
class TGHorizontalFrame;
class TGVerticalFrame;
class TGLayoutHints;
class TCanvas;
class TGHSlider;
class TGListBox;
class TObjArray;
class RecEvent;
class SdRecStation;
class GenStation;
class StyleManager;
class SDEvent;
class DetectorGeometry;
class TGVButtonGroup;
class TGRadioButton;
class TGCheckButton;
class ArrayPlot;
class TGDoubleHSlider;
class TGTab;

class SdPlots : public TQObject, public VPlots {

private:
  SdPlots();

public:
  SdPlots (TGCompositeFrame* main, 
	   const StyleManager* const * styleManager,
	   const DetectorGeometry* const * geom,		  
	   const RecEvent* const * event, 
	   const bool& ismc);
    
  ~SdPlots();

  void Clear();
  void Update();
  void DoSdButton(); 
  void SelectStation();  

  void DoSdReleased();
  void DoSdPressed();
  std::string PrintPostScript();
  void HandleArrayClicked(Int_t envent, Int_t st, Int_t py, TObject *sel);
  void DrawAllTraces(TCanvas *myCanvas);
  void UpdateArrayPlot();
  void UpdateMPD(const SdRecStation& station);
  void SetShowFD(const bool what) {fShowFD = what;}
  void SetShowMC(const bool what) {fShowMC = what;}
  void SetShowMCTraces(const bool what){ fShowMCTraces= what; }
  void SetShowAllTraces(const bool what) { fShowAllTraces = what;}
  void SetShowBadStations(const bool what) { fArrayPlot->SetShowBadStations(what); }

  void SetLDFType(const ELDFType type) {fLDFType= type;}
  void SetShowerPlaneArray(const bool what) {fShowShowerArray = what;}
  void SetRecStationClassVersion(const int version)
      {fRecStationClassVersion= version;}
  void DoTracesSlider(); 
 
private:
  
  void UpdateStationsList();
  void UpdateTracesPlots(int a=1);
  void SdEventInfo(TCanvas *);
  void SdMCInfo();
  void DrawLDF();
  void DrawTimeResiduals();
  void DrawTraces(int pmtId, const SdRecStation &);
  void DrawTracesAllPMTs(const SdRecStation &);
  void DrawMCTraces(int pmtId, const GenStation &, const SdRecStation &);
  void CreateTracesPads(TCanvas & canvas, std::string padname);


  const StyleManager* const * fStyleManager; // for plotting style options
  const RecEvent* const * fEvent;   // this is just the current event reference
  const bool& fIsMC;
  const DetectorGeometry* const * fDetectorGeometry;
  
  ArrayPlot * fArrayPlot;

  bool fShowFD;
  bool fShowMC;
  bool fShowAllTraces;

  bool fShowShowerArray;
  int  fSdTimeRes; // 1-plane time res, 2- curv time res, 0-no time res
  bool fSdFallTime;
  bool fSdRiseTime;
  bool fSdT50;
 
  int fSdColorStatus;
  int fRecStationClassVersion;
  bool fHasFADCTraces;
  bool fHasVEMTraces;
  bool fSdArrayOnStatus;
  bool fSdLDFOnStatus;

  TGCompositeFrame *fMain;
  TGListBox *fStationsListBox;
  
  TGTab *fSDEventTab;
  TGTab *fSDEventInfoTab;

  TCanvas *fCanvasArray;
  TCanvas *fCanvasLDF;
  TCanvas *fCanvasTRes;
  TCanvas *fCanvasInfo;
  TCanvas *fCanvasMCInfo;
  TCanvas *fCanvasStations;
  TCanvas *fCanvasPMTVEM;
  TCanvas *fCanvasPMTLG;
  TCanvas *fCanvasPMTHG;
  TCanvas *fCanvasMPD;

  //  TGDoubleHSlider* fTracesSlider; 
  
  TCanvas *fCanvasTest;
  TGHSlider *fArrayZoomButton;

  TObjArray * fPMTObjects;
  TObjArray * fEventObjects;
  TObjArray * fTracesObjects;

  TGRadioButton * fColButton1;
  TGRadioButton * fColButton2;
  TGRadioButton * fColButton3;
  TGRadioButton * fColButton4;
  //  TGRadioButton * fColButton5;
  TGRadioButton * fArrayButton;
  TGRadioButton * fTracesButton;
  TGRadioButton * fLDFButton;
  TGRadioButton * fLDFResButton;
  TGRadioButton * fEventTimeRes; 
  TGRadioButton * fEventCurvTimeRes;
  TGRadioButton * fEventNoTimeRes;
 
  TGCheckButton * fEventFallTime;
  TGCheckButton * fEventRiseTime;
  TGCheckButton * fEventT50;
  
  ELDFType fLDFType; 
  
  bool fShowMCTraces;
  
 
  ClassDef (SdPlots, 7);
};



#endif
