#ifndef _include_AugerPlots_h__
#define _include_AugerPlots_h__

#include <TGFrame.h>
#include "VPlots.h"
#include <TString.h>
#include <TMarker.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include "EventBrowserSignals.h"

#include <vector>

class TCanvas;
class TGWindow;
class TGTab;
class TGHSlider;
class TGCompositeFrame;
class TObjArray;
class RecEvent;
class RecEventFile;
class ArrayPlot;
class Display3D;
class DetectorGeometry;
class StyleManager;

class AugerPlots : public TGFrame, public VPlots {

private:
  AugerPlots();

public:
  AugerPlots(TGCompositeFrame* main,
	     const StyleManager* const * styleManager,
	     const DetectorGeometry* const * geom,
	     const RecEvent* const * event,
	     const bool& ismc);
  ~AugerPlots();
  void Update();
  void Clear();
  void UpdateArrayPlot();
  void Update3DPlot();
  void Set3DFDButtons(EButtonSignals e);
  void SetShowMC (bool f) {fShowMC = f;}
  void SetFDT3Flag(bool f);
  std::string PrintPostScript();
  void DrawProfilePlot();
  void UpdatePalette();
  void Save3D(const std::string &str) const;

  // SYSTEM ENTRY for signal handling
  Bool_t ProcessMessage (Long_t msg, Long_t parm1, Long_t parm2);
  void HandleGalacticButton();
  void HandleShowerParameterButton();

  void LoadSources(char* fileName);
  void SetRecStationClassVersion(int version){
      fRecStationClassVersion= version;}
private:

  void Draw2DPlot();
  void DrawShowerParameterPlot();
  void DrawEnergyPlot();
  void DrawXmaxPlot();
  void DrawAnglePlot();
  void DrawEventInfo();

  void GalactProject(Int_t iproj, Double_t xgphi, Double_t ygthe, Double_t& xp, Double_t& yp);
  void PlotGalacticAxis();
  void HammerAitoff(double gLong, double gLat, double& x, double& y);

  const StyleManager* const * fStyleManager;
  const RecEvent* const * fEvent;
  const bool& fIsMC;
  const DetectorGeometry* const * fDetectorGeometry;

  ArrayPlot* fArrayPlot;
  bool fShowMC;
  TGTab* fArrayTab;
  TCanvas* fProfilePlot;
  TCanvas* f2DPlot;
  TCanvas* fCanvasInfo;
  TCanvas* fEnergyPlot;
  TCanvas* fAnglePlot;
  TGHSlider* fArrayZoomButton;
  TGHSlider* fProfileRebinButton;

  TGCompositeFrame* fDisplay3DFrame;
  Display3D* fDisplay3D;

  TGRadioButton* fEnergyOverviewButton;
  TGRadioButton* fXmaxOverviewButton;

  TGRadioButton *fHammerAitoffButton;
  TGRadioButton *fSansonFlamsteedButton;
  TGRadioButton *fParabolicButton;
  int fProjectionType;

  TObjArray* fEventInfoObjects;
  TObjArray* fAnglePlotObjects;
  TObjArray* fShowerParameterObjects;
  TObjArray* f2DPlotObjects;
  TObjArray* fProfilePlotObjects;

  std::vector<std::pair<double,double> > fSourceCatalogue;
  std::vector<std::string> fSourceNames;
  int fRecStationClassVersion;
  ClassDef (AugerPlots, 2);
};



#endif
