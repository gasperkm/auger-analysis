#include "EventBrowser.h"

#include "EventBrowserMenu.h"
#include "EventBrowserSignals.h"
#include "VPlots.h"
#include "FdPlots.h"
#include "SdPlots.h"
#include "RdPlots.h"
#include "AugerPlots.h"
#include "RiseTimePlots.h"
#include "SdSimulationPlots.h"

#include "StatusBar.h"
#include "EventSelection.h"
#include "StyleManager.h"
#include "OfflineConfigurationPopup.h"

#include "RecEventFile.h"
#include "RecEvent.h"
#include "EventInfo.h"
#include "FileInfo.h"
#include "DetectorGeometry.h"

#include "TReadProgress.h"
#include <TROOT.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TCanvas.h>
#include <TChain.h>
#include <TApplication.h>
#include <TLatex.h>
#include <TString.h>
#include <KeySymbols.h>

#include <TGFrame.h>
#include <TGTab.h>
#include <TGFileDialog.h>
#include <TGComboBox.h>
#include <TGNumberEntry.h>
#include <TGMsgBox.h>

#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <algorithm>
using namespace std;



ClassImp (EventBrowser);


string
EventBrowser::GetVersion()
{
  const string SVNname ("$HeadURL: https://devel-ik.fzk.de/svn/auger/Offline/trunk/ADST/EventBrowser/src/EventBrowser.cc $");

  vector<string> releases;
  releases.push_back("/tags/");
  releases.push_back("/branches/");

  for (unsigned int i=0; i<releases.size(); ++i)
    if (SVNname.find(releases[i])!=string::npos) {
      const int pos = SVNname.find(releases[i]);
      return SVNname.substr(pos+releases[i].size(),
                            SVNname.find("/",pos+releases[i].size()+1)-
                            pos-releases[i].size());
    }

  return string("trunk");
}

string
EventBrowser::GetRevision()
{
  const string SVNversion ("$Id: EventBrowser.cc 20743 2012-03-30 10:18:04Z munger $");
  istringstream iss(SVNversion);
  string version;
  iss >> version >> version >> version;
  return version;
}

string
EventBrowser::GetDate()
{
  const string SVNversion ("$Id: EventBrowser.cc 20743 2012-03-30 10:18:04Z munger $");
  istringstream iss(SVNversion);
  string date;
  iss >> date >> date >> date >> date;
  return date;
}

void
EventBrowser::Welcome()
{
  // -- RecEvent version --
  ostringstream RecEventVersion;
  RecEventVersion << RecEvent::GetReleaseName() << " " << RecEvent::GetVersion()
                  << " (SVN: " << RecEvent::GetSVNVersion()
                  << " rev "<< RecEvent::GetSVNRevision() << ")";

  string space = "       ";

  ostringstream line1, line2, line3;
  cout << "\n   ____|                |   __ ) \n"
       << "   __|        _ \\ __ \\  __| __ \\"
       << "   __| _ \\           __|  _ \\  __|\n"
       << "   |   \\ \\ /  __/ |   | |   |   | |  "
       << " (   |\\ \\  \\ /\\__ \\  __/ |\n"
       << "  _____|\\_/ \\___|_|  _|\\__| ___/ _|"
       << "  \\___/  \\_/\\_/ ____/\\___|_|\n";

  line1 << ">>>>>>>> EventBrowser " << GetVersion()
        << " (rev " << GetRevision() <<  ")" << " <<<<<<<<";
  line2 << "ADST: " << RecEventVersion.str();
  line3 << "KIT "  << GetDate();

  cout << "\n\n" << space << line1.str() << "\n\n";
  int nSpace = (line1.str().length() - line2.str().length()) / 2;
  for (int iSpace=0; iSpace<nSpace; iSpace++) cout << " ";
  cout << space << line2.str() << "\n\n";
  nSpace = (line1.str().length() - line3.str().length()) / 2;
  for (int iSpace=0; iSpace<nSpace; iSpace++) cout << " ";
  cout << space << line3.str() << "\n\n";
#ifdef AUGER_RADIO_ENABLED
  cout << space << " Radio enabled \n \n" ;
#endif
  ostringstream info;
  info << " ***********************************************************************\n"
       << " * - please report bugs to www.auger.unam.mx/bugzilla (Package: ADST)  *\n"
       << " * - user info at https://www.auger.unam.mx/mailman/listinfo/adst-user *\n"
       << " ***********************************************************************\n"
       << "\n";
  cout << info.str();
}


/*****************************************************************************/
EventBrowser::EventBrowser(const TGWindow * p,
                           UInt_t width, UInt_t height,
                           const vector<string> & fileNames,
                           const bool batchMode) :
  TGMainFrame(p, width, height),
  fIsInBatchMode(batchMode),
  fIsMC (false),
  fEventFile (0),
  fEvent (0),
  fTotEvent (0),
  fGeometry (0),
  fMenu(0),
  fCuts(0),
  fSDPlots(0),
  fSdSimPlots(0),
  fRiseTimePlots(0),
  fAugerPlots(0),
  fAugerTabIndex(0),
  fFDTabIndex(0),
  fSDTabIndex(0),
  fSDMCTabIndex(0),
  fRDTabIndex(0),
  fCutTabIndex(0)
{
  // welcome printout
  Welcome();

  // style manager loading
  fStyleManager = new StyleManager();

  if (!fStyleManager->IsInitialized())
    exit(1);
  fStyleManager->UpdateMuonPalette();


  // menu, auger tab, status bar

  const UInt_t menuHeight = 25;
  const UInt_t statusBarHeight = 25;
  const int tmpHeight = (int)height - (int)menuHeight - (int)statusBarHeight;
  const UInt_t tabHeight = tmpHeight > 100 ? tmpHeight : 100;

  fMenu = new EventBrowserMenu(this);

  fTabs = new TGTab(this, width, tabHeight);
  TGLayoutHints* tabLayout =
    new TGLayoutHints(kLHintsCenterX|kLHintsCenterY, 3, 3, 3, 3);
  AddFrame(fTabs, tabLayout);

  fAugerTabIndex = fTabs->GetNumberOfTabs();
  fAugerFrame  = fTabs->AddTab("Auger");
  fAugerPlots  = new AugerPlots(fAugerFrame,
				&fStyleManager,
				&fGeometry,
				&fEvent,
				fIsMC);
  fPlotVector.push_back(fAugerPlots);

  fStatusBar = new StatusBar(this, width, statusBarHeight);

  // open ADST if provided
  if (!fileNames.empty())
    OpenOfflineOutput(fileNames);
  else {
    if (!fIsInBatchMode) {
      MapSubwindows();
      Resize (GetDefaultSize());
      MapWindow();
    }
  }

  // lets go ...
  if (!fIsInBatchMode) {
    SetWindowName("EventBrowser");
    InitKeyStrokes();
  }

}



/*****************************************************************************/
EventBrowser::~EventBrowser()
{
  if (fEventFile)
    fEventFile->Close();

  delete fEventFile;
  delete fGeometry;

  delete fCuts;
  delete fSDPlots;
  delete fSdSimPlots;
  //  delete fRiseTimePlots;
  delete fAugerPlots;

  for (vector<FdPlots*>::iterator iTab = fFDPlots.begin();
       iTab != fFDPlots.end();
       ++iTab)
    delete (*iTab);

  delete fTabs;
  delete fMenu;
}


void
EventBrowser::KeepAnimatedEpsFiles()
{
  for (vector<FdPlots*>::iterator iTab = fFDPlots.begin();
       iTab != fFDPlots.end();
       ++iTab)
    (*iTab)->KeepAnimatedEpsFiles();
}

/*****************************************************************************/
bool
EventBrowser::HandleKey(Event_t *event)
{
  unsigned int keysym;
  char str[2];
  gVirtualX->LookupString(event, str, sizeof(str), keysym);

  if (event->fType == kGKeyPress) {
    EKeySym theKeyPressed = (EKeySym) keysym;
    if (theKeyPressed == kKey_q || theKeyPressed == kKey_Q)
      CloseWindow();
    else if (theKeyPressed == kKey_s || theKeyPressed == kKey_S)
      SaveEvent();
    else if (theKeyPressed == kKey_p || theKeyPressed == kKey_P)
      PrintPS();
    else if (theKeyPressed == kKey_Escape)
      CloseWindow();
    else if (theKeyPressed == kKey_Down || theKeyPressed == kKey_PageDown)
      ChangeEvent(eNextEvent);
    else if (theKeyPressed == kKey_Up || theKeyPressed == kKey_PageUp)
      ChangeEvent(ePreviousEvent);
    else if (theKeyPressed == kKey_Home)
      ChangeEvent(eFirstEvent);
    else if (theKeyPressed == kKey_End)
      ChangeEvent(eLastEvent);
    else if (theKeyPressed == kKey_Space || theKeyPressed == kKey_Backtab)
      ChangeTab(ePreviousTab);
    else if (theKeyPressed == kKey_Tab)
      ChangeTab(eNextTab);
    else if (theKeyPressed == kKey_a || theKeyPressed == kKey_A)
      DumpEventASCII();
  }

  return kTRUE;
}

/*****************************************************************************/
Bool_t
EventBrowser::ProcessMessage(Long_t msg, Long_t parm1, Long_t parm2)
{
  // Process messages coming from widgets associated with the dialog.

  //  cout << " :ProcessMessage1 " << msg << " " << parm1 << " " << parm2 << endl; // debug
  //  cout << "                 " <<   GET_MSG (msg) << " " << GET_SUBMSG (msg) << endl;

  switch (GET_MSG (msg)) {

  case kC_COMMAND:
    switch (GET_SUBMSG (msg)) {
    case kCM_COMBOBOX: {
      if (parm1 == eStatusBarEventList) {
        fCuts->SetCurrentEvent(parm2);
        fEventFile->ReadEvent(parm2);
        UpdateBrowser();
      }
    }
      break;
    case kCM_TAB: {
      if (!fEventInfo.empty())
        UpdateTab(parm1);
    }
      break;
    case kCM_BUTTON: {
      if (parm1 == eNextEvent)
        ChangeEvent(eNextEvent);
      else if (parm1 == ePreviousEvent)
        ChangeEvent(ePreviousEvent);
      else if (parm1 == eFirstEvent)
        ChangeEvent(eFirstEvent);
      else if (parm1 == eLastEvent)
        ChangeEvent(eLastEvent);
      else if (parm1 == eResetSelection)
        fCuts->ResetSelection();
      else if (parm1 == eHQFDSelection)
        fCuts->SetHQFDSelection();
      else if (parm1 == eHQSDSelection)
        fCuts->SetHQSDSelection();
      else if (parm1 == eFileSelection)
        fCuts->DoFileSelection();
      else if (parm1 == eUpdateSelection) {
        fCuts->SelectEvents(fEventInfo,fStatusBar->GetEventList());
        ChangeEvent(eCurrentEvent);
      } else if (parm1 == ePrint3D) {
        ostringstream fileName3D;
        fileName3D << (fEvent)->GetEventId() << ".eps";
        fAugerPlots->Save3D(fileName3D.str());
      }
      else if (parm1 == eFindFDID ||
                parm1 == eFindSDID ||
                parm1 == eFindRDID ||
                parm1 == eFindGPSTime)
        FindEvent(parm1);
    }
      break;
    case kCM_CHECKBUTTON: {
      if (parm1 == eEnableSelection)
        if (!fCuts->ToggleSelectionEnable()) {
          fCuts->SelectEvents(fEventInfo,fStatusBar->GetEventList());
          ChangeEvent(eCurrentEvent);
        }
    }
      break;
    case kCM_MENU:
      switch (parm1) {

	// ------------------- THE FILE MENU ----------------
      case eFileOpen:
        {
          TString directory(".");
          TGFileInfo fi;
          fi.fIniDir  = StrDup(directory.Data());
          const char * rootFiles[] = { "ROOT files",   "*.root" ,
                                       "All files",    "*",
                                       0,              0 };
          fi.fFileTypes   = rootFiles;
          new TGFileDialog(gClient->GetRoot(), this, kFDOpen, &fi);
          if(fi.fFilename){
            vector<string> tmp;
            tmp.push_back(string(fi.fFilename));
            OpenOfflineOutput(tmp);
          }
        }
        break;
      case eLoadSources:
        {
          TString directory(ADST_CONFIG_DIR);
          TGFileInfo fi;
          const char * textFiles[] = { "ASCII files",   "*.txt" ,
                                       "All files" ,    "*",
                                       0,              0 };
          fi.fFileTypes   = textFiles;
          fi.fIniDir  = StrDup(directory.Data());
          new TGFileDialog(gClient->GetRoot(), this, kFDOpen, &fi);
          if(fi.fFilename)
            fAugerPlots->LoadSources(fi.fFilename);
        }
        break;
      case eLoadStyle:
        {
          TString directory(ADST_CONFIG_DIR);
          TGFileInfo fi;
          const char * styleFileTypes[] = { "Style files",   "*.sty" ,
                                            "All files",    "*",
                                            0,              0 };
          fi.fFileTypes   = styleFileTypes;
          fi.fIniDir  = StrDup(directory.Data());
          new TGFileDialog(gClient->GetRoot(), this, kFDOpen, &fi);
          if(fi.fFilename) {
            fStyleManager->ReadStyleFile(fi.fFilename);
            fAugerPlots->UpdatePalette();
            for_each(fFDPlots.begin(), fFDPlots.end(),
                     mem_fun(&FdPlots::UpdatePalette));
          }
          UpdateBrowser();
        }
        break;
      case eFileSavePS:
        PrintPS();
        break;
      case eFileSaveROOT:
        SaveEvent();
        break;
      case eFileSaveSelection:
        SaveSelectedEvents();
        break;
      case eFileDumpASCII:
        DumpEventASCII();
        break;
      case eViewOfflineConfig:
        ShowOfflineConfiguration();
        break;
      case eFileClear:
        break;

      case eFileTreeViewer:
        {
          if (fEventFile) {
            TTree* tree= fEventFile->GetEventTree();
            //  tree->Scan();
            if (tree->GetEntries()!=0) {
              TCanvas* canvas = new TCanvas("canvas", "Viewer Canvas", 1);
              canvas->cd();
              TLatex * erlegend=new TLatex();
              erlegend->SetNDC();
              erlegend->SetTextAlign(12);
              erlegend->SetTextSize(0.035);
              erlegend->SetTextColor(1);
              erlegend->DrawLatex(0.05,0.8,"If you want a tree viewer");
              erlegend->DrawLatex(0.05,0.6,"open root and type:");
              erlegend->SetTextColor(4);
              erlegend->DrawLatex(0.05,0.5,"RecEventFile* b= new RecEventFile"
                                  "(\"dummyfile.root\",RecEventFile::eRead)");
              erlegend->DrawLatex(0.05,0.4,"b->GetEventTree()->StartViewer()");
              erlegend->SetTextColor(1);
              erlegend->SetTextSize(0.055);
              erlegend->DrawLatex(0.05,0.2," Have fun !");

              erlegend->Draw("");
            }
          }
        }
        break;
      case eFileQuit:
        CloseWindow();
        break;
	// -------------------- THE OPTIONS MENU --------------------------
      case eSaveAnimations:
        {
          bool flag = fMenu->ToggleAnimation();
          for (unsigned int i=0;i<fFDPlots.size(); ++i)
            fFDPlots[i]->SetSaveAnimation(flag);
        }
        break;
      case eSpeedAnimations:
        {
          bool flag = fMenu->ToggleSpeedAnimation();
          for (unsigned int i=0;i<fFDPlots.size(); ++i)
            fFDPlots[i]->SetSpeedAnimation(flag);
        }
        break;
      case eShowerPlaneArray:
        {
          fSDPlots->SetShowerPlaneArray(fMenu->ToggleShowerPlaneArray());
          fSDPlots->UpdateArrayPlot();
        }
        break;
      case eShowSDinFD:
        {
          bool plotFlag=fMenu->ToggleSDinFD();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowSD(plotFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer()) {
              fFDPlots[i]->DrawCamera();
              fFDPlots[i]->DrawTimeFit();
            }
          }
        }
        break;
      case eShowZeta:
        {
          bool plotFlag=fMenu->ToggleZeta();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowZeta(plotFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawCamera();
          }
        }
        break;
      case eShowFDinSD:
        {
          bool plotFlag=fMenu->ToggleFDinSD();
          if (fSDPlots) {
            fSDPlots->SetShowFD(plotFlag);
            fSDPlots->UpdateArrayPlot();
          }
        }
        break;
      case eShowBadStations:
        {
          if (fSDPlots) {
            fSDPlots->SetShowBadStations(fMenu->ToggleShowBadStations());
            fSDPlots->UpdateArrayPlot();
          }
        }
        break;
      case eShowFDT3SDP:
        {
          bool plotFlag=fMenu->ToggleFDT3SDP();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetT3SDP(plotFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawCamera();
          }
          fAugerPlots->SetFDT3Flag(plotFlag);
          if( fTabs->GetCurrentContainer() == fAugerFrame)
            fAugerPlots->UpdateArrayPlot();
        }
        break;
      case eShowXmaxInSDP:
        {
          bool plotFlag=fMenu->ToggleFDXmaxSDP();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowXmaxInSDP(plotFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawCamera();
          }
        }
        break;
      case eCumulativeFDAperture:
        {
          bool apertureFlag = fMenu->ToggleAperture();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetCumulativeAperture(apertureFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eShowAerosols:
        {
          bool mieFlag = fMenu->ToggleShowAerosols();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowAerosols(mieFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eShowTelsInDAQ:
        {
          const bool daqFlag = fMenu->ToggleShowTelsInDAQ();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowTelsInDAQ(daqFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawCamera();
          }
        }
        break;
      case eShowViewableFOV:
        {
          const bool fovFlag = fMenu->ToggleShowViewableFOV();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowViewableFOV(fovFlag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eUseLCEfficiency:
        {
          bool lceffFlag = fMenu->ToggleUseLCEfficiency();
          if (lceffFlag)
            fMenu->SetShowEyeAndTelApertureLight();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetUseLCEfficiency(lceffFlag);
            if (lceffFlag) {
              fFDPlots[i]->SetShowEyeApertureLight(true);
              fFDPlots[i]->SetShowTelApertureLight(true);
            }
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eRBShowEyeApertureLight:
        {
          fMenu->SetShowEyeApertureLight();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowEyeApertureLight(true);
            fFDPlots[i]->SetShowTelApertureLight(false);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eRBShowTelApertureLight:
        {
          fMenu->SetShowTelApertureLight();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowEyeApertureLight(false);
            fFDPlots[i]->SetShowTelApertureLight(true);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eRBShowEyeAndTelApertureLight:
        {
          fMenu->SetShowEyeAndTelApertureLight();
          for (unsigned int i = 0; i < fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowEyeApertureLight(true);
            fFDPlots[i]->SetShowTelApertureLight(true);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->DrawProfile();
          }
        }
        break;
      case eShowMC:
        {
          bool mcflag = fMenu->ToggleShowMC();
          for (unsigned int i=0;i<fFDPlots.size(); ++i) {
            fFDPlots[i]->SetShowMC(mcflag);
            if (fFdFrame[i] == fTabs->GetCurrentContainer())
              fFDPlots[i]->Update();
          }
          if (fSDPlots) {
            fSDPlots->SetShowMC(mcflag);
            fSDPlots->Update();
          }
          fAugerPlots->SetShowMC(mcflag);
          fAugerPlots->Update();
        }
        break;
      case eShowMCTraces:{
        bool mcflag = fMenu->ToggleShowMCTraces();
        if (fSDPlots) {
          fSDPlots->SetShowMCTraces(mcflag);
          fSDPlots->Update();
        }
      }
        break;
      case eShowAllTraces:{
        bool plotFlag = fMenu->ToggleAllTracesinSD();
        if (fSDPlots) {
          fSDPlots->SetShowAllTraces(plotFlag);
          fSDPlots->Update();
        }
      }
        break;
	// ------------------- THE HELP MENU ----------------
      case eAbout:
        {
          ostringstream RecEventVersion;
          RecEventVersion << RecEvent::GetReleaseName() << " "
                          << RecEvent::GetVersion()
                          << " (SVN: " << RecEvent::GetSVNVersion()
                          << " rev "<< RecEvent::GetSVNRevision() << ")";

          EMsgBoxIcon icontype = kMBIconAsterisk;
          EMsgBoxButton buttonType = kMBOk;
          Int_t retval;
          ostringstream info;
          info << "ADST EventBrowser \n\n"
               << "Version: rev " << GetRevision() << " from "
               << GetDate() << "\n"
               << "Compiled with ROOT v" << gROOT->GetVersion() << "\n"
               << "ADST: " << RecEventVersion.str() << "\n"
               << "Authors: I.C. Maris, F. Schuessler, R. Ulrich, M. Unger\n\n"
               << "have fun browsing !\n\n"
               << "************************************************\n"
               << "If you want to stay in touch with ADST/EventBrowser "
               << "development,\n"
               << "subscribe to the \"adst-user\" mailing list at:\n"
               << " https://www.auger.unam.mx/mailman/listinfo/adst-user\n"
               << "************************************************\n"
               << "Please report bugs and comments to\n"
               << "www.auger.unam.mx/bugzilla and use product: ADST\n"
               << "and/or mail to the \"adst-devel\" mailing list\n"
               << "************************************************\n";
          new TGMsgBox(gClient->GetRoot(), gClient->GetRoot(),
                       "About",info.str().c_str(),
                       icontype, buttonType, &retval);
        }
        break;
      case eFDHelp:
        {
          cout << "---------------------------------------------------" << endl;
          cout << " pop up: \n legends (i.e. colors etc) for FD plots \n" << endl;
          cout << "---------------------------------------------------" << endl;
        }
        break;
      case eSDHelp:
        {
          cout << "---------------------------------------------------" << endl;
          cout << " pop up: \n legends (i.e. colors etc) for SD plots \n" << endl;
          cout << "---------------------------------------------------" << endl;
        }
        break;
      }
    }
  }
  return kTRUE;
}

/*****************************************************************************/
void
EventBrowser::PrintPS()
{
  if (!fEvent)
    return;

  ostringstream command;
  command << ADST_BIN_DIR << "/MergePostscript.csh";

  for (unsigned int i=0; i<fPlotVector.size(); ++i) {

    if (fTabs->IsEnabled(i)) {
      UpdateTab(i);
      command << " " << fPlotVector[i]->PrintPostScript();
    }

  }

  command << " " << ExtractAugerId();

  if (system(command.str().c_str())) { /* to prevent compiler warning ... */ }
}


/*****************************************************************************/
string EventBrowser::ExtractAugerId() const {

  const unsigned int kAugerIdLength=12;
  string Id = (fEvent)->GetEventId();
  string AugerId="123456789";
  string auger="uger";
  string event="event"; // MC ID

  if((int)Id.find(auger) > 0) { //looks like data reconstruction
    string tempString(Id.begin() + Id.find(auger) + 5, Id.begin() + Id.find(auger) + 5 + kAugerIdLength);
    AugerId="AugerEvent_";
    AugerId+=tempString;
  }
  else {
    if((int)Id.find(event) > 0) { //looks like MC reconstruction
      Id.erase(0, (int)Id.find(event)+5);
      AugerId="MCEvent_";
      AugerId+=Id;
    }
    else { //some other strange stuff is going on
      int eventNumber = fEventFile->GetCurrentEvent();
      char charId[100];
      sprintf(charId,"Event_%d",eventNumber);
      AugerId=charId;
    }
  }

  return AugerId;
}

/*****************************************************************************/
void EventBrowser::SaveEvent() {

  if (!fEvent)
    return;

  TString directory(".");
  TGFileInfo fi;
  fi.fIniDir  = StrDup(directory.Data());
  new TGFileDialog(gClient->GetRoot(), this, kFDSave, &fi);
  if(fi.fFilename) {
    string fileName = fi.fFilename;
    if (fileName.find(".root")==string::npos) {
      ostringstream tmpName;
      tmpName << fileName
	      << ".root";
      fileName = tmpName.str();
    }
    cout << " saving current event to " << fileName << endl;
    RecEventFile outputFile(fileName, RecEventFile::eWrite);
    outputFile.SetBuffers (&fEvent);
    outputFile.WriteEvent();
    outputFile.WriteDetectorGeometry (*fGeometry);
    FileInfo thisFileInfo;
    fEventFile->ReadFileInfo (thisFileInfo);
    outputFile.WriteFileInfo (thisFileInfo);
    outputFile.Close();
  }


}

/*****************************************************************************/
void EventBrowser::SaveSelectedEvents() {

  if (!fEvent)
    return;

  TString directory(".");
  TGFileInfo fi;
  fi.fIniDir  = StrDup(directory.Data());
  new TGFileDialog(gClient->GetRoot(), this, kFDSave, &fi);
  if(fi.fFilename) {
    string fileName = fi.fFilename;
    if (fileName.find(".root")==string::npos) {
      ostringstream tmpName;
      tmpName << fileName
	      << ".root";
      fileName = tmpName.str();
    }
    cout << " saving all selected events to " << fileName
         << "... " << endl;
    RecEventFile outputFile(fileName, RecEventFile::eWrite);
    outputFile.SetBuffers (&fEvent);

    int currentEvent = fCuts->GetEventNumber(eCurrentEvent);
    const std::vector <int> & selectedEventList = fCuts->GetSelectedEventList();

    gSystem->ProcessEvents();
    TReadProgress * theProgress = new TReadProgress( gClient->GetRoot(), 300, 100 ,
						     "Writing file ...");
    theProgress->SetNEvents(selectedEventList.size());
    const int nUpdate=100;
    int nEventsForUpdate=selectedEventList.size()/nUpdate;
    if(nEventsForUpdate==0)
      nEventsForUpdate=10;

    for (unsigned int i=0;i<selectedEventList.size(); ++i) {
      if (fEventFile->ReadEvent(selectedEventList[i]) == RecEventFile::eSuccess)  {
        outputFile.WriteEvent();
        if (i%nEventsForUpdate == 0) {
          if (theProgress->Event(i))
            break;
          gSystem->ProcessEvents();
        }
      }
    }
    delete theProgress;
    gSystem->ProcessEvents();

    outputFile.WriteDetectorGeometry (*fGeometry);
    FileInfo thisFileInfo;
    fEventFile->ReadFileInfo (thisFileInfo);
    outputFile.WriteFileInfo (thisFileInfo);
    outputFile.Close();

    cout << " saving file " << fileName << " done!" << endl;

    // read again the original event
    fEventFile->ReadEvent(currentEvent);

  }


}

/*****************************************************************************/
void EventBrowser::ShowOfflineConfiguration() {

  if (!fEventFile)
    return;

  FileInfo thisFileInfo;
  fEventFile->ReadFileInfo (thisFileInfo);

  OfflineConfigurationPopup * offConfig =
    new OfflineConfigurationPopup(this,
				  thisFileInfo,
				  (UInt_t) (0.9*this->GetWidth()),
				  (UInt_t) (0.9*this->GetHeight()));
  offConfig->Popup();

}

/*****************************************************************************/
void
EventBrowser::DumpEventASCII()
{
  if (!fEvent)
    return;
  cout << *fEvent << endl;
}


/*****************************************************************************/
void
EventBrowser::ProcessAugerButtons()
{
  if (!fEventFile ||
      fEventFile->GetCurrentEvent()<0)
    return;

  TGButton* button = (TGButton*)gTQSender;
  UInt_t id = button->WidgetId();

  switch(id) {
  case ePrint3D:
    {
      ostringstream fileName3D;
      fileName3D << ExtractAugerId() << ".eps";
      fAugerPlots->Save3D(fileName3D.str());
    }
    break;
  case eFDLightRays:
    {
      fAugerPlots->Set3DFDButtons(eFDLightRays);
      fAugerPlots->Update3DPlot();
    }
    break;
  case eFDSignalTrace:
    {
      fAugerPlots->Set3DFDButtons(eFDSignalTrace);
      fAugerPlots->Update3DPlot();
    }
    break;
  case eShowRadiusIn3D:
    fAugerPlots->Update3DPlot();
    break;
  case eMCShowFirstInteraction:
    fAugerPlots->Update3DPlot();
    break;
  case eSDShowAllTanks:
    fAugerPlots->Update3DPlot();
    break;
  default:
    break;
  }
}


/*****************************************************************************/
void EventBrowser::ProcessFdButtons() {

  if (!fEventFile ||
      fEventFile->GetCurrentEvent()<0)
    return;

  int currTab=fTabs->GetCurrent()-fFDTabIndex;

  Int_t id;
  TGFrame *frm = (TGFrame *) gTQSender;
  if (frm->IsA()->InheritsFrom(TGButton::Class())) {
    TGButton* button = (TGButton*)gTQSender;
    id = button->WidgetId();
  }
  else if (frm->IsA()->InheritsFrom(TGNumberEntry::Class())) {
    TGNumberEntry* numberEntry = (TGNumberEntry*)gTQSender;
    id = numberEntry->WidgetId();
  }
  else {
    cerr << " unexpected widget in EventBrowser::ProcessFdButtons() "
         << endl;
    return;
  }

  switch(id) {
  case eFDdEdX:
    {
      for (unsigned int i=0;i<fFDPlots.size(); ++i) {
        fFDPlots[i]->SetProfileMode(edEdX);
        if( fFdFrame[i] == fTabs->GetCurrentContainer())
          fFDPlots[i]->DrawProfile();
      }
      break;
    }
  case eFDdEdXShowerAge:
    {
      for (unsigned int i=0;i<fFDPlots.size(); ++i) {
        fFDPlots[i]->SetProfileMode(edEdXShowerAge);
        if( fFdFrame[i] == fTabs->GetCurrentContainer())
          fFDPlots[i]->DrawProfile();
      }
      break;
    }
  case eFDAperture:
    {
      for (unsigned int i=0;i<fFDPlots.size(); ++i) {
        fFDPlots[i]->SetProfileMode(eLightAtAperture);
        if( fFdFrame[i] == fTabs->GetCurrentContainer())
          fFDPlots[i]->DrawProfile();
      }
      break;
    }

  case eFDElectrons:
    {

      for (unsigned int i=0;i<fFDPlots.size(); ++i) {
        fFDPlots[i]->SetProfileMode(eElectrons);
        if( fFdFrame[i] == fTabs->GetCurrentContainer())
          fFDPlots[i]->DrawProfile();
      }
      break;
    }

  case eProfileRebin: {

    TGNumberEntry* numberEntry = (TGNumberEntry*)gTQSender;
    for (unsigned int i=0;i<fFDPlots.size(); ++i) {
      if( fFdFrame[i] == fTabs->GetCurrentContainer())
        fFDPlots[i]->DrawProfile();
      else
        fFDPlots[i]->SetRebinValue(numberEntry->GetIntNumber());
    }
    break;
  }

  case eFDEyeView:{

    const bool newButtonState =
      ( fFDPlots[currTab]->GetEyeViewButtonState() == kButtonDown) ?
      true : false;

    for (unsigned int i=0;i<fFDPlots.size(); ++i) {

      fFDPlots[i]->SetShowEyeView(newButtonState);
      fFDPlots[i]->ToggleEyeViewButton(fFDPlots[currTab]->GetEyeViewButtonState());

      if( fFdFrame[i] == fTabs->GetCurrentContainer())
        fFDPlots[i]->DrawCamera();
    }
    break;
  }

  case eFDresiduals:{
    const bool newButtonState =
      ( fFDPlots[currTab]->GetResidualButtonState() == kButtonDown) ?
      true : false;

    for (unsigned int i=0;i<fFDPlots.size(); ++i) {

      fFDPlots[i]->SetResidualMode(newButtonState);
      fFDPlots[i]->ToggleResidualButton(fFDPlots[currTab]->GetResidualButtonState());

      if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
        fFDPlots[i]->DrawTimeFit();
        fFDPlots[i]->DrawProfile();
      }
    }
    break;
  }

  case eFDAllPixels: {
    const bool newButtonState =
      ( fFDPlots[currTab]->GetAllPixelsButtonState() == kButtonDown) ?
      true : false;

    for (unsigned int i=0;i<fFDPlots.size(); ++i) {

      fFDPlots[i]->SetPixelMode(newButtonState);
      fFDPlots[i]->TogglePixelButton(fFDPlots[currTab]->GetAllPixelsButtonState());

      if( fFdFrame[i] == fTabs->GetCurrentContainer())
        fFDPlots[i]->DrawCamera();
    }
    break;
  }

  case eFDAllStations: {
    const bool newButtonState =
      ( fFDPlots[currTab]->GetAllStationsButtonState() == kButtonDown) ?
      true : false;

    for (unsigned int i=0;i<fFDPlots.size(); ++i) {

      fFDPlots[i]->SetStationMode(newButtonState);
      fFDPlots[i]->ToggleStationButton(fFDPlots[currTab]->GetAllStationsButtonState());

      if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
        fFDPlots[i]->DrawTimeFit();
        fFDPlots[i]->DrawCamera();
      }
    }
    break;

  }

  case eFDTimeColors:
    {
      for (unsigned int i=0;i<fFDPlots.size(); ++i) {

        fFDPlots[i]->SetPixelColorMode(eTime);

        if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
          fFDPlots[i]->ComputePixelColorRange();
          fFDPlots[i]->DrawCamera();
          fFDPlots[i]->DrawTimeFit();
        }
      }
      break;
    }

  case eFDSignalColors:
    {
      for (unsigned int i=0; i<fFDPlots.size(); i++) {

        fFDPlots[i]->SetPixelColorMode(eCharge);

        if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
          fFDPlots[i]->ComputePixelColorRange();
          fFDPlots[i]->DrawCamera();
          fFDPlots[i]->DrawTimeFit();
        }
      }
      break;
    }

  case eFDCloudColorMode:
    {
      for (unsigned int i=0; i<fFDPlots.size(); i++) {

        fFDPlots[i]->SetPixelColorMode(eCloudColors);

        if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
          fFDPlots[i]->ComputePixelColorRange();
          fFDPlots[i]->DrawCamera();
          fFDPlots[i]->DrawTimeFit();
        }
      }
      break;
    }

  case eFDLogSignalColors:
    {
      for (unsigned int i=0; i<fFDPlots.size(); ++i) {

        fFDPlots[i]->SetPixelColorMode(eLogCharge);

        if( fFdFrame[i] == fTabs->GetCurrentContainer()) {
          fFDPlots[i]->ComputePixelColorRange();
          fFDPlots[i]->DrawCamera();
          fFDPlots[i]->DrawTimeFit();
        }
      }
      break;
    }

  default:
    break;
  }

  // above we updated only the active tab --> reset all others
  for (unsigned int i=0;i<fFDPlots.size(); ++i) {
    if( fFdFrame[i] != fTabs->GetCurrentContainer()) {
      fFDPlots[i]->SetUpToDate(false);
      fFDPlots[i]->Clear();
    }
  }
}



/*****************************************************************************/
void EventBrowser::CloseWindow() {

  // return from TApplication::Run()
  gSystem->ExitLoop();

}



/*****************************************************************************/
void
EventBrowser::UpdateBrowser()
{
  const int currentTab = fTabs->GetCurrent();

  // reset everything
  for (unsigned int i=0; i<fPlotVector.size(); ++i) {
    fPlotVector[i]->Clear();
    fPlotVector[i]->SetUpToDate(false);
  }

  // activate tabs with data
  for (unsigned int i=0;i<fFDPlots.size(); ++i)
    fTabs->SetEnabled(fFDTabIndex+i, fEvent->HasEye(fFDPlots[i]->GetEyeID()));

  fTabs->SetEnabled(fSDTabIndex, bool(fEvent->GetSDEvent().GetEventId()));
#ifdef AUGER_RADIO_ENABLED
  fTabs->SetEnabled(fRDTabIndex, bool(fEvent->GetRdEvent().GetRdEventId()));
#endif

  if(fSDMCTabIndex)
    fTabs->SetEnabled(fSDMCTabIndex, fTabs->IsEnabled(fSDTabIndex));

  // always stay on selection tab ...
  if (currentTab == int(fCutTabIndex))
    return;

  // ... jump to hottest eye if already on FD ...
  for (unsigned int i=0;i<fFDPlots.size(); ++i) {
    if (fFdFrame[i] ==  fTabs->GetCurrentContainer()) {
      const int eyeID = fEvent->GetHottestEyeId();
      if (eyeID > 0) {
        for (unsigned int i=0;i<fFDPlots.size(); ++i) {
          if (eyeID == fFDPlots[i]->GetEyeID()) {
            fTabs->SetTab(i+fFDTabIndex);
            UpdateTab(i+fFDTabIndex);
            return;
          }
        }
      }
    }
  }

  // ... stay on current tab if active ...
  if (fTabs->IsEnabled(currentTab)) {
    UpdateTab(currentTab);
    return;
  }

  // ... and if reached here simply go to Auger tab
  fTabs->SetTab(fAugerTabIndex);
  UpdateTab(fAugerTabIndex);

}

FdPlots*
EventBrowser::GetHottestFdPlots()
{
  const int eyeId = fEvent->GetHottestEyeId();
  for (unsigned int i=0; i<fFDPlots.size(); i++) {
    if (eyeId == fFDPlots[i]->GetEyeID()) {
      UpdateTab(i+fFDTabIndex);
      return fFDPlots[i];
    }
  }
  return 0;
}

FdPlots*
EventBrowser::GetFdPlot(const int eyeId)
{
  for (unsigned int i=0; i<fFDPlots.size(); i++) {
    if (eyeId == fFDPlots[i]->GetEyeID()) {
      UpdateTab(i+fFDTabIndex);
      return fFDPlots[i];
    }
  }
  return 0;
}


/*****************************************************************************/
void
EventBrowser::UpdateTab(Long_t iTab)
{
  if (iTab < (Long_t) fPlotVector.size()) {
    if (!fPlotVector[iTab]->IsUpToDate()) {
      fPlotVector[iTab]->Update();
      fPlotVector[iTab]->SetUpToDate(true);
    }
  }
}

/*****************************************************************************/
void
EventBrowser::OpenOfflineOutput(const vector<string> & fileNames)
{
  if (fileNames.empty()) {
    cerr << " EventBrowser::OpenOfflineOutput() - No file specified!";
    return;
  }

  // clear event list
  fEventInfo.clear();

  // open file
  if (fEventFile)
    delete fEventFile;

  fEventFile = new RecEventFile (fileNames);

  if (fEventFile->GetNFiles() < 1) {
    cerr << " EventBrowser::OpenOfflineOutput() - Error opening ";
    for (unsigned int i=0; i<fileNames.size(); i++)
      cerr << fileNames[i] << endl;
    return;
  }

  fTotEvent = fEventFile->GetNEvents();
  if (fTotEvent < 1) {
    cerr << " EventBrowser::OpenOfflineOutput() - No events in file ";
    for (unsigned int i=0; i<fileNames.size(); i++)
      cerr << fileNames[i] << endl;
    return;
  }

  GetDetectorGeometry();

  fEventFile->SetBuffers(&fEvent);

  FileInfo thisFileInfo;
  fEventFile->ReadFileInfo (thisFileInfo);
  fIsMC=thisFileInfo.HasMC();

  ReadEventList();
  InitEventTabs();
}


/*****************************************************************************/
void
EventBrowser::UpdateTabsOnOpenFile()
{
  if(fTotEvent < 1)
    return;

  FileInfo thisFileInfo;
  fEventFile->ReadFileInfo (thisFileInfo);
  fCuts->SetEventInfoClassVersion(thisFileInfo.GetEventInfoClassVersion());
  fCuts->SelectEvents(fEventInfo,fStatusBar->GetEventList());
  fSDPlots->SetRecStationClassVersion(thisFileInfo.GetSdRecStationClassVersion());
  fAugerPlots->SetRecStationClassVersion(thisFileInfo.GetSdRecStationClassVersion());

  if (fIsMC)
    fMenu->EnableMC();

  for (unsigned int i=0; i<fPlotVector.size(); ++i)
    fPlotVector[i]->SetShowMC(fIsMC);


  for (unsigned int i=0;i<fFDPlots.size(); ++i) {
    if(thisFileInfo.HasFdTraces())
      fFDPlots[i]->EnablePixelTraceTab();
    fFDPlots[i]->SetRecStationClassVersion(thisFileInfo.GetSdRecStationClassVersion());
  }
  ChangeEvent(eCurrentEvent);
}

/*****************************************************************************/
void
EventBrowser::ReadEventList()
{
  // get rid of pending events
  gSystem->ProcessEvents();

  // read in event info
  TReadProgress* theProgress =
    new TReadProgress( gClient->GetRoot(), 300, 100);
  theProgress->SetNEvents(fTotEvent);

  // ProcessEvents() is slow, so update only nUpdate times
  const int nUpdate =  100;
  int nEventsForUpdate = fTotEvent / nUpdate;
  if (nEventsForUpdate == 0)
    nEventsForUpdate = 1;

  fEventInfo.resize(fTotEvent);
  int i=0;
  while ( fEventFile->GetEventInfos(i,nEventsForUpdate,fEventInfo)) {
    if (theProgress->Event(i))
      break;
    gSystem->ProcessEvents();
    i += nEventsForUpdate;
  }

  delete theProgress;
  gSystem->ProcessEvents();
}


/*****************************************************************************/
void
EventBrowser::GetDetectorGeometry()
{
  delete fGeometry;
  fGeometry = new DetectorGeometry();

  if (fEventFile) {
    if (fEventFile->ReadDetectorGeometry (*fGeometry) == RecEventFile::eSuccess)
      return;
  }
  else {
    cerr << " Could not read detector geometry in EventBrowser::GetDetectorGeometry !" << endl;
    exit (1);
  }
}




/*****************************************************************************/
void
EventBrowser::ChangeTab(Long_t where)
{
  const int nTabs = fTabs->GetNumberOfTabs();
  const int currTab = fTabs->GetCurrent();

  if (where == eNextTab) {
    for (int i = currTab+1; i<nTabs; ++i)
      if (fTabs->IsEnabled(i)) {
        fTabs->SetTab(i);
        return;
      }

    for (int i = 0; i<currTab ; ++i)
      if (fTabs->IsEnabled(i)) {
        fTabs->SetTab(i);
        return;
      }

  }
  else if (where == ePreviousTab) {
    for (int i = currTab-1; i>-1; i--)
      if (fTabs->IsEnabled(i)) {
        fTabs->SetTab(i);
        return;
      }

    for (int i = nTabs-1; i>currTab ; i--)
      if (fTabs->IsEnabled(i)) {
        fTabs->SetTab(i);
        return;
      }

  }
}

/*****************************************************************************/
void
EventBrowser::InitEventTabs()
{
  if (!fGeometry) {
    cerr << " EventBrowser::InitEventTabs() -"
         << " Error : DetectorGeometry is not set!" << endl;
    return;
  }

  // init windows
  if (!fSDPlots) {

    fFDTabIndex = fTabs->GetNumberOfTabs();
    for (DetectorGeometry::ConstEyeIterator eyeIter = fGeometry->EyesBegin();
          eyeIter != fGeometry->EyesEnd();
          ++eyeIter)  {
      fFdFrame.push_back(fTabs->AddTab(eyeIter->second.GetEyeName()));
      fFDPlots.push_back( new FdPlots(fFdFrame.back(),
				      &fStyleManager,
                                      &fGeometry,
				      &fEvent,
                                      eyeIter->first,
				      fIsMC));
      fPlotVector.push_back(fFDPlots.back());
    }

    fSDTabIndex = fTabs->GetNumberOfTabs();
    fSdFrame     = fTabs->AddTab("SD");

    FileInfo thisFileInfo;
    fEventFile->ReadFileInfo(thisFileInfo);

    fSDPlots = new SdPlots(fSdFrame,
			   &fStyleManager,
			   &fGeometry,
			   &fEvent,
			   fIsMC);
    fSDPlots->SetLDFType(thisFileInfo.GetLDFType());
    fPlotVector.push_back(fSDPlots);
    if (fIsMC) {
      fSDMCTabIndex = fTabs->GetNumberOfTabs();
      fSdSimFrame  = fTabs->AddTab("SDSim");
      fSdSimPlots  = new SdSimulationPlots( fSdSimFrame,
					    fStyleManager,
                                            &fGeometry,
					    &fEvent,
					    &fIsMC);
      fPlotVector.push_back(fSdSimPlots);
    }

#ifdef AUGER_RADIO_ENABLED

    fRDTabIndex = fTabs->GetNumberOfTabs();
    fRdFrame = fTabs->AddTab("RD");

    fRdPlots = new RdPlots( fRdFrame, &fStyleManager,&fGeometry, &fEvent, fIsMC);

    fRdPlots->SetHasStationTraces(thisFileInfo.HasRdStation());
    fRdPlots->SetHasRdChannelTraces(thisFileInfo.HasRdChannel());
    fPlotVector.push_back(fRdPlots);

#endif

    fCutTabIndex = fTabs->GetNumberOfTabs();
    fCutFrame    = fTabs->AddTab("Selection");
    fCuts = new EventSelection(fCutFrame);

    if (!fIsInBatchMode) {
      MapSubwindows();
      Resize (GetDefaultSize());
      MapWindow();
    }
  }
  else {
    unsigned int i=0;
    for (DetectorGeometry::ConstEyeIterator eyeIter = fGeometry->EyesBegin();
          eyeIter != fGeometry->EyesEnd();
          ++eyeIter)  {
      if (i >= fFDPlots.size() ||
          (unsigned int) fFDPlots[i]->GetEyeID() != eyeIter->first) {
        cerr << "\n EventBrowser::InitEventTabs(): Error while opening new file!\n"
             << "   eye configuration does not match the one of previous file\n"
             << "   please re-open file...\n "
             << "   exit! " << endl;
        exit(1);
      }
      i++;
    }
  }

  // set tab to view at startup and read first event
  UpdateTabsOnOpenFile();
  fTabs -> SetTab(fStyleManager->GetStartUpTab());
}

/*****************************************************************************/
void
EventBrowser::InitKeyStrokes()
{
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Q), kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Escape), kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Down),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Up), kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_PageDown),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_PageUp), kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Home),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_End), kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Space),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Tab),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_Backtab),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_P),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_S),kAnyModifier);
  BindKey((const TGWindow*)this, gVirtualX->KeysymToKeycode(kKey_A),kAnyModifier);
}


/*****************************************************************************/
void
EventBrowser::FindEvent(UInt_t id)
{
  if (!fCuts)
    return;
  fCuts->FindEvent(id, fEventInfo);
  ChangeEvent(eCurrentEvent);
}


/*****************************************************************************/
bool
EventBrowser::ChangeEvent(Long_t what)
{
  if (!fCuts)
    return false;

  const int currentEvent = fCuts->GetEventNumber(what);
  if (currentEvent >= 0) {
    if (fEventFile->ReadEvent(currentEvent) == RecEventFile::eSuccess) {
      fStatusBar->GetEventList()->Select(currentEvent);
      UpdateBrowser();
      return true;
    }
    else
      cerr << " EventBrowser::ChangeEvent - Error reading event number "
           << currentEvent << " ( file has " << fEventFile->GetNEvents()
           << " event)" << endl;
  }
  return false;
}

//*******************************************************************
void printHelp() {
  cout << "\n  Usage: EventBrowser [-s <scale factor>] [-k] [-b] <RecEvent files> \n"
       << "     (use -k to keep temporary files, i.e. of the spot animation ...) \n"
       << "     (use -b to produce plots in batch mode)"
       << endl;
}

//*******************************************************************
int main(int argc, char **argv)
{

  // Draw a title

  if (gROOT->IsBatch()) {
    cerr << argv[0] << ": cannot run in batch mode";
    return 1;
  }

  // get command line options

  int j = 1;
  bool keepTmpFiles = false; // e.g. to keep the output of the camera animation
  bool batchMode = false; // do not start the GUI, just produce plots
  double scaleFactor = 1.;
  int c;
  while ((c = getopt (argc, argv, "s:bkhv")) != -1) {
    switch (c) {
    case 's':
      scaleFactor = atof(optarg);
      j += 2;
      break;
    case 'k':
      keepTmpFiles = true;
      j += 1;
      break;
    case 'b':
      batchMode = true;
      j += 1;
      break;
    case 'v':
      EventBrowser::Welcome();
      return 0;
      break;
    default:
      printHelp();
      return 0;
    }
  }

  // read list of filenames from command line

  vector<string> fileNames;
  while ( argv[j] != NULL) {
    fileNames.push_back(string(argv[j]));
    j++;
  }

  // open a root application
  int nArg = 1;
  TApplication theApp("App", &nArg, argv);

  // Get the screen dimensions
  Int_t  x, y;
  UInt_t w, h;
  gVirtualX->GetWindowSize(gClient->GetRoot()->GetId(),x,y,w,h);


  // The window is slightly smaller than the screen
  UInt_t height = UInt_t(h*0.7*scaleFactor);
  UInt_t width = UInt_t(height*4.5/3.*scaleFactor);

  EventBrowser* mainWindow =
    new EventBrowser(gClient->GetRoot(), width, height, fileNames, batchMode);
  if (keepTmpFiles)
    mainWindow->KeepAnimatedEpsFiles();

  ostringstream iconName;
  iconName << ADST_CONFIG_DIR << "/eventBrowser.ico";

  mainWindow->SetIconPixmap(iconName.str().c_str());
  if (!mainWindow) {
    cerr << " Could not start up!" << endl;
    exit (1);
  }

  if (!batchMode)
    theApp.Run();
  else {
    do {
#warning make this a bit more flexible ...
      mainWindow->PrintPS();
      mainWindow->DumpEventASCII();

      FdPlots* fd = mainWindow->GetHottestFdPlots();
      if (fd) {
        ostringstream cameraName;
        cameraName << "camera." << mainWindow->ExtractAugerId() << ".eps";
        fd->SetPixelColorMode(eLogCharge);
        fd->ComputePixelColorRange();
        fd->DrawCamera();
        fd->SaveCameraCanvas(cameraName.str());
      }
    } while (mainWindow->ChangeEvent(eNextEvent));
  }

  return 0;
}
