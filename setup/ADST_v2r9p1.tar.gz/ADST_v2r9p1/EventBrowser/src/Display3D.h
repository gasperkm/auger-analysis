#ifndef _include_Display3D_h__
#define _include_Display3D_h__

#include <TQObject.h>
#include <TGFrame.h>
#include "EventBrowserSignals.h"

class TGCompositeFrame;
class DetectorGeometry;
class RecEvent;
class StyleManager;
class TCanvas;
class TObjArray;

class TGeoVolume;
class TGeoMedium;

class TGCheckButton;
class TGRadioButton;

#include <vector>

class Display3D : public TQObject {

private:
  Display3D();                 // disabled
  Display3D(const Display3D&); // disabled
  
public:
  Display3D(TGCompositeFrame* main,
	    const StyleManager* const * styleManager,
	    const DetectorGeometry* const * geom,		  
	    const RecEvent* const * event, 
	    const bool& ismc);
  ~Display3D();
  
  //void Draw(bool drawSD=true, bool drawFD=true, bool drawMC=false);
  void Update();
  void Clear();
  void SaveCanvas(const std::string &fileName) const;
  void SetFDButtons(EButtonSignals e);
  void UpdatePalette();

private:
  void DrawDetector();
  void DrawSDRecData(bool draw);
  void DrawFDRecData();

  void FindTimeWindow();
  

private:
  const RecEvent* const * fEvent;   // this is just the current event reference
  const StyleManager* const * fStyleManager; // for plotting style options
  const DetectorGeometry* const * fDetectorGeometry;
  const bool& fIsMC;


  TGCompositeFrame *fMain; 

  TCanvas *f3DCanvas;
  TGeoVolume *fWorld;
  TGeoMedium *fMaterial;

  // ----- for 3D plots ------
  TObjArray * f3DObjects;
  
  
  Long64_t fTimeMin;
  Long64_t fTimeMax;
  
  double fStationMax;
  double fMaxPixelSignal;
  double fMaxdEdXMax;

  int fMinColor;
  int fMaxColor;
  
  
  int fColorRangeStart;
  double fPixelColorRangeMin;
  double fPixelColorRangeMax;
  std::vector<Int_t> fPixelColor;

  double fXminDet;
  double fYminDet;
  double fZminDet;
  double fXmaxDet;
  double fYmaxDet;
  double fZmaxDet;
  
  bool fFirstEvt;
  double fXminEvt;
  double fYminEvt;
  double fZminEvt;
  double fXmaxEvt;
  double fYmaxEvt;
  double fZmaxEvt;

  // drawing options
  bool fShowSDP;
  
  TGCheckButton * fShowAllTanks;
  TGRadioButton * fLightRays;
  TGRadioButton * fSignalTrace;
  TGCheckButton * fShowRadiusPoint;
  TGCheckButton * fShowMC;

  ClassDef (Display3D, 1);
};

#endif
