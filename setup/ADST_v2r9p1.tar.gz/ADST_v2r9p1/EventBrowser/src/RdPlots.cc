#ifdef AUGER_RADIO_ENABLED
#include "RdPlots.h"
#include "EventBrowserSignals.h"
#include "EventBrowserConst.h"
#include "RecEvent.h"
#include "Detector.h"
#include "DetectorGeometry.h"

#include "Detector.h"
#include "RdEvent.h"
#include "ArrayPlot.h"
#include "StyleManager.h"

#include <TGTab.h>
#include <TGFrame.h>
#include <TRootEmbeddedCanvas.h>
#include <TCanvas.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TF1.h>
#include <TH1F.h>
#include <TH2F.h>
#include <TClass.h>
#include <TLegend.h>
#include <TLegendEntry.h>
#include <TObjArray.h>
#include <TLine.h>
#include <TLatex.h>
#include <TGSlider.h>
#include <TLatex.h>
#include <TGButtonGroup.h>
#include <TGButton.h>
#include <TSystem.h>
#include <TGListBox.h>
#include <TMarker.h>
#include <TTimeStamp.h>
#include <TText.h>
#include <TColor.h>
#include <TGDoubleSlider.h>
#include <TBox.h>

#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <iomanip>

#include <ShowerRRecDataQuantities.h>
#include <StationRRecDataQuantities.h>

using namespace std;

ClassImp(RdPlots);
#define round(x) (x<0? ceil( (x)-0.5 ) : floor( (x)+0.5 ))

RdPlots::RdPlots(TGCompositeFrame *main, const StyleManager* const * styleManager, const DetectorGeometry* const * geom,
    const RecEvent* const * event, const bool& isMC) :
        fStyleManager(styleManager),
        fEvent(event),
        fIsMC(isMC),
        fDetectorGeometry(geom),
        fShowFD(false),
        fShowMC(false),  // Not Ready to show MC informafion the MC is not written yet
        fShowAllTraces(true),
        fRdArrayOnStatus(true),
        fHasStationTraces(false),
        fHasRdChannelTraces(false),
        fShowMCTraces(false),
        fDrawChannel(false),
        fDrawTriggerWindow(false),
        fDrawNoiseWindow(false),
        fDrawPeakLine(false),
        fDrawVertPolarization(false),
        fDrawEastPolarization(true),
        fDrawNorthPolarization(true),
        fDrawResAxis(true),
        fDrawSdAxis(false),
        fCurrentStation(0)

{
  fSdLDFOnStatus = true;
  fPMTObjects = new TObjArray();
  fPMTObjects->SetOwner(kTRUE);
  fEventObjects = new TObjArray();
  fEventObjects->SetOwner(kTRUE);
  fPlotsObjects = new TObjArray();
  fPlotsObjects->SetOwner(kTRUE);

  fTracesObjects = new TObjArray();
  fTracesObjects->SetOwner(kTRUE);

  fMain = main;
  fMain->SetCleanup(kDeepCleanup);

  double width = main->GetWidth();
  double height = main->GetHeight();

  TGLayoutHints* mainHorizontalLayout = new TGLayoutHints(kLHintsExpandX, 3, 3, 3, 3);

  TGHorizontalFrame* mainHorizontal1 = new TGHorizontalFrame(main, UInt_t(width), UInt_t(0.55 * height));
//  TGHorizontalFrame* mainHorizontal1bis = new TGHorizontalFrame(main, UInt_t(width)*0.5, UInt_t(0.55*height));
  TGHorizontalFrame* mainHorizontal2 = new TGHorizontalFrame(main, UInt_t(width), UInt_t(0.4 * height));
  TGHorizontalFrame* mainHorizontal3 = new TGHorizontalFrame(main, UInt_t(width), UInt_t(0.05 * height));

  main->AddFrame(mainHorizontal1, mainHorizontalLayout);
//  main->AddFrame(mainHorizontal1bis,new TGLayoutHints());
  main->AddFrame(mainHorizontal2, mainHorizontalLayout);
  main->AddFrame(mainHorizontal3, mainHorizontalLayout);

  //*************** FIRST HORIZONTAL FRAME ******/
  TGVerticalFrame* vertical1 = new TGVerticalFrame(mainHorizontal1, UInt_t(0.2 * width), UInt_t(0.55 * height));
  //*************** FIRST VERTICAL FRAME ********/

  // event info
  fRdEventInfoTab = new TGTab(vertical1, UInt_t(0.20 * width), UInt_t(0.4 * height));
  TGCompositeFrame *eventInfoFrame = fRdEventInfoTab->AddTab("Event Info");
  TGHorizontalFrame *horizFrameInfo = new TGHorizontalFrame(eventInfoFrame, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas *canvasInfoEmb = new TRootEmbeddedCanvas("canvasInfoEmb", horizFrameInfo, UInt_t(0.23 * width),
      UInt_t(0.4 * height));
  fCanvasInfo = canvasInfoEmb->GetCanvas();
// MC Info
  TGCompositeFrame *MCInfoFrame = fRdEventInfoTab->AddTab("MC Info");
  TGHorizontalFrame *horizFrameMC = new TGHorizontalFrame(MCInfoFrame, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas *canMCInfoEmb = new TRootEmbeddedCanvas("MCInfoEmb", horizFrameMC, UInt_t(0.23 * width),
      UInt_t(0.4 * height));
  fCanvasMCInfo = canMCInfoEmb->GetCanvas();

  vertical1->AddFrame(fRdEventInfoTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

// Zoom

  TGVButtonGroup* arrayButtons = new TGVButtonGroup(vertical1, "");
  fArrayZoomButton = new TGHSlider(arrayButtons, 190, kSlider2 | kScaleBoth, eSDZoomToCore);
  fArrayZoomButton->Connect("Pressed()", "RdPlots", this, "DoRdPressed()");
  fArrayZoomButton->Connect("Released()", "RdPlots", this, "DoRdReleased()");
  fArrayZoomButton->SetRange(0, 1000);
  fArrayZoomButton->SetPosition(935);
  vertical1->AddFrame(arrayButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 3, 3, 3, 3));

  //*************** SECOND VERTICAL FRAME *****************************************/
  fRdGeoTab = new TGTab(mainHorizontal1, UInt_t(0.39 * width), UInt_t(0.55 * height));
  TGCompositeFrame *Arrayframe = fRdGeoTab->AddTab("Array");
  TGHorizontalFrame *horizframeArray = new TGHorizontalFrame(Arrayframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasArrayEmb = new TRootEmbeddedCanvas("canvasArrayEmb", horizframeArray, UInt_t(0.39 * width),
      UInt_t(0.55 * height));

  fCanvasArray = canvasArrayEmb->GetCanvas();

  fCanvasArray->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "RdPlots", this,
      "HandleArrayClicked(Int_t,Int_t,Int_t,TObject*)");
  fCanvasArray->SetBottomMargin(0.14);
  fCanvasArray->SetTopMargin(0.06);
  fCanvasArray->GetCanvas()->SetEditable(false);
  fArrayPlot = new ArrayPlot(fEvent, fDetectorGeometry, fStyleManager, fArrayZoomButton, fCanvasArray);
  fArrayPlot->SetSDColorStatus(fSdColorStatus);
  fArrayPlot->SetRadioOn();
  fArrayPlot->SetSDColorStatus(eSDGroundTimeColors);
  fArrayPlot->SetRecStationClassVersion(fRecStationClassVersion);
  fArrayZoomButton->Connect("PositionChanged(Int_t)", "ArrayPlot", fArrayPlot, "DoSdZoom(Int_t)");

  TGCompositeFrame *LDFframe = fRdGeoTab->AddTab("LDF");
  TGHorizontalFrame *horizFrameLDF = new TGHorizontalFrame(LDFframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasLDFEmb = new TRootEmbeddedCanvas("canvasLDFEmb", horizFrameLDF, UInt_t(0.39 * width),
      UInt_t(0.55 * height));
  fCanvasLDF = canvasLDFEmb->GetCanvas();
  fCanvasLDF->SetBottomMargin(0.14);
  fCanvasLDF->SetTopMargin(0.06);

  TGCompositeFrame *Residualsframe = fRdGeoTab->AddTab("Residuals");
  TGHorizontalFrame *horizFrameResiduals = new TGHorizontalFrame(Residualsframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasResidualsEmb = new TRootEmbeddedCanvas("canvasResidualsEmb", horizFrameResiduals,
      UInt_t(0.39 * width), UInt_t(0.55 * height));
  fCanvasResiduals = canvasResidualsEmb->GetCanvas();
  fCanvasResiduals->SetBottomMargin(0.14);
  fCanvasResiduals->SetTopMargin(0.06);

  // Lorentz Angle Plot
  TGCompositeFrame *Lorentzframe = fRdGeoTab->AddTab("Lorentz Angle");
  TGHorizontalFrame *horizFrameLorentz = new TGHorizontalFrame(Lorentzframe, UInt_t(width), UInt_t(height));
  TRootEmbeddedCanvas* canvasLorentzEmb = new TRootEmbeddedCanvas("canvasLorentzEmb", horizFrameLorentz, UInt_t(0.39 * width),
      UInt_t(0.55 * height));
  fCanvasLorentz = canvasLorentzEmb->GetCanvas();
  fCanvasLorentz->SetBottomMargin(0.14);
  fCanvasLorentz->SetTopMargin(0.06);

  //*************** THIRD VERTICAL FRAME *****************************************/

  TGVerticalFrame* vertical2 = new TGVerticalFrame(mainHorizontal1, UInt_t(0.3 * width), UInt_t(0.55 * height));
  fStationsListBox = new TGListBox(vertical2, 89);
  fStationsListBox->Connect("Selected(Int_t)", "RdPlots", this, "SelectStation()");
  fStationsListBox->Resize(UInt_t(0.25 * width), UInt_t(0.3 * height));

  TGHorizontalFrame* horiz_small = new TGHorizontalFrame(vertical2, UInt_t(0.3 * width), UInt_t(0.55 * height));

  TGVButtonGroup *tracesButtons = new TGVButtonGroup(horiz_small, "");
  fStationButton = new TGRadioButton(tracesButtons, "Station  ", eRDStation);
  fStationButton->SetToolTipText("Draw trace and spectrum at the station level");

  fChannelButton = new TGRadioButton(tracesButtons, "Channel  ", eRDChannel);
  fChannelButton->SetToolTipText("Draw trace and spectrum at the channel level");

  fStationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fChannelButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  tracesButtons->SetRadioButtonExclusive();

  TGHorizontalFrame* horiz_small2 = new TGHorizontalFrame(vertical2, UInt_t(0.3 * width), UInt_t(0.55 * height));

  // *************** SECOND HORIZONTAL FRAME *****************************************/
  fRdEventTab = new TGTab(mainHorizontal2, UInt_t(width), UInt_t(0.4 * height));

  //*****************   Traces TABs  ******************************************************/
  TGCompositeFrame *TraceFrame = fRdEventTab->AddTab("Traces ");
  TRootEmbeddedCanvas *canvasTraceemb = new TRootEmbeddedCanvas("canvasTraceemb", TraceFrame, UInt_t(0.95 * width),
      UInt_t(0.4 * height));
  fCanvasTrace = canvasTraceemb->GetCanvas();

  TGCompositeFrame *SpectrFrame = fRdEventTab->AddTab("Spectrum ");

  TRootEmbeddedCanvas *canvasSpectrum = new TRootEmbeddedCanvas("canvasSpectrum", SpectrFrame, UInt_t(0.95 * width),
      UInt_t(0.4 * height));
  fCanvasSpectrum = canvasSpectrum->GetCanvas();

  TGCompositeFrame *FieldFrame = fRdEventTab->AddTab("2D-Field");
  TRootEmbeddedCanvas *canvasFieldemb = new TRootEmbeddedCanvas("canvasFieldemb", FieldFrame, UInt_t(0.95 * width),
      UInt_t(0.4 * height));
  fCanvasField = canvasFieldemb->GetCanvas();

  fCanvasSpectrum->SetBottomMargin(0.14);
  fCanvasSpectrum->SetTopMargin(0.14);
  fCanvasTrace->SetBottomMargin(0.14);
  fCanvasTrace->SetTopMargin(0.14);
  fCanvasField->SetBottomMargin(0.14);
  fCanvasField->SetTopMargin(0.14);

  //*********** THRID HORIZONTAL FRAME ********************************/

  TGHButtonGroup* RdOptionsButtons = new TGHButtonGroup(mainHorizontal3, "Options");

  fRdTriggerWindowButton = new TGCheckButton(RdOptionsButtons, new TGHotString("Signal window"), eRdTriggerWindow);
  fRdNoiseWindowButton = new TGCheckButton(RdOptionsButtons, new TGHotString("Noise window"), eRdNoiseWindow);
  fRdPeakLineButton = new TGCheckButton(RdOptionsButtons, new TGHotString("Peak line"), eRDPeakLine);
  fRdEastPolarizationButton = new TGCheckButton(RdOptionsButtons, new TGHotString("East pol."), eRdEastPolarization);
  fRdNorthPolarizationButton = new TGCheckButton(RdOptionsButtons, new TGHotString("North pol."), eRdNorthPolarization);
  fRdVertPolarizationButton = new TGCheckButton(RdOptionsButtons, new TGHotString("Vertical pol."), eRdVertPolarization);


  fRdEastPolarizationButton->SetState(kButtonDown);
  fRdNorthPolarizationButton->SetState(kButtonDown);

  fRdTriggerWindowButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdNoiseWindowButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdPeakLineButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdVertPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdEastPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fRdNorthPolarizationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");

  // Buttons to select how the residuals are plotted
  TGHButtonGroup* ResidualButtons = new TGHButtonGroup(mainHorizontal3,"Residuals");
  fResAxisButton = new TGRadioButton(ResidualButtons, new TGHotString("Shower axis"),eResAxis);
  fResStationButton = new TGRadioButton(ResidualButtons, new TGHotString("Station Id"),eResStation);
  fResAxisButton->SetToolTipText("Plot residuals as function of shower axis");
  fResStationButton->SetToolTipText("Plot residuals as function of station number");
  fResAxisButton->SetState(kButtonDown);
  fResAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fResStationButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");

  // Buttons to select which shower axis is used
  TGHButtonGroup* AxisButtons = new TGHButtonGroup(mainHorizontal3,"Shower axis");
  fRadioAxisButton = new TGRadioButton(AxisButtons, new TGHotString("Radio"),eRadioAxis);
  fSdAxisButton = new TGRadioButton(AxisButtons, new TGHotString("Sd"),eSdAxis);
  fRadioAxisButton->SetToolTipText("Plot LDF and residuals with radio axis");
  fSdAxisButton->SetToolTipText("Plot LDF and residuals with Sd axis");
  fRadioAxisButton->SetState(kButtonDown);
  fRadioAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");
  fSdAxisButton->Connect("Clicked()", "RdPlots", this, "DoRdButton()");


  // ********************

  mainHorizontal1->AddFrame(vertical1, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  mainHorizontal1->AddFrame(vertical2, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  //mainHorizontal1->AddFrame(canvasArrayEmb, new TGLayoutHints(kLHintsCenterX|kLHintsCenterY,3,3,3,3));
  mainHorizontal1->AddFrame(fRdGeoTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  mainHorizontal2->AddFrame(fRdEventTab, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  mainHorizontal3->AddFrame(RdOptionsButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 1, 1, 1, 1));
  mainHorizontal3->AddFrame(AxisButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 1, 1, 1, 1));
  mainHorizontal3->AddFrame(ResidualButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 1, 1, 1, 1));

  vertical2->AddFrame(fStationsListBox, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  vertical2->AddFrame(horiz_small, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));
  vertical2->AddFrame(horiz_small2, new TGLayoutHints(kLHintsTop | kLHintsCenterY, 3, 3, 3, 3));

  eventInfoFrame->AddFrame(horizFrameInfo, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameInfo->AddFrame(canvasInfoEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  MCInfoFrame->AddFrame(horizFrameMC, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameMC->AddFrame(canMCInfoEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  horiz_small->AddFrame(tracesButtons, new TGLayoutHints(kLHintsTop | kLHintsLeft, 3, 3, 3, 3));
  arrayButtons->AddFrame(fArrayZoomButton, new TGLayoutHints(kLHintsBottom | kLHintsCenterY, 3, 3, 3, 3));

  Arrayframe->AddFrame(horizframeArray, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizframeArray->AddFrame(canvasArrayEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  LDFframe->AddFrame(horizFrameLDF, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameLDF->AddFrame(canvasLDFEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  Residualsframe->AddFrame(horizFrameResiduals, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameResiduals->AddFrame(canvasResidualsEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  Lorentzframe->AddFrame(horizFrameLorentz, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  horizFrameLorentz->AddFrame(canvasLorentzEmb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  TraceFrame->AddFrame(canvasTraceemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  SpectrFrame->AddFrame(canvasSpectrum, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));
  FieldFrame->AddFrame(canvasFieldemb, new TGLayoutHints(kLHintsCenterX | kLHintsCenterY, 3, 3, 3, 3));

  fRdEventTab->SetEnabled(0, fHasStationTraces);
  fRdEventTab->SetEnabled(1, fHasStationTraces);
  fRdEventTab->SetEnabled(2, fHasStationTraces);
//  fRdEventTab->SetEnabled(3, fHasRStations);

}

RdPlots::~RdPlots()
{
  fEventObjects->Delete();
  fPMTObjects->Delete();
  fPlotsObjects->Delete();
  delete fEventObjects;
  delete fPMTObjects;
  delete fPlotsObjects;

  fMain->Cleanup();

}

void RdPlots::Clear()
{
  fPMTObjects->Delete();
  fPlotsObjects->Delete();
  fEventObjects->Delete();
  fTracesObjects->Delete();
  fCanvasInfo->Clear();
  fCanvasInfo->Update();
}

void RdPlots::Update()
{
  fEventObjects->Delete();

  fHasRStations = (*fEvent)->GetRdEvent().HasRdStations();
  fRdEventTab->SetEnabled(0, fHasStationTraces);
  fRdEventTab->SetEnabled(1, fHasStationTraces);
  fRdEventTab->SetEnabled(2, fHasStationTraces);
  fStationButton->SetEnabled(fHasStationTraces);
  fChannelButton->SetEnabled(fHasRdChannelTraces);
  fRdEventInfoTab->SetEnabled(0, true);
  RdEventInfo(fCanvasInfo);
  if(fIsMC) {
    RdMCInfo(fCanvasMCInfo);
    fRdEventInfoTab->SetEnabled(1, true);
  } else
    fRdEventInfoTab->SetEnabled(1, false);
  if(!((*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis)) {
    fSdAxisButton->SetState(kButtonUp);
    fRadioAxisButton->SetState(kButtonDown);
    fDrawSdAxis = false;
  }
  fSdAxisButton->SetEnabled((*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis);
  if(fDrawSdAxis == true)
    fSdAxisButton->SetState(kButtonDown);
   

  if(fRdArrayOnStatus) {
    if(fStationButton->IsEnabled())
      fStationButton->SetState(kButtonUp);
    fRdArrayOnStatus = true;
    fArrayPlot->Clear(); // Should reset the zoom
    fArrayPlot->GetMaxAndMinTime();
    UpdateArrayPlot();
  }
  //  fRdEventTab->SetTab(0);
  //DrawTimeResiduals();
  UpdateStationsList();

}

void RdPlots::DoRdReleased()
{
  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eSDZoomToCore:
    fRdArrayOnStatus = true;
    UpdateArrayPlot();
    break;

  default:
    break;
  }
}

void RdPlots::DoRdPressed()
{
  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eSDZoomToCore:
    fRdArrayOnStatus = true;
    break;
  default:
    break;
  }
}
void RdPlots::UpdateStationsList()
{

#if ROOT_VERSION_CODE <= ROOT_VERSION(5,12,0)
  // note: remove acts on IDs (this is very inefficient and
  // will not work for station lists containt ID>maxStation
  const int maxStation = 20000;
  fStationsListBox->RemoveEntries(0,maxStation);
  fStationsListBox->Layout();
#else
  fStationsListBox->RemoveAll();
#endif

  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  unsigned int firstId = 0;
  unsigned int lastId = 0;
  int n = 0;

  ostringstream name;
  for(unsigned int iS = 0; iS < stations.size(); iS++) {

    name.str("");
    int stationId = stations[iS].GetId();
    name << (*fDetectorGeometry)->GetRdStationName(stationId) << " ";
//    name << stations[iS].GetStationTriggerName(fRecStationClassVersion)<< " ";
    if(stations[iS].HasParameter(revt::eSignalToNoise) && stations[iS].HasParameter(revt::eSignal)) {
      // *1e6 to convert unit to muV/m
      name << round(stations[iS].GetParameter(revt::eSignal)*10.*1e6) / 10.;
      if(stations[iS].HasParameterError(revt::eSignal)) {
        name << " +/- " << round(stations[iS].GetParameterError(revt::eSignal)*10.*1e6) / 10.;
      }
      name  << " muV/m";
      if(stations[iS].HasParameter(revt::eSignalToNoise)) {
        name << " SNR=" << round(stations[iS].GetParameter(revt::eSignalToNoise)*10.) / 10.;
      }
    }
//    if(stations[iS].HasParameter(revt::eWaveletSimilarity)) {
//      name << " WSimi = " << round(stations[iS].GetParameter(revt::eWaveletSimilarity));
//    }

    if(stations[iS].HasParameter(revt::eAngleToLorentzVector)) {
      name << " Lorentz = " << round(TMath::RadToDeg()*stations[iS].GetParameter(revt::eAngleToLorentzVector)) << " deg";
    }

//    name << " ";

    if(firstId == 0)
      firstId = stations[iS].GetId();
    fStationsListBox->InsertEntry(name.str().c_str(), stationId, lastId);
    if(!stations[iS].HasPulse())
      fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(18));
    ++n;
    lastId = stations[iS].GetId();
  }

  /*  for ( unsigned int iS=0;iS<stations.size();iS++) {
   name <<  stations[iS].GetId() << " ";

   name <<  stations[iS].GetStationTriggerName(fRecStationClassVersion) << " ";
   name <<  round(stations[iS].GetTotalSignal()*10.)/10.;
   int stationId= stations[iS].GetId();
   fStationsListBox->AddEntry(name.str().c_str(), stationId);
   //  fStationsListBox->GetEntry(stationId)->SetBackgroundColor(TColor::Number2Pixel(18));
   ++n;
   }
   */
  fStationsListBox->MapSubwindows();
  fStationsListBox->Layout();
  fStationsListBox->Select(firstId);
  UpdateTabPlots();
  if(fHasStationTraces) {
    UpdateTraceTabPlots(0);
  }
}

void RdPlots::SelectStation()
{
  unsigned int stationNumber = fStationsListBox->GetSelected();
  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  for(unsigned int iS = 0; iS < stations.size(); iS++)
    if((stations[iS].GetId()) == (unsigned int) fStationsListBox->GetSelected())
      stationNumber = iS;
  fCurrentStation = stationNumber;

  if(fHasStationTraces) {
    UpdateTraceTabPlots(stationNumber);
  }
  UpdateArrayPlot();
  fArrayPlot->DrawSelectedRStationMarker(stationNumber);
}

void RdPlots::DoRdButton()
{
  if(!*fEvent)
    return;

  TGButton* button = (TGButton*) gTQSender;
  UInt_t id = button->WidgetId();
  switch(id) {
  case eRDChannel:
    fDrawChannel = true;
    fRdEventTab->SetEnabled(2, false);
    UpdateTraceTabPlots(fCurrentStation); // To be improved to keep the same station selected
    break;
  case eRDStation:
    fDrawChannel = false;
    fRdEventTab->SetEnabled(2, fHasStationTraces);
    UpdateTraceTabPlots(fCurrentStation); // To be improved to keep the same station selected
    break;
  case eRdTriggerWindow:
    fDrawTriggerWindow = fRdTriggerWindowButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdNoiseWindow:
    fDrawNoiseWindow = fRdNoiseWindowButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRDPeakLine:
    fDrawPeakLine = fRdPeakLineButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdVertPolarization:
    fDrawVertPolarization = fRdVertPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdEastPolarization:
    fDrawEastPolarization = fRdEastPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eRdNorthPolarization:
    fDrawNorthPolarization = fRdNorthPolarizationButton->IsDown();
    UpdateTraceTabPlots(fCurrentStation);
    break;
  case eResAxis:
    fDrawResAxis = true;
    UpdateTabPlots();
    break;
  case eResStation:
    fDrawResAxis = false;
    UpdateTabPlots();
    break;
  case eRadioAxis:
    fDrawSdAxis = false;
    UpdateTabPlots();
    break;
  case eSdAxis:
    fDrawSdAxis = true;
    UpdateTabPlots();
    break;
  default:
    break;
  }

}

void RdPlots::UpdateTraceTabPlots(unsigned int stNumber)
{
  fPMTObjects->Delete();
  if(!(*fEvent)->GetRdEvent().HasRdStations()) {
    cout << "WARNING: Event has no Radio Stations" << endl;
    return;
  }
  const std::vector<RdRecStation> & stations = (*fEvent)->GetRdEvent().GetRdStationVector();
  if(stNumber > stations.size())
    return;
  fCanvasTrace->Clear();
  fCanvasSpectrum->Clear();
  fCanvasField->Clear();
  const RdRecStation& recStation = stations[stNumber];
  fCanvasSpectrum->SetRightMargin(0.261663);
  fCanvasTrace->SetRightMargin(0.261663);
  fCanvasField->SetRightMargin(0.50);
  if(!fDrawChannel) {
    DrawAllTraces(recStation);
    DrawSpectrum(recStation);
    Draw2DField(recStation);
  } else if(fHasRdChannelTraces) {
    DrawChannelTraces(recStation);
    DrawChannelSpectrum(recStation);
  }
  fCanvasTrace->GetCanvas()->Modified();
  fCanvasTrace->GetCanvas()->Update();
  fCanvasSpectrum->GetCanvas()->Modified();
  fCanvasSpectrum->GetCanvas()->Update();
  fCanvasField->GetCanvas()->Modified();
  fCanvasField->GetCanvas()->Update();
}

void RdPlots::UpdateTabPlots()
{
  fPlotsObjects->Delete();
  if(!(*fEvent)->GetRdEvent().HasRdStations()) {
    cout << "WARNING: Event has no Radio Stations" << endl;
    return;
  }
  fCanvasLDF->Clear();
  DrawLDF();
  fCanvasLDF->GetCanvas()->Modified();
  fCanvasLDF->GetCanvas()->Update();

  fCanvasResiduals->Clear();
  DrawResiduals();
  fCanvasResiduals->GetCanvas()->Modified();
  fCanvasResiduals->GetCanvas()->Update();

  fCanvasLorentz->Clear();
  DrawLorentz();
  fCanvasLorentz->GetCanvas()->Modified();
  fCanvasLorentz->GetCanvas()->Update();

}

void RdPlots::DrawChannelSpectrum(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;
  const int start = 0;
  float maxtr = 0;
  float mintr = 0;
  float minfreq = 0;
  float maxfreq = 0;
  fCanvasSpectrum->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  TH1F *first_spect = NULL;
  for(int ch = eCH1; ch <= eCH2; ch++) {
    try {
      RdTrace tra = recStation.GetRdTrace(ch);
      const int end = tra.GetAbsoluteFreqSpectrum().size();
      //cout << "End " << end << endl;
      minfreq = min(tra.GetMinFreq(), tra.GetMaxFreq());
      maxfreq = max(tra.GetMinFreq(), tra.GetMaxFreq());
      //cout << "Frequencies: "<<tra.GetMinFreq() << "   " << tra.GetMaxFreq() << endl; // Anna
      ostringstream trname;
      trname << "spch_" << ch - 10 + 1;
      TH1F *hsp = new TH1F(trname.str().c_str(), " ", end - start + 1, minfreq, maxfreq);
      //cout << "TH1F parameteres: " << end-start+1 << " " << minfreq << " " << maxfreq << endl;  
      fPMTObjects->Add(hsp);

      hsp->GetYaxis()->SetTitle("Signal #muV/MHz");
      hsp->GetXaxis()->SetTitle("F(MHz)");
      hsp->SetLineWidth(1);
      for(int i = start; i < end; ++i)
        hsp->Fill(tra.Bin2Freq(i), tra.GetAbsoluteFreqSpectrum()[i]);
      int color = 0;
      TLegendEntry *entry;
      ostringstream legname;
      legname.str("");
      switch(ch) {
      case eCH1:
        color = kBlue;
        legname << "CH1";

        break;
      case eCH2:
        color = kRed;
        legname << "CH2";
        break;
      case eCH3:
        color = kCyan;
        legname << "CH3";
        break;
      case eCH4:
        color = kMagenta;
        legname << "CH4";
        break;
      }
      entry = legend->AddEntry("", legname.str().c_str());
      entry->SetTextColor(color);
      hsp->SetLineColor(color);
      if(ch == eCH1) {
        first_spect = hsp;
        hsp->Draw();
      } else {
        hsp->Draw("SAME");
      }
      float thismax = hsp->GetMaximum();
      float thismin = hsp->GetMinimum();
      if(thismin != 0) {
        if(mintr == 0)
          mintr = thismin;
        else
          mintr = min(thismin, mintr);
      }
      maxtr = max(thismax, maxtr);
      if(first_spect != NULL) {
        first_spect->GetYaxis()->SetRangeUser(max(mintr * .9, 0.1), maxtr * 1.1);
        //cout << "scaling y: " << max(mintr*.9,0.01) << " " << maxtr*1.1 << endl;
        first_spect->GetXaxis()->SetRangeUser(max(float(25.), minfreq), min(float(85.), maxfreq));
        //cout << "scaling x: " << max(float(25.),minfreq) << " " << min(float(85.),maxfreq) << endl;
      }
    } catch(std::out_of_range & e) {
      cerr << " RdPlots::DrawChannelSpectrum :: Caught std::out_of_range \n";
      cerr << e.what() << endl;
      cerr << "Keep Looping " << endl;
    }
    legend->Draw("SAME");
  }
}
void RdPlots::DrawSpectrum(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;

  const int start = 0;
  float maxtr, mintr;
  mintr = 0;
  maxtr = 0;
  float thisVEM;
  float minthistrace;

  // ------------- Station Spectrum --------------
  fCanvasSpectrum->cd();
  //fCanvasSpectrum->SetLogy(); // the beauty comes with the Log scaling for data
  TLegend *legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  TH1F *first_spect = NULL;

  for(int pol = 0; pol < 3; ++pol) {
    const vector<float>& spectrum = recStation.GetRdTrace(pol).GetAbsoluteFreqSpectrum();
    const int end = spectrum.size();
    const bool goodtrace = bool(spectrum.size());
    float minfreq = min(recStation.GetRdTrace(pol).GetMinFreq(), recStation.GetRdTrace(pol).GetMaxFreq());
    float maxfreq = max(recStation.GetRdTrace(pol).GetMinFreq(), recStation.GetRdTrace(pol).GetMaxFreq());
    ostringstream histName;
    histName << "Spectr" << pol;
    TH1F *hspect = new TH1F(histName.str().c_str(), " ", end + 1, minfreq, maxfreq);
    fPMTObjects->Add(hspect);

    hspect->GetYaxis()->SetTitle("Signal #muV/m/MHz");
    hspect->GetXaxis()->SetTitle("Frequency MHz");
    hspect->SetLineWidth(1);
    if(goodtrace) {
      for(int j = start; j < end; ++j) {
        hspect->Fill(recStation.GetRdTrace(pol).Bin2Freq(j), spectrum[j]);
      }
    }

    hspect->SetLineColor(pol + 1);
    if(pol + 1 == 3)
      hspect->SetLineColor(4);
    hspect->GetYaxis()->SetTitleOffset(0.5);
    if(first_spect == NULL) {
      first_spect = hspect;
      hspect->GetXaxis()->SetRangeUser(max(float(25.), minfreq), min(float(85.), maxfreq)); // Set by hand the range from 25 to 85 Mhz, the automatic setting gives ugly histogram if up-sampling is used
      hspect->Draw("AXIS");
      if (fDrawEastPolarization && pol==0)
        hspect->Draw("same");
      thisVEM = hspect->GetMaximum();
      minthistrace = hspect->GetMinimum();
      maxtr = max(thisVEM, maxtr);
      if(mintr == 0)
        mintr = minthistrace;
      else if(minthistrace != 0)
        mintr = min(minthistrace, mintr);
    } else {
      if(pol == 2) {
        if(fDrawVertPolarization) { // Button for vertical polarization
          hspect->Draw("same");
          thisVEM = hspect->GetMaximum();
          minthistrace = hspect->GetMinimum();
          maxtr = max(thisVEM, maxtr);
          if(mintr == 0)
            mintr = minthistrace;
          else if(minthistrace != 0)
            mintr = min(minthistrace, mintr);
        }
      } else if (fDrawNorthPolarization && pol==1) {
        hspect->Draw("same");
        thisVEM = hspect->GetMaximum();
        minthistrace = hspect->GetMinimum();
        maxtr = max(thisVEM, maxtr);
        if(mintr == 0)
          mintr = minthistrace;
        else if(minthistrace != 0)
          mintr = min(minthistrace, mintr);
      }
    }

  } //pol

//Write Legend and statistics in the legend
  if(first_spect != NULL) {
    if(fIsMC)
      first_spect->GetYaxis()->SetRangeUser(max(0.01, mintr * 0.9), maxtr * 1.1);
    else
      first_spect->GetYaxis()->SetRangeUser(max(0.5, mintr * 0.9), maxtr * 1.1);
  } // max() necessary in order to avoid problems in axis scaling with log

  TString name;
  ostringstream legname;
  name = "Spectra ";
  TLegendEntry *entry; //= legend->AddEntry("",name,"");
  for(int pol = 0; pol < 3; ++pol) {
    legname.str("");
    legname << "polarisation " << GetPolarisationName(pol);
    if(pol == 2) {
      if(fDrawVertPolarization) {
        entry = legend->AddEntry("", legname.str().c_str(), "");
        entry->SetTextColor(4);
      }
    } else {
      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pol + 1);
    }
  }
  legend->Draw();

}

void RdPlots::DrawChannelTraces(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;
  const int start = 0;
  float maxtr = 0;
  float mintr = 0;
  fCanvasTrace->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  TH1F *first_trace = NULL;
#warning: plotting channel 1&2 only: temporary fix until channels are selectable
  for(int ch = eCH1; ch <= eCH2; ch++) {
    try {
      RdTrace tra = recStation.GetRdTrace(ch);
      float timeBinning = tra.GetSamplingRate();
      const int end = tra.GetTimeTrace().size();
      ostringstream trname;
      trname << "ch_" << ch - 10 + 1;
      TH1F *htrace = new TH1F(trname.str().c_str(), " ", end - start + 1, start * timeBinning, end * timeBinning);
      htrace->Reset();
      fPMTObjects->Add(htrace);

      htrace->GetYaxis()->SetTitle("Signal #muV");
      htrace->GetXaxis()->SetTitle("t [ns]");
      htrace->SetLineWidth(1);
      for(int i = start; i < end; ++i)
        htrace->Fill(i * timeBinning, tra.GetTimeTrace()[i]);
      int color = 0;
      TLegendEntry *entry;
      ostringstream legname;
      legname.str("");
      switch(ch) {
      case eCH1:
        color = kBlue;
        legname << "CH1";
        break;
      case eCH2:
        color = kRed;
        legname << "CH2";
        break;
      case eCH3:
        color = kCyan;
        legname << "CH3";
        break;
      case eCH4:
        color = kMagenta;
        legname << "CH4";
        break;
      }
      entry = legend->AddEntry("", legname.str().c_str());
      entry->SetTextColor(color);
      htrace->SetLineColor(color);
      if(ch == eCH1) {
        first_trace = htrace;
        htrace->Draw();
      } else {
        htrace->Draw("SAME");
      }
      float thismax = htrace->GetMaximum();
      float thismin = htrace->GetMinimum();
      if(thismin != 0) {
        if(mintr == 0)
          mintr = thismin;
        else
          mintr = min(thismin, mintr);
      }
      maxtr = max(thismax, maxtr);
    } catch(std::out_of_range & e) {
      cerr << " RdPlots::DrawChannelTraces :: Caught std::out_of_range \n";
      cerr << e.what() << endl;
      cerr << "Keep Looping " << endl;
      continue;
    }
  }
  legend->Draw("SAME");
  first_trace->GetYaxis()->SetRangeUser(mintr * 1.05, maxtr * 1.05);
  first_trace->Draw("SAME");
//    first_trace->GetXaxis()->SetRangeUser(min(mintr*.9,mintr*1.1),maxtr*1.1);
} //DrawChannelTraces

void RdPlots::DrawAllTraces(const RdRecStation& recStation)
{
  unsigned int stationID = (unsigned int) recStation.GetId();
  if(stationID == 0)
    return;

  const int start = 0;
  float maxtr = 0;
  float mintr = 0;

  // ------------- Time trace --------------
  fCanvasTrace->cd();
  TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
  fPMTObjects->Add(legend);
  legend->SetFillColor(0);
  legend->SetLineColor(0);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);

  TH1F *first_trace = NULL;

  for(int pol = 0; pol < 3; ++pol) {
    float timeBinning = recStation.GetRdTrace(pol).GetSamplingRate();
    const int end = recStation.GetRdTrace(pol).GetTimeTrace().size();
    const vector<float>& trace = recStation.GetRdTrace(pol).GetTimeTrace();
    const bool goodtrace = bool(trace.size());
    ostringstream histName;
    histName << "Trace" << pol;
    TH1F *htrace = new TH1F(histName.str().c_str(), " ", end - start + 1, start * timeBinning, end * timeBinning);
    fPMTObjects->Add(htrace);

    htrace->GetYaxis()->SetTitle("Signal #muV/m");
    htrace->GetXaxis()->SetTitle("t [ns]");
    htrace->SetLineWidth(1);
    if(goodtrace) {
      for(int j = start; j < end; ++j) {
        htrace->Fill(j * timeBinning, trace[j]);
      }
    }

    htrace->SetLineColor(pol + 1);
    if(pol + 1 == 3)
      htrace->SetLineColor(4);

    htrace->GetYaxis()->SetTitleOffset(0.5);
    if(first_trace == NULL) {
      first_trace = htrace;
      htrace->Draw("AXIS");
      if(fDrawEastPolarization && pol == 0)
        htrace->Draw("same");
    } else {  
      if(fDrawNorthPolarization && pol == 1)
         htrace->Draw("same");   
      if(fDrawVertPolarization && pol == 2) 
        htrace->Draw("same");

    }

    float thisVEM = htrace->GetMaximum();
    float thismin = htrace->GetMinimum();
    if(thismin != 0) {
      if(mintr == 0)
        mintr = thismin;
      else
        mintr = min(thismin, mintr);
    }
    maxtr = max(thisVEM, maxtr);
  } //pol

//Write Legend and statistics in the legend
  if(first_trace != NULL)
    first_trace->GetYaxis()->SetRangeUser(mintr * 1.1, maxtr * 1.1);

  TString name;
  ostringstream legname;
  name = "Trace ";
  TLegendEntry *entry;
  for(int pmt = 0; pmt < 3; ++pmt) {
    legname.str("");
    legname << " polarisation " << GetPolarisationName(pmt);

    if(fDrawVertPolarization && pmt == 2) {                        // Button

      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pmt + 2);
    }

    if(pmt != 2) {

      entry = legend->AddEntry("", legname.str().c_str(), "");
      entry->SetTextColor(pmt + 1);

    }

  }
  try {
    if(recStation.GetParameter(revt::eSignalTime) != 0) {
      float LineTime = recStation.GetParameter(revt::eSignalTime) - recStation.GetParameter(revt::eTraceStartTime);
      float peakx[] = { LineTime };
      float peaky[] = { 0. };
      float peakex[] = { 0. };
      float peakey[] = { 1.1 * max(maxtr, abs(mintr)) };
      TGraphErrors *PeakLine = new TGraphErrors(1, peakx, peaky, peakex, peakey); // It's not a real line, but TGraph clips to the frame boundary
      fPMTObjects->Add(PeakLine);
      PeakLine->SetLineColor(kMagenta);
      PeakLine->SetLineWidth(1);
      PeakLine->SetLineStyle(2);
      if(fDrawPeakLine) // Button
        PeakLine->Draw();
    }
  }

  catch(const std::out_of_range & e) {
    cerr << " RdPlots::DrawAllTraces :: Caught std::out_of_range when drawing pulse position \n";
    cerr << e.what() << endl;
  }
  try {
    float signalstarttime = recStation.GetParameter(revt::eSignalSearchWindowStart);
    float signalstoptime = recStation.GetParameter(revt::eSignalSearchWindowStop);
    float signalx[] = { signalstarttime, signalstoptime };
    float signaly[] = { 0., 0. };
    float signalex[] = { 0., 0. };
    float signaley[] = { 1.1 * max(maxtr, abs(mintr)), 1.1 * max(maxtr, abs(mintr)) };
    TGraphErrors *bxSignal = new TGraphErrors(2, signalx, signaly, signalex, signaley); // It's not a real box, but TGraph clips to the frame boundary
    fPMTObjects->Add(bxSignal);
    bxSignal->SetFillColor(kGreen);
    bxSignal->SetFillStyle(3315);
    if(fDrawTriggerWindow)      //Button
      bxSignal->Draw("3");

    float noisestarttime = recStation.GetParameter(revt::eNoiseWindowStart);
    float noisestoptime = recStation.GetParameter(revt::eNoiseWindowStop);
    float noisex[] = { noisestarttime, noisestoptime };
    float noisey[] = { 0., 0. };
    float noiseex[] = { 0., 0. };
    float noiseey[] = { 1.1 * max(maxtr, abs(mintr)), 1.1 * max(maxtr, abs(mintr)) };
    TGraphErrors *bxNoise = new TGraphErrors(2, noisex, noisey, noiseex, noiseey); // It's not a real box, but TGraph clips to the frame boundary
    bxNoise->SetFillColor(kOrange + 2);
    bxNoise->SetFillStyle(3351);
    fPMTObjects->Add(bxNoise);
    if(fDrawNoiseWindow)    //Button
      bxNoise->Draw("3");

  } catch(...) {
    cerr << " RdPlots::DrawAllTraces :: Caught exception when drawing signal/noise search window\n";
  }

  legend->Draw();

}

void RdPlots::Draw2DField(const RdRecStation& recStation)
{
  const float windowsizens = 100.; // 100 ns !
//  const int graphsize(80); // Number of points for the graph/ should instead define a time window
  const vector<float>& traceX = recStation.GetRdTrace(eX).GetTimeTrace();
  const vector<float>& traceY = recStation.GetRdTrace(eY).GetTimeTrace();
  vector<float> X;
  vector<float> Y;
  fCanvasField->cd();
  int peakposition = 2000;
  try {
    peakposition = TMath::Floor(
        (recStation.GetParameter(revt::eSignalTime) - recStation.GetParameter(revt::eTraceStartTime))
            / recStation.GetRdTrace(eX).GetSamplingRate());
  } catch(const std::out_of_range & e) {
    cerr << " RdPlots::Draw2DField :: Caught std::out_of_range when searching for pulse\n";
    cerr << e.what();
    cerr << " Trying to draw field from an arbitrary position (2000 bins)" << endl;
  }
  try {
    int graphsize = TMath::Floor(windowsizens / recStation.GetRdTrace(eX).GetSamplingRate()); // Number of the point for the graph windowssizens/binsize
    if(peakposition <= 0)
      return;
    for(int i = (peakposition - graphsize / 2); i < (peakposition + graphsize / 2); ++i) {
      X.push_back(traceX[i]);
      Y.push_back(traceY[i]);
    }
    TGraph *gr_field = new TGraph(X.size(), &X.front(), &Y.front());
    fPMTObjects->Add(gr_field);
    ostringstream title;
    float xmin, xmax;
    title.str("");
    title << "Pole " << recStation.GetId(); // Name should not be hard-coded !
    gr_field->SetTitle("Electric Field around the peak (2D view)");
    gr_field->GetXaxis()->SetTitle("X component");
    gr_field->GetYaxis()->SetTitle("Y component");
    gr_field->SetMarkerStyle(6);
    gr_field->SetLineColor(kGray + 1);
    xmin = min(gr_field->GetXaxis()->GetXmin(), gr_field->GetYaxis()->GetXmin());
    //  ymin=gr_field->GetYaxis()->GetXmin(),;
    //  ymin=gr_field->GetMinimum();
    xmax = max(gr_field->GetXaxis()->GetXmax(), gr_field->GetYaxis()->GetXmax());
    //  ymax=gr_field->GetYaxis()->GetXmax();
    //  ymax=gr_field->GetMaximum();
    //gr_field->SetMinimum(min(xmin,ymin));
    // gr_field->SetMaximum(max(xmax,ymax));
    TH2F *H_axis = new TH2F("2D Field", "2Dfield", 100, xmin, xmax, 100, xmin, xmax);
    fPMTObjects->Add(H_axis);
    H_axis->Draw("");
    H_axis->GetXaxis()->SetTitle("X Field #mu V/m");
    H_axis->GetYaxis()->SetTitle("Y Field #mu V/m");
    gr_field->Draw("PC SAME");

    TLegend * legend = new TLegend(0.768763, 0.156584, 0.941176, 0.882562);
    fPMTObjects->Add(legend);
    legend->SetFillColor(0);
    legend->SetLineColor(0);
    legend->SetFillStyle(0);
    legend->SetBorderSize(0);
    legend->AddEntry("", title.str().c_str(), "");
    legend->Draw();
  }

  catch(const std::out_of_range & e) {
    cerr << "RdPlots::Draw2DField :: Get std::out_of_range when trying to get the trace\n";
    cerr << e.what();
    cerr << " I give up " << endl;
  }
}

void RdPlots::RdEventInfo(TCanvas* myCanvas)
{

  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const RdEvent &rdevent = (*fEvent)->GetRdEvent();

  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);

  y -= 0.5 * dy;

  ostringstream info;
  info << "Run " << rdevent.GetRdRunNumber();
  info << "  Event " << rdevent.GetRdEventId();
  info << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  const int lGPSsec = rdevent.GetGPSSecond();
  const int lGPSnsec = rdevent.GetGPSNanoSecond();
  info << "GPS Time " << lGPSsec << " s " << lGPSnsec << " ns";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  int yymmdd = (*fEvent)->GetYYMMDD();
  int hhmmss = (*fEvent)->GetHHMMSS();
  int year = yymmdd / 10000;
  int month = (yymmdd % 10000) / 100;
  int day = (yymmdd % 100);
  int hour = (int) (hhmmss / 10000.);
  int minute = (hhmmss % 10000) / 100;
  int second = (hhmmss % 100);
  info << "UTC Date: 20";
  if(year > 9) {
    info << year;
  } else {
    info << "0" << year;
  }
  if(month > 9) {
    info << "/" << month;
  } else {
    info << "/0" << month;
  }
  if(day > 9) {
    info << "/" << day;
  } else {
    info << "/0" << day;
  }
  if(hour > 9) {
    info << "   " << hour;
  } else {
    info << "   0" << hour;
  }
  if(minute > 9) {
    info << ":" << minute;
  } else {
    info << ":0" << minute;
  }
  if(second > 9) {
    info << ":" << second;
  } else {
    info << ":0" << second;
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");
  double recStage = 0;
  if(rdevent.GetRdRecShower().HasParameter(revt::eRecStage)) {
    recStage = rdevent.GetRdRecShower().GetParameter(revt::eRecStage);
    info << "RecStage = " << GetRecStage(recStage);
  } else
    info << "RecStage undefined";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");
  try {
    float theta = TMath::RadToDeg()
        * acos(rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisZ) / rdevent.GetRdRecShower().GetRadius());
    float thetaError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithError();
    float phi = atan2(rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisY),
        rdevent.GetRdRecShower().GetParameter(revt::eShowerAxisX));
    float phiError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthError();
    if(phi < 0)
      phi += 2 * TMath::Pi();
    phi *= TMath::RadToDeg();
    info << "#theta = " << 1. * TMath::Nint(theta * 100) / 100;
    if(recStage >= 1.1 and not isnan(thetaError)) //
      info << "#pm" << 1. * TMath::Nint(thetaError * 100) / 100;
    info << " deg  #phi = " << 1. * TMath::Nint(phi * 100) / 100;
    if(recStage >= 1.1 and not isnan(phiError))  //
      info << "#pm" << 1. * TMath::Nint(phiError * 100) / 100 << " deg";
  } catch(...) {
    info << " #theta and #phi not defined ";
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  if(rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisX)
      && rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisY)
      && rdevent.GetRdRecShower().HasParameter(revt::ePreFitShowerAxisZ)) {
    float thetaPre = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithPreFit();
    float thetaPreError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithPreFitError();
    float phiPre = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthPreFit();
    float phiPreError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthPreFitError();
    info << "PreFit: #theta = " << 1. * TMath::Nint(thetaPre * 10) / 10 << "#pm" << 1. * TMath::Nint(thetaPreError * 100) / 100
         << " deg  #phi = " << 1. * TMath::Nint(phiPre * 10) / 10 << "#pm" << 1. * TMath::Nint(phiPreError * 100) / 100 << " deg";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 1.2) {
    //This quantities make no sense if the fit is plane or not chi^{2} based
    double radius = rdevent.GetRdRecShower().GetRadius();
    double radiusError = rdevent.GetRdRecShower().GetRadiusError();
    info << "radius = " << radius << " #pm " << radiusError << " m";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");

    double convergedFit = 0;
    double FitSuccess = 0;
    if(rdevent.GetRdRecShower().HasParameter(revt::eFitConvergence))
      convergedFit = rdevent.GetRdRecShower().GetParameter(revt::eFitConvergence);
    if(rdevent.GetRdRecShower().HasParameter(revt::eFitSuccess))
      FitSuccess = rdevent.GetRdRecShower().GetParameter(revt::eFitSuccess);
    info << "FitStatus = ";
    if(convergedFit == 1)
      info << "converged";
    if(FitSuccess == 0)
      info << "failed";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 1.1) {
    if(rdevent.GetRdRecShower().HasParameter(revt::eWaveFitChi2) && rdevent.GetRdRecShower().HasParameter(revt::eWaveFitNDF))
      info << "Chi2/NDF = " << setprecision(3) << rdevent.GetRdRecShower().GetParameter(revt::eWaveFitChi2) << " / "
           << rdevent.GetRdRecShower().GetParameter(revt::eWaveFitNDF);
    else
      info << "Chi2/NDF undefined";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }
  if(recStage > 0.0) {
    info << "x = " << rdevent.GetRdRecShower().GetCoreSiteCS().X() / 1000 << " km, y = "
         << rdevent.GetRdRecShower().GetCoreSiteCS().Y() / 1000 << " km"; // one day this should also display errors
  } else {
    info << " x and y not defined";
  }
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  if(not isnan(rdevent.GetRdRecShower().GetZenith())) {
    double zenith = rdevent.GetRdRecShower().GetZenith();
    double azimuth = rdevent.GetRdRecShower().GetAzimuth();
    TVector3 bfield = TVector3(1);
    bfield.SetTheta(TMath::DegToRad() * 58);
    bfield.SetPhi(TMath::DegToRad() * 87.4);
    TVector3 showeraxis = TVector3(1);
    showeraxis.SetTheta(zenith);
    showeraxis.SetPhi(azimuth);
    double alpha = TMath::RadToDeg() * showeraxis.Angle(bfield);
    info << "#alpha = " << alpha << "#circ";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
  }

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}

void RdPlots::RdMCInfo(TCanvas* myCanvas)
{
  fEventObjects->Delete();

  myCanvas->cd();
  myCanvas->Clear();

  const GenShower & genShower = (*fEvent)->GetGenShower();

  float x1 = 0.03;
  float y = 0.95;
  float dy = 0.08;

  TLatex *slegend = new TLatex();
  fEventObjects->Add(slegend);
  slegend->SetNDC();
  slegend->SetTextSize(0.055);

  y -= 0.5 * dy;
  ostringstream info;
  info.str("");
  info << " MC Event ";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  float theta = genShower.GetZenith() / view::Consts::degree;
  float phi = genShower.GetAzimuth() / view::Consts::degree;

  info << "#theta = " << theta << "deg  #phi = " << phi << " deg";
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << "Energy = " << genShower.GetEnergy() / 1e18 << " EeV " << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << "Xmax = " << genShower.GetXmax() << " g/cm^{2}" << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  info << "Primary particle: " << genShower.GetPrimaryName() << endl;
  slegend->DrawLatex(x1, y, info.str().c_str());
  y -= dy;
  info.str("");

  myCanvas->GetCanvas()->Modified();
  myCanvas->GetCanvas()->Update();
}

std::string RdPlots::PrintPostScript()
{

  const int evId = (*fEvent)->GetRdEvent().GetRdEventId();
  ostringstream arrayFileStream;
  arrayFileStream << "/tmp/tmp" << evId << "_Rarray.eps";
  fCanvasArray->cd();
  fCanvasArray->Print(arrayFileStream.str().c_str());

  ostringstream traceFileStream;
  traceFileStream << "/tmp/tmp" << evId << "_Rtrace.eps";
  fCanvasTrace->cd();
  fCanvasTrace->Print(traceFileStream.str().c_str());

  ostringstream spectrFileStream;
  spectrFileStream << "/tmp/tmp" << evId << "_Rspectr.eps";
  fCanvasSpectrum->cd();
  fCanvasSpectrum->Print(spectrFileStream.str().c_str());

  ostringstream infoFileStream;
  infoFileStream << "/tmp/tmp" << evId << "_Rinfo.eps";
  fCanvasInfo->cd();
  fCanvasInfo->SaveAs(infoFileStream.str().c_str());

  ostringstream filenameStream;
  filenameStream << "RdEvent_" << evId << ".ps";
  const char* filename = filenameStream.str().c_str();
  ostringstream commandStream;

  commandStream << ADST_BIN_DIR << "/RdEvent2ps.csh " << evId << " " << filename;

  const char* command = commandStream.str().c_str();
  int retvalue = system(command);
  if(retvalue != 0)
    cout << " Something wrong occured during RdPlots Saving" << endl;
  return string(filename);
}

void RdPlots::UpdateArrayPlot()
{
  fArrayPlot->Draw(true, fShowFD, fIsMC);
}

void RdPlots::HandleArrayClicked(Int_t event, Int_t px, Int_t py, TObject* /*sel*/)
{
  TCanvas *c = (TCanvas *) gTQSender;
  TPad *pad = (TPad *) c->GetSelectedPad();
  if(event == kButton1Down || event == kButton1Double) {

    if(fRdArrayOnStatus) {
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      const int stid = (*fDetectorGeometry)->GetClosestRdStationId(ClickX * 1000., ClickY * 1000.);
      if(stid != 0) {
        const std::vector<RdRecStation>& stations = (*fEvent)->GetRdEvent().GetRdStationVector();

        fStationsListBox->Select(stid);
        for(unsigned int iS = 0; iS < stations.size(); ++iS) {
          if(int(stations[iS].GetId()) == stid) {
            if(fHasStationTraces)
              UpdateTraceTabPlots(iS);

            UpdateArrayPlot();
            fArrayPlot->DrawSelectedStationMarker(iS);
            break;
          }
        }
      }
    } // if array on

  } else if(event == kButton2Down || event == kButton2Double) {

    if(fRdArrayOnStatus) {
      Double_t ClickX = pad->AbsPixeltoX(px);
      Double_t ClickY = pad->AbsPixeltoY(py);
      ClickX = pad->PadtoX(ClickX);
      ClickY = pad->PadtoY(ClickY);
      fArrayPlot->SetZoomCenter(ClickX, ClickY);
      UpdateArrayPlot();
    }
  }
}

void RdPlots::DrawLDF(const int pol)
{
  /*
   This function is still at debug stage and should not be trusted for physics
   TODO
   + Error calculation
   + Check DetectorGeometry->GetRdStationPosition()
   */

  fCanvasLDF->cd();
  // This should be updated to make all the button usable but this is a first version
  int count = 0;
  int noisecount = 0;
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  double axisdistmax = 0.0;
  double amplitudemax = 0.0;
  TGraphErrors *gr_LDF = new TGraphErrors(v_stat.size());
  TGraphErrors *gr_LDFNoise = new TGraphErrors(v_stat.size());
  fPlotsObjects->Add(gr_LDF);
  fPlotsObjects->Add(gr_LDFNoise);
  if((*fEvent)->GetRdEvent().GetRdRecShower().HasParameter(revt::eRecStage)) {
    TVector3 axis;
    TVector3 core;
    if(fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) {
      axis = (*fEvent)->GetSDEvent().GetSdRecShower().GetAxisSiteCS();
      core = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS();
    }
    else {
      axis = radioevt.GetRdRecShower().GetAxisSiteCS();
      core = radioevt.GetRdRecShower().GetCoreSiteCS();
    }
    for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); stiter++) {
      float amplitude = 0;
      float amplitudeError = 0;
      try {
        if(pol == 0) {
          amplitude = stiter->GetParameter(revt::eSignal)*1e6;
          amplitudeError = stiter->GetParameterError(revt::eSignal)*1e6;
        } else if(pol == 1) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeEW)*1e6;
        } else if(pol == 2) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeNS)*1e6;
        } else if(pol == 3) {
          amplitude = stiter->GetParameter(revt::ePeakAmplitudeV)*1e6;
        }
      } catch(...) {
        cerr << " RdPlots::DrawLDF :: Caught std::invalid_argument when asking for pulse maximum\n";
      }
      //double axisdist=(*fDetectorGeometry)->GetStationAxisDistance(stiter->GetId(),axis,core); // This should work To be checked !!
      double axisdist = (*fDetectorGeometry)->GetStationAxisDistance((*fDetectorGeometry)->GetRdStationPosition(stiter->GetId()),
          axis, core);
      if(axisdist > axisdistmax)
        axisdistmax = axisdist;
      if(amplitude > amplitudemax)
        amplitudemax = amplitude;
      if (stiter->HasPulse()) {
        gr_LDF->SetPoint(count, axisdist, amplitude);
        gr_LDF->SetPointError(count, 0, amplitudeError); 
        count++;
      }
      else {
        gr_LDFNoise->SetPoint(noisecount, axisdist, amplitude);
        gr_LDFNoise->SetPointError(noisecount, 0, amplitudeError);
        noisecount++;
      }
    } // for stiter
    axisdistmax += 0.2 * axisdistmax;
    amplitudemax += 0.2 * amplitudemax;
    ostringstream title;
    title.str("");
    title << " Lateral distribution for polarization " << GetPolarisationName(pol);
    TH2F *H_ldfaxis = new TH2F("LDF", title.str().c_str(), 300, 0.01, axisdistmax, 300, 0.01, amplitudemax);
    fPlotsObjects->Add(H_ldfaxis);
    if (fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) H_ldfaxis->GetXaxis()->SetTitle("Distance to Sd shower axis [m]");
    else H_ldfaxis->GetXaxis()->SetTitle("Distance to radio shower axis [m]");
    H_ldfaxis->GetYaxis()->SetTitle("Amplitude [#muV/m]");
    H_ldfaxis->Draw("");
    gr_LDF->SetMarkerStyle(24);
    gr_LDF->Draw("P SAME");
    gr_LDFNoise->SetMarkerStyle(24);
    gr_LDFNoise->SetMarkerColor(kGray);
    gr_LDFNoise->SetLineColor(kGray);
    gr_LDFNoise->Draw("P SAME");
  } else {
    TText text;
    text.SetTextSize(0.035);
    text.DrawTextNDC(0.4, 0.5, "no LDF available");
  }
  fCanvasLDF->Update();
}

void RdPlots::DrawResiduals()
{
  fCanvasResiduals->cd();
  TGraphErrors *gr_Residuals = new TGraphErrors();
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  fPlotsObjects->Add(gr_Residuals);
  bool hasResiduum = false;
  for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); stiter++) {
    if(stiter->HasParameter(revt::eTimeResidual)) {
      hasResiduum = true;
      if(fDrawResAxis) {
        TVector3 axis;
        TVector3 core;
        if(fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) {
          axis = (*fEvent)->GetSDEvent().GetSdRecShower().GetAxisSiteCS();
          core = (*fEvent)->GetSDEvent().GetSdRecShower().GetCoreSiteCS();
        }
        else {
          axis = radioevt.GetRdRecShower().GetAxisSiteCS();
          core = radioevt.GetRdRecShower().GetCoreSiteCS();
        }
        double axisdist = (*fDetectorGeometry)->GetStationAxisDistance((*fDetectorGeometry)->GetRdStationPosition(stiter->GetId()), axis, core);
        gr_Residuals->SetPoint(gr_Residuals->GetN(), axisdist, stiter->GetParameter(revt::eTimeResidual));
      }
      else gr_Residuals->SetPoint(gr_Residuals->GetN(), stiter->GetId() , stiter->GetParameter(revt::eTimeResidual));
      if(stiter->HasParameterCovariance(revt::eTimeResidual, revt::eTimeResidual)) {
        gr_Residuals->SetPointError(gr_Residuals->GetN() - 1, 0, stiter->GetParameterError(revt::eTimeResidual));
      } else {
        cout << "WARNING: ParameterError eTimeResidual not set" << endl;
        gr_Residuals->SetPointError(gr_Residuals->GetN() - 1, 0, 0);
      }
      if(not stiter->HasParameterError(revt::eSignal)) {
        cout << "WARNING ParameterError eSignal not set" << endl;
      }
    }
  } // for stiter

  if(hasResiduum) {
    if(!fDrawResAxis) gr_Residuals->GetXaxis()->SetTitle("Station Id");
    else if (fDrawSdAxis && (*fEvent)->GetSDEvent().GetRecLevel()>=eHasSdAxis) gr_Residuals->GetXaxis()->SetTitle("Distance to Sd shower axis [m]");
    else gr_Residuals->GetXaxis()->SetTitle("Distance to radio shower axis [m]");
    gr_Residuals->GetYaxis()->SetTitle("time offset [ns]");
    gr_Residuals->SetMarkerStyle(8);
    gr_Residuals->SetMarkerColor(4);
    // adjust y-range
    double max = TMath::Max(gr_Residuals->GetHistogram()->GetMaximum(), abs(gr_Residuals->GetHistogram()->GetMinimum()));
    gr_Residuals->GetYaxis()->SetRangeUser(-max, max);
    gr_Residuals->Draw("AP");
    fCanvasResiduals->SetGridy();
  } else {
    TText text;
    text.SetTextColor(2);
    text.SetTextSizePixels(30);
    text.SetTextAngle(40);
    text.DrawTextNDC(0.30, 0.40, "No data available");

    text.SetTextColor(1);
    text.SetTextSizePixels(12);
    text.SetTextAngle(0);
    text.DrawTextNDC(0.17, 0.20, "use Module RdWaveFit or RdPlaneFit to reconstruct this quantity");
  }

  fCanvasResiduals->Update();
}

void RdPlots::DrawLorentz()
{
  fCanvasLorentz->cd();
  TH1D *hLorentz = new TH1D("hLorentz", "", 9, 0, 90);
  const RdEvent& radioevt = (*fEvent)->GetRdEvent();
  const vector<RdRecStation>& v_stat = radioevt.GetRdStationVector();
  fPlotsObjects->Add(hLorentz);
  bool hasLorentz = false;
  for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); stiter++) {
    if(stiter->HasParameter(revt::eAngleToLorentzVector)) {
      hLorentz->Fill(TMath::RadToDeg() * stiter->GetParameter(revt::eAngleToLorentzVector));
      hasLorentz = true;
    }
  } // for stiter

  hLorentz->GetXaxis()->SetTitle("#angle(#vec{E},#vec{F}_{Lorentz}) [deg]");
  hLorentz->GetYaxis()->SetTitle("Entries");
  hLorentz->Draw();

  if(!hasLorentz) {
    TText text;
    text.SetTextColor(2);
    text.SetTextSizePixels(30);
    text.SetTextAngle(40);
    text.DrawText(40, 0.3, "No data available");

    text.SetTextColor(1);
    text.SetTextSizePixels(12);
    text.SetTextAngle(0);
    text.DrawText(17, 0.2, "use Module RdStationEFieldVectorCalculator");
    text.DrawText(17, 0.17, "to reconstruct this quantity");
  }

  fCanvasLorentz->Update();
}

string RdPlots::GetPolarisationName(const int pol)
{
  switch(pol) {
  case 0:
    return "East";
  case 1:
    return "North";
  case 2:
    return "Vertical";
  default:
    return "unknown";
  }
}

string RdPlots::GetRecStage(const double recStage)
{
  // convert recstage to an int to use a switch statement
  const int nRecStage = int(recStage * 10);
  switch(nRecStage) {
  case 0:
    return "unsuccessful/none";
  case 5:
    return "BaryCenter";
  case 10:
    return "PlaneFitLinear";
  case 11:
    return "PlaneFitLinear2";
  case 12:
    return "PlaneFit3d";
  case 15:
    return "SphericalWaveFit";
  case 16:
    return "SphericalWaveFitVarC";
  default:
    stringstream sstr;
    sstr << "unknown = " << recStage;
    string temp;
    sstr >> temp;
    return temp;
  }
}

#endif
