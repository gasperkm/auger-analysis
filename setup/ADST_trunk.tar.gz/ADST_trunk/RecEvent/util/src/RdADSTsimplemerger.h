#ifndef _adst_RdADSTsimplemerger_h_
#define _adst_RdADSTsimplemerger_h_

#include "RecEventFile.h"
#include <string>


class DetectorGeometry;
class RecEvent;
class RdEvent;

class RdADSTsimplemerger {
public:
  RdADSTsimplemerger(std::string outputfile);
  ~RdADSTsimplemerger();
  void WriteGeometry(DetectorGeometry* geo);
  void WriteFileInfo(FileInfo info);
  void Merge(RecEvent* recevent, RdEvent& radioevent);
  void WriteEvent();
  inline void MergeAndWrite(RecEvent* recevent, RdEvent& radioevent) { Merge(recevent, radioevent); WriteEvent(); }
  void CloseMergedFile();
  void MergeAndWriteFileInfo(FileInfo obsinfo, FileInfo radioinfo);
private:
  RecEventFile fOutFile;
  RecEvent* fmergedEvent;

};


#endif
