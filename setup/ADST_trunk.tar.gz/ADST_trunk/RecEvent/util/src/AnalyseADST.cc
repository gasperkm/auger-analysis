/********************************************************************************
                        AnalyseADST
   
  example program to apply quality cuts on Auger-Hybrid 
  events (ADST-format) and create ROOT-histograms

  Installation: 
   - copy AnalyseADST.cc to $ADSTROOT/RecEvent/util/src
   - do "cd $ADSTROOT/RecEvent/util" 
   - type "make"

  Usage:
   - "cd $ADSTROOT/RecEvent/util"
   - "AnalyseADST <ADSTfileName> <Outputfilename>"
      where <ADSTfileName> is the name of an ADST file, e.g. $ADSTROOT/Events/HybridRec.root 
      or a list of ADST files, e.g. "HybridRec*.root"
   - the created histogram(s) can be found in <Outputfilename>

  Please send questions and comments to adst-devel@auger.unam.mx

*********************************************************************************/

#include "RecEvent.h"
#include "RecEventFile.h"
#include "DetectorGeometry.h"
#include "FileInfo.h"
#include <TH1F.h>
#include <TFile.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
using namespace std;

/*========================================================
   print some usage hints
==========================================================*/
void usage() {
    cerr <<  "\n  Usage: AnalyseADST <ADSTfileName> <Outputfilename>  \n" 
	 <<  "         where <ADSTfileName> is the name of an ADST file, e.g. HybridRec.root \n" 
	 <<  "         or a list of ADST files, e.g. \"HybridRec*.root\". \n "<<endl;
}  

/*========================================================
  AcceptEvent()
  
   Event selection
   return value determines if event is used (return true)
   or not (return 
==========================================================*/
bool AcceptEvent(FDEvent & theFDEvent) {
    bool selected;
    
    // using only full reconstructed events
    if(theFDEvent.GetRecLevel() < eHasEnergy)
	return false;
    
    //some cut variables
    const FdRecShower& theShower = theFDEvent.GetFdRecShower();
    double lgE=log10(theShower.GetEnergy());
    double minFOV=theShower.GetXFOVMin();
    double maxFOV=theShower.GetXFOVMax();
    
    double CutMinFOV=576. + 58.* ( lgE - 18.); //values from Coll.Meeting March 2006
    double CutMaxFOV=770. + 50.* ( lgE - 18.); //values from Coll.Meeting March 2006
    
    // some example quality cuts
    if(
	theFDEvent.IsHybridEvent() // at least 'brass-hybrid' reconstruction
	&& theShower.IsXmaxInFOV(0.) // Xmax is in FOV
	&& minFOV < CutMinFOV && minFOV>0. //'MinBias' minimal FOV cut
	&& maxFOV > CutMaxFOV //'MinBias' maximal FOV cut
	//... to be continued
	)
	selected = true;
    else
	selected = false;
    
    return selected;
}

//##############################################################
int main(int argc, char **argv) {
    
    if ( argc != 3 ) {
	usage();
	exit(1);
    }

    //  OUTPUT-Definitions
    TFile *histoFile= new TFile(argv[2],"RECREATE");
    //some histograms
    const int kNE=32; 
    const double kMinE=17.;
    const double kMaxE=21.;
    TH1F * h_e= new TH1F("energy","energy",kNE,kMinE,kMaxE);
    
    
    RecEventFile dataFile(argv[1]);
    RecEvent * theRecEvent = new RecEvent();
    dataFile.SetMicroADST(); //speedup if only high-level variables are used
    dataFile.SetBuffers(&(theRecEvent));
    unsigned int nsel=0;
    unsigned int ntot=dataFile.GetNEvents();
    cout << " reading file(s) " << argv[1] << " with " << ntot<<" events\n" << endl;
    
    // loop over events  
    for ( unsigned int i=0;i<ntot;i++) {
	if(!dataFile.ReadEvent(i)==RecEventFile::eSuccess) continue;
	
	//loop over FD events
	std::vector<FDEvent> & fdEvents = theRecEvent->GetFDEvents();
	for ( vector<FDEvent>::iterator eye = fdEvents.begin();
	      eye != fdEvents.end(); ++eye ) {  
	    
	    // apply quality / selection cuts
	    if(AcceptEvent(*eye)) {  
		nsel++;
		
		// fill histograms
		double lgE=log10(eye->GetFdRecShower().GetEnergy());
		h_e->Fill(lgE);
	    }
	}
	if ( i%1000 == 0 )
	    cerr<<" "<<i<<" out of "<<ntot<<" events processed"<<endl;
    }  
    
    //save histograms
    histoFile->cd();
    histoFile->Write();
    histoFile->Close();
    
    cout << "\n total number of Auger-Events: " << ntot << "\n"
	 << " selected FD-Events:           " << nsel 
	 << endl;
}
