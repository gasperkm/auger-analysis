#ifndef __FdRecStation_H
#define __FdRecStation_H

#include <RecStation.h>
#include <StationStatus.h> // for the enums

#include <TObject.h>
#include <string>


//  Station data definition

class FdRecStation : public RecStation {

public:
  FdRecStation();
  virtual ~FdRecStation();

  // ------------------ setters -------------------------------------

  /// set chi_i angle of station i
  void SetChi_i(Double_t c) { fChi_i = c; }

  /// set azimuth and elevation angle
  void SetAzimuthAndElevation(Double_t azi, Double_t elev) { fAzimuth = azi; fElevation = elev; }

  /// set time of station i
  void SetTimeEye(Double_t c) { fTimeEye = c; }

  /// set time of station i
  void SetTime(Double_t c, Double_t e) { fTime = c; fTimeError = e; }

  /// set distance to shower axis
  //SetStationAxisDistance
  void SetDistanceToAxis(Double_t c) { fDistanceToAxis = c; }

  /// set time residual to axis fit
  void SetTimeResidual(Double_t c) { fTimeResidual = c; }

  void SetAge (double age) { fAge = age; }
  void SetSlantDepth (double x) { fSlantDepth = x; }

  // ----------- getters ---------------------------------------------
  Double_t GetChi_i() const { return fChi_i; }            ///< get chi_i angle of station
  Double_t GetTimeEye() const { return fTimeEye; }         ///< get station time at the eye
  Double_t GetTime() const { return fTime; }               ///< get time of station
  Double_t GetTimeError() const { return fTimeError; }     ///< get time error
  Double_t GetSignal() const { return fSignal; }           ///< get signal
  Double_t GetSignalError() const { return fSignalError; }
  Double_t GetDistanceToAxis() const { return fDistanceToAxis; } ///< get distance to shower axis
  Double_t GetTimeResidual() const { return  fTimeResidual; }    ///< get time residual to axis fit
  Double_t GetAzimuth() const { return fAzimuth; }         ///< get azimuth angle in eye CS
  Double_t GetElevation() const { return fElevation; }       ///< get elevation angle in eye CS

  Double_t GetAge() const { return fAge; }
  Double_t GetSlantDepth() const { return fSlantDepth; }

  // station status

protected:
  Double_t fChi_i;
  Double_t fTimeEye;
  Double_t fTime;
  Double_t fTimeError;
  Double_t fSignal;
  Double_t fSignalError;
  Double_t fTimeResidual;
  Double_t fDistanceToAxis;
  Double_t fAzimuth;
  Double_t fElevation;

  Double_t fAge;
  Double_t fSlantDepth;
  ClassDef(FdRecStation, 8);

};


#endif
