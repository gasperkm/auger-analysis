// $Id: SdRecScintillator.cc 30052 2017-03-13 19:37:40Z schmidt-d $
#include <SdRecScintillator.h>

using namespace std;


ClassImp(SdRecScintillator);


//=============================================================================
/*!
  \class   SdRecScintillator
  \brief   Data of reconstructed SD station scintillators

  \version 2.0
  \date    March 2017
  \author  D. Schmidt

*/
//=============================================================================

SdRecScintillator::SdRecScintillator():
  fTotalSignal(0),
  fTotalSignalError(0)
{
  //placeholder
}