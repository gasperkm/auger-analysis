//#include <config.h>
/*
   Martin Maur
   27 Jun 2012
*/

#ifndef _adst_MdRecShower_h_
#define _adst_MdRecShower_h_

#include <RecShower.h>

#include <TVector3.h>

#include <vector>
#include <iostream>


class MdRecShower : public RecShower {

public:

  MdRecShower();
  virtual ~MdRecShower() { }

  void SetTabulatedValues(const std::vector<double>& x, const std::vector<double>& y)
  { fRhos = x; fValues = y; }

  double TabulatedFunction(const double r) const;

  double TabulatedFunction(const double* const x, const double*) const { return TabulatedFunction(x[0]); }

  // overloaded operator () is required to construct ROOT TF1s
  double operator()(const double* const x, const double* const /*p*/) const { return TabulatedFunction(x[0]); }

  ///> get the chi2 from the plane fit
  double GetAngleChi2() const { return fAngleChi2; }
  ///> get the no of degrees of freedom from the plane fit
  unsigned int GetAngleNDoF() const { return fAngleNdof; }

  /// get the mean of the time residual
  double GetTimeResidualMean() const { return fTimeResidualMean; }
  /// get the spread of the time residual
  double GetTimeResidualSpread() const { return fTimeResidualSpread; }

  /// get the angle between the axis reconstructed by the MD and the SD
  double GetMdSdAngle() const { return fMdSdAngle; }    

  double GetMLDFChi2() const { return fMLDFChi2; }

  double GetMLDFNdof() const { return fMLDFNdof; }

  double GetMLDFLikelihood() const { return fMLDFLikelihood; }

  double GetBeta() const { return fBeta; }

  double GetBetaError() const { return fBetaError; }

  double GetBetaSystematics() const { return fBetaSystematics; }

  double GetNMuRef() const { return fNMuRef; }

  double GetNMuRefError() const { return fNMuRefError; }

  double GetNMuRefSystematics() const { return fNMuRefSystematics; }

  double GetReferenceDistance() const { return fReferenceDistance; }

  double GetCurvatureRadius() const { return fCurvatureRadius; }   ///> get curvature radius in meters

  double GetCurvatureRadiusError() const { return fCurvatureRadiusError; }   ///> get curvature error

  // ----------- setters --------------------------------------

  void SetAngleChi2(const double chi2, const unsigned int ndof)
  { fAngleChi2 = chi2; fAngleNdof = ndof; }

  void SetMdSdAngle(double a) { fMdSdAngle=a; }   

  void SetTimeResidualMean(const double mean) { fTimeResidualMean = mean; }
  void SetTimeResidualSpread(const double spread) { fTimeResidualSpread = spread; }

  void SetMLDFLikelihood(const double likelihood) { fMLDFLikelihood = likelihood; }

  void SetMLDFChi2(const double chi2) { fMLDFChi2 = chi2; }

  void SetMLDFNdof(const double ndof) { fMLDFNdof = ndof; }

  void SetBeta(const double beta, const double error) { fBeta = beta; fBetaError = error; }

  void SetBetaSystematics(const double BetaSys) { fBetaSystematics = BetaSys; }

  void SetNMuRef(const double NMuRef, const double error) { fNMuRef = NMuRef; fNMuRefError = error; }

  void SetNMuRefSystematics(const double NMuRefSys) { fNMuRefSystematics = NMuRefSys; }

  void SetReferenceDistance(const double reference) { fReferenceDistance = reference; }

	///> set curvature radius in meters
  void SetCurvatureRadius(const double radius, const double dradius)
  { fCurvatureRadius = radius; fCurvatureRadiusError = dradius; }

  // Reconstruction flags

  bool IsLdfReconstructed() const { return fLdfReconstructed; }
  void SetLdfReconstructed(bool flag=true) { fLdfReconstructed = flag; } 

  bool IsBetaFixed() const { return fBetaFixed; }
  void SetBetaFixed(bool flag=true) { fBetaFixed = flag; } 

  bool IsCoreFixedLdf() const { return fCoreFixedLdf; }
  void SetCoreFixedLdf(bool flag) { fCoreFixedLdf = flag; } 

  bool IsGeometryReconstructed() const { return fGeometryReconstructed; }
  void SetGeometryReconstructed(bool flag=true) { fGeometryReconstructed = flag; } 

  bool IsCoreFixedGeo() const { return fCoreFixedGeo; }
  void SetCoreFixedGeo(bool flag) { fCoreFixedGeo = flag; } 

  bool IsCurvatureFixed() const { return fCurvatureFixed; }
  void SetCurvatureFixed(bool flag) { fCurvatureFixed = flag; } 


private:

  std::vector<double> fRhos;
  std::vector<double> fValues;

  double fAngleChi2;
  unsigned int fAngleNdof;
  double fMdSdAngle; 

  double fTimeResidualMean;
  double fTimeResidualSpread;

  double fBeta;
  double fBetaError;
  double fBetaSystematics;
  double fNMuRef;
  double fNMuRefError;
  double fNMuRefSystematics;
  double fMLDFChi2;
  double fMLDFNdof;
  double fMLDFLikelihood;
  double fReferenceDistance;
  double fCurvatureRadius;
  double fCurvatureRadiusError;

  // Reconstruction status flags
  bool fLdfReconstructed;  // Indicates if the ldf reconstruction was performed
  bool fBetaFixed;   // true is beta is fixed 
  bool fCoreFixedLdf;  // true if the core is fixed in the ldf fit
  bool fGeometryReconstructed;  // Indicates if the geometrical reconstruction was performed
  bool fCoreFixedGeo; // true if the core is fixed in the geometrical reconstruction
  bool fCurvatureFixed; // true if radius of curvature is free in the geometrical reconstruction 

  ClassDef(MdRecShower, 4);

};


#endif
