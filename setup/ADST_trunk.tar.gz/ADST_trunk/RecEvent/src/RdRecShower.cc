#include <RdRecShower.h>

#include <cmath>
#include <limits>

using namespace std;

ClassImp(RdRecShower);

//=============================================================================
/*!
 \class   RdRecShower
 \brief   Reconstructed shower parameters

 \version 1.0
 \date    May 2010
 \author  M. Melissas

 */
//=============================================================================
RdRecShower::RdRecShower() :
    fRadiusError(0), 
    fAzimuthError(0), 
    fZenithError(0), 
    fZenithPreFitError(0), 
    fAzimuthPreFitError(0)
{
}

double RdRecShower::GetRadius() const
{
  try {
    return sqrt(
        pow(GetParameter(revt::eShowerAxisX), 2) + pow(GetParameter(revt::eShowerAxisY), 2)
            + pow(GetParameter(revt::eShowerAxisZ), 2));
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetAERAScintRadius() const
{
  try {
    return sqrt(
        pow(GetParameter(revt::eAERAScintShowerAxisX), 2) + pow(GetParameter(revt::eAERAScintShowerAxisY), 2)
            + pow(GetParameter(revt::eAERAScintShowerAxisZ), 2));
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetGeomagneticAngle() const
{
  TVector3 showeraxis = TVector3(1., 0, 0);
  showeraxis.SetPhi(GetAzimuth());
  showeraxis.SetTheta(GetZenith());
  TVector3 bfield = GetMagneticFieldVector();
  return showeraxis.Angle(bfield);
}

double RdRecShower::GetAzimuth() const
{
  try {
    double azimuth = atan2(GetParameter(revt::eShowerAxisY), GetParameter(revt::eShowerAxisX));
    if(azimuth < 0) {
      azimuth += 2 * M_PI;
    }
    return azimuth;
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetAERAScintAzimuth() const
{
  try {
    double azimuthscint = atan2(GetParameter(revt::eAERAScintShowerAxisY), GetParameter(revt::eAERAScintShowerAxisX));
    if(azimuthscint < 0) {
      azimuthscint += 2 * M_PI;
    }
    return azimuthscint;
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetZenith() const
{
  try {
    return acos(GetParameter(revt::eShowerAxisZ) / GetRadius());
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetAERAScintZenith() const
{
  try {
    return acos(GetParameter(revt::eAERAScintShowerAxisZ) / GetAERAScintRadius());
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetZenithPreFit() const
{
  try {
    return acos(GetParameter(revt::ePreFitShowerAxisZ));
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetAzimuthPreFit() const
{
  try {
    double azimuth = atan2(GetParameter(revt::ePreFitShowerAxisY), GetParameter(revt::ePreFitShowerAxisX));
    if(azimuth < 0) {
      azimuth += 2 * M_PI;
    }
    return azimuth;
  } catch(...) {
    return numeric_limits<double>::quiet_NaN();
  }
}

///Does the naming of these function make any sense ?
// Why PlaneFit Gives values from WaveFit ?

double RdRecShower::GetRdPlaneFitChi2() const
{
  cout << "WARNING: Outdated interface used: RdRecShower::GetRdPlaneFitChi2()" << std::endl;
  if(HasParameter(revt::eWaveFitChi2)) {
    return GetParameter(revt::eWaveFitChi2);
  } else {
    cout << "WARNING: Parameter eWaveFitChi2 was not set" << std::endl;
    return numeric_limits<double>::quiet_NaN();
  }
}

/// get the no of degrees of freedom from the wave fit
double RdRecShower::GetRdPlaneFitNDoF() const
{
  cout << "WARNING: Outdated interface used: RdRecShower::GetRdPlaneFitNDoF()" << std::endl;
  if(HasParameter(revt::eWaveFitNDF)) {
    return GetParameter(revt::eWaveFitNDF);
  } else {
    cout << "WARNING: Parameter eWaveFitNDF was not set" << std::endl;
    return std::numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetRdRecStage() const
{
  cout << "WARNING: Outdated interface used: RdRecShower::GetRdRecStage()" << std::endl;
  if(HasParameter(revt::eRecStage)) {
    return GetParameter(revt::eRecStage);
  } else {
    cout << "WARNING: Parameter eRecStage was not set" << std::endl;
    return std::numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetRdFitConvergenceStatus() const
{
  std::cout << "WARNING: Outdated interface used: RdRecShower::GetRdFitConvergence()" << std::endl;
  if(HasParameter(revt::eFitConvergence)) {
    return GetParameter(revt::eFitConvergence);
  } else {
    std::cout << "WARNING: Parameter eFitConvergence was not set" << std::endl;
    return std::numeric_limits<double>::quiet_NaN();
  }
}

double RdRecShower::GetRdFitSuccess() const
{
  cout << "WARNING: Outdated interface used: RdRecShower::GetRdFitSuccess()" << std::endl;
  if(HasParameter(revt::eFitSuccess)) {
    return GetParameter(revt::eFitSuccess);
  } else {
    cout << "WARNING: Parameter eFitSuccess was not set" << std::endl;
    return numeric_limits<double>::quiet_NaN();
  }
}
// Curvature Chi2/Ndof to be added

void RdRecShower::DumpASCII(ostream &o) const
{
  Shower::DumpASCII(o);
}


