#ifndef __FDEvent_H
#define __FDEvent_H

#include <FdRecShower.h>
#include <FdRecGeometry.h>
#include <SdRecGeometry.h>
#include <FdRecApertureLight.h>
#include <FdRecPixel.h>
#include <FdRecStation.h>
#include <FdGenGeometry.h>
//#include <FdGenApertureLight.h>
#include <FdGenShower.h>
#include <FdTelescopeData.h>

#include <TObject.h>
#include <TBits.h>

#include <map>
#include <string>

//
//  class to hold FD event
//

class FDEvent : public TObject {

public:
  FDEvent();
  virtual ~FDEvent();

  FdRecShower& GetFdRecShower();
  const FdRecShower& GetFdRecShower() const;

  FdRecApertureLight& GetFdRecApertureLight();
  const FdRecApertureLight& GetFdRecApertureLight() const;

  FdRecGeometry& GetFdRecGeometry();
  const FdRecGeometry& GetFdRecGeometry() const;

  SdRecGeometry& GetSdRecGeometry();
  const SdRecGeometry& GetSdRecGeometry() const;

  FdRecPixel& GetFdRecPixel();
  const FdRecPixel& GetFdRecPixel() const;

  FdGenGeometry& GetGenGeometry();
  const FdGenGeometry& GetGenGeometry() const;

  /*
  FdGenApertureLight& GetGenApertureLight(const int telId);
  const FdGenApertureLight& GetGenApertureLight(const int telId) const;
  bool HasGenApertureLight(const int telId) const;
  */  

  FdGenShower& GetGenShower();
  const FdGenShower& GetGenShower() const;

  void AddStation(const FdRecStation &station);
  const FdRecStation* GetStation(const UInt_t i) const;
  const std::vector<FdRecStation>& GetStationVector() const
  { return fStations; }
  void ClearStationList() { fStations.clear(); }
  
  bool IsHybridEvent() const; ///< check for Hybrid reconstruction
  bool IsProfileConstrainedGeometry() const;
  
  // -------- eye header variables ---------

  /// get Eye ID starting from 1
  UShort_t GetEyeId() const { return fEye; }
  /// get run number
  UInt_t GetRunId() const { return fRun; }
  /// get event number
  UInt_t GetEventId() const { return fFdEventId; }
  /// get GPS second
  UInt_t GetGPSSecond() const { return fFdGPSSecond; }
  /// get GPS nano second
  UInt_t GetGPSNanoSecond() const { return fFdGPSNanoSecond; }
  /// get date in YYMMDD format
  UInt_t GetYYMMDD() const { return fFdYYMMDD; }
  /// get time in HHMMSS format
  UInt_t GetHHMMSS() const { return fFdHHMMSS; }
  /// get moon cycle
  Double_t GetMoonCycle() const { return fMoonCycle; }
  /// get mirrors in event
  const TBits& GetMirrorsInEvent() const { return fTelEvtBits; }
  /// check if mirror is in event
  bool MirrorIsInEvent(const int iMirr) const { return fTelEvtBits.TestBitNumber(iMirr); }

  /// check if Xmax is in telescope FOV
  bool IsXmaxInTelFOV(const int iTelID) const;
  /// get the ID of the telescope with Xmax in FOV
  int GetXmaxInFOVTelId() const;

  /// get reconstruction level (see FdRecLevel.h)
  EFdRecLevel GetRecLevel() const { return fFdRecLevel; }

  /// get status of MHz time correction (see FdRecLevel.h)
  ETimeCorrectionStatus GetTimeCorrectionStatus() const
  { return fTimeCorrectionStatus; }

  /// T3 related stuff

  /// get FD event class
  const std::string& GetEventClass() const { return fFdEventClass; }
  /// get FD event type
  const std::string& GetEventType() const { return fFdEventType; }
  /// returns true if T3 reconstruction data is present
  bool HasT3Reconstruction() const { return fT3NPixels > 0; }
  /// get estimated T3 SDP theta
  double GetT3SDPTheta() const { return fT3SDPTheta; }
  /// get estimated T3 SDP phi
  double GetT3SDPPhi() const { return fT3SDPPhi; }
  /// get estimated T3 time at ground in second
  unsigned int GetT3TimeAtGround() const { return fT3TimeAtGround; }
  /// get estimated T3 time at ground in nano second
  unsigned int GetT3TimeAtGroundNS() const { return fT3TimeAtGroundNanoSecond; }
  /// get number of pixels
  unsigned int GetT3NPixels() const { return fT3NPixels; }
  /// get T3 azimuth
  double GetT3Azimuth() const { return fT3Azimuth; }
  /// get number of mirrors in current eye
  int GetMirrorsInEye() const { return fMirrorTimeOffset.size(); }
  /// get mirror time offset [ns]
  int GetMirrorTimeOffset(const int mirror) const;
  /// get mirror time offsets
  const std::map<UShort_t, Int_t>& GetMirrorTimeOffsets() const
  { return fMirrorTimeOffset; }

  /// returns true if event passed the TLT
  bool HasTLT(const int telId) const;
  /// get the label assigned by the TLT
  std::string GetTLTLabel(const int telId) const;

  /// set Eye ID starting from 1
  void SetEyeId(const UShort_t arg) { fEye = arg; }
  /// set run number
  void SetRunId(const UInt_t arg) { fRun = arg; }
  /// set event number
  void SetEventId(const UInt_t arg) { fFdEventId = arg; }
  /// set GPS second (Eye trigger time + trace length)
  void SetGPSSecond(const UInt_t arg) { fFdGPSSecond = arg; }
  /// set GPS nano second (Eye trigger time + trace length)
  void SetGPSNanoSecond(const UInt_t arg) { fFdGPSNanoSecond = arg; }
  /// set date in YYMMDD format
  void SetYYMMDD(const UInt_t dateYYMMDD) { fFdYYMMDD = dateYYMMDD; }
  /// set time in HHMMSS format
  void SetHHMMSS(const UInt_t timeHHMMSS) { fFdHHMMSS = timeHHMMSS; }
  /// set moon cycle
  void SetMoonCycle(const Double_t arg) { fMoonCycle = arg; }
  /// set mirrors in event
  void SetMirrorsInEvent(const TBits& arg) { fTelEvtBits = arg; }
  /// set reconstruction level (see FdRecLevel.h)
  void SetRecLevel(const EFdRecLevel arg) { fFdRecLevel = arg; }
  /// set T3 Data
  void SetT3Data(const double theta, const double phi, const unsigned int nPix,
                 const double azimuth, const unsigned int second, const unsigned int nanosecond)
  { fT3SDPTheta = theta; fT3SDPPhi = phi; fT3Azimuth = azimuth;
    fT3NPixels = nPix; fT3TimeAtGround = second; fT3TimeAtGroundNanoSecond = nanosecond; }
  /// set time correction status
  void SetTimeCorrectionStatus(ETimeCorrectionStatus s)
  { fTimeCorrectionStatus = s; }

  /// set FD event class
  void SetEventClassAndType(const std::string& theClass,
                            const std::string& theType)
  { fFdEventClass = theClass; fFdEventType = theType; }
  /// set mirror time offset [ns]
  void SetMirrorTimeOffset(const Int_t mirror, const Int_t offset)
  { fMirrorTimeOffset[mirror] = offset; }
  void SetMirrorTimeOffsets(const std::map<UShort_t, Int_t>& offsets)
  { fMirrorTimeOffset = offsets; }

  /// set TLT
  void SetTLT(const std::map<int, bool>& tlt) { fHasTLT = tlt; }
  /// set the label assigned by the TLT
  void SetTLTLabel(const std::map<int, std::string>& tltLabel)
  { fTLTLabel = tltLabel; }

  int GetHottestMirrorId() const; ///< get ID of mirror with largest # of pixel

  int GetXmaxPixel() const;
  
  typedef std::map<int, FdTelescopeData>::iterator TelescopeDataIterator;
  typedef std::map<int, FdTelescopeData>::const_iterator TelescopeDataConstIterator;
  
  bool HasTelescopeData(unsigned int telId) const;
  const FdTelescopeData& GetTelescopeData(unsigned int telId) const;
  FdTelescopeData& GetTelescopeData(unsigned int telId);
  void SetTelescopeData(unsigned int telId, const FdTelescopeData& telRD);
  void MakeTelescopeData(unsigned int telId) { fTelescopeData[telId] = FdTelescopeData(); }

  TelescopeDataIterator TelescopeDataBegin() { return fTelescopeData.begin(); }
  TelescopeDataConstIterator TelescopeDataBegin() const { return fTelescopeData.begin(); }

  TelescopeDataIterator TelescopeDataEnd() { return fTelescopeData.end(); }
  TelescopeDataConstIterator TelescopeDataEnd() const { return fTelescopeData.end(); }

  void DumpASCII(std::ostream& o = std::cout) const;

private:
  FdRecShower fFdRecShower;
  FdRecApertureLight fFdRecApertureLight;
  FdRecGeometry fFdRecGeometry;
  SdRecGeometry fSdRecGeometry;
  FdRecPixel fFdRecPixel;
  
  FdGenGeometry fFdGenGeometry;
  //std::map<int, FdGenApertureLight> fFdGenApertureLight;
  FdGenShower fFdGenShower;

  std::vector<FdRecStation> fStations;

  // -------- eye header variables ---------
  UShort_t fEye;
  UInt_t fRun;
  UInt_t fFdEventId;
  UInt_t fFdGPSSecond;
  UInt_t fFdGPSNanoSecond;
  UInt_t fFdYYMMDD;
  UInt_t fFdHHMMSS;
  std::string fFdEventClass;
  std::string fFdEventType;
  ETimeCorrectionStatus fTimeCorrectionStatus;
  double fT3SDPTheta;
  double fT3SDPPhi;
  double fT3Azimuth;
  unsigned int fT3NPixels;
  unsigned int fT3TimeAtGround;
  unsigned int fT3TimeAtGroundNanoSecond;
  TBits fTelEvtBits;
  Double_t fMoonCycle;
  EFdRecLevel fFdRecLevel;
  UInt_t fNoTel;
  std::map<UShort_t, Int_t> fMirrorTimeOffset;

  std::map<int, bool> fHasTLT;
  std::map<int, std::string> fTLTLabel;

  std::map<int, FdTelescopeData> fTelescopeData;

  ClassDef(FDEvent, 21);
};

#endif
