#include <config.h>
/*

   Martin Maur
   14 Apr 2012

*/

#include "MdRecCounter.h"

ClassImp(MdRecCounter);

MdRecCounter::MdRecCounter():
  fId(0),
  fSdPartnerId(0),
  fRecStatus(eUndefined),
  fLDFResidual(0),
  fHasT50(false),
  fT50Second(0),
  fT50Nano(0),
  fT502SdStart(0),
  fT50Error(0),
  fTimeResidual(0),
  fNumberOfMuons(0),
  fNumberOfMuonsErrorHigh(0),
  fNumberOfMuonsErrorLow(0),
  fNumberOfMuonsLowLimit(0),
  fActiveArea(0),
  fMuonDensity(0),
  fMuonDensityErrorHigh(0),
  fMuonDensityErrorLow(0), 
  fNumberOfChannelsOn(0),
  fSPDistance(0),
  fSPDistanceError(0),
  fSPDelta(0),
  fSPDeltaError(0),
  fSPAzimuth(0),
  fSPAzimuthError(0),
  fRecData(false),
  fIsDense(false)
{
}

bool 
MdRecCounter::HasModule(unsigned int id) 
const
{
  for (ModuleList::const_iterator it = fModules.begin(); it != fModules.end(); ++it) {
    if ( it->GetId() == id ) {
      return true;
    }
  } 
  return false; // the id is not found
}

MdRecModule* 
MdRecCounter::GetModule(unsigned int id)
{
  for (ModuleIterator it = fModules.begin(); it != fModules.end(); ++it) {
    if ( it->GetId() == id ) {
      return &(*it);
    }
  }
  return NULL; // the id is not found
}

bool 
MdRecCounter::IsSaturated() 
{
  for (ModuleIterator it = fModules.begin(); it != fModules.end(); ++it) {
    if (it->IsSaturated()) {
      return true;
    }
  }
  // all modules are unsaturated
  return false; 
}
