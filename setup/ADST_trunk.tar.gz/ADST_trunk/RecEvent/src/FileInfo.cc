// $Id: FileInfo.cc 28752 2016-04-11 10:30:41Z aherve $
#include <FileInfo.h>
#include <fstream>
#include <iostream>

using namespace std;


FileInfo::FileInfo() :
  fADSTVersion("unknown"),
  fEventInfoClassVersion(-1),
  fRecEventClassVersion(-1),
  fSDEventClassVersion(-1),
  fFDEventClassVersion(-1),
  fShowerClassVersion(-1),
  fRecShowerClassVersion(-1),
  fFdRecShowerClassVersion(-1),
  fSdRecShowerClassVersion(-1),
  
  fUnivRecShowerClassVersion(-1),

  fSdRecStationClassVersion(-1),
  fGenShowerClassVersion(-1),
  fHasMC(false),
  fHasFD(false),
  fHasSD(false),
  fHasFdTraces(false),
  fHasVEMTraces(false),
  fHasSdAllTraces(false),
  fHasRadioStation(false),
  fHasRadioChannel(false),
  fRdEventClassVersion(-1),
  fLDFType(eNKG),
  fOfflineVersion("unknown"),
  fHost("unknown"),
  fUser("unknown"),
  fOfflineConfiguration("unknown")
{  }


void
FileInfo::PrintOfflineConfiguration(const string& fileName)
  const
{
  if (fileName != "") {
    ofstream out(fileName.c_str());
    out << fOfflineConfiguration;
    out.close();
  } else
    cout << fOfflineConfiguration << endl;
}


string
FileInfo::GetOfflineConfigurationValue(const string& topBranchName,
                                       const string& branchName)
  const
{
  const string& xmlConfiguration = fOfflineConfiguration;
  const string errorString = branchName + string(" not found in ") + topBranchName;

  const size_t firstTopBranchPos = xmlConfiguration.find(string("<") + topBranchName);
  if (firstTopBranchPos == string::npos)
    return errorString;

  const size_t secondTopBranchPos =
    xmlConfiguration.find(string("</") + topBranchName, firstTopBranchPos + 1);

  if (secondTopBranchPos == string::npos)
    return errorString;

  const size_t firstBranchPos =
    xmlConfiguration.find(string("<") + branchName, firstTopBranchPos);

  if (firstBranchPos == string::npos || firstBranchPos>secondTopBranchPos)
    return errorString;

  const size_t dataStart = xmlConfiguration.find(string(">"), firstBranchPos) + 1;
  if (dataStart == string::npos)
    return errorString;

  const size_t dataEnd = xmlConfiguration.find(string("</"), dataStart);
  if (dataEnd == string::npos)
    return errorString;

  return xmlConfiguration.substr(dataStart, dataEnd - dataStart);
}
