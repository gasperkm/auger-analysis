#ifndef __SdRecShowerParameterStorageMap_H
#define __SdRecShowerParameterStorageMap_H
#include <TObject.h>
#include <map>
#include <utility>
#include <stdexcept>
#include <sstream>
#include <cmath>
#include "ShowerSRecDataQuantities.h"

class SdRecShowerParameterStorageMap : public TObject {
  public:
    typedef sevt::ShowerSRecDataQuantities SShowerParameterKey;
    typedef std::pair<sevt::ShowerSRecDataQuantities, sevt::ShowerSRecDataQuantities> SShowerCovarianceKey;

    typedef std::map<SShowerParameterKey, double> SShowerParameterMap;
    typedef std::map<SShowerCovarianceKey, double> SShowerCovarianceMap;

//     SdRecShowerParameterStorageMap();
//     virtual ~SdRecShowerParameterStorageMap();

    void
    SetParameter(const SShowerParameterKey index, const double value)
    {
      fSShowerParameterMap[index] = value;
    }

    void
    SetParameterCovariance(const SShowerParameterKey index1, const SShowerParameterKey index2, const double value)
    {
      fSShowerCovarianceMap[GenSShowerCovarianceKey(index1, index2)] = value;
    }

    void
    SetParameterError(const SShowerParameterKey index, const double value)
    {
      SetParameterCovariance(index, index, value * value);
    }

    double
    GetParameter(const SShowerParameterKey index)
      const
    {
      const SShowerParameterMap::const_iterator it = fSShowerParameterMap.find(index);
      if (it != fSShowerParameterMap.end()) {
        return it->second;
      }
      else {
        std::stringstream sstr;
        sstr << "Shower Parameter " << index << " not set";
        throw std::out_of_range(sstr.str().c_str());
      }
    }

    double
    GetParameterCovariance(const SShowerParameterKey index1,
                           const SShowerParameterKey index2)
      const
    {
      const SShowerCovarianceMap::const_iterator it =
        fSShowerCovarianceMap.find(GenSShowerCovarianceKey(index1, index2));

      if (it != fSShowerCovarianceMap.end()) {
        return it->second;
      }
      else {
        std::stringstream sstr;
        sstr << "Shower ParameterCovariance " << index1 << ", " << index2 << " not set";
        throw std::out_of_range(sstr.str().c_str());
      }
    }

    double
    GetParameterError(const SShowerParameterKey index)
      const
    {
      return std::sqrt(GetParameterCovariance(index, index));
    }

    bool
    HasParameter(const SShowerParameterKey index)
      const
    {
      return fSShowerParameterMap.find(index) != fSShowerParameterMap.end();
    }

    bool
    HasParameterCovariance(const SShowerParameterKey index1,
                           const SShowerParameterKey index2)
      const
    {
      return fSShowerCovarianceMap.find(GenSShowerCovarianceKey(index1, index2))
        != fSShowerCovarianceMap.end();
    }

  private:

    SShowerParameterMap fSShowerParameterMap;
    SShowerCovarianceMap fSShowerCovarianceMap;

    /// helper function to create the key for the covariance map from the parameters using sorting
    inline
    SShowerCovarianceKey
    GenSShowerCovarianceKey(const SShowerParameterKey param1,
                     const SShowerParameterKey param2)
    const
    {
      if (long(param1) < long(param2))
        return std::make_pair(param1, param2);
      else
        return std::make_pair(param2, param1);
    }

  ClassDef(SdRecShowerParameterStorageMap, 4);
};


#endif

