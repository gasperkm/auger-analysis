// $Id: FdGenShower.cc 30035 2017-03-09 16:22:09Z rulrich $
#include <FdGenShower.h>



ClassImp(FdGenShower);



FdGenShower::FdGenShower() :
  fX1Chi(0),
  fXmaxChi(0),
  fChkovFrac(0) {
}
