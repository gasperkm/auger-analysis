/*
  \file
  ShowerSRecDataQuantities quantities to be stored in ParameterStorage objects of ShowerRecData
*/

#ifndef _sevt_ShowerSRecDataQuantities_h_
#define _sevt_ShowerSRecDataQuantities_h_


static const char CvsId_sevt_ShowerSRecDataQuantities[] =
 "$Id: StationRecData.h ";

namespace sevt {

  /** ATTENTION: - Numerate enum
   *             - never change an index
   */
  enum ShowerSRecDataQuantities {
    eShowerAxisX = 0,
    eShowerAxisY = 1,
    eShowerAxisZ = 2,
    //Parameters from SdCompositionParameters Module
    eRiseTime1000 = 3,
    eRiseTime1000Chi2 = 4,
    eRiseTime1000NDF = 5,
    eRiseTime1000NSt = 6,
    eRiseTime1000NStClose = 7, //number of stations max 1000m away
    eRiseTime1000Flag = 8,
    eRiseTime1000FlagAlt = 9,
    eLeedsDelta = 10,
    eDeltaRiseTimeFlag = 11,
    eDeltaRiseTimeFlagAlt = 12,
    eLDF_RNKG = 13,
    eLDF_S4 = 14,
    eLDF_NSt = 15,
    eLDFFlag = 16,
    eEgammaRec = 17,           //energy if particle is a photon
    eEgammaIter = 18,
    eEgammaXmax = 19,
    eEgammaFlag = 20

  };

}


#endif
