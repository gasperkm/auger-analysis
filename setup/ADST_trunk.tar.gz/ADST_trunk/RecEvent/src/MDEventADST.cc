#include "MDEventADST.h"

/*

   Martin Maur
   14 Apr 2012
   Diego Ravignani
   18 Aug 2015

*/

ClassImp(MDEvent);

MDEvent::MDEvent():
  fNumberOfCandidates(0),
  fRecLevel(eNoMdEvent)
{
}

// Reconstructed counter methods

bool
MDEvent::HasCounter(unsigned int id)
  const
{
  for (CounterList::const_iterator it = fCounters.begin(); it != fCounters.end(); ++it) {
    if ( it->GetId() == id ) {
      return true;
    }
  }
  return false; // the id is not found
}

bool
MDEvent::HasCounterBySdPartnerId(unsigned int id)
  const
{
  for (CounterList::const_iterator it = fCounters.begin(); it != fCounters.end(); ++it) {
    if ( it->GetSdPartnerId() == id ) {
      return true;
    }
  }
  return false; // the id is not found
}

MdRecCounter*
MDEvent::GetCounter(unsigned int id)
{
  for (CounterIterator it = fCounters.begin(); it != fCounters.end(); ++it) {
    if ( it->GetId() == id ) {
      return &(*it);
    }
  }
  return NULL; // the id is not found
}

MdRecCounter*
MDEvent::GetCounterBySdPartnerId(unsigned int id)
{
  for (CounterIterator it = fCounters.begin(); it != fCounters.end(); ++it) {
    if ( it->GetSdPartnerId() == id ) {
      return &(*it);
    }
  }
  return NULL; // the id is not found
}

// Simulated counter methods

bool
MDEvent::HasSimCounter(unsigned int id)
const
{
  for (SimCounterList::const_iterator it = fSimCounters.begin(); it != fSimCounters.end(); ++it) {
    if ( it->GetId() == id ) {
      return true;
    }
  }
  return false;
}

bool
MDEvent::HasSimCounterBySdPartnerId(unsigned int id)
const
{
  for (SimCounterList::const_iterator it = fSimCounters.begin(); it != fSimCounters.end(); ++it) {
    if ( it->GetSdPartnerId() == id ) {
      return true;
    }
  }
  return false;
}

MdSimCounter*
MDEvent::GetSimCounter(unsigned int id)
{
  for (SimCounterIterator it = fSimCounters.begin(); it != fSimCounters.end(); ++it) {
    if ( it->GetId() == id ) {
      return &(*it);
    }
  }
  return NULL; // the id is not found
}

MdSimCounter*
MDEvent::GetSimCounterBySdPartnerId(unsigned int id)
{
  for (SimCounterIterator it = fSimCounters.begin(); it != fSimCounters.end(); ++it) {
    if ( it->GetSdPartnerId() == id ) {
      return &(*it);
    }
  }
  return NULL; // the id is not found
}

MdRecCounter*
MDEvent::GetHottestCounter()
{

  if (!HasCounters()) {
    return NULL;
  }

  MdRecCounter* hottest(NULL);
  double maxDensity(0);

  for (CounterIterator counter=CountersBegin(); counter!=CountersEnd(); ++counter) {
    // assume a saturated counter is the hottest (only 1 saturated counter per event)

    if (counter->IsSaturated()) {
      return &*counter;
    }

    double density = counter->GetMuonDensity();

    if (density>maxDensity) {
      hottest = &*counter;
      maxDensity = density;
    }

  }

  return hottest;

}

