// #include <config.h>

/*
   Martin Maur
   14 Apr 2012
*/

#ifndef __MdSimCounter_h_
#define __MdSimCounter_h_

#include <TObject.h>
#include <vector>
#include <MdSimScintillator.h>
#include <map>


class MdSimCounter : public TObject {

public:
  MdSimCounter();
  virtual ~MdSimCounter() { }

  void SetInsideRMinFlag(const bool r) { fInsideMinRadius = r; }
  bool IsInsideRMin() const { return fInsideMinRadius; }

  void SetId(const unsigned int id) { fId = id; }
  unsigned int GetId() const { return fId; }

  unsigned int GetNumberOfInjectedMuons() const;

  unsigned int GetNumberOfSimScintillators() const { return fScintillators.size(); }

  double GetEnergyDeposit() const;

  double GetMuonEnergyDeposit() const;

  void SetSPDistance(const double c) { fSPDistance = c; }
  double GetSPDistance() const { return fSPDistance; }
  void SetSPDelta(const double c) { fSPDelta = c; }
  double GetSPDelta() const { return fSPDelta; }
  void SetSPAzimuth(const double c) { fSPAzimuth = c; }
  double GetSPAzimuth() const { return fSPAzimuth; }

  double GetArea() const;

  unsigned int GetSdPartnerId() const { return fSdPartnerId; }
  void SetSdPartnerId(const int partnerId) { fSdPartnerId = partnerId; }

  const MdSimScintillator* GetSimScintillator(const unsigned int i) const;
  const MdSimScintillator* GetSimScintillatorById(const unsigned int mId, const unsigned int scId) const;
  const MdSimScintillator* GetSimScintillatorByChannelId(const unsigned int mId, const unsigned int chId) const;
  const MdSimScintillator* GetSimScintillatorByPixelId(const unsigned int mId, const unsigned int pxId) const;
  const std::vector<MdSimScintillator>& GetSimScintillatorVector() const { return fScintillators; }

  bool HasSimScintillator(const unsigned int mId, const unsigned int scId) const;
  bool HasSimScintillatorByChannel(const unsigned int mId, const unsigned int chId) const;
  bool HasSimScintillatorByPixel(const unsigned int mId, const unsigned int pxId) const;
  bool HasSimScintillators() const { return !fScintillators.empty(); }

  void AddSimScintillator(const MdSimScintillator& s);

  void SetAreaByModule(const double area, const unsigned int moduleId) { fAreaByModule[moduleId] = area; }
  double GetAreaByModule(const unsigned int moduleId) const;
  bool HasModule(const unsigned int moduleId) const;
  const std::map<unsigned int, double>& GetAreaByModules() { return fAreaByModule; }

private:
  unsigned int fId;
  unsigned int fSdPartnerId;
  bool fInsideMinRadius;

  double fSPDelta;
  double fSPDistance;
  double fSPAzimuth;

  std::vector<MdSimScintillator> fScintillators;
  std::map<unsigned int, double> fAreaByModule;

  ClassDef(MdSimCounter, 1);

};


#endif // __MdSimCounter_h_
