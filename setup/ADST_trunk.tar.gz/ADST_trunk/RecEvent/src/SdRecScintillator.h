// $Id: SdRecScintillator.h 30052 2017-03-13 19:37:40Z schmidt-d $
#ifndef __SdRecScintillator_h_
#define __SdRecScintillator_h_

#include <TObject.h>
#include <cmath>


//  Station scintillator data

class SdRecScintillator: public TObject {

public:
  SdRecScintillator();

  // Setters
  void SetTotalSignal(const Double_t c, const Double_t e)
  { fTotalSignal = c; fTotalSignalError = e; }

  Double_t fTotalSignal;
  Double_t fTotalSignalError;

  ClassDef(SdRecScintillator, 1);

};


#endif
