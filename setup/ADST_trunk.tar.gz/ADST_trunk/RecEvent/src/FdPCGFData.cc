
#include <FdPCGFData.h>


ClassImp(FdPCGFData);

//=============================================================================
/*!
  \class   FdPCGFData
  \brief   Profile constraint geometry fit data
  \version 1.0
  \date    May 2017
  \author  R. Ulrich  
*/
//=============================================================================
FdPCGFData::FdPCGFData() :
  fChi0(0),
  fRp(0),
  fT0(0),
  //  std::map<std::string, double> fChi2;
  fStatus(ePCGFUnknown) 
{   
}


double
FdPCGFData::GetChi2Sum()
  const
{
  double sum = 0;
  for(std::map<std::string,double>::const_iterator it = fChi2.begin();
      it != fChi2.end(); ++it) {
    sum += it->second;
  }
  return sum;
}


double
FdPCGFData::GetChi2(const std::string& w) const
{
  std::map<std::string, double>::const_iterator it = fChi2.find(w);
  if (it == fChi2.end())
    return 0;
  return it->second;
}

double
FdPCGFData::GetNDofSum()
  const
{
  double sum = 0;
  for(std::map<std::string,double>::const_iterator it = fNDof.begin();
      it != fNDof.end(); ++it) {
    sum += it->second;
  }
  return sum;
}


double
FdPCGFData::GetNDof(const std::string& w) const
{
  std::map<std::string, double>::const_iterator it = fNDof.find(w);
  if (it == fNDof.end())
    return 0;
  return it->second;
}
