
#include <FdRecGeometry.h>

#include <FdRecLevel.h>

#include <iostream>

ClassImp(FdRecGeometry);

//=============================================================================
/*!
  \class   FdGeometry
  \brief   uncertainties of shower axis parameters (SDP, \f$\chi_0\f$ etc.)
  \version 1.0
  \date    July 2006
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
  
*/
//=============================================================================
FdRecGeometry::FdRecGeometry() :
  fSDPThetaError(0.),
  fSDPPhiError(0.),
  fRhoThetaPhi(0.),
  fSDPChi2(0.),
  fSDPNdF(0),
  fT0Error(0.),
  fChi0Error(0.),
  fRpError(0.),
  fRhoChi0T0(0.),
  fRhoChi0Rp(0.),
  fRhoRpT0(0.),
  fTimeFitChi2(0.),
  fTimeFitFDChi2(0.),
  fLinearTimeFitChi2(0.),
  fTimeFitNdF(0),
  fNorthEastCorrelation(0.),
  fNorthThetaCorrelation(0.),
  fNorthPhiCorrelation(0.),
  fNorthTCoreCorrelation(0.),
  fEastThetaCorrelation(0.),
  fEastPhiCorrelation(0.),
  fEastTCoreCorrelation(0.),
  fThetaPhiCorrelation(0.),
  fThetaTCoreCorrelation(0.),
  fPhiTCoreCorrelation(0.),
  fAxisFitChi2(0.),
  fAxisFitNdF(0),
  fFdGeomRecLevel(eNoGeometry),
  fNTimeFitPixels(0),
  fNTank(0),
  fHottestTank(0),
  fAxisDist(1.e99),
  fSDFDdT(1.e99),
  fSDPDist(1.e99)
{   

}


double
FdRecGeometry::GetCoreEyeDistanceError()
  const
{
  double Rp = GetRp();
  double chi0 = GetChi0();
  double sinChi0 = sin( chi0 );

  // derivatives
  double dFdRp = 1./sinChi0;
  double dFdChi0 = - Rp/sinChi0/sinChi0*cos(chi0);

  double uncorrelatedVariance =   dFdRp*dFdRp   *   fRpError*fRpError  +   
                                dFdChi0*dFdChi0 * fChi0Error*fChi0Error;
  
  double covRpChi0 = fRhoChi0Rp * fRpError * fChi0Error;
  double totalVariance = uncorrelatedVariance + dFdRp*dFdChi0*covRpChi0;

  return sqrt(totalVariance);
}


void
FdRecGeometry::DumpASCII(std::ostream& o)
  const
{
  o << "  Rp(m)/T0(ns)/Chi0(deg) " 
    << GetRp() << "+-" << fRpError << " / " << GetT0() << "+-" << fT0Error << " / " << GetChi0()  << "+-" << fChi0Error 
    << std::endl;
}
