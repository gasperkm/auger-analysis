// $Id: FdGenGeometry.cc 30875 2017-07-26 11:37:15Z rulrich $
#include <FdGenGeometry.h>


ClassImp(FdGenGeometry);

#include <iostream>

//=============================================================================
/*!
  \class   FdGenGeometry
  \brief   Generated shower axis parameters (SDP, \f$\chi_0\f$ etc.)

  \version 1.0
  \date    Jan 20 2004
  \author  I. Maris, F. Sch&uuml;ssler, R. Ulrich, M. Unger
*/
//=============================================================================

void
FdGenGeometry::DumpASCII(std::ostream& o)
  const
{
  if (GetRp()!=0 || GetT0()!=0 || GetChi0()!=0) {
    o << "  Rp(m)/T0(ns)/Chi0(deg) " 
      << GetRp() << " / " << GetT0() << " / " << GetChi0() << "  [simulated] "
      << std::endl;
  }
}

