#ifndef __FdPCGFData_h__
#define __FdPCGFData_h__

#include <TObject.h>

#include <string>
#include <map>

enum EPCGFStatus {
  ePCGFUnknown = 0,
  ePCGFScan = 1,
  ePCGFFit = 2,
  ePCGFInitial = 3,
  ePCGFFinal = 4
};

class FdPCGFData : public TObject {

public:  
  FdPCGFData();
  
  void SetChi0(const double vec) {fChi0=vec;}
  void SetRp(const double vec) {fRp=vec;}
  void SetT0(const double vec) {fT0=vec;}
  void AddChi2(const std::string s, double v) {  fChi2[s] += v; }
  void AddNDof(const std::string s, double v) {  fNDof[s] += v; }
  void SetChi2(const std::map<std::string,double> vec) {fChi2=vec;}
  void SetNDof(const std::map<std::string,double> vec) {fNDof=vec;}
  void SetStatus(const EPCGFStatus vec) {fStatus=vec;}

  double GetChi0() const  {return fChi0;}
  double GetRp() const  {return fRp;}
  double GetT0() const  {return fT0;}  

  const std::map<std::string,double>& GetChi2() const  {return fChi2;}
  double GetChi2(const std::string& w) const;
  double GetChi2Sum() const;

  const std::map<std::string,double>& GetNDof() const  {return fNDof;}
  double GetNDof(const std::string& w) const;
  double GetNDofSum() const;
  
  EPCGFStatus GetStatus() const {return fStatus;}
  
private:

  double fChi0;
  double fRp;
  double fT0;
  std::map<std::string, double> fChi2;
  std::map<std::string, double> fNDof;
  EPCGFStatus fStatus;
  
  ClassDef(FdPCGFData, 3);
};


#endif
