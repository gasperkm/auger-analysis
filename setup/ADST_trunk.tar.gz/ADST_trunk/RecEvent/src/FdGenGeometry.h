#ifndef __FdGenGeometry_h__
#define __FdGenGeometry_h__

#include <FdGeometry.h>
#include <iostream>

class FdGenGeometry : public FdGeometry {

public:

  void DumpASCII(std::ostream& o) const;

private:

  ClassDef(FdGenGeometry, 3);

};


#endif
