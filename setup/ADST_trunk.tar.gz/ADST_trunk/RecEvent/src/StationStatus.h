#ifndef _adst_StationStatus_h_
#define _adst_StationStatus_h_


//  Station data definition

enum EStationStatus {
  eUnknown,
  eSilent,
  eAccidental,
  eCandidate
};


enum EStationTrigger {
  eT1Threshold,
  eT2Threshold,
  eTOT,
  eRandom,
  eNone,
  eTOTd,
  eMoPS
};


// Keep this in sync with Offline/Framework/SEvent/StationConstants.h

enum ERejectionStatus {
  eNoRejection      = 0,
  eLightning        = (1 << 0),
  eBadCompress      = (1 << 1),
  eOutOfTime        = (1 << 2),
  eOffGrid          = (1 << 3),
  eDenseArray       = (1 << 4),
  eRandomR          = (1 << 5),
  eEngineeringArray = (1 << 6),
  eMCInnerRadiusCut = (1 << 7),
  eNoRecData        = (1 << 8),
  eLonely           = (1 << 9),
  eNoTrigger        = (1 << 10),
  eErrorCode        = (1 << 11),
  eNoCalibData      = (1 << 12),
  eNoGPSData        = (1 << 13),
  eBadCalib         = (1 << 14),
  eRegularMC        = (1 << 15), 
  eTOTdRejected     = (1 << 16),
  eMoPSRejected     = (1 << 17),
  eNotAliveT2       = (1 << 18), // not alive in the T2 files
  eNotAliveT120     = (1 << 19), // does not fulfill the T2 120 condition 
  eBadSilent        = (1 << 20), // silent stations removed in the LDFFinder
  eAllPMTsBad       = (1 << 21),

  eNumRejectionStatusBits = 22
};


#endif
