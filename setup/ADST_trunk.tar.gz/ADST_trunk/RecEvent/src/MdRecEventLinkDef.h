#ifndef _adst_MdRecEventLinkDef_h_
#define _adst_MdRecEventLinkDef_h_

#ifdef __CINT__

#pragma link C++ class MDEvent+;
#pragma link C++ class MdRecShower+;
#pragma link C++ class MdRecCounter+;
#pragma link C++ class MdSimCounter+;
#pragma link C++ class std::vector<MdSimCounter>+;
#pragma link C++ class std::vector<MdRecCounter>+;
#pragma link C++ class MdRecChannel+;
#pragma link C++ class std::vector<MdRecChannel>+;
#pragma link C++ class MdSimScintillator+;
#pragma link C++ class std::vector<MdSimScintillator>+;
#pragma link C++ class MdSimScintillator::SPEPulse+;
#pragma link C++ class std::vector<MdSimScintillator::SPEPulse>+;
#pragma link C++ class MdRecModule+;
#pragma link C++ class std::vector<MdRecModule>+;

#endif

#endif
