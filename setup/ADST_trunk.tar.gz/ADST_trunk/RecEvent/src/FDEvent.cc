#include <FDEvent.h>
#include <FdRecLevel.h>
#include <FdRecShower.h>
#include <FdRecPixel.h>
#include <FdRecStation.h>
#include <DetectorGeometry.h>
#include <FdGenGeometry.h>

#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>

using namespace std;


ClassImp(FDEvent);


FDEvent::FDEvent() :
  fEye(0),
  fRun(0),
  fFdEventId(0),
  fFdGPSSecond(0),
  fFdGPSNanoSecond(0),
  fFdYYMMDD(0),
  fFdHHMMSS(0),
  fFdEventClass("unknown"),
  fFdEventType("unknown"),
  fTimeCorrectionStatus(eUndefinedCorrection),
  fT3SDPTheta(9999),
  fT3SDPPhi(9999),
  fT3Azimuth(9999),
  fT3NPixels(0),
  fT3TimeAtGround(0),
  fT3TimeAtGroundNanoSecond(0),
  fTelEvtBits(0),
  fMoonCycle(0.),
  fFdRecLevel(eNoFdEvent),
  fNoTel(0)
{
#ifdef DEBUGKG
  cout << "  FDEvent::FDEvent() begin\n"
          "  FDEvent::FDEvent() end" << endl;
#endif
}


FDEvent::~FDEvent()
{
#ifdef DEBUGKG
  cout << " FDEvent::~FDEvent()   begin\n"
          " FDEvent::~FDEvent()   end" << endl;
#endif
}


FdRecShower&
FDEvent::GetFdRecShower()
{
  return fFdRecShower;
}


const FdRecShower&
FDEvent::GetFdRecShower()
  const
{
  return fFdRecShower;
}


FdRecGeometry&
FDEvent::GetFdRecGeometry()
{
  return fFdRecGeometry;
}


const FdRecGeometry&
FDEvent::GetFdRecGeometry()
  const
{
  return fFdRecGeometry;
}


SdRecGeometry&
FDEvent::GetSdRecGeometry()
{
  return fSdRecGeometry;
}


const SdRecGeometry&
FDEvent::GetSdRecGeometry()
  const
{
  return fSdRecGeometry;
}


FdRecApertureLight&
FDEvent::GetFdRecApertureLight()
{
  return fFdRecApertureLight;
}


const FdRecApertureLight&
FDEvent::GetFdRecApertureLight()
  const
{
  return fFdRecApertureLight;
}


FdGenShower&
FDEvent::GetGenShower()
{
  return fFdGenShower;
}


const FdGenShower&
FDEvent::GetGenShower()
  const
{
  return fFdGenShower;
}


FdRecPixel&
FDEvent::GetFdRecPixel()
{
  return fFdRecPixel;
}


const FdRecPixel&
FDEvent::GetFdRecPixel()
  const
{
  return fFdRecPixel;
}


FdGenGeometry&
FDEvent::GetGenGeometry()
{
  return fFdGenGeometry;
}


const FdGenGeometry&
FDEvent::GetGenGeometry()
  const
{
  return fFdGenGeometry;
}


/*
FdGenApertureLight&
FDEvent::GetGenApertureLight(const int telId)
{
  return fFdGenApertureLight[telId];
}


const FdGenApertureLight&
FDEvent::GetGenApertureLight(const int telId)
  const
{
  const std::map<int, FdGenApertureLight>::const_iterator tltIter = fFdGenApertureLight.find(telId);
  return tltIter->second;
}


bool
FDEvent::HasGenApertureLight(const int telId)
  const
{
  const std::map<int, FdGenApertureLight>::const_iterator tltIter = fFdGenApertureLight.find(telId);
  return tltIter != fFdGenApertureLight.end();
}
*/


void
FDEvent::AddStation(const FdRecStation& station)
{
  fStations.push_back(station);
}


//======================================================================
const FdRecStation*
FDEvent::GetStation(const UInt_t i)
  const
{
  if (i < fStations.size())
    return &fStations[i];
  else
    return NULL;
}


//======================================================================
bool
FDEvent::HasTLT(const int telId)
  const
{
  const std::map<int, bool>::const_iterator tltIter = fHasTLT.find(telId);
  return (tltIter != fHasTLT.end()) ? tltIter->second : false;
}


//======================================================================
std::string
FDEvent::GetTLTLabel(const int telId)
  const
{
  const std::string noTLT = " --- ";

  const std::map<int, std::string>::const_iterator tltIter = fTLTLabel.find(telId);
  return (tltIter != fTLTLabel.end()) ? tltIter->second : noTLT;
}


//======================================================================
// check for Hybrid reconstruction
bool
FDEvent::IsHybridEvent()
  const
{
  return fFdRecGeometry.GetNHybridStations() > 0 && fFdRecGeometry.GetHottestStation() > 0;
}

bool 
FDEvent::IsProfileConstrainedGeometry() 
  const
{
  return fFdRecGeometry.HasPCGFData();
}


int
FDEvent::GetMirrorTimeOffset(const int mirror)
  const
{
  const std::map<UShort_t, Int_t>::const_iterator mirrIter = fMirrorTimeOffset.find(mirror);
  if (mirrIter != fMirrorTimeOffset.end())
    return mirrIter->second;

  cerr << " FdRecShower::GetMirrorTimeOffset(): unknown mirror " << mirror << endl;
  return 0;
}


//======================================================================
int
FDEvent::GetHottestMirrorId()
  const
{
  int idHot = 0;
  int nPixHot = 0;

  const FdRecPixel recPixel = GetFdRecPixel();
  const int nPixel = recPixel.GetNumberOfPixels();
  std::vector<int> NTimeFitPixel;
  std::vector<int> NSDPFitPixel;
  std::vector<int> NPulsedPixel;
  std::vector<int> NTriggeredPixel;

  for (int pix = 0; pix < nPixel; ++pix) {

    const UShort_t iTel = recPixel.GetTelescopeId(pix);

    if (recPixel.GetStatus(pix) >= eTimeFitPix) {
      if (NTimeFitPixel.size() <= iTel) {
        for (unsigned int i = NTimeFitPixel.size(); i<= iTel; ++i)
          NTimeFitPixel.push_back(0);
      } else
        ++NTimeFitPixel[iTel];
    }

    if (recPixel.GetStatus(pix) >= eSDPRecPix) {
      if (NSDPFitPixel.size() <= iTel) {
        for (unsigned int i = NSDPFitPixel.size(); i<= iTel; ++i)
          NSDPFitPixel.push_back(0);
      } else
        ++NSDPFitPixel[iTel];
    }

    if (recPixel.GetStatus(pix) >= ePulseRecPix) {
      if (NPulsedPixel.size() <= iTel) {
        for (unsigned int i = NPulsedPixel.size(); i<= iTel; ++i)
          NPulsedPixel.push_back(0);
      } else
        ++NPulsedPixel[iTel];
    }

    if (recPixel.GetStatus(pix) >= eTriggeredPix) {
      if (NTriggeredPixel.size() <= iTel) {
        for (unsigned int i = NTriggeredPixel.size(); i<= iTel; ++i)
          NTriggeredPixel.push_back(0);
      } else
        ++NTriggeredPixel[iTel];
    }

  }

  for (unsigned int tel = 0; tel < NTimeFitPixel.size(); ++tel) {
    if (NTimeFitPixel[tel] > nPixHot) {
      nPixHot = NTimeFitPixel[tel];
      idHot = tel;
    }
  }
  if (idHot != 0)
    return idHot;

  for (unsigned int tel = 0; tel < NSDPFitPixel.size(); ++tel) {
    if (NSDPFitPixel[tel] > nPixHot) {
      nPixHot = NSDPFitPixel[tel];
      idHot = tel;
    }
  }
  if (idHot != 0)
    return idHot;

  for (unsigned int tel = 0; tel < NPulsedPixel.size(); ++tel) {
    if (NPulsedPixel[tel] > nPixHot) {
      nPixHot = NPulsedPixel[tel];
      idHot = tel;
    }
  }
  if (idHot != 0)
    return idHot;

  for (unsigned int tel = 0; tel < NTriggeredPixel.size(); ++tel) {
    if (NTriggeredPixel[tel] > nPixHot) {
      nPixHot = NTriggeredPixel[tel];
      idHot = tel;
    }
  }
  if (idHot != 0)
    return idHot;

  return 0;
}


//======================================================================
int
FDEvent::GetXmaxInFOVTelId()
  const
{
  const FdRecShower& fdRecShower = GetFdRecShower();
  const FdRecApertureLight& fdApertureLight = GetFdRecApertureLight();
  const FdRecPixel& fdRecPixel = GetFdRecPixel();

  double xmax = fdRecShower.GetXmax();
  if (xmax == 0)
    return -1;

  const std::vector<Double_t>& depth = fdRecShower.GetDepth();
  const std::vector<Double_t>& time = fdApertureLight.GetTime();

  if (time.size() != depth.size()) {
    cerr << "FDEvent::GetXmaxInFOVTelId: something is terribly wrong: "
            "found different sizes for long. profile and light at aperture " << endl;
    return -1;
  }

  double minDepthTime = 0;
  double minDepthDist = 0;
  bool haveMinDepthDist = false;
  for (unsigned int i = 0; i < depth.size(); ++i) {
    const double thisDist = std::fabs(xmax - depth[i]);
    if (!haveMinDepthDist || thisDist < minDepthDist) {
      haveMinDepthDist = true;
      minDepthDist = thisDist;
      minDepthTime = time[i];
    }
  }

  const int nPix = fdRecPixel.GetNumberOfPixels();
  int bestTelID = -1;
  double bestTimeDiff = 0;
  bool FirstPixel = true;

  for (int i = 0; i < nPix; ++i) {
    if (fdRecPixel.GetStatus(i) >= ePulseRecPix) {

      const int iTel = fdRecPixel.GetTelescopeId(i);

      const UInt_t iOff = UInt_t(GetMirrorTimeOffset(iTel) / 100);
      const double timeDiff = std::fabs(minDepthTime - fdRecPixel.GetTime(i) - iOff);

      if (FirstPixel || timeDiff < bestTimeDiff) {
        bestTimeDiff = timeDiff;
        FirstPixel = false;
        bestTelID = iTel;
      }

    }
  }

  return bestTelID;
}


//======================================================================
bool
FDEvent::IsXmaxInTelFOV(const int iTelID)
  const
{
  return GetXmaxInFOVTelId() == iTelID;
}


int
FDEvent::GetXmaxPixel()
  const
{
  if (GetRecLevel() < eHasGHParameters) {
    cerr << " no GH parameters " << endl;
    return -1;
  }

  //cout << " have gh " << endl;

  const FdRecShower& rec = GetFdRecShower();
  const double xMax = rec.GetXmax();

  //cout << " xMax " << xMax << endl;

  // find Xmax bin
  int maxBin = -1;
  const vector<Double_t>& depth = rec.GetDepth();
  const vector<Double_t>& depthError = rec.GetDepthError();
  const int nProf = depth.size();
  if (nProf <= 1)
    return -5;

  bool first = true;
  double minXmaxDist = 0;
  for (int iProf = 0; iProf < nProf; ++iProf) {
    const double binXmax = depth[iProf]; // - depthError[iProf]/2.;
    const double distXmax = std::fabs(binXmax - xMax);
    if (first) {
      minXmaxDist = distXmax;
      maxBin = iProf;
      first = false;
    } else if (distXmax < minXmaxDist) {
      minXmaxDist = distXmax;
      maxBin = iProf;
    }
  }
  if (maxBin == -1) {
    cerr << " WARNING: could not find Xmax bin: "
            " xmax=" << xMax
         << " nP=" << nProf
         << " depthMin=" << depth[0] << " (" << depthError[0] << ")"
            " depthMax=" << depth[nProf-1] << " (" << depthError[nProf-1] << ")"
         << endl;
    return -2;
  }

  // get bin time
  const double timeXmax = GetFdRecApertureLight().GetTime()[maxBin];

  // find xMax pixel
  int maxPixel = -1;
  double maxCharge = 0;
  first = true;
  const FdRecPixel& recPixel = GetFdRecPixel();
  const int nPixel = recPixel.GetNumberOfPixels();
  for (int iPixel = 0; iPixel < nPixel; ++iPixel) {

    if (recPixel.GetStatus(iPixel) < ePulseRecPix)
      continue;

    const int id = recPixel.GetID(iPixel);
    const double charge = recPixel.GetCharge(iPixel);
    const double pixStart = recPixel.GetPulseStart(iPixel);
    const double pixStop = recPixel.GetPulseStop(iPixel);

    if (timeXmax >= pixStart && timeXmax <= pixStop) {

      if (first) {

        maxCharge = charge;
        maxPixel = id;
        first = false;

      } else if (charge > maxCharge) {

        maxCharge = charge;
        maxPixel = id;

      }

    }

  } // loop pixels

  return maxPixel;
}


void
FDEvent::DumpASCII(std::ostream& o)
  const
{
  o << "\n"
       "  eye/run/event/GPS      " << fEye << " / " << fRun << " / " << fFdEventId << " / " << fFdGPSSecond
    << endl;
  fFdRecGeometry.DumpASCII(o);
  fFdGenGeometry.DumpASCII(o);
  fFdRecShower.DumpASCII(o);
}


const FdTelescopeData&
FDEvent::GetTelescopeData(unsigned int telId)
  const
{
  map<int, FdTelescopeData>::const_iterator tel = fTelescopeData.find(telId);
  if (tel == fTelescopeData.end()) {
    ostringstream msg;
    msg << "No FdTelescopeData for telescope " << telId;
    throw std::out_of_range(msg.str());
  }
  else
    return tel->second;
}


FdTelescopeData&
FDEvent::GetTelescopeData(unsigned int telId)
{
  map<int, FdTelescopeData>::iterator tel = fTelescopeData.find(telId);
  if (tel == fTelescopeData.end()) {
    ostringstream msg;
    msg << "No FdTelescopeData for telescope " << telId;
    throw std::out_of_range(msg.str());
  }
  else
    return tel->second;
}


bool
FDEvent::HasTelescopeData(unsigned int telId)
  const
{
  return (fTelescopeData.find(telId) != fTelescopeData.end());
}


void
FDEvent::SetTelescopeData(unsigned int telId, const FdTelescopeData& telRD)
{
  fTelescopeData[telId] = telRD;
}

