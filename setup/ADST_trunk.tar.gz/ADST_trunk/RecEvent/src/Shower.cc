#include <Shower.h>
#include <cmath>

using namespace std;


ClassImp(Shower);


Shower::Shower() :
  fEnergy(0.),
  fCoreTimeSecond(0),
  fCoreTimeNanoSecond(0),
  fCoreSiteCS(0.,0.,0.),
  fCoreUTMCS(0.,0.,0.),
  fAxisCoreCS(0.,0.,0.),
  fAxisSiteCS(0.,0.,0.),
  fGalacticLong(0.),
  fGalacticLat(0.),
  fDeclination(0.),
  fRightAscension(0.),
  fLocalSiderealTime(0.)
{
}


Double_t
Shower::GetZenith()
  const
{
  return fAxisCoreCS.Theta();
}


Double_t
Shower::GetCosZenith()
  const
{
  return fAxisCoreCS.z();
}


Double_t
Shower::GetAzimuth()
  const
{
  double azi = fAxisCoreCS.Phi();
  if (azi < 0)
    azi = 2.*M_PI + azi;
  return azi;
}


TVector3
Shower::GetCoreAtAltitudeUTMCS(const double /*altitude*/)
  const
{
  cerr << " Shower::GetCoreAtAltitudeUTMCS() not implemented" << endl;
  TVector3 a(0, 0, 0);
  return a;
}


TVector3
Shower::GetCoreAtAltitudeSiteCS(const double altitude)
  const
{
  const TVector3 normal(0., 0., 1);
  const TVector3 translation(0, 0, fCoreSiteCS.Z() - altitude);

  if (fAxisSiteCS == TVector3(0., 0., 0.))
    return fCoreSiteCS;

  return fCoreSiteCS -((normal * translation) /
                       (normal * fAxisSiteCS)) * fAxisSiteCS;
}


void
Shower::DumpASCII(std::ostream& o)
  const
{
  o << "  energy [EeV]           " << fEnergy/1.e18 << '\n'
    << "  north/east/height [m]  " << fixed << fCoreUTMCS.y()
    << " / " << fCoreUTMCS.x() << " / " << fCoreUTMCS.z() << '\n'
    << "  theta/phi (core) [deg] " << fAxisCoreCS.Theta()*180./M_PI
    << " / " << fAxisCoreCS.Phi()*180./M_PI
    << endl;
}
