#ifndef _adst_EventBrowserConfig_h_
#define _adst_EventBrowserConfig_h_

#include "FileInfo.h"

#include <bitset>


namespace cfg {

  enum EventBrowserSwitch {
    eFdCumulativeAperture,
    eFdShowXmaxInSdp,
    eFdShowSd,
    eFdShowZeta,
    eFdShowT3Sdp,
    eFdSaveAnimation,
    eFdSpeedAnimation,
    eFdShowMCInfoWithNoReco,
    
    eSdShowBadStations,
    eSdShowPMTSignals,
    eSdShowLDFOnArray,
    eSdShowFd,
    eSdShowAllTraces,
    eSdShowShowerPlaneArray,

    eRdShowFd,
    eRdShowSd,

    eMdShowFd,
    eMdShowSd,

    eAtmoShowAerosols,
    eAtmoShowCloudsOnArray,

    eShowMC,
    eShowMCTraces,
    eSizeEventBrowserSwitch

  };

}


class EventBrowserConfig {
private:
  static EventBrowserConfig& GetInstance();

public:
  static bool Get(const cfg::EventBrowserSwitch sw);
  static void Set(const cfg::EventBrowserSwitch sw, bool value);

  static ELDFType GetLDFType();
  static void SetLDFType(const ELDFType type);

private:
  EventBrowserConfig() { }
  ~EventBrowserConfig() { }
  EventBrowserConfig(const EventBrowserConfig&);
  EventBrowserConfig& operator=(const EventBrowserConfig&);

  std::bitset<cfg::eSizeEventBrowserSwitch> fBits;

  ELDFType fLDFType;
};


#endif
