#include "EventBrowserMenu.h"
#include "EventBrowserSignals.h"
#include "EventBrowser.h"
#include "EventBrowserConfig.h"

#include <TGClient.h>
#include <TGFrame.h>
#include <TGWindow.h>
#include <TGMenu.h>
#include <TGLayout.h>

#include <iostream>
using namespace std;

EventBrowserMenu::EventBrowserMenu(TGCompositeFrame* main) {

  // menu layouts
  fMenuBarLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft | kLHintsExpandX,
				     0, 0, 1, 1);
  fMenuBarItemLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft, 0, 4, 0, 0);
  fMenuBarHelpLayout = new TGLayoutHints(kLHintsTop | kLHintsRight);


  // for the Menu
  fMenuFile = new TGPopupMenu(gClient->GetRoot());
  fMenuFile->AddEntry("Open file ...", eFileOpen);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("Save event as PS", eFileSavePS);
  fMenuFile->AddEntry("Save event as ADST", eFileSaveROOT);
  fMenuFile->AddEntry("Save selected events as ADST", eFileSaveSelection);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("Dump ASCII event info", eFileDumpASCII);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("View Offline configuration", eViewOfflineConfig);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("Load source catalogue ...", eLoadSources);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("Load style file ...", eLoadStyle);
  fMenuFile->AddSeparator();
  fMenuFile->AddEntry("Start tree viewer", eFileTreeViewer);
  fMenuFile->AddEntry("Quit", eFileQuit);

  // for the options
  fMenuFDOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuFDOptions->AddEntry("Cumulative FD aperture plots", eCumulativeFDAperture);
  fMenuFDOptions->AddEntry("Show SD in FD", eShowSDinFD);
  fMenuFDOptions->AddEntry("Show T3 SDP", eShowFDT3SDP);
  fMenuFDOptions->AddEntry("Show Xmax in SDP", eShowXmaxInSDP);
  fMenuFDOptions->AddEntry("Show zeta angle", eShowZeta);
  fMenuFDOptions->AddEntry("Show expected FOV(40g,20deg)", eShowViewableFOV);
  fMenuFDOptions->AddEntry("Show telescopes in DAQ", eShowTelsInDAQ);

  fMenuApertureLightOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuApertureLightOptions->AddEntry("Eye-based only", eRBShowEyeApertureLight);
  fMenuApertureLightOptions->AddEntry("Telescope-based only", eRBShowTelApertureLight);
  fMenuApertureLightOptions->AddEntry("Both", eRBShowEyeAndTelApertureLight);
  // FIXME switch to tel-light by default as soon as appropriate... (also keep in sync with defaults in FdPlots.cc)
  fMenuApertureLightOptions->CheckEntry(eRBShowEyeApertureLight);

  fMenuFDOptions->AddPopup("Show Aperture Light", fMenuApertureLightOptions);
  fMenuFDOptions->AddEntry("Use L-C-Efficiency", eUseLCEfficiency);
  fMenuFDOptions->AddEntry("Show MC info for eyes with no reco data", eShowMCInfoWithNoReco);
  fMenuFDOptions->AddSeparator();
  fMenuFDOptions->AddEntry("Save animation", eSaveAnimations);
  fMenuFDOptions->AddEntry("Speed up animations", eSpeedAnimations);

  fMenuFDOptions->CheckEntry(eCumulativeFDAperture);
  EventBrowserConfig::Set(cfg::eFdCumulativeAperture, true);
  fMenuFDOptions->CheckEntry(eShowXmaxInSDP);
  EventBrowserConfig::Set(cfg::eFdShowXmaxInSdp, true);

  fMenuSDOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuSDOptions->AddEntry("Show FD in SD", eShowFDinSD);
  fMenuSDOptions->AddEntry("Show bad stations", eShowBadStations);
  fMenuSDOptions->AddEntry("Show PMT signals", eShowPMTSignals);
  fMenuSDOptions->AddEntry("Show LDF on array", eShowLDFOnArray);
  fMenuSDOptions->AddEntry("Show all SD PMT traces ", eShowAllTraces);
  fMenuSDOptions->AddEntry("Show array in SP", eShowerPlaneArray);
  // fMenuSDOptions->DisableEntry(eShowerPlaneArray);

  fMenuSDOptions->CheckEntry(eShowFDinSD);
  EventBrowserConfig::Set(cfg::eSdShowFd, true);
  fMenuSDOptions->CheckEntry(eShowBadStations);
  EventBrowserConfig::Set(cfg::eSdShowBadStations, true);
  fMenuSDOptions->CheckEntry(eShowLDFOnArray);
  EventBrowserConfig::Set(cfg::eSdShowLDFOnArray, true);

  fMenuRDOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuRDOptions->AddEntry("Show SD in RD", eShowSDinRD);
  fMenuRDOptions->AddEntry("Show FD in RD", eShowFDinRD);

  fMenuRDOptions->CheckEntry(eShowSDinRD);
  EventBrowserConfig::Set(cfg::eRdShowSd, true);  

  fMenuMDOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuMDOptions->AddEntry("Show SD in MD", eShowSDinMD);
  fMenuMDOptions->AddEntry("Show FD in MD", eShowFDinMD);

  fMenuMDOptions->CheckEntry(eShowSDinMD);
  EventBrowserConfig::Set(cfg::eMdShowSd, true);  

  fMenuAtmoOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuAtmoOptions->AddEntry("Show Aerosols in FD", eShowAerosols);
  fMenuAtmoOptions->AddEntry("Show clouds on array", eShowCloudsOnArray);

  fMenuMCOptions = new TGPopupMenu(gClient->GetRoot());
  fMenuMCOptions->AddEntry("Show MC", eShowMC);
  fMenuMCOptions->AddEntry("Show MC traces", eShowMCTraces);

  fMenuMCOptions->CheckEntry(eShowMC);
  EventBrowserConfig::Set(cfg::eShowMC, true);
  if (!((EventBrowser*)main)->IsMCData()) {
    fMenuMCOptions->DisableEntry(eShowMC);
    fMenuMCOptions->DisableEntry(eShowMCTraces);
  }


  // for some help
  fMenuHelp = new TGPopupMenu(gClient->GetRoot());
  fMenuHelp->AddEntry("FD plots ...", eFDHelp);
  fMenuHelp->AddEntry("SD plots ...", eSDHelp);
  fMenuHelp->AddSeparator();
  fMenuHelp->AddEntry("About", eAbout);

  fMenuHelp->DisableEntry(eFDHelp);
  fMenuHelp->DisableEntry(eSDHelp);

  fMenuFile->Associate(main);
  fMenuFDOptions->Associate(main);
  fMenuAtmoOptions->Associate(main);
  fMenuApertureLightOptions->Associate(main);
  fMenuSDOptions->Associate(main);
  fMenuRDOptions->Associate(main);
  fMenuMDOptions->Associate(main);

  fMenuMCOptions->Associate(main);
  fMenuHelp->Associate(main);



  fMenuBar = new TGMenuBar(main);
  fMenuBar->AddPopup("File", fMenuFile, fMenuBarItemLayout);
  fMenuBar->AddPopup("FD", fMenuFDOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("SD", fMenuSDOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("RD", fMenuRDOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("MD", fMenuMDOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("Atm", fMenuAtmoOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("MC", fMenuMCOptions, fMenuBarItemLayout);
  fMenuBar->AddPopup("Help", fMenuHelp, fMenuBarHelpLayout);
  fMenuBar->DrawBorder();

  main->AddFrame(fMenuBar, fMenuBarLayout);

}


EventBrowserMenu::~EventBrowserMenu() {
  delete fMenuBar;
}


bool
EventBrowserMenu::ToggleFDEntry(const int entryId)
{

  EButtonSignals signal = EButtonSignals(entryId);

  if (fMenuFDOptions->IsEntryChecked(signal)) {

    fMenuFDOptions->UnCheckEntry(signal);
    return false;
  }

  fMenuFDOptions->CheckEntry(signal);
  return true;
}


bool
EventBrowserMenu::ToggleAtmoEntry(const int entryId)
{

  EButtonSignals signal = EButtonSignals(entryId);

  if (fMenuAtmoOptions->IsEntryChecked(signal)) {

    fMenuAtmoOptions->UnCheckEntry(signal);
    return false;
  }

  fMenuAtmoOptions->CheckEntry(signal);
  return true;
}


bool
EventBrowserMenu::ToggleShowAerosols()
{
  return ToggleAtmoEntry(eShowAerosols);
}

bool
EventBrowserMenu::ToggleShowCloudsOnArray()
{
  return ToggleAtmoEntry(eShowCloudsOnArray);
}


bool
EventBrowserMenu::ToggleAperture()
{
  return ToggleFDEntry(eCumulativeFDAperture);
}

bool
EventBrowserMenu::ToggleShowViewableFOV()
{
  return ToggleFDEntry(eShowViewableFOV);
}

bool
EventBrowserMenu::ToggleShowTelsInDAQ()
{
  return ToggleFDEntry(eShowTelsInDAQ);
}


bool
EventBrowserMenu::ToggleUseLCEfficiency()
{
  return ToggleFDEntry(eUseLCEfficiency);
}

bool
EventBrowserMenu::ToggleShowMCWithNoReco()
{
  return ToggleFDEntry(eShowMCInfoWithNoReco);
}

bool
EventBrowserMenu::ToggleAnimation()
{
  return ToggleFDEntry(eSaveAnimations);
}


bool
EventBrowserMenu::ToggleZeta()
{
  return ToggleFDEntry(eShowZeta);
}

bool
EventBrowserMenu::ToggleFDT3SDP()
{
  return ToggleFDEntry(eShowFDT3SDP);
}

bool
EventBrowserMenu::ToggleFDXmaxSDP()
{
  return ToggleFDEntry(eShowXmaxInSDP);
}

bool
EventBrowserMenu::ToggleSDinFD()
{
  return ToggleFDEntry(eShowSDinFD);
}


bool
EventBrowserMenu::ToggleSpeedAnimation()
{
  return ToggleFDEntry(eSpeedAnimations);
}


bool
EventBrowserMenu::ToggleAllTracesinSD()
{
  if (fMenuSDOptions->IsEntryChecked(eShowAllTraces)) {
    fMenuSDOptions->UnCheckEntry(eShowAllTraces);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowAllTraces);
  return true;
}

bool
EventBrowserMenu::ToggleFDinSD()
{
  if (fMenuSDOptions->IsEntryChecked(eShowFDinSD)) {
    fMenuSDOptions->UnCheckEntry(eShowFDinSD);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowFDinSD);
  return true;
}

bool
EventBrowserMenu::ToggleShowerPlaneArray()
{
  if(fMenuSDOptions->IsEntryChecked(eShowerPlaneArray)) {
    fMenuSDOptions->UnCheckEntry(eShowerPlaneArray);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowerPlaneArray);
  return true;
}


bool
EventBrowserMenu::ToggleShowMC()
{
  if(fMenuMCOptions->IsEntryChecked(eShowMC)) {
    fMenuMCOptions->UnCheckEntry(eShowMC);
    return false;
  }

  fMenuMCOptions->CheckEntry(eShowMC);
  return true;
}


bool
EventBrowserMenu::ToggleShowMCTraces()
{
  if(fMenuMCOptions->IsEntryChecked(eShowMCTraces)) {

    fMenuMCOptions->UnCheckEntry(eShowMCTraces);
    return false;
  }

  fMenuMCOptions->CheckEntry(eShowMCTraces);
  return true;
}


bool
EventBrowserMenu::ToggleShowBadStations()
{
  if (fMenuSDOptions->IsEntryChecked(eShowBadStations)) {
    fMenuSDOptions->UnCheckEntry(eShowBadStations);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowBadStations);
  return true;
}


bool
EventBrowserMenu::ToggleShowPMTSignals()
{
  if (fMenuSDOptions->IsEntryChecked(eShowPMTSignals)) {
    fMenuSDOptions->UnCheckEntry(eShowPMTSignals);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowPMTSignals);
  return true;
}


bool
EventBrowserMenu::ToggleShowLDFOnArray()
{
  if (fMenuSDOptions->IsEntryChecked(eShowLDFOnArray)) {
    fMenuSDOptions->UnCheckEntry(eShowLDFOnArray);
    return false;
  }

  fMenuSDOptions->CheckEntry(eShowLDFOnArray);
  return true;
}

bool
EventBrowserMenu::ToggleSDinRD()
{
  if (fMenuRDOptions->IsEntryChecked(eShowSDinRD)) {
    fMenuRDOptions->UnCheckEntry(eShowSDinRD);
    return false;
  }

  fMenuRDOptions->CheckEntry(eShowSDinRD);
  return true;
}

bool
EventBrowserMenu::ToggleFDinRD()
{
  if (fMenuRDOptions->IsEntryChecked(eShowFDinRD)) {
    fMenuRDOptions->UnCheckEntry(eShowFDinRD);
    return false;
  }

  fMenuRDOptions->CheckEntry(eShowFDinRD);
  return true;
}

bool
EventBrowserMenu::ToggleSDinMD()
{
  if (fMenuMDOptions->IsEntryChecked(eShowSDinMD)) {
    fMenuMDOptions->UnCheckEntry(eShowSDinMD);
    return false;
  }

  fMenuMDOptions->CheckEntry(eShowSDinMD);
  return true;
}

bool
EventBrowserMenu::ToggleFDinMD()
{
  if (fMenuMDOptions->IsEntryChecked(eShowFDinMD)) {
    fMenuMDOptions->UnCheckEntry(eShowFDinMD);
    return false;
  }

  fMenuMDOptions->CheckEntry(eShowFDinMD);
  return true;
}

void
EventBrowserMenu::SetShowTelApertureLight()
{
  fMenuApertureLightOptions->CheckEntry(eRBShowTelApertureLight);
  fMenuApertureLightOptions->UnCheckEntry(eRBShowEyeAndTelApertureLight);
  fMenuApertureLightOptions->UnCheckEntry(eRBShowEyeApertureLight);
}

void
EventBrowserMenu::SetShowEyeApertureLight()
{
  fMenuApertureLightOptions->UnCheckEntry(eRBShowTelApertureLight);
  fMenuApertureLightOptions->UnCheckEntry(eRBShowEyeAndTelApertureLight);
  fMenuApertureLightOptions->CheckEntry(eRBShowEyeApertureLight);
}

void
EventBrowserMenu::SetShowEyeAndTelApertureLight()
{
  fMenuApertureLightOptions->UnCheckEntry(eRBShowTelApertureLight);
  fMenuApertureLightOptions->CheckEntry(eRBShowEyeAndTelApertureLight);
  fMenuApertureLightOptions->UnCheckEntry(eRBShowEyeApertureLight);
}

void
EventBrowserMenu::EnableMC()
{
  fMenuMCOptions->EnableEntry(eShowMC);
  fMenuMCOptions->CheckEntry(eShowMC);
}
