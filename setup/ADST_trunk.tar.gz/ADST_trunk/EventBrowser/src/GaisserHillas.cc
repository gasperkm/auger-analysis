#include "GaisserHillas.h"
#include <FdRecShower.h>
#include <TF1.h>

#include <iostream>
#include <cmath>
using namespace std;

GaisserHillas::GaisserHillas() :
  fResiduals(false),
  fXisAge(false),
  fNSigma(0.),
  fScaleFactor(1.) {
}

GaisserHillas::~GaisserHillas() {

}

void
GaisserHillas::SetShowerParameters(const FdRecShower& shower) {


  fCovMat[eNmax][eNmax] = pow(shower.GetdEdXmaxError(),2);
  fCovMat[eXmax][eXmax] = pow(shower.GetXmaxError(),2);
  fCovMat[eX0][eX0] = pow(shower.GetX0Error(),2);
  fCovMat[eLambda][eLambda] = pow(shower.GetLambdaError(),2);

  fCovMat[eNmax][eXmax] = shower.GetdEdXmaxXMaxCorrelation();
  fCovMat[eNmax][eX0] = shower.GetdEdXmaxX0Correlation();
  fCovMat[eNmax][eLambda] = shower.GetdEdXmaxLambdaCorrelation();
  fCovMat[eXmax][eX0]= shower.GetXMaxX0Correlation();
  fCovMat[eXmax][eLambda]= shower.GetXMaxLambdaCorrelation();
  fCovMat[eX0][eLambda]= shower.GetLambdaX0Correlation();

  for ( int i=0; i<eNParameters; i++ ) {
    for ( int j=0; j<=i; j++ ) {
      if ( i!=j ) {
        fCovMat[j][i] *= sqrt(fCovMat[i][i]*fCovMat[j][j]);
        fCovMat[i][j] = fCovMat[j][i];
      }
    }
  }

  fGHParameters[eNmax] = shower.GetdEdXmax();
  fGHParameters[eXmax] = shower.GetXmax();
  fGHParameters[eLambda] = shower.GetLambda();
  fGHParameters[eX0] = shower.GetX0();

}


double
GaisserHillas::operator() (double* xx, double* )
  const {


  if ( fResiduals && fNSigma == 0. )
    return 0.;

  const double* p = fGHParameters;
  const double x = *xx;
  const double X = fXisAge?2*x*p[eXmax]/(3-x):x;

  if ( X <= p[eX0] )
    return 0.;

  const double tmp = p[eXmax] - p[eX0];
  const double t1 = pow((X - p[eX0]) / tmp, tmp/p[eLambda]);
  const double t2 = exp((p[eXmax] - X) / p[eLambda]);
  const double ghFunc = p[eNmax] * t1 * t2;

  if ( fNSigma == 0. )
    return fScaleFactor * ghFunc;

  // calculate relative derivatives 1/GH*(dGH/dp_i)
  // (see GAP2009_078, Eq.75-78)

  const double logTerm = log((p[eX0]-X)/(p[eX0]-p[eXmax]));
  const double nominator = (p[eX0]-p[eXmax])*logTerm+(X-p[eXmax]);

  vector<double> deriv(eNParameters);
  deriv[eNmax] = 1./p[eNmax];
  deriv[eXmax] = logTerm/p[eLambda];
  deriv[eX0] = nominator/p[eLambda]/(p[eX0]-X);
  deriv[eLambda] = nominator/pow(p[eLambda],2);

  double product[eNParameters];

  for ( int i=0; i<eNParameters; i++ ) {
    double sum = 0.;
    for ( int j=0; j<eNParameters; j++ )
      sum += fCovMat[i][j]*deriv[j];
    product[i] = sum;
  }

  double ghRelVariance = 0.;
  for ( int i=0; i<eNParameters; i++ )
    ghRelVariance += product[i]*deriv[i];
  const double ghSigma = sqrt(ghRelVariance)*ghFunc;

  return fScaleFactor * (ghFunc+fNSigma*ghSigma);

}


