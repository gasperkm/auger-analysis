#ifndef _include_FdPlots_h__
#define _include_FdPlots_h__

#include <vector>
#include <string>

#include <TQObject.h>
#include <TGButton.h>
#include <TGNumberEntry.h>
#include "GaisserHillas.h"
#include "VPlots.h"

class TCanvas;
class TObjArray;
class TGCompositeFrame;
class TPolyLine;
class TH1;
class TF1;
class TObjArray;
class TMarker;

class TGTab;
class TGHButtonGroup;

class RecEvent;
class DetectorGeometry;
class StyleManager;
class FdGeometry;

class FdPlots : public TQObject, public VPlots {

 public:
  enum EPixelColorMode {
    eTime,
    eCharge,
    eLogCharge,
    eADCSum,
    eLogADCSum,
    eCloudColors
  };
  
  enum EProfileMode {
    edEdX,
    edEdXShowerAge,
    eLightAtAperture,
    eElectrons
  };
  
  enum EPCGFMode {
    ePCGFChi0,
    ePCGFT0,
    ePCGFRp
  };
  
private:
  FdPlots();

public:
  FdPlots (TGCompositeFrame* main,
	   const StyleManager* const * styleManager,
	   const DetectorGeometry* const * geom,
	   const RecEvent* const * event,
	   int eyeID,
	   const bool& ismc);
  ~FdPlots();

  void Update();
  void Clear();

  void KeepAnimatedEpsFiles();

  int  GetEyeID() const {return fEyeId;}
  bool GetShowEyeView() const {return fShowEyeView;}
  bool GetShowViewableFOV() const {return fShowViewableFOV;}
  bool GetUseLCEfficiency() const {return fUseLCEfficiency;}

  EPixelColorMode GetPixelColorMode() const {return fPixelColorMode;}
  bool GetStationMode() const {return fShowAllStations;}

  void SetShowEyeView(bool f) {fShowEyeView = f;}
  void SetShowCloudCamData(bool f) {fShowCloudCamData = f;}
  void SetShowViewableFOV(bool f) {fShowViewableFOV = f;}
  void SetShowTelsInDAQ(bool f) {fShowTelsInDAQ = f;}
  void SetUseLCEfficiency(bool f) {fUseLCEfficiency = f;}
  void SetStationMode(bool f) {fShowAllStations = f;}
  void SetPixelMode(bool f) {fShowAllPixels = f;}
  void SetResidualMode(bool f) {fResiduals = f;}
  //void SetTimeColors(bool f);
  void SetPixelColorMode(EPixelColorMode mode);
  void SetProfileMode(const EProfileMode m);
  void SetPCGFMode(const EPCGFMode m);

  void SetShowTelApertureLight(bool flag) {fShowTelApertureLight=flag;}
  void SetShowEyeApertureLight(bool flag) {fShowEyeApertureLight=flag;}


  EButtonState GetEyeViewButtonState(){return fEyeViewButton->GetState();}
  void ToggleEyeViewButton(EButtonState state) {fEyeViewButton->SetState(state);}
  EButtonState GetResidualButtonState(){return fResidualButton->GetState();}
  void ToggleResidualButton(EButtonState state) {fResidualButton->SetState(state);}
  EButtonState GetAllStationsButtonState(){return fStationButton->GetState();}
  void ToggleStationButton(EButtonState state) {fStationButton->SetState(state);}
  EButtonState GetAllPixelsButtonState(){return fPixelButton->GetState();}
  void TogglePixelButton(EButtonState state) {fPixelButton->SetState(state);}

  void SelectPixel(Int_t,Int_t,Int_t,TObject*);
  void EnablePixelTraceTab();
  void EnablePCGFTab();

  void SetRecStationClassVersion(int version)
    {fRecStationClassVersion= version;}

  std::string PrintPostScript();
  void PrintPDF(const std::string& anme);

  void DrawCamera(const int timeBin=-1);
  void AnimateCamera();
  void DrawProfile();
  void DrawPCGF();
  void ComputePixelColorRange(const int startBin=-1, const int stopBin=-1);
  void DrawTimeFit();
  void UpdatePalette();

  void SaveCameraCanvas(const std::string& name) const;

  void SetRebinValue(Long_t value)
  { fRebinField->SetIntNumber(value); }

private:

  void InitObjArrays();
  void ConnectButtons(TGCompositeFrame* main);

  void DrawSDP(double theta, double phi, double omegaMin,
               double omegaMax, double phiMin,
               double phiMax, int color);
  TF1* MakeTimeFitFunction(const std::string& name, const FdGeometry& geo);
  void DrawEventInfo();
  void DrawdEdXProfile();
  void DrawAperturePhotons();

  TPolyLine* GetCameraPixel(UInt_t iPix, UInt_t iTel) const;

  void DrawADCTrace(int CurrRecPixel=-1);
  void DrawSelectedPixelMarker(int CurrRecPixel=-1);

  int CalculatePixelColor (double index) const;
  int GetPixelColor(int index, int timeBin=-1) const;
  int GetCloudColor(int telescopeId, int pixelId) const;
  bool IsPixelADCbinSaturated(const int iPix, const int timeBin) const;

  void DrawGHErrorBand(double xMin, double xMax);


  void UpdateAnimateButton();

  void SuperimposeAerosols(TCanvas* canvas,
			   const std::vector<Double_t>& xReferenceVector);
  void SuperimposeViewableFOV(TCanvas* canvas, const bool useAge);

  void ShowExcuse(TCanvas* where, TObjArray* manager,
                  const char* excuse, const int color=kBlack) const;

  const StyleManager* const * fStyleManager; // for plotting style options
  const RecEvent* const * fEvent;   // this is just the current event reference
  const bool& fIsMC;
  const DetectorGeometry* const * fDetectorGeometry;

  int fEyeId;
  int fRecStationClassVersion;

  TGCompositeFrame* fMain;
  TGTab* fEventInfoTab;

  TCanvas* fCanvasCamera;
  TCanvas* fCanvasTime;
  TCanvas* fCanvasProfile;
  TCanvas* fCanvasInfo;
  TCanvas* fCanvasPixels;
  TCanvas* fCanvasPCGF;

  bool fKeepAnimatedEpsFiles;

  // Buttons
  TGCheckButton* fResidualButton;
  TGCheckButton* fStationButton;
  TGCheckButton* fPixelButton;
  TGCheckButton* fEyeViewButton;
  TGRadioButton* fProfdEdXButton;
  TGRadioButton* fProfdEdXShowerAgeButton;
  TGRadioButton* fProfLightButton;
  TGRadioButton* fProfNeButton;
  TGRadioButton* fPCGFChi0Button;
  TGRadioButton* fPCGFRpButton;
  TGRadioButton* fPCGFT0Button;
  TGRadioButton* fColorButton1;
  TGRadioButton* fColorButton2;
  TGRadioButton* fColorButton3;
  TGRadioButton* fColorButton4;
  TGTextButton*  fAnimateButton;

  // ----- for SDP plots ------
  TObjArray* fSDPObjects;

  // ------ for time fits plots ----
  TObjArray* fTimeFitObjects;

  // ----- for profile plots -----
  TObjArray* fProfileObjects;

  // ----- for event info stuff
  TObjArray* fEventInfoObjects;

  // ----- for PCGF stuff
  TObjArray* fPCGFObjects;

 // ----- trace plot -----
  TObjArray* fTracePlotObjects;

  TMarker* fSelectedPixelMarker;

  bool fShowEyeView;
  bool fShowCloudCamData;
  bool fShowViewableFOV;
  bool fShowTelsInDAQ;
  bool fUseLCEfficiency;
  bool fResiduals;
  bool fShowAllStations;
  bool fShowAllPixels;
  EProfileMode fProfileMode;
  EPCGFMode fPCGFMode;

  int fSignalColorRangeStart;
  int fTimeColorRangeStart;
  int fSignalColorLength;
  int fTimeColorLength;
  EPixelColorMode fPixelColorMode;
  double fPixelColorRangeMin;
  double fPixelColorRangeMax;

  static const double kMaxADC;
  static const double kMinADC;

  bool fShowTelApertureLight;
  bool fShowEyeApertureLight;

  TGNumberEntry* fRebinField;
  GaisserHillas fGaisserHillas;

  ClassDef(FdPlots, 2);
};



#endif
