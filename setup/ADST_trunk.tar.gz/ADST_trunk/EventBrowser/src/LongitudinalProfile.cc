#include "LongitudinalProfile.h"

#include <FDEvent.h>
#include <GenShower.h>

#include <TGraphErrors.h>
#include <TF1.h>

#include <algorithm>
using namespace std;

void LongitudinalProfile::SetProfile(const FDEvent& fdEvent,
                                     const GenShower& genShower,
                                     const EProfXaxis xAxisType,
                                     const EProfYaxis yAxisType,
                                     const EProfResidual residualType,
                                     const TF1* fitFunction) {

  const FdRecShower& shower = fdEvent.GetFdRecShower();
  const FdRecApertureLight& light = fdEvent.GetFdRecApertureLight();
  //..const FdGenApertureLight& genLight = fdEvent.GetGenApertureLight();

  const vector<double>& depth = shower.GetDepth();

  const vector<double>& yVec =
    yAxisType == edEdX ? shower.GetEnergyDeposit() :
    yAxisType == eNe ? shower.GetElectrons() :
    light.GetTotalLightAtAperture();
  const vector<double>& yVecErr =
    yAxisType == edEdX ? shower.GetEnergyDepositError() :
    yAxisType == eNe ? shower.GetElectronsError() :
    light.GetTotalLightAtApertureError();
  const vector<double> xVec =             // no ref (GetShowerAge!)
    xAxisType == eTime ? light.GetTime() :
    xAxisType == eDepth ? shower.GetDepth() :
    shower.GetShowerAge();

  TGraph mcGraph;
  if ( residualType == eMC ) {

    if (yAxisType==eLight) {
      cerr << "FdPlots, LongitudinalProfile: WARNING eMC residual for light does not work right now! " << endl;
    }
    const vector<double>& yGenVec =
      yAxisType == edEdX ? genShower.GetEnergyDeposit() :
      genShower.GetElectrons();
    const vector<double> xGenVec =             // no ref (GetShowerAge!)
      xAxisType == eTime ? light.GetTime() : 
      xAxisType == eDepth ? genShower.GetDepth() :
      genShower.GetShowerAge();
    /*
    const vector<double>& yGenVec =
      yAxisType == edEdX ? genShower.GetEnergyDeposit() :
      yAxisType == eNe ? genShower.GetElectrons() :
      genLight.GetTotalLightAtAperture();
    const vector<double> xGenVec =             // no ref (GetShowerAge!)
      xAxisType == eTime ? genLight.GetTime() :
      xAxisType == eDepth ? genShower.GetDepth() :
      genShower.GetShowerAge();
    */

    mcGraph = TGraph(xGenVec.size(),
                     &xGenVec.front(),
                     &yGenVec.front());
  }

  if ( yVec.size() != depth.size() || xVec.size() != depth.size() ) {
    cerr << " LongitudinalProfile::SetProfile() - ERROR: "
         << " incompatible vector sizes " << endl;
    return;
  }

  for ( unsigned int i=0; i<depth.size(); i++ ) {

    const double x =xVec[i];
    const double y =
      residualType == eNone ? yVec[i] :
      residualType == eFit ? yVec[i] - fitFunction->Eval(x) :
      yVec[i] - mcGraph.Eval(x);
    fProfile.push_back(ProfilePoint(x, y, yVecErr[i], depth[i]));

  }

  sort(fProfile.begin(), fProfile.end());

}


TGraphErrors*
LongitudinalProfile::GetGraph(const double deltaDepth) const {

  if ( fProfile.empty() )
    return NULL;

  TGraphErrors* profileGraph = new TGraphErrors();

  double nextDepthBin = fProfile.front().fDepth + deltaDepth;

  double yWeightSum = 0.;
  double weightSum = 0.;
  double xSum = 0.;
  unsigned int n = 0;

  unsigned int nProfilePoints = 0;
  for ( unsigned int i=0; i<fProfile.size(); i++ ) {
    const double thisDepth = fProfile[i].fDepth;
    if ( thisDepth >= nextDepthBin && n>0 ) {
      const double y = yWeightSum/weightSum;
      const double yErr = sqrt(1/weightSum);
      const double x = xSum/n;
      profileGraph->SetPoint(nProfilePoints, x, y);
      profileGraph->SetPointError(nProfilePoints, 0, yErr);
      yWeightSum = 0.;
      weightSum = 0.;
      xSum = 0.;
      n = 0;
      nProfilePoints++;
      nextDepthBin = thisDepth + deltaDepth;
    }
    const double w = 1./pow(fProfile[i].fYErr,2);
    yWeightSum += fProfile[i].fY*w;
    weightSum += w;
    xSum += fProfile[i].fX;
    n++;
  }

  if ( n!= 0 ) {
    const double y = yWeightSum/weightSum;
    const double yErr = sqrt(1/weightSum);
    const double x = xSum/n;
    profileGraph->SetPoint(nProfilePoints, x, y);
    profileGraph->SetPointError(nProfilePoints, 0, yErr);
  }

  return profileGraph;

}

