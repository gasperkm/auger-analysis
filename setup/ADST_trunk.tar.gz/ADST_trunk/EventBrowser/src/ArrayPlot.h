#ifndef _include_ArrayPlot_h__
#define _include_ArrayPlot_h__

#include <TQObject.h>

class TH2Poly;
class TGHSlider;
class TBox;
class DetectorGeometry;
class RecEvent;
class StyleManager;
class TCanvas;
class TObjArray;
class TBits;

class ArrayPlot : public TQObject {
private:
  ArrayPlot();
public:
  ArrayPlot (const RecEvent* const * event,
             const DetectorGeometry* const * detectorGeometry,
             const StyleManager* const * styleManager,
             const TGHSlider* fArrayZoomButton,
             TCanvas* canvas);

  ArrayPlot (const RecEvent* const * event,
             const DetectorGeometry* const * detectorGeometry,
             const StyleManager* const * styleManager,
             int xmin, int xmax, int ymin, int ymax,
             TCanvas* canvas);

  ~ArrayPlot();

  void Draw(const bool drawSD = true,
            const bool drawFD = true,
            const bool drawMC = true);
  void DrawShowerPlaneArray(bool drawSD = true,
                            bool drawFD = true,
                            bool drawMC = false);

  void Clear();
  void DoSdZoom(Int_t iZoom);
  void GetMaxAndMinTime();
  int  GetColor(Long64_t x, double y, double z);
  void SetSDColorStatus(int iCol)
  { fSdColorStatus=iCol;}
  void SetZoomCenter(double x, double y);
  void SetRecStationClassVersion(int version)
      {fRecStationClassVersion= version;}
  void DrawSelectedStationMarker(int stationNumber);
  // To avoid changing the prototype of the Draw()
  // function we will use this flag as a selector
  inline void SetRadioOn() {fUseRadio=true;};
  inline void SetRadioOff(){fUseRadio=false;};
  void DrawSelectedRStationMarker(int stationNumber);
private:

  void DrawSDOnArray(float x1, float x2, float y1, float y2);
  void DrawFDOnArray();
  void DrawMCOnArray();
  void DrawLDFOnArray();
  void DrawMuonMapOnArray();
  void DrawRadioInShowerPlaneArray(bool HasAlreadyDrawnSD);
  void DrawRdOnArray();
  /// superimpose array given station-bits on existing histogram
  void DrawArray(const TBits& stationArray, const int color, const int edgeColor, const double size) const;
  void DrawEyes(const TBits* eyeArray, double, double, double, double) const;
  const RecEvent* const * fEvent;
  const DetectorGeometry* const * fDetectorGeometry;
  const StyleManager* const * fStyleManager;
  const TGHSlider* fArrayZoomButton;
  void FillClouds(TH2Poly& hist, const double meterToPlot) const;
  void SetCoreAltitude();

  TCanvas* fCanvasArray;
  TBox* fZoomBox;
  TObjArray* fArrayObjects;

  int fSdColorStatus;
  double fZoomDX;
  Long64_t fMaxTime;
  Long64_t fMinTime;
  double fMaxTimeRes;
  double fMinTimeRes;
  int fRecStationClassVersion;
  bool fHasZoomCenter;
  double fZoomCenterX;
  double fZoomCenterY;
  double fCoreAltitude;
  bool fUseRadio;

  bool fInteractiveMode;
  int fxmin, fxmax, fymin, fymax;
  ClassDef (ArrayPlot, 4);
};
#endif
