#ifndef __RDSelection_H
#define __RDSelection_H

#include <Selection.h>

#include <string>
#include <vector>
#include <set>

class RDSelection : public Selection {
public:
  RDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::string& cutFile = "rdCuts.txt");

  RDSelection(const DetectorGeometry* const* geom,
              const RecEvent* const* event,
              int verbosity = 1,
              bool nMinusOne = true,
              const std::vector<std::string>& cutFiles = std::vector<std::string>(1, "rdCuts.txt") );
  const std::set<unsigned long int>& GetIds() const {return fRdIds;}

private:
  const static CutSpec fgRDCutSpecs[];
  static bool fgCutSpecsInitialized;

  double GetNEvents() const { return GetNAugerEvents(); }

  static bool minRecLevelCut(Cut&);
  static bool minZenithCut(Cut&);
  static bool maxZenithCut(Cut&);
  static bool minAzimuthCut(Cut&);
  static bool maxAzimuthCut(Cut&);
  static bool minGeomagneticAngleCut(Cut&);
  static bool maxGeomagneticAngleCut(Cut&);
  static bool minStationsCut(Cut& cut);
  static bool maxStationsCut(Cut& cut);
  static bool maxAngleSDRD(Cut& cut);

  static std::set<unsigned long int> fRdIds;
  static std::vector<unsigned int> fGPSStart;
  static std::vector<unsigned int> fGPSStop;
  static bool fInitiatedIdsFromFile;
};

#endif
