#ifndef __Analysis_H
#define __Analysis_H

#include <T2TriggerProb.h>

#include <iostream>
#include <string>
#include <vector>
#include <map>


class FDSelection;
class SDSelection;
class RDSelection;
class SimSelection;
class AugerUpTime;
class RecEvent;
class DetectorGeometry;
class TBits;
class TRandom;


class Analysis {

public:
  Analysis(const DetectorGeometry* const* geom,
           const RecEvent* const* event,
           const std::string& configFile = "analysis.config",
           bool withNMinusOne = true, const std::string& analysisName = "",
           int verbosity = 1);
  ~Analysis();

  const std::string& GetName() const { return fAnalysisName; }

  // selection related stuff
  bool HasFDSelection();
  bool HasSDSelection();
  bool HasRDSelection();
  bool HasSimSelection();
  const FDSelection& GetFDSelection();
  const SDSelection& GetSDSelection();
  const RDSelection& GetRDSelection();
  const SimSelection& GetSimSelection();
  const RecEvent* const* GetRecEvent() { return fEvent; }
  bool IsGoodEye(unsigned int iEye, double weight = 1);
  bool IsGoodSD(double weight = 1);
  bool IsGoodRD(double weight = 1);
  bool IsGoodSim(double weight = 1);
  int GetFDCutWhichKilledEvent() const;
  int GetSDCutWhichKilledEvent() const;
  int GetRDCutWhichKilledEvent() const;
  int GetSimCutWhichKilledEvent() const;

  typedef std::map<std::string, std::string> Configuration;
  const Configuration& GetUserConfiguration() { return fUserConfiguration; }

  // write n-1 histograms to output root file
  void WriteNMinusOne();
  // write cut statistics as histograms to output root file
  void WriteCutStatistics() const;
  // print cut statistics as text to stdout
  void PrintCutStatistics(bool latex = false) const;

  void InitSDCuts();
  void InitSimCuts();
  void InitFDCuts();
  void InitRDCuts();

  const DetectorGeometry* const* GetDetectorGeometry() const
  { return fDetectorGeometry; }

  // upTime related stuff
  AugerUpTime* GetAugerUpTime();
  const TBits* GetCurrentArrayStatus();
  double GetFDUpFraction(int GPSTime, int iTel);

  // brass hybrid probability related stuff
  T2TriggerProb& GetT2TriggerProb();

  // FD specific
  int GetXmaxPixel(unsigned int iEye); // (iTel-1)*440+(iPix-1) AND iPix=(col-1)*22 + (row-1)

  // SD specific

  static std::string ADSTAnalysisVersion() { return std::string("checkout from SVN"); }
  static unsigned int ADSTAnalysisRevision();

  void Dump(std::ostream& output);

private:
  void InitUpTime();
  Analysis();
  static void StripComments(std::string& line);
  static std::string MakeAbsolutePath(const std::string& file, const std::string& path);

  FDSelection* fFDSelection;
  RDSelection* fRDSelection;
  SDSelection* fSDSelection;
  SimSelection* fSimSelection;
  AugerUpTime* fAugerUpTime;

  std::vector<std::string> fFDCutFileNames;
  std::vector<std::string> fRDCutFileNames;
  std::vector<std::string> fSDCutFileNames;
  std::vector<std::string> fSimCutFileNames;
  std::string fFDLifeFileName;
  std::string fRDLifeFileName;
  std::string fSDLifeFileName;
  std::string fAnalysisName;

  const DetectorGeometry* const* fDetectorGeometry;
  const RecEvent* const* fEvent;
  T2TriggerProb fT2TriggerProb;
  bool fWithNMinusOne;

  Configuration fUserConfiguration;

  int fVerbosity;
};


#endif
