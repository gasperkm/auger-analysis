#include <RDSelection.h>
#include <EventInfo.h>

#include <FdRecLevel.h>
#include <RecEvent.h>
#include <DetectorGeometry.h>

#include <vector>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cstdlib>

using namespace std;

// Associate all cut names with their functions
const CutSpec RDSelection::fgRDCutSpecs[] = {
  // ATTENTION: keep this in sync with allRD.cuts

  CutSpec("minRecLevel",         minRecLevelCut),
  CutSpec("minZenithRD",         minZenithCut, 1),
  CutSpec("maxZenithRD",         maxZenithCut, 1),
  CutSpec("minAzimuthRD",        minAzimuthCut, 1),
  CutSpec("maxAzimuthRD",        maxAzimuthCut, 1),
  CutSpec("minGeomagAngle",      minGeomagneticAngleCut, 1),
  CutSpec("maxGeomagAngle",      maxGeomagneticAngleCut, 1),
  CutSpec("minStationsRD",       minStationsCut, 1),
  CutSpec("maxStationsRD",       maxStationsCut, 1),
  CutSpec("maxAngleSDRD",        maxAngleSDRD, 1),
  // this must be always the last cutspec. Think \0
  CutSpec("END"),
};

bool RDSelection::fgCutSpecsInitialized = false;
set<unsigned long int> RDSelection::fRdIds;
bool RDSelection::fInitiatedIdsFromFile = false;
vector<unsigned int> RDSelection::fGPSStart;
vector<unsigned int> RDSelection::fGPSStop;

RDSelection::RDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity,
                         bool nMinusOne,
                         const string& cutFile) :
  Selection(geom, event, verbosity, nMinusOne, cutFile)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgRDCutSpecs);
    fgCutSpecsInitialized = true;
  }
  SetSelectionName(string("RD"));
  ReadCuts(cutFile);
  InitializeCutFunctions();
}

RDSelection::RDSelection(const DetectorGeometry* const* geom,
                         const RecEvent* const* event,
                         int verbosity, 
                         bool nMinusOne,
                         const vector<string>& cutFiles) :
  Selection(geom, event, verbosity, nMinusOne, cutFiles)
{
  if (!fgCutSpecsInitialized) {
    AddToCutRegistry(fgRDCutSpecs);
    fgCutSpecsInitialized = true;
  }
  SetSelectionName(string("RD"));
  ReadCuts(cutFiles);
  InitializeCutFunctions();
}

bool RDSelection::minRecLevelCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double recLevel = theShower.GetParameter(revt::eRecStage);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(recLevel);
  return cut.GetNormalOrAnti(recLevel >= cutVal);
}

bool RDSelection::minZenithCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double zenith = theShower.GetZenith() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(zenith);
  return cut.GetNormalOrAnti(zenith >= cutVal);
}

bool RDSelection::maxZenithCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double zenith = theShower.GetZenith() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(zenith);
  return cut.GetNormalOrAnti(zenith <= cutVal);
}

bool RDSelection::minAzimuthCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double azimuth = theShower.GetAzimuth() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(azimuth);
  return cut.GetNormalOrAnti(azimuth >= cutVal);
}

bool RDSelection::maxAzimuthCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double azimuth = theShower.GetAzimuth() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(azimuth);
  return cut.GetNormalOrAnti(azimuth <= cutVal);
}

bool RDSelection::minGeomagneticAngleCut(Cut& cut){
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double alpha = theShower.GetGeomagneticAngle() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(alpha);
  return cut.GetNormalOrAnti(alpha >= cutVal);
}

bool RDSelection::maxGeomagneticAngleCut(Cut& cut){
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const double alpha = theShower.GetGeomagneticAngle() * TMath::RadToDeg();

  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(alpha);
  return cut.GetNormalOrAnti(alpha <= cutVal);
}

bool RDSelection::minStationsCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const int nCand = theShower.GetParameter(revt::eNumberOfStationsWithPulseFound);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(nCand);
  return cut.GetNormalOrAnti(nCand >= cutVal);
}

bool RDSelection::maxStationsCut(Cut& cut) {
  const RdRecShower& theShower = CurrEvent().GetRdEvent().GetRdRecShower();
  const int nCand = theShower.GetParameter(revt::eNumberOfStationsWithPulseFound);

  const double cutVal = cut.GetCutValue();
  cut.SetCurrValue(nCand);
  return cut.GetNormalOrAnti(nCand <= cutVal);
}

bool RDSelection::maxAngleSDRD(Cut& cut) {
  const RdRecShower& theShowerRd = CurrEvent().GetRdEvent().GetRdRecShower();
  const double RdZenith = theShowerRd.GetZenith();
  const double RdAzimuth = theShowerRd.GetAzimuth();

  const SDEvent& currSDEvent = CurrEvent().GetSDEvent();
  if (!currSDEvent.HasAxis())
    return false;
  const SdRecShower& theShowerSd = currSDEvent.GetSdRecShower();
  const double SdZenith = theShowerSd.GetZenith();
  const double SdAzimuth = theShowerSd.GetAzimuth();

  // spherical coordinates for RD and SD
  const double xr = sin(RdZenith)*cos(RdAzimuth);
  const double yr = sin(RdZenith)*sin(RdAzimuth);
  const double zr = cos(RdZenith);
  const double xs = sin(SdZenith)*cos(SdAzimuth);
  const double ys = sin(SdZenith)*sin(SdAzimuth);
  const double zs = cos(SdZenith);

  // opening angle between RD and SD
  const double phi = acos((xr*xs+yr*ys+zr*zs) /
        (sqrt(xr*xr+yr*yr+zr*zr)*sqrt(xs*xs+ys*ys+zs*zs)))*TMath::RadToDeg();
  const double cutVal  = cut.GetCutValue();
  cut.SetCurrValue(phi);
  return cut.GetNormalOrAnti(phi <= cutVal);
}
