
#include <Timing.h>

#include <TTimeStamp.h>

#include <iostream>
#include <fstream>
using namespace std;

/**********************************************************************************/
Timing::~Timing()
{
}

/**********************************************************************************/
Timing::Timing() :
  fTimeBinSeconds(600),
  fFirstGPS(756950413), //January 1st 2004
  fLastGPS(883180812) //December 31rd 2007 23:59:59
{
  fNTimeBins = (fLastGPS-fFirstGPS)/fTimeBinSeconds;
  fLastGPS = fFirstGPS + fNTimeBins*fTimeBinSeconds;
}

/**********************************************************************************/
Timing::Timing(unsigned int binSize, unsigned int start, unsigned int stop) :
  fTimeBinSeconds(binSize),
  fFirstGPS(start),
  fLastGPS(stop)
{
  if (fTimeBinSeconds != 0)
    fNTimeBins = (fLastGPS - fFirstGPS) / fTimeBinSeconds;
  else {
    fNTimeBins = 0;
    cerr << "Timing::Timing: trying to set time-binsize to " << fTimeBinSeconds << endl;
  }
  fLastGPS=fFirstGPS+ fNTimeBins*fTimeBinSeconds;
}

/**********************************************************************************/
void Timing::SetTimeBins(unsigned int secs,
                         unsigned int firstGPS,
                         unsigned int lastGPS)
{
  fTimeBinSeconds = secs;
  fFirstGPS = firstGPS;
  fLastGPS = lastGPS;
  if (secs != 0)
    fNTimeBins = (lastGPS-firstGPS)/secs;
  else {
    fNTimeBins = 0;
    cerr << "Timing::SetTimeBins: trying to set time-binsize to " << secs << endl;
  }
  fLastGPS = fFirstGPS + fNTimeBins*fTimeBinSeconds;
}

/**********************************************************************************/
bool Timing::HasTimeBin(unsigned int iGPS) const
{
  if(iGPS >= fFirstGPS && iGPS < fLastGPS)
    return true;
  else
    return false;
}

/**********************************************************************************/
unsigned int Timing::GetTimeBin(unsigned int iGPS) const {
  unsigned int bin = 0;
  unsigned int DeltaT = 0;

  if(iGPS >= fFirstGPS && iGPS <= fLastGPS && fTimeBinSeconds > 0) {
    DeltaT = iGPS - fFirstGPS;
    bin = DeltaT / fTimeBinSeconds;
  }
  return bin;
}

/**********************************************************************************/
unsigned int Timing::GetBinStart(unsigned int bin) const {
  unsigned int gps = fFirstGPS+bin*fTimeBinSeconds;

  if (gps >= fFirstGPS && gps < fLastGPS)
    return gps;
  else
    return 0;
}

/**********************************************************************************/
unsigned int Timing::GetBinStop(unsigned int bin) const {
  unsigned int gps = fFirstGPS + (bin+1)*fTimeBinSeconds;

  if (gps >= fFirstGPS && gps <= fLastGPS) // <= lastGPS in order to get end of last bin correct
    return gps;
  else
    return 0;
}

/**********************************************************************************/
unsigned int Timing::GetGPSFromDate(unsigned int date, unsigned int time) const {
  unsigned int gps = 0;
  unsigned int sec = time%100;
  time /= 100;
  unsigned int min = time%100;
  time /= 100;
  unsigned int hour = time;

  unsigned int day = date%100;
  date /= 100;
  unsigned int month = date%100;
  date /= 100;
  unsigned int year = date;

  TTimeStamp stamp(year, month, day, hour, min, sec, 0, kTRUE, -315964787);
  gps = stamp.GetSec();

  if (gps < fFirstGPS || gps >= fLastGPS)
    gps = 0;

  return gps;
}

