#ifndef _adst_AnalysisLinkDef_h_
#define _adst_AnalysisLinkDef_h_

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ namespace UtilityFunctions;
#pragma link C++ function UtilityFunctions::SigmaFromProb(double);


#endif
#endif
