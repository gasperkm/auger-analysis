#include <RecEventFile.h>
#include <RecEvent.h>
#include <SDEvent.h>
#include <SdRecShower.h>
#include <RecStation.h>
#include <AnalysisConsts.h>

#include <TApplication.h>
#include <TCanvas.h>
#include <TH1I.h>
#include <TFile.h>
#include <TGraphErrors.h>
#include <ShowerSRecDataQuantities.h>
#include <ShowerRRecDataQuantities.h>
#include <TTree.h>

#include <fstream>
#include <string>
#include <algorithm>

using namespace std;
using namespace sevt;

void usage() {
  cerr << "\n usage: ./ParameterStoragetoROOTTrees.cc ADSTfilelist.txt outputROOTfilename.root\n\n" 
       << endl;
}

int main(int argc, const char * argv[]){
  if(argc!=3){
    usage();
    return 0;
  }  
  vector<string> inputFiles;
  const char *inputfilename=argv[1];
  const char *outputfilename=argv[2];
  TFile outfile(outputfilename, "recreate");
  TTree *OutputTree = new TTree("inputtree","inputtree");

  double inputeRiseTime1000;
  double inputeRiseTime1000Error;
  double inputeRiseTime1000Chi2;
  double inputeRiseTime1000NDF;
  double inputeRiseTime1000NSt;
  double inputeRiseTime1000NStClose;
  bool inputeRiseTime1000Flag;
  bool inputeRiseTime1000FlagAlt;
  double inputeLeedsDelta;
  double inputeDeltaRiseTimeFlag;
  double inputeDeltaRiseTimeFlagAlt;
  double inputeLDF_RNKG;
  double inputeLDF_S4;
  double inputeLDFFlag;
  double inputeEgammaRec;
  double inputeEgammaIter;
  double inputeEgammaXmax;
  double inputeEgammaFlag;
  double inputeLDF_NSt;
  double inputeThetaDeg;
  double inputeHadrEnergy;
  double inputeEventId;
  double inputeMCEnergy;
  double inputeX1;
  bool eventtocut;
  vector<int> cutsdids;
  long int a,b,c;
  ifstream in("./EventsToCut_6T5_070609_151109.txt",ios::in); //read in file containing FakeT5 events
  while (in>>a>>b>>c) {cutsdids.push_back(b);}


  OutputTree->Branch("eRiseTime1000", &inputeRiseTime1000, "size/D");
  OutputTree->Branch("eRiseTime1000Error", &inputeRiseTime1000Error, "size/D");
  OutputTree->Branch("eRiseTime1000Chi2", &inputeRiseTime1000Chi2, "size/D");
  OutputTree->Branch("eRiseTime1000NDF", &inputeRiseTime1000NDF, "size/D");
  OutputTree->Branch("eRiseTime1000NSt", &inputeRiseTime1000NSt, "size/D");
  OutputTree->Branch("eRiseTime1000NStClose", &inputeRiseTime1000NStClose, "size/D");
  OutputTree->Branch("eRiseTime1000Flag", &inputeRiseTime1000Flag, "size/O");
  OutputTree->Branch("eRiseTime1000FlagAlt", &inputeRiseTime1000FlagAlt, "size/O");
  OutputTree->Branch("eLeedsDelta", &inputeLeedsDelta, "size/D");
  OutputTree->Branch("eDeltaRiseTimeFlag", &inputeDeltaRiseTimeFlag, "size/D");
  OutputTree->Branch("eDeltaRiseTimeFlagAlt", &inputeDeltaRiseTimeFlagAlt, "size/D");
  OutputTree->Branch("eLDF_RNKG", &inputeLDF_RNKG, "size/D");
  OutputTree->Branch("eLDF_S4", &inputeLDF_S4, "size/D");
  OutputTree->Branch("eLDFFlag", &inputeLDFFlag, "size/D");
  OutputTree->Branch("eEgammaRec", &inputeEgammaRec, "size/D");
  OutputTree->Branch("eEgammaIter", &inputeEgammaIter, "size/D");
  OutputTree->Branch("eEgammaXmax", &inputeEgammaXmax, "size/D");
  OutputTree->Branch("eEgammaFlag", &inputeEgammaFlag, "size/D");
  OutputTree->Branch("eLDF_NSt", &inputeLDF_NSt, "size/D");
  OutputTree->Branch("eThetaDeg", &inputeThetaDeg, "size/D");
  OutputTree->Branch("eHadrEnergy", &inputeHadrEnergy, "size/D");
  OutputTree->Branch("eEventId", &inputeEventId, "size/D");
  OutputTree->Branch("eMCEnergy", &inputeMCEnergy, "size/D");
  OutputTree->Branch("eX1", &inputeX1, "size/D");
  OutputTree->Branch("eventtocut_badperiod", &eventtocut, "eventtocut/B");
  
  ifstream steer(inputfilename);
  string line, adstname;
  while ( !steer.eof( ) ){  //loop over all ADST files listed in input textfile
    getline(steer, line, '\n');
    if (line.length()==0) continue;
    adstname=line.substr(0,5+line.find(".root"));
    cout<<adstname<<endl;
    RecEventFile recEventFile(adstname);
    RecEvent* recEvent = 0;  // will be assigned by root
    recEventFile.SetBuffers(&recEvent);
    const unsigned int nEvents = recEventFile.GetNEvents();
    cout<<"nevents="<<nEvents<<endl;
    for (unsigned int i = 0; i < nEvents; ++i) {
      if (recEventFile.ReadEvent(i) != RecEventFile::eSuccess)
        continue;
      const SDEvent& sdEvent = recEvent->GetSDEvent();
      if (!sdEvent.Is6T5())
        continue;
      const SdRecShower& sdRecShower = sdEvent.GetSdRecShower();
      const double energy = sdRecShower.GetEnergy();
      const double theta = sdRecShower.GetZenith();
      const double thetadeg = sdRecShower.GetZenith()*180./TMath::Pi();
      const int sdreclevel = sdEvent.GetRecLevel();
      const double MCenergy = recEvent->GetGenShower().GetEnergy();
      const double MCX1 = recEvent->GetGenShower().GetX1();
      const double beta = sdRecShower.GetBeta();
      const double gamma = sdRecShower.GetGamma();
      //////////////CUTS//////////////////
      /*
      if(sdreclevel<3)
        cout<<sdEvent.GetEventId()<<" out bc of revlvl"<<endl;
      if(sdreclevel<3)
        continue;

      if(energy<TMath::Power(10,18))
        cout<<sdEvent.GetEventId()<<" out bc of en"<<endl;
      else if(thetadeg<30. || thetadeg > 60.)
        cout<<sdEvent.GetEventId()<<" out bc of zen"<<endl;
      else if(sdreclevel<3)
        cout<<sdEvent.GetEventId()<<" out bc of revlvl"<<endl;
      else if(!sdRecShower.HasParameter(eDeltaRiseTimeFlagAlt))
        cout<<sdEvent.GetEventId()<<" out bc of hasdeltaflagalt"<<endl;
      else if(!sdRecShower.GetParameter(eDeltaRiseTimeFlagAlt))
        cout<<sdEvent.GetEventId()<<" out bc of deltaflagalt"<<endl;
      */
      if(sdreclevel<3)
        continue;
      /*
      if(energy<TMath::Power(10,18))
         continue;
      if(thetadeg<30. || thetadeg > 60.)
        continue;
      if(!sdRecShower.HasParameter(eLDFFlag))
        continue;
      else if(sdRecShower.GetParameter(eLDFFlag) == 0)
        continue;
      */
      ///////////////////////////////////
      /*
      cout<<endl<<"ID= "<<sdEvent.GetEventId()<<endl;
      cout<<"E= "<<energy<<endl;
      cout<<"Theta= "<<theta<<endl;
      cout<<"RL= "<<sdEvent.GetRecLevel()<<endl;
      cout<<"X1= "<<recEvent->GetGenShower().GetX1()<<endl;
cout<<"beta= "<<beta<<endl;
cout<<"gamma= "<<gamma<<endl;
      */
      inputeHadrEnergy = energy;
      inputeThetaDeg = thetadeg;
      inputeMCEnergy = MCenergy;
      inputeX1 = MCX1;
      inputeEventId = sdEvent.GetEventId();

      if(sdRecShower.HasParameter(eRiseTime1000)){
        inputeRiseTime1000 = sdRecShower.GetParameter(eRiseTime1000);
      }
      if(sdRecShower.HasParameterCovariance(eRiseTime1000, eRiseTime1000)){
        inputeRiseTime1000Error = sdRecShower.GetParameterError(eRiseTime1000);
      }
      if(sdRecShower.HasParameter(eRiseTime1000Chi2)){
        inputeRiseTime1000Chi2 = sdRecShower.GetParameter(eRiseTime1000Chi2);
      }
      if(sdRecShower.HasParameter(eRiseTime1000NDF)){
        inputeRiseTime1000NDF = sdRecShower.GetParameter(eRiseTime1000NDF);
      }
      if(sdRecShower.HasParameter(eRiseTime1000NSt)){
        inputeRiseTime1000NSt = sdRecShower.GetParameter(eRiseTime1000NSt);
      }
      if(sdRecShower.HasParameter(eRiseTime1000NStClose)){
        inputeRiseTime1000NStClose = sdRecShower.GetParameter(eRiseTime1000NStClose);
      }
      if(sdRecShower.HasParameter(eRiseTime1000Flag)){
        inputeRiseTime1000Flag = sdRecShower.GetParameter(eRiseTime1000Flag);
      }
      if(sdRecShower.HasParameter(eRiseTime1000FlagAlt)){
        inputeRiseTime1000FlagAlt = sdRecShower.GetParameter(eRiseTime1000FlagAlt);
      }
      if(sdRecShower.HasParameter(eLeedsDelta)){
        inputeLeedsDelta = sdRecShower.GetParameter(eLeedsDelta);
      }
      if(sdRecShower.HasParameter(eDeltaRiseTimeFlag)){
        inputeDeltaRiseTimeFlag = sdRecShower.GetParameter(eDeltaRiseTimeFlag);
      }
      if(sdRecShower.HasParameter(eDeltaRiseTimeFlagAlt)){
        inputeDeltaRiseTimeFlagAlt = sdRecShower.GetParameter(eDeltaRiseTimeFlagAlt);
      }
      if(sdRecShower.HasParameter(eLDF_RNKG)){
        inputeLDF_RNKG = sdRecShower.GetParameter(eLDF_RNKG);
      }
      if(sdRecShower.HasParameter(eLDF_S4)){
        inputeLDF_S4 = sdRecShower.GetParameter(eLDF_S4);
      }
      if(sdRecShower.HasParameter(eLDFFlag)){
        inputeLDFFlag = sdRecShower.GetParameter(eLDFFlag);
      }
      if(sdRecShower.HasParameter(eEgammaRec)){
        inputeEgammaRec = sdRecShower.GetParameter(eEgammaRec);
      }
      if(sdRecShower.HasParameter(eEgammaIter)){
        inputeEgammaIter = sdRecShower.GetParameter(eEgammaIter);
      }
      if(sdRecShower.HasParameter(eEgammaXmax)){
        inputeEgammaXmax = sdRecShower.GetParameter(eEgammaXmax);
      }
      if(sdRecShower.HasParameter(eEgammaFlag)){
        inputeEgammaFlag = sdRecShower.GetParameter(eEgammaFlag);
      }
      if(sdRecShower.HasParameter(eLDF_NSt)){
        inputeLDF_NSt = sdRecShower.GetParameter(eLDF_NSt);
      }
      if(std::find(cutsdids.begin(), cutsdids.end(), inputeEventId) != cutsdids.end())eventtocut=true;else eventtocut=false;


      OutputTree->Fill();
    }
    recEventFile.Close();
    recEvent = 0;  // will be assigned by root

  }  
  OutputTree->Write("", TObject::kOverwrite);
  
}  
