const int fgLineColorNormal = 4; 
const int fgLineWidthNormal = 2; 
const int fgLineColorWarning = 2; 
const int fgLineWidthWarning = 2; 

void compareEvents(const char* option = "undefined", 
		   const char* fileName = "compareEvents.root") {
  
  setStyle();
  
  TFile* theFile = new TFile(fileName);
  if ( theFile == 0 || theFile->IsZombie() ) {
    usage(); 
    return;
  }

  if ( option == "SD" ) 
    drawSD("compareSD.ps", false);
  else if ( option == "FD" )
    drawFD("compareFD.ps", false);
  else if ( option == "FDvsT" )
    drawFDvsT("compareFDvsT.ps", false);
  else if ( option == "all" ) {
    TCanvas cSum;
    gStyle->SetTitlePS("Summary");
    cSum.Print("summary.ps[", "Landscape");
    drawSD("summary.ps", true);
    drawFD("summary.ps", true);
    drawFDvsT("summary.ps", true);
    cSum.Print("summary.ps]", "Landscape");
  } else {
    usage();
  }
}

void usage() {
  cerr << "\n usage: compareEvents(\"option\",\"filename\")\n\n" 
       << "\t- available options: FD/FDvsT/SD/all \n"
       << "\t- default filename: compareEvents.root \n"
       << endl;
}

void drawFDvsT(const char* postscriptName, bool savePNGs) {
  
  TCanvas *c0 = new TCanvas("cfdvst", "FD versus time", 800, 672);
  TLatex *title = new TLatex(.05, .961, "Hybrid reconstruction versus time");
  title->SetTextSize(0.055);
  title->SetTextFont(42);
  title->Draw();
  c0->cd();
  TPad* c1 = new TPad("padfd", "padfd", 0., 0., 1., 0.91);
  c1->Draw();  
  c1->Divide(3,2);  
  
  c1->cd(1);
  dEFD->GetXaxis()->SetRangeUser(-0.5, 0.5);
  dEFD->GetXaxis()->SetTitle("#DeltaE/<E>");
  dEFD->GetYaxis()->SetTitle("entries");
  dEFD->Draw();
  gPad->RedrawAxis();
  //if (savePNGs) SavePNG(gPad, "fdvst_dEFD.png");
  
  c1->cd(2);
  dXmax->GetXaxis()->SetRangeUser(-50., 50.);
  dXmax->GetXaxis()->SetTitle("#DeltaX_{max} [g/cm^{2}]");
  dXmax->GetYaxis()->SetTitle("entries");
  dXmax->Draw();
  gPad->RedrawAxis();
  //if (savePNGs) SavePNG(gPad, "fdvst_dXmax.png");

  c1->cd(3);
  //  dEFDvsT->GetXaxis()->SetRangeUser(17.5,20.5);
  CheckProfile(dEFDvsT, 0.05);
  dEFDvsT->GetYaxis()->SetTitle("#DeltaE/<E>");
  dEFDvsT->GetXaxis()->SetTitle("time [moon cycles]");
  dEFDvsT->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fdvst_dEFDvsT.png");

  c1->cd(4);
  //  dXmaxvsT->GetXaxis()->SetRangeUser(17.5,20.5);
  CheckProfile(dXmaxvsT, 2.);
  dXmaxvsT->GetYaxis()->SetTitle("#DeltaX_{max} [g/cm^{2}]");
  dXmaxvsT->GetXaxis()->SetTitle("time [moon cycles]");
  dXmaxvsT->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fdvst_dXmaxvsT.png");
  
  c1->cd(5);
  //  dGHChi2->GetXaxis()->SetRangeUser(0.25,1.);
  CheckHist(dGHChi2, 0.5, 2);
  dGHChi2->GetYaxis()->SetTitle("entries");
  dGHChi2->GetXaxis()->SetTitle("#Delta #chi^{2} (GH)");
  dGHChi2->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fdvst_dGHChi2.png");
  
  c1->cd(6);
  // dGHChi2vsT->GetXaxis()->SetRangeUser(0.25,1.);
  CheckProfile(dGHChi2vsT, 0.01);
  dGHChi2vsT->GetYaxis()->SetTitle("#Delta #chi^{2} (GH)");
  dGHChi2vsT->GetXaxis()->SetTitle("time [moon cycles]");
  dGHChi2vsT->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fdvst_dGHChi2vsT.png");

  c0->Print(postscriptName, "Landscape");
}


void drawSD(const char* postscriptName, bool savePNGs) {
  
  TCanvas *c0 = new TCanvas("csd", "SD", 800, 672);
  TLatex *title = new TLatex(.05, .961, "SD reconstruction");
  title->SetTextSize(0.055);
  title->SetTextFont(42);
  title->Draw();
  c0->cd();
  TPad* c1 = new TPad("padsd", "padsd", 0., 0., 1., 0.91);
  c1->Draw();
  c1->Divide(3,2);
  
  c1->cd(1);
  CheckHist(dESD, 0.05, 0.05);
  dESD->GetXaxis()->SetRangeUser(-0.5, 0.5);
  dESD->GetXaxis()->SetTitle("#DeltaE/<E>");
  dESD->GetYaxis()->SetTitle("entries");
  dESD->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dESD.png");

  c1->cd(2);
  CheckHist(dS1000, 0.05, 0.05);
  dS1000->GetXaxis()->SetRangeUser(-0.5,0.5);
  dS1000->GetXaxis()->SetTitle("#DeltaS_{1000}/<S_{1000}>");
  dS1000->GetYaxis()->SetTitle("entries");
  dS1000->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dS1000.png");

  c1->cd(3);
  CheckProfile(dESDvsE, 0.05);
  dESDvsE->GetXaxis()->SetRangeUser(17.5, 20.5);
  dESDvsE->GetYaxis()->SetTitle("#DeltaE/<E>");
  dESDvsE->GetXaxis()->SetTitle("lg(<E>/eV)");
  dESDvsE->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dESDvsE.png");
  
  c1->cd(4);
  if (dStations->GetMaximum()>0) gPad->SetLogy(1);
  CheckHist(dStations, 1, 1);
  dStations->GetXaxis()->SetTitle("#Delta(# stations)");
  dStations->GetYaxis()->SetTitle("entries");
  dStations->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dStations.png");

  c1->cd(5);
  CheckProfile(dS1000vsCos2Theta, 0.05);
  dS1000vsCos2Theta->GetYaxis()->SetTitle("#DeltaS_{1000}/<S_{1000}>");
  dS1000vsCos2Theta->GetXaxis()->SetTitle("cos^2<#theta>");
  dS1000vsCos2Theta->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dS1000vsTheta.png");
  
  c1->cd(6);
  CheckHist(dTheta_SD, 1, 1);
  dTheta_SD->GetYaxis()->SetTitle("#");
  dTheta_SD->GetXaxis()->SetTitle("#Delta #theta");
  dTheta_SD->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "sd_dTheta.png");
  
  c0->Print(postscriptName, "Landscape");
}


void drawFD(const char* postscriptName, bool savePNGs) {
  
  TCanvas *c0 = new TCanvas("cfd", "FD", 800, 672);
  TLatex *title = new TLatex(.05, .961, "Hybrid reconstruction");
  title->SetTextSize(0.055);
  title->SetTextFont(42);
  title->Draw();
  c0->cd();
  TPad* c1 = new TPad("padfd", "padfd", 0., 0., 1., 0.91);
  c1->Draw();
  c1->Divide(3,2);
  
  c1->cd(1);
  CheckHist(dEFD, 0.05, 0.05);
  dEFD->GetXaxis()->SetRangeUser(-0.5, 0.5);
  dEFD->GetXaxis()->SetTitle("#DeltaE/<E>");
  dEFD->GetYaxis()->SetTitle("entries");
  dEFD->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dEFD.png");
  
  c1->cd(2);
  CheckHist(dXmax, 3, 5);
  dXmax->GetXaxis()->SetRangeUser(-50., 50.);
  dXmax->GetXaxis()->SetTitle("#DeltaX_{max} [g/cm^{2}]");
  dXmax->GetYaxis()->SetTitle("entries");
  dXmax->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dXmax.png");

  c1->cd(3);
  CheckProfile(dEFDvsE, 0.05);
  dEFDvsE->GetXaxis()->SetRangeUser(17.5, 20.5);
  dEFDvsE->GetYaxis()->SetTitle("#DeltaE/<E>");
  dEFDvsE->GetXaxis()->SetTitle("lg(<E>/eV)");
  dEFDvsE->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dEFDvsE.png");

  c1->cd(4);
  CheckProfile(dXmaxvsE, 1);
  dXmaxvsE->GetXaxis()->SetRangeUser(17.5, 20.5);
  dXmaxvsE->GetYaxis()->SetTitle("#DeltaX_{max} [g/cm^{2}]");
  dXmaxvsE->GetXaxis()->SetTitle("lg(<E>/eV)");
  dXmaxvsE->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dXmaxvsE.png");

  c1->cd(5);
  CheckProfile(dEFDvsCosTheta, 0.05);
  dEFDvsCosTheta->GetXaxis()->SetRangeUser(0.25, 1.);
  dEFDvsCosTheta->GetYaxis()->SetTitle("#DeltaE/<E>");
  dEFDvsCosTheta->GetXaxis()->SetTitle("cos(#theta)");
  dEFDvsCosTheta->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dEFDvsCosTheta.png");

  c1->cd(6);
  CheckProfile(dXmaxvsCosTheta, 2);
  dXmaxvsCosTheta->GetXaxis()->SetRangeUser(0.25, 1.);
  dXmaxvsCosTheta->GetYaxis()->SetTitle("#DeltaX_{max} [g/cm^{2}]");
  dXmaxvsCosTheta->GetXaxis()->SetTitle("cos(#theta)");
  dXmaxvsCosTheta->Draw();
  gPad->RedrawAxis();
  if (savePNGs) SavePNG(gPad, "fd_dXmaxvsCosTheta.png");

  c0->Print(postscriptName, "Landscape");

}



void setStyle() {
  
  // pad margins
  gStyle->SetPadLeftMargin(0.18);
  gStyle->SetPadBottomMargin(0.175);
  gStyle->SetPadRightMargin(0.05);
  gStyle->SetPadTopMargin(0.025);
  
  // stat-box
  gStyle->SetStatColor(0);
  gStyle->SetStatBorderSize(1);
  gStyle->SetOptFit(0);  
  gStyle->SetOptTitle(0);
  gStyle->SetOptStat(1110);
  gStyle->SetStatX(1.-0.05);
  gStyle->SetStatY(1.-0.025);
  gStyle->SetStatW(0.28);
  gStyle->SetStatH(0.2);
  
  // axis
  gStyle->SetTitleSize(0.06,"X");
  gStyle->SetTitleSize(0.06,"Y");
  gStyle->SetLabelSize(0.045,"X");
  gStyle->SetLabelSize(0.045,"Y");
  gStyle->SetTitleOffset(1., "X");
  gStyle->SetTitleOffset(1.3, "Y");
  gStyle->SetLabelOffset(0.005,"X");
  gStyle->SetLabelOffset(0.005,"Y");
  
  // canvas/pad
  gStyle->SetFrameBorderMode(0);
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetPadBorderMode(0);
  gStyle->SetPadColor(0);
  gStyle->SetCanvasColor(0);
  
  // histograms/graphs
  gStyle->SetPalette(1,0);
  gStyle->SetErrorX(0.);
  gStyle->SetHistLineColor(fgLineColorNormal);
  gStyle->SetHistLineWidth(fgLineWidthWarning);
  gStyle->SetMarkerColor(fgLineColorNormal);
  gStyle->SetMarkerStyle(20);
  gStyle->SetMarkerSize(0.6);
  
  // postscript output
  gStyle->SetPaperSize(TStyle::kA4);  
  
  gROOT->ForceStyle();
}

bool CheckHist(TH1* h, const double maxMean, const double maxRMS) {
  if (!h) return false;
  const double mean = abs(h->GetMean());
  const double rms = h->GetRMS();					
  if (mean > maxMean ||
      rms > maxRMS) {
    h->SetLineColor(fgLineColorWarning);
    h->SetLineWidth(fgLineWidthWarning);
    h->SetMarkerColor(fgLineColorWarning);
    cerr << " *** Histogram \"" << h->GetName() << "\" seems to be out of bounds."
	 << " Mean=" << mean << " (max=" << maxMean << ")" 
	 << " RMS = " << rms << " (max=" << maxRMS << ")"
	 << endl;
    return false;
  }
  return true;
} 

bool CheckProfile(TProfile* h, const double maxSlope) {
  if (!h) return false;
  TF1 slope("slope_test", "pol1");
  h->Fit(&slope, "Q0", "");
  const double slopeFit = abs(slope.GetParameter(1));
  const double slopeFitError = abs(slope.GetParError(1));
  if (slopeFit > maxSlope) {
    h->SetLineColor(fgLineColorWarning);
    h->SetLineWidth(fgLineWidthWarning);
    h->SetMarkerColor(fgLineColorWarning);
    cerr << " *** Profile \"" << h->GetName() << "\" seems to be out of bounds."
	 << " slope = " << slopeFit << " +- " << slopeFitError
	 << " > " << maxSlope
	 << endl;
    return false;
  }
  return true;
} 

void SavePNG(TPad* pad, const char* filename) {
  //pad->SaveAs(filename);
  pad->SaveAs("/tmp/tmp.eps");
  ostringstream cmd;
  cmd << "convert -density 110 /tmp/tmp.eps " << filename;
  gSystem->Exec(cmd.str().c_str());
}
