#!/usr/bin/python
import sys
import adst
import ROOT
from math import log10 as lg

ROOT.gROOT.SetBatch(1)  # batch mode, no ROOT graphics

# access the list of files provided at command line
fileList = sys.argv[1:]

# read only shower-level observables like energy, direction, ...
degreeOfDetail = adst.MICRO  # use adst.FULL to read everything

# make histograms of encountered energies
hSD = ROOT.TH1D("hSD", "SD energies", 40, 17, 21)
hFDDict = {}  # use a dictionary because we don't know before what eyes we may encounter

print "Reading ADST data"
iRecEvent = 0
for recEvent in adst.RecEventProvider(fileList, degreeOfDetail):
    # This is a simple reading example, we don't do event selection.
    # If a particular event was not properly fitted, the energies
    # we fetch here are garbage. Event selection can be done inside
    # this loop, but it is recommended to use the selectADSTEvents
    # program shipped with Offline. That is *much* faster than doing
    # selections in Python.
    sdEnergy = recEvent.GetSDEvent().GetSdRecShower().GetEnergy()
    if sdEnergy > 0:  # skip garbage
        hSD.Fill(lg(sdEnergy))

    for fdEvent in recEvent.GetFDEvents():
        eyeId = fdEvent.GetEyeId()
        if eyeId not in hFDDict:
            # variables in Python behave like pointers
            h = ROOT.TH1D("hFD{}".format(eyeId),
                          "FD-{} energies".format(eyeId),
                          40, 17, 21)
            hFDDict[eyeId] = h
        fdEnergy = fdEvent.GetFdRecShower().GetEnergy()
        if fdEnergy > 0:  # skip garbage
            hFDDict[eyeId].Fill(lg(fdEnergy))

    iRecEvent += 1
    if iRecEvent % 1000 == 0:
        print iRecEvent, "events processed"

print iRecEvent, "events processed"

# save histograms in a ROOT file
print "Writing histogramOutput.root"
oFile = ROOT.TFile("histogramOutput.root", "RECREATE")
hSD.Write()
for hFD in hFDDict.values():
    hFD.Write()
oFile.Close()
