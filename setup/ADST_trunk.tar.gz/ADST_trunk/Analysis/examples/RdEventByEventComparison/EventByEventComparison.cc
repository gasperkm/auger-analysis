#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <TCanvas.h>
#include <TH2F.h>
#include <TMath.h>
#include <TFile.h>
#include <TGraph.h>
#include <TROOT.h>
#include <TStyle.h>
#include <TColor.h>
#include <TTimeStamp.h>
#include <TLatex.h>
#define AUGER_RADIO_ENABLED
#include "RecEventFile.h"
#include "RecEvent.h"
#include "RdEvent.h"
#include "DetectorGeometry.h"
#include "SDEvent.h"
#include "DetectorGeometry.h"
#include "SdRecStation.h"
#include "ShowerRRecDataQuantities.h"
#include "StationRRecDataQuantities.h"
#include <TEllipse.h>

//Added
#include <TVector3.h>
#include <TProfile.h>
#include <RdTrace.h>
#include <EventInfo.h>
#include <RecEventFile.h>
#include <TGraphErrors.h>
#include <TLegend.h>

#include "ArrayPlot.h"
#include "StyleManager.h"
#include "EventBrowserSignals.h"

using namespace std;

int dutch_stations[46]= {102, 104, 105, 108, 109, 112, 134, 135, 136, 143, 144, 149, 158, 159, 160, 169, 170, 183, 184, 185, 188, 192, 193, 194, 200, 201, 202, 203, 210, 211, 212, 213, 222, 223, 224, 225, 226, 235, 236, 237, 244, 245, 246, 251, 252, 257};

string getUTCDate(RecEvent* fEvent) {
    int yymmdd = (*fEvent).GetYYMMDD();
    int hhmmss = (*fEvent).GetHHMMSS();
    int year = yymmdd / 10000;
    int month = (yymmdd % 10000) / 100;
    int day = (yymmdd % 100);
    int hour = (int) (hhmmss / 10000.);
    int minute = (hhmmss % 10000) / 100;
    int second = (hhmmss % 100);

    ostringstream info;
    info << "UTC Date: 20" << setw(2) << setfill('0') << year;
    info << "/" << setw(2) << setfill('0') << month;
    info << "/" << setw(2) << setfill('0') << day;
    info << "   " << setw(2) << setfill('0') << hour;
    info << ":" << setw(2) << setfill('0') << minute;
    info << ":" << setw(2) << setfill('0') << second;

    return info.str();
}

string GetRecStage(const double recStage) {
    // convert recstage to an int to use a switch statement
    const int nRecStage = int(recStage * 100);
    switch(nRecStage) {
    case 0:
        return "unsuccessful/none";
    case 50:
        return "BaryCenter";
    case 100:
        return "PrePlaneFit";
    case 105:
        return "PlaneFitLinear";
    case 110:
        return "PlaneFitLinear2";
    case 120:
        return "PlaneFit3d";
    case 150:
        return "SphericalWaveFit";
    case 160:
        return "SphericalWaveFitVarC";
    case 170:
        return "ConicalWaveFit";
    case 180:
        return "LDFFit1d";
    case 190:
        return "HyperbolicWaveFit";
    case 200:
        return "LDFFit2d";
    case 220:
        return "LDFFit2dWithCore";
    default:
        stringstream sstr;
        sstr << "unknown = " << recStage;
        return sstr.str();
    }
}

void getEventInfo(RdEvent rdevent, TPad& pad, string label) {
    float x1 = 0.1;
    float y = 0.92;
    float dy = 0.06;

    TLatex *slegend = new TLatex();
    slegend->SetNDC();

    // Print label
    ostringstream info;
    info << label << endl;
    slegend->SetTextSize(0.1);
    slegend->DrawLatex(x1, y, info.str().c_str());
    slegend->SetTextSize(0.055);
    y -= 2*dy;
    info.str("");

    // Rec stage
    double recStage = 0;
    if(rdevent.GetRdRecShower().HasParameter(revt::eRecStage)) {
        recStage = rdevent.GetRdRecShower().GetParameter(revt::eRecStage);
        info << "RecStage = " << GetRecStage(recStage);
    } else
        info << "RecStage undefined";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");

    // Shower Direction
    try {
        float theta = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenith();
        float thetaError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetZenithError();
        float phi = rdevent.GetRdRecShower().GetAzimuth();
        float phiError = TMath::RadToDeg() * rdevent.GetRdRecShower().GetAzimuthError();
        if(phi < 0)
            phi += 2 * TMath::Pi();
        phi *= TMath::RadToDeg();
        info << "#theta = " << 1. * TMath::Nint(theta * 100) / 100;
        if(recStage >= 1.1 and not isnan(thetaError)) //
            info << "#pm" << 1. * TMath::Nint(thetaError * 100) / 100;
        info << " deg  #phi = " << 1. * TMath::Nint(phi * 100) / 100;
        if(recStage >= 1.1 and not isnan(phiError))  //
            info << "#pm" << 1. * TMath::Nint(phiError * 100) / 100;
        info << " deg";
    } catch(...) {
        info << " #theta and #phi not defined ";
    }
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");

    // Radiation Energy
    if(rdevent.GetRdRecShower().HasParameter(revt::eRadiationEnergy)) {
        info << "rad. energy: ";
        info << setprecision(3) << rdevent.GetRdRecShower().GetParameter(revt::eRadiationEnergy);
        info << " +/- " << rdevent.GetRdRecShower().GetParameterError(revt::eRadiationEnergy);
        info << " eV";
        slegend->DrawLatex(x1, y, info.str().c_str());
        y -= dy;
        info.str("");
    }

    // Energy
    if(recStage >= 2.0) {
        if(rdevent.GetRdRecShower().HasParameter(revt::eEnergy)) {
            info << "Energy = " << setprecision(4) << rdevent.GetRdRecShower().GetParameter(revt::eEnergy) << " eV";
            slegend->DrawLatex(x1, y, info.str().c_str());
            y -= dy;
            info.str("");
        }
    }

    // Core
    if(rdevent.GetRdRecShower().HasParameter(revt::eRadiationEnergy)) {
        info << "core x, y = ";
        info << rdevent.GetRdRecShower().Get2dLDFFitResult().Parameter(1);
//    info << " +/- " << rdevent.GetRdRecShower().Get2dLDFFitResult().Error(1);
        info << " m, ";

        info << rdevent.GetRdRecShower().Get2dLDFFitResult().Parameter(2);
//    info << " +/- " << rdevent.GetRdRecShower().Get2dLDFFitResult().Error(2);
        info << " m";
        slegend->DrawLatex(x1, y, info.str().c_str());
        y -= dy;
        info.str("");
    }

    // Stations
    info << "Stations: ";
    if(rdevent.GetRdRecShower().HasParameter(revt::eNumberOfStationsWithPulseFound))
        info << rdevent.GetRdRecShower().GetParameter(revt::eNumberOfStationsWithPulseFound);
    else
        info << "not set";
    slegend->DrawLatex(x1, y, info.str().c_str());
    y -= dy;
    info.str("");
}

void plotLDF(RecEvent fEvent, DetectorGeometry fDetectorGeometry,
             TGraphErrors* gr_LDF, TGraphErrors* gr_LDFNoise, bool MC) {
    TVector3 axis, core;
    if(MC) {
        axis = fEvent.GetGenShower().GetAxisSiteCS();
        core = fEvent.GetGenShower().GetCoreSiteCS();
    } else {
        axis = fEvent.GetSDEvent().GetSdRecShower().GetAxisSiteCS();
        core = fEvent.GetSDEvent().GetSdRecShower().GetCoreSiteCS();
    }
    const RdRecShower& rshower = fEvent.GetRdEvent().GetRdRecShower();
    const vector<RdRecStation>& v_stat = fEvent.GetRdEvent().GetRdStationVector();

    int count = 0;
    int noisecount = 0;

    int polarisation = 0;

    for(vector<RdRecStation>::const_iterator stiter = v_stat.begin(); stiter != v_stat.end(); ++stiter) {

        if (stiter->IsRejected()) {
            continue; // Do not draw stations which are rejected
        }
        for(int i=0; i<46; i++)
            if(((stiter->GetId())-100)==dutch_stations[i]) continue; //skip dutch
        float amplitude = 0;
        float amplitudeError = 0;
        try {
            if(polarisation == 0) {
                amplitude = stiter->GetParameter(revt::eSignal)*1e6;
                amplitudeError = stiter->GetParameterError(revt::eSignal)*1e6;
            } else if(polarisation == 1) {
                amplitude = stiter->GetParameter(revt::ePeakAmplitudeEW)*1e6;
            } else if(polarisation == 2) {
                amplitude = stiter->GetParameter(revt::ePeakAmplitudeNS)*1e6;
            } else if(polarisation == 3) {
                amplitude = stiter->GetParameter(revt::ePeakAmplitudeV)*1e6;
            } else if(polarisation == 4) {
                amplitude = stiter->GetParameter(revt::ePeakAmplitudeMag)*1e6;
            }
        } catch(...) {
            //      cerr << " RdPlots::DrawLDF :: Caught std::invalid_argument when asking for pulse maximum\n";
        }
        double axisdist = fDetectorGeometry.GetStationAxisDistance(fDetectorGeometry.GetRdStationPosition(stiter->GetId()), axis, core);
        if (stiter->HasPulse()) {
            gr_LDF->SetPoint(count, axisdist, amplitude);
            gr_LDF->SetPointError(count, 0, amplitudeError);
            count++;
        }
        else {
            gr_LDFNoise->SetPoint(noisecount, axisdist, amplitude);
            gr_LDFNoise->SetPointError(noisecount, 0, amplitudeError);
            noisecount++;
        }
    } // for stiter
}

bool check_cuts(RecEvent* event){
    const SDEvent& sdev = event->GetSDEvent();
    const SdRecShower& sshow = sdev.GetSdRecShower();
    double stheta = sshow.GetZenith() * TMath::RadToDeg();

    const int minRecLevel=3; //has reconstructed energy
    const int minCandidateStations=4;
    const int T4Trigger=2; //has T4 and SD triggered independently of FD
    const int T5Trigger=3; //has T5 Posterior, which is the T5 HAS in this case
    const float minZenithSD=62;
    const float maxZenithSD=80;

    if(sdev.GetRecLevel() < minRecLevel || 
       sdev.GetNumberOfCandidates() < minCandidateStations ||
       sdev.GetT4Trigger() < T4Trigger || sdev.GetT5Trigger() < T5Trigger ||
       stheta>maxZenithSD || stheta<minZenithSD) {
        return false;
    } else {
        return true;
    }
}

int main() {
    /* config aera labels, useAxis, plot dir*/
    string plotdir("plots");

    int colorsSignal[] = {2, 4};
    int colorsNoise[] = {46, 38};
    bool useMCaxis[] = {false, true};
    string labels[] = {"Data", "Sim"};

    RecEventFile* dataFile[2];
    RecEvent* recEvent[2];

    for(int i=0; i<2; i++){
        // read in ADST Files from file
        string file = "ADSTList" + to_string(i) + ".txt";
        ifstream fileList(file.c_str());
        vector<string> v_filename;
        char filename[10000];
        while (fileList >> filename) {
            v_filename.push_back(filename);
        }

        dataFile[i] = new RecEventFile(v_filename);
        recEvent[i] = new RecEvent();
        dataFile[i]->SetBuffers(recEvent+i);
    }

    StyleManager* fStyleManager = new StyleManager();

    cout << " building search map... " << flush;
    dataFile[1]->SearchForRDEvent(0,0);
    cout << " done " << endl;

    unsigned int nEv0 = dataFile[0]->GetNEvents();
    EventInfo eventInfo;

    RdEvent rdEvent[2];
    DetectorGeometry* geo[2];

    for (unsigned int n=0; n<nEv0; ++n){
        dataFile[0]->GetEventInfo(n, &eventInfo);

        int runID = eventInfo.GetRdRunNumber();
        int eventID = eventInfo.GetRdEventId();

        if (dataFile[1]->SearchForRDEvent(runID, eventID) == RecEventFile::eSuccess ){
            dataFile[0]->ReadEvent(n);

            //check cuts for data event
            if (!check_cuts(recEvent[0])) continue;

            //compare the Events
            TCanvas canvas("canvas", "canvas",1800,1000);
            TPad* pad1 = new TPad("pad1", "pad1",0.0,0.5,0.2,1.0);
            TPad* pad2 = new TPad("pad2", "pad2",0.0,0.0,0.2,0.5);
            TPad* pad3 = new TPad("pad3", "pad3",0.2,0.0,0.8,1.0);
            TPad* pad4 = new TPad("pad4", "pad4",0.8,0.5,1.0,1.0);
            TPad* pad5 = new TPad("pad5", "pad5",0.8,0.0,1.0,0.5);

            pad1->Draw();
            pad2->Draw();
            pad3->Draw();
            pad4->Draw();
            pad5->Draw();

            rdEvent[0] = recEvent[0]->GetRdEvent();
            rdEvent[1] = recEvent[1]->GetRdEvent();

            // Get Event Infos
            pad1->cd();
            getEventInfo(rdEvent[0], *pad1, labels[0]);

            pad4->cd();
            getEventInfo(rdEvent[1], *pad4, labels[1]);

            // LDF Plot
            pad3->cd();

            TGraphErrors* AmpSignal[2];
            TGraphErrors* AmpNoise[2];

            for (int i=0; i<2; i++){
                const vector<RdRecStation>& v_stat = rdEvent[i].GetRdStationVector();

                geo[i] = new DetectorGeometry();
                dataFile[i]->ReadDetectorGeometry(*(geo[i]));

                AmpSignal[i] = new TGraphErrors(v_stat.size());
                AmpNoise[i] = new TGraphErrors(v_stat.size());

                plotLDF(*recEvent[i], *geo[i], AmpSignal[i], AmpNoise[i], useMCaxis[i]);
            }
            double distmax = max(
                max(TMath::MaxElement(AmpSignal[0]->GetN(),AmpSignal[0]->GetX()),
                    TMath::MaxElement(AmpNoise[0]->GetN(),AmpNoise[0]->GetX())),
                max(TMath::MaxElement(AmpSignal[1]->GetN(),AmpSignal[1]->GetX()),
                    TMath::MaxElement(AmpNoise[1]->GetN(),AmpNoise[1]->GetX()))
            );
            double ampmax = max(
                max(TMath::MaxElement(AmpSignal[0]->GetN(),AmpSignal[0]->GetY()),
                    TMath::MaxElement(AmpNoise[0]->GetN(),AmpNoise[0]->GetY())),
                max(TMath::MaxElement(AmpSignal[1]->GetN(),AmpSignal[1]->GetY()),
                    TMath::MaxElement(AmpNoise[1]->GetN(),AmpNoise[1]->GetY()))
            );

            char title[50];
            sprintf(title, "RdId: %i_%i, %s", runID, eventID,
                        getUTCDate(recEvent[0]).c_str());

            TH2F *H_ldfaxis = new TH2F("LDF", title, 300, 0.01, 1.2*distmax, 
                                        300, 0.01, 1.2*ampmax);
            H_ldfaxis->Draw("");
            H_ldfaxis->SetStats(kFALSE);
            H_ldfaxis->GetXaxis()->SetTitle("Distance to SD (MC) axis [m]");
            H_ldfaxis->GetYaxis()->SetTitle("Amplitude [#muV/m]");

            TLegend* legend = new TLegend(0.7,0.8,0.9,0.9);

            for (int i=0; i<2; i++){
                AmpNoise[i]->SetMarkerStyle(24);
                AmpNoise[i]->SetMarkerColor(colorsNoise[i]);
                AmpNoise[i]->SetLineColor(colorsNoise[i]);
                AmpNoise[i]->Draw("P SAME");

                AmpSignal[i]->SetMarkerStyle(24);
                AmpSignal[i]->SetMarkerColor(colorsSignal[i]);
                AmpSignal[i]->SetMarkerSize(2);
                AmpSignal[i]->SetLineColor(colorsSignal[i]);
                AmpSignal[i]->SetLineWidth(2);
                AmpSignal[i]->Draw("P SAME");

                legend->AddEntry(AmpSignal[i], labels[i].c_str(), "P");
            }
            legend->Draw();

            // Do Array Plots
            const StyleManager* const* sm = &fStyleManager;

            int xmax = -24, xmin = -29;
            int ymax = 18, ymin = 15;

            TPad* pads[] = {pad2, pad5};
            for (int i=0; i<2; i++){
                const RecEvent* const* event = &recEvent[i];
                const DetectorGeometry* const* geometry = &geo[i];

                TCanvas tmpArrayPlot("tmp", "tmp", 1800, 1000);
                ArrayPlot* fArrayPlot = new ArrayPlot(event, geometry, sm,
                              xmin, xmax, ymin, ymax, &tmpArrayPlot);
                fArrayPlot->SetRadioOn();
                fArrayPlot->GetMaxAndMinTime();
                fArrayPlot->SetSDColorStatus(eSDGroundTimeColors);
                fArrayPlot->Draw(false, false, true);

                pads[i]->cd();
                tmpArrayPlot.DrawClonePad();
            }

            char filename[50];
            sprintf(filename, "%s/%i_%i.pdf", plotdir.c_str(), runID, eventID);
            canvas.SaveAs(filename);

            delete H_ldfaxis;
        }
    }
}
