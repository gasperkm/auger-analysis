#include <RecEvent.h>

#include <cppunit/extensions/HelperMacros.h>

#include <fwk/CentralConfig.h>

#include <iostream>
#include <string>

//using tst::Expected;
using namespace fwk;
using namespace utl;
//using namespace tst;


class testADST : public CppUnit::TestFixture {

  CPPUNIT_TEST_SUITE(testADST);
  CPPUNIT_TEST(testConstruct);
  CPPUNIT_TEST_SUITE_END();

public:
  // shared data for tests

  void setUp()
  {
  }

  void tearDown()
  {
  }

  void testConstruct()
  {
    RecEvent event;
  }
};


CPPUNIT_TEST_SUITE_REGISTRATION(testADST);

